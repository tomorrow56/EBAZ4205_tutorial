# Usage with Vitis IDE:
# In Vitis IDE create a Single Application Debug launch configuration,
# change the debug type to 'Attach to running target' and provide this 
# tcl script in 'Execute Script' option.
# Path of this script: /home/tomorrow56/ws/EBAZ4205_ps_test/vitis_zynq7000_spi/lcd_lvgl_system/_ide/scripts/debugger_lcd_lvgl-default.tcl
# 
# 
# Usage with xsct:
# To debug using xsct, launch xsct and run below command
# source /home/tomorrow56/ws/EBAZ4205_ps_test/vitis_zynq7000_spi/lcd_lvgl_system/_ide/scripts/debugger_lcd_lvgl-default.tcl
# 
connect -url tcp:127.0.0.1:3121
targets -set -nocase -filter {name =~"APU*"}
rst -system
after 3000
targets -set -filter {jtag_cable_name =~ "Platform Cable USB 00000000000000" && level==0 && jtag_device_ctx=="jsn-DLC9LP-00000000000000-13722093-0"}
fpga -file /home/tomorrow56/ws/EBAZ4205_ps_test/vitis_zynq7000_spi/lcd_lvgl/_ide/bitstream/zynq7000_spi_wrapper.bit
targets -set -nocase -filter {name =~"APU*"}
loadhw -hw /home/tomorrow56/ws/EBAZ4205_ps_test/vitis_zynq7000_spi/ebaz4205_ps_spi/export/ebaz4205_ps_spi/hw/zynq7000_spi_wrapper.xsa -mem-ranges [list {0x40000000 0xbfffffff}] -regs
configparams force-mem-access 1
targets -set -nocase -filter {name =~"APU*"}
source /home/tomorrow56/ws/EBAZ4205_ps_test/vitis_zynq7000_spi/lcd_lvgl/_ide/psinit/ps7_init.tcl
ps7_init
ps7_post_config
targets -set -nocase -filter {name =~ "*A9*#0"}
dow /home/tomorrow56/ws/EBAZ4205_ps_test/vitis_zynq7000_spi/lcd_lvgl/Debug/lcd_lvgl.elf
configparams force-mem-access 0
targets -set -nocase -filter {name =~ "*A9*#0"}
con
