transcript off
onbreak {quit -force}
onerror {quit -force}
transcript on

asim +access +r +m+PL_HDMI  -L xil_defaultlib -L xpm -L unisims_ver -L unimacro_ver -L secureip -O5 xil_defaultlib.PL_HDMI xil_defaultlib.glbl

do {PL_HDMI.udo}

run 1000ns

endsim

quit -force
