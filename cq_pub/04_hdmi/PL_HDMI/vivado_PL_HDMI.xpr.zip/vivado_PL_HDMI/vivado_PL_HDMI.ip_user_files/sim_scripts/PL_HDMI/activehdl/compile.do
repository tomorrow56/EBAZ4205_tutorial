transcript off
onbreak {quit -force}
onerror {quit -force}
transcript on

vlib work
vlib activehdl/xpm
vlib activehdl/xil_defaultlib

vmap xpm activehdl/xpm
vmap xil_defaultlib activehdl/xil_defaultlib

vlog -work xpm  -sv2k12 "+incdir+../../../../vivado_PL_HDMI.srcs/sources_1/bd/PL_HDMI/ipshared/3cbc" -l xpm -l xil_defaultlib \
"V:/Xilinx/Vivado/2024.2/data/ip/xpm/xpm_cdc/hdl/xpm_cdc.sv" \

vcom -work xpm -93  \
"V:/Xilinx/Vivado/2024.2/data/ip/xpm/xpm_VCOMP.vhd" \

vlog -work xil_defaultlib  -v2k5 "+incdir+../../../../vivado_PL_HDMI.srcs/sources_1/bd/PL_HDMI/ipshared/3cbc" -l xpm -l xil_defaultlib \
"../../../bd/PL_HDMI/ip/PL_HDMI_clk_wiz_0_0/PL_HDMI_clk_wiz_0_0_clk_wiz.v" \
"../../../bd/PL_HDMI/ip/PL_HDMI_clk_wiz_0_0/PL_HDMI_clk_wiz_0_0.v" \
"../../../bd/PL_HDMI/ip/PL_HDMI_color_bar_0_0/sim/PL_HDMI_color_bar_0_0.v" \
"../../../bd/PL_HDMI/ip/PL_HDMI_rgb2dvi_0_0/sim/PL_HDMI_rgb2dvi_0_0.v" \
"../../../bd/PL_HDMI/sim/PL_HDMI.v" \

vlog -work xil_defaultlib \
"glbl.v"

