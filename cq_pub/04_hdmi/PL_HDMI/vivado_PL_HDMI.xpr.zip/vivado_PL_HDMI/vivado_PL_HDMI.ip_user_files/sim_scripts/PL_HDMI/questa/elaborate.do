vopt -l elaborate.log +acc=npr -suppress 10016  -L xil_defaultlib -L xpm -L unisims_ver -L unimacro_ver -L secureip -work xil_defaultlib xil_defaultlib.PL_HDMI xil_defaultlib.glbl -o PL_HDMI_opt
