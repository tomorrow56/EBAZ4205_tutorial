vlib questa_lib/work
vlib questa_lib/msim

vlib questa_lib/msim/xpm
vlib questa_lib/msim/xil_defaultlib

vmap xpm questa_lib/msim/xpm
vmap xil_defaultlib questa_lib/msim/xil_defaultlib

vlog -work xpm  -incr -mfcu  -sv "+incdir+../../../../vivado_PL_HDMI.srcs/sources_1/bd/PL_HDMI/ipshared/3cbc" \
"V:/Xilinx/Vivado/2024.2/data/ip/xpm/xpm_cdc/hdl/xpm_cdc.sv" \

vcom -work xpm  -93  \
"V:/Xilinx/Vivado/2024.2/data/ip/xpm/xpm_VCOMP.vhd" \

vlog -work xil_defaultlib  -incr -mfcu  "+incdir+../../../../vivado_PL_HDMI.srcs/sources_1/bd/PL_HDMI/ipshared/3cbc" \
"../../../bd/PL_HDMI/ip/PL_HDMI_clk_wiz_0_0/PL_HDMI_clk_wiz_0_0_clk_wiz.v" \
"../../../bd/PL_HDMI/ip/PL_HDMI_clk_wiz_0_0/PL_HDMI_clk_wiz_0_0.v" \
"../../../bd/PL_HDMI/ip/PL_HDMI_color_bar_0_0/sim/PL_HDMI_color_bar_0_0.v" \
"../../../bd/PL_HDMI/ip/PL_HDMI_rgb2dvi_0_0/sim/PL_HDMI_rgb2dvi_0_0.v" \
"../../../bd/PL_HDMI/sim/PL_HDMI.v" \

vlog -work xil_defaultlib \
"glbl.v"

