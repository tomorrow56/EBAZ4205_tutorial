//Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
//Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2024.2 (win64) Build 5239630 Fri Nov 08 22:35:27 MST 2024
//Date        : Sat Jun  6 09:57:20 2026
//Host        : MASAO running 64-bit major release  (build 9200)
//Command     : generate_target PL_HDMI.bd
//Design      : PL_HDMI
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CORE_GENERATION_INFO = "PL_HDMI,IP_Integrator,{x_ipVendor=xilinx.com,x_ipLibrary=BlockDiagram,x_ipName=PL_HDMI,x_ipVersion=1.00.a,x_ipLanguage=VERILOG,numBlks=6,numReposBlks=6,numNonXlnxBlks=0,numHierBlks=0,maxHierDepth=0,numSysgenBlks=0,numHlsBlks=0,numHdlrefBlks=2,numPkgbdBlks=0,bdsource=USER,da_board_cnt=3,synth_mode=Hierarchical}" *) (* HW_HANDOFF = "PL_HDMI.hwdef" *) 
module PL_HDMI
   (TMDS_CLK_n,
    TMDS_CLK_p,
    TMDS_DATA_n,
    TMDS_DATA_p,
    clk);
  (* x_interface_info = "xilinx.com:signal:clock:1.0 CLK.TMDS_CLK_N CLK" *) (* x_interface_parameter = "XIL_INTERFACENAME CLK.TMDS_CLK_N, CLK_DOMAIN PL_HDMI_rgb2dvi_0_0_TMDS_Clk_n, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, INSERT_VIP 0, PHASE 0.0" *) output TMDS_CLK_n;
  (* x_interface_info = "xilinx.com:signal:clock:1.0 CLK.TMDS_CLK_P CLK" *) (* x_interface_parameter = "XIL_INTERFACENAME CLK.TMDS_CLK_P, CLK_DOMAIN PL_HDMI_rgb2dvi_0_0_TMDS_Clk_p, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, INSERT_VIP 0, PHASE 0.0" *) output TMDS_CLK_p;
  output [2:0]TMDS_DATA_n;
  output [2:0]TMDS_DATA_p;
  (* x_interface_info = "xilinx.com:signal:clock:1.0 CLK.CLK CLK" *) (* x_interface_parameter = "XIL_INTERFACENAME CLK.CLK, CLK_DOMAIN PL_HDMI_clk_100MHz, FREQ_HZ 33330000, FREQ_TOLERANCE_HZ 0, INSERT_VIP 0, PHASE 0.0" *) input clk;

  wire TMDS_CLK_n;
  wire TMDS_CLK_p;
  wire [2:0]TMDS_DATA_n;
  wire [2:0]TMDS_DATA_p;
  wire clk;
  wire clk_wiz_0_clk_out1;
  wire clk_wiz_0_clk_out2;
  wire color_bar_0_de;
  wire color_bar_0_hs;
  wire [7:0]color_bar_0_rgb_b;
  wire [7:0]color_bar_0_rgb_g;
  wire [7:0]color_bar_0_rgb_r;
  wire color_bar_0_vs;
  wire [23:0]ilconcat_0_dout;
  wire [0:0]ilconstant_0_dout;
  wire [0:0]ilvector_logic_0_Res;

  PL_HDMI_clk_wiz_0_0 clk_wiz_0
       (.clk_in1(clk),
        .clk_out1(clk_wiz_0_clk_out1),
        .clk_out2(clk_wiz_0_clk_out2));
  PL_HDMI_color_bar_0_0 color_bar_0
       (.clk(clk_wiz_0_clk_out1),
        .de(color_bar_0_de),
        .hs(color_bar_0_hs),
        .rgb_b(color_bar_0_rgb_b),
        .rgb_g(color_bar_0_rgb_g),
        .rgb_r(color_bar_0_rgb_r),
        .rst(ilconstant_0_dout),
        .vs(color_bar_0_vs));
  assign ilconcat_0_dout = {color_bar_0_rgb_g, color_bar_0_rgb_b, color_bar_0_rgb_r};
  assign ilconstant_0_dout = 1'h0;
  assign ilvector_logic_0_Res = ~ ilconstant_0_dout;
  PL_HDMI_rgb2dvi_0_0 rgb2dvi_0
       (.PixelClk(clk_wiz_0_clk_out1),
        .SerialClk(clk_wiz_0_clk_out2),
        .TMDS_Clk_n(TMDS_CLK_n),
        .TMDS_Clk_p(TMDS_CLK_p),
        .TMDS_Data_n(TMDS_DATA_n),
        .TMDS_Data_p(TMDS_DATA_p),
        .aRst(ilconstant_0_dout),
        .aRst_n(ilvector_logic_0_Res),
        .vid_pData(ilconcat_0_dout),
        .vid_pHSync(color_bar_0_hs),
        .vid_pVDE(color_bar_0_de),
        .vid_pVSync(color_bar_0_vs));
endmodule
