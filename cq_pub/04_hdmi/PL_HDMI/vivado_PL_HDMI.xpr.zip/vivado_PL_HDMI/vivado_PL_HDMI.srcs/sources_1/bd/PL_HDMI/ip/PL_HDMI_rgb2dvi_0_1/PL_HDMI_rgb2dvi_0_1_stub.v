// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2024.2 (win64) Build 5239630 Fri Nov 08 22:35:27 MST 2024
// Date        : Sat Jun  6 12:55:54 2026
// Host        : MASAO running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub
//               v:/IPI/vivado_PL_HDMI/vivado_PL_HDMI.srcs/sources_1/bd/PL_HDMI/ip/PL_HDMI_rgb2dvi_0_1/PL_HDMI_rgb2dvi_0_1_stub.v
// Design      : PL_HDMI_rgb2dvi_0_1
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7z010clg400-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* CHECK_LICENSE_TYPE = "PL_HDMI_rgb2dvi_0_1,rgb2dvi,{}" *) (* CORE_GENERATION_INFO = "PL_HDMI_rgb2dvi_0_1,rgb2dvi,{x_ipProduct=Vivado 2024.2,x_ipVendor=xilinx.com,x_ipLibrary=module_ref,x_ipName=rgb2dvi,x_ipVersion=1.0,x_ipCoreRevision=1,x_ipLanguage=VERILOG,x_ipSimLanguage=MIXED,kGenerateSerialClk=false,kClkPrimitive=PLL,kClkRange=1,kRstActiveHigh=true,kD0Swap=false,kD1Swap=false,kD2Swap=false,kClkSwap=false}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) 
(* IP_DEFINITION_SOURCE = "module_ref" *) (* X_CORE_INFO = "rgb2dvi,Vivado 2024.2" *) 
module PL_HDMI_rgb2dvi_0_1(TMDS_Clk_p, TMDS_Clk_n, TMDS_Data_p, 
  TMDS_Data_n, aRst, aRst_n, vid_pData, vid_pVDE, vid_pHSync, vid_pVSync, PixelClk, SerialClk)
/* synthesis syn_black_box black_box_pad_pin="TMDS_Clk_p,TMDS_Clk_n,TMDS_Data_p[2:0],TMDS_Data_n[2:0],aRst,aRst_n,vid_pData[23:0],vid_pVDE,vid_pHSync,vid_pVSync" */
/* synthesis syn_force_seq_prim="PixelClk" */
/* synthesis syn_force_seq_prim="SerialClk" */;
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 TMDS_Clk_p CLK" *) (* X_INTERFACE_MODE = "master" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME TMDS_Clk_p, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN PL_HDMI_rgb2dvi_0_1_TMDS_Clk_p, INSERT_VIP 0" *) output TMDS_Clk_p;
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 TMDS_Clk_n CLK" *) (* X_INTERFACE_MODE = "master" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME TMDS_Clk_n, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN PL_HDMI_rgb2dvi_0_1_TMDS_Clk_n, INSERT_VIP 0" *) output TMDS_Clk_n;
  output [2:0]TMDS_Data_p;
  output [2:0]TMDS_Data_n;
  input aRst;
  input aRst_n;
  input [23:0]vid_pData;
  input vid_pVDE;
  input vid_pHSync;
  input vid_pVSync;
  input PixelClk /* synthesis syn_isclock = 1 */;
  input SerialClk /* synthesis syn_isclock = 1 */;
endmodule
