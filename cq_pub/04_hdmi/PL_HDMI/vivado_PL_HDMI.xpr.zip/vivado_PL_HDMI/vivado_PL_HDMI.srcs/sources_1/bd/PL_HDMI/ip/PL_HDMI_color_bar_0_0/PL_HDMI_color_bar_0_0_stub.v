// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2024.2 (win64) Build 5239630 Fri Nov 08 22:35:27 MST 2024
// Date        : Sat Jun  6 09:06:08 2026
// Host        : MASAO running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub
//               v:/IPI/vivado_PL_HDMI/vivado_PL_HDMI.srcs/sources_1/bd/PL_HDMI/ip/PL_HDMI_color_bar_0_0/PL_HDMI_color_bar_0_0_stub.v
// Design      : PL_HDMI_color_bar_0_0
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7z010clg400-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* CHECK_LICENSE_TYPE = "PL_HDMI_color_bar_0_0,color_bar,{}" *) (* CORE_GENERATION_INFO = "PL_HDMI_color_bar_0_0,color_bar,{x_ipProduct=Vivado 2024.2,x_ipVendor=xilinx.com,x_ipLibrary=module_ref,x_ipName=color_bar,x_ipVersion=1.0,x_ipCoreRevision=1,x_ipLanguage=VERILOG,x_ipSimLanguage=MIXED,H_ACTIVE=0x0320,H_FP=0x0028,H_SYNC=0x0080,H_BP=0x0058,V_ACTIVE=0x0258,V_FP=0x0001,V_SYNC=0x0004,V_BP=0x0017,HS_POL=1,VS_POL=1,H_TOTAL=1056,V_TOTAL=628,WHITE_R=11111111,WHITE_G=11111111,WHITE_B=11111111,YELLOW_R=11111111,YELLOW_G=11111111,YELLOW_B=00000000,CYAN_R=00000000,CYAN_G=11111111,CYAN_B=11111111,GREEN_R=00000000,GREEN_G=11111111,GREEN_B=00000000,MAGENTA_R=11111111,MAGENTA_G=00000000,MAGENTA_B=11111111,RED_R=11111111,RED_G=00000000,RED_B=00000000,BLUE_R=00000000,BLUE_G=00000000,BLUE_B=11111111,BLACK_R=00000000,BLACK_G=00000000,BLACK_B=00000000}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) 
(* IP_DEFINITION_SOURCE = "module_ref" *) (* X_CORE_INFO = "color_bar,Vivado 2024.2" *) 
module PL_HDMI_color_bar_0_0(clk, rst, hs, vs, de, rgb_r, rgb_g, rgb_b)
/* synthesis syn_black_box black_box_pad_pin="rst,hs,vs,de,rgb_r[7:0],rgb_g[7:0],rgb_b[7:0]" */
/* synthesis syn_force_seq_prim="clk" */;
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 clk CLK" *) (* X_INTERFACE_MODE = "slave" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME clk, ASSOCIATED_RESET rst, FREQ_HZ 39996000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_0_clk_out1, INSERT_VIP 0" *) input clk /* synthesis syn_isclock = 1 */;
  (* X_INTERFACE_INFO = "xilinx.com:signal:reset:1.0 rst RST" *) (* X_INTERFACE_MODE = "slave" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME rst, POLARITY ACTIVE_LOW, INSERT_VIP 0" *) input rst;
  output hs;
  output vs;
  output de;
  output [7:0]rgb_r;
  output [7:0]rgb_g;
  output [7:0]rgb_b;
endmodule
