// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2026 Advanced Micro Devices, Inc. All Rights Reserved.
// -------------------------------------------------------------------------------

`timescale 1 ps / 1 ps

(* BLOCK_STUB = "true" *)
module PL_HDMI (
  clk,
  TMDS_CLK_p,
  TMDS_CLK_n,
  TMDS_DATA_p,
  TMDS_DATA_n
);

  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 CLK.CLK CLK" *)
  (* X_INTERFACE_MODE = "slave CLK.CLK" *)
  (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME CLK.CLK, FREQ_HZ 33330000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN PL_HDMI_clk_100MHz, INSERT_VIP 0" *)
  input clk;
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 CLK.TMDS_CLK_P CLK" *)
  (* X_INTERFACE_MODE = "master CLK.TMDS_CLK_P" *)
  (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME CLK.TMDS_CLK_P, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN PL_HDMI_rgb2dvi_0_1_TMDS_Clk_p, INSERT_VIP 0" *)
  output TMDS_CLK_p;
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 CLK.TMDS_CLK_N CLK" *)
  (* X_INTERFACE_MODE = "master CLK.TMDS_CLK_N" *)
  (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME CLK.TMDS_CLK_N, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN PL_HDMI_rgb2dvi_0_1_TMDS_Clk_n, INSERT_VIP 0" *)
  output TMDS_CLK_n;
  (* X_INTERFACE_IGNORE = "true" *)
  output [2:0]TMDS_DATA_p;
  (* X_INTERFACE_IGNORE = "true" *)
  output [2:0]TMDS_DATA_n;

  // stub module has no contents

endmodule
