// (c) Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// (c) Copyright 2022-2026 Advanced Micro Devices, Inc. All rights reserved.
// 
// This file contains confidential and proprietary information
// of AMD and is protected under U.S. and international copyright
// and other intellectual property laws.
// 
// DISCLAIMER
// This disclaimer is not a license and does not grant any
// rights to the materials distributed herewith. Except as
// otherwise provided in a valid license issued to you by
// AMD, and to the maximum extent permitted by applicable
// law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
// WITH ALL FAULTS, AND AMD HEREBY DISCLAIMS ALL WARRANTIES
// AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
// BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
// INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
// (2) AMD shall not be liable (whether in contract or tort,
// including negligence, or under any other theory of
// liability) for any loss or damage of any kind or nature
// related to, arising under or in connection with these
// materials, including for any direct, or any indirect,
// special, incidental, or consequential loss or damage
// (including loss of data, profits, goodwill, or any type of
// loss or damage suffered as a result of any action brought
// by a third party) even if such damage or loss was
// reasonably foreseeable or AMD had been advised of the
// possibility of the same.
// 
// CRITICAL APPLICATIONS
// AMD products are not designed or intended to be fail-
// safe, or for use in any application requiring fail-safe
// performance, such as life-support or safety devices or
// systems, Class III medical devices, nuclear facilities,
// applications related to the deployment of airbags, or any
// other applications that could lead to death, personal
// injury, or severe property or environmental damage
// (individually and collectively, "Critical
// Applications"). Customer assumes the sole risk and
// liability of any use of AMD products in Critical
// Applications, subject only to applicable laws and
// regulations governing limitations on product liability.
// 
// THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
// PART OF THIS FILE AT ALL TIMES.
// 
// DO NOT MODIFY THIS FILE.


// IP VLNV: xilinx.com:module_ref:color_bar:1.0
// IP Revision: 1

(* X_CORE_INFO = "color_bar,Vivado 2024.2" *)
(* CHECK_LICENSE_TYPE = "PL_HDMI_color_bar_0_0,color_bar,{}" *)
(* CORE_GENERATION_INFO = "PL_HDMI_color_bar_0_0,color_bar,{x_ipProduct=Vivado 2024.2,x_ipVendor=xilinx.com,x_ipLibrary=module_ref,x_ipName=color_bar,x_ipVersion=1.0,x_ipCoreRevision=1,x_ipLanguage=VERILOG,x_ipSimLanguage=MIXED,H_ACTIVE=0x0320,H_FP=0x0028,H_SYNC=0x0080,H_BP=0x0058,V_ACTIVE=0x0258,V_FP=0x0001,V_SYNC=0x0004,V_BP=0x0017,HS_POL=1,VS_POL=1,H_TOTAL=1056,V_TOTAL=628,WHITE_R=11111111,WHITE_G=11111111,WHITE_B=11111111,YELLOW_R=11111111,YELLOW_G=11111111,YELLOW_B=00000000,CYAN_R=00000000,CYAN_G=11111111,CYAN_B=1111\
1111,GREEN_R=00000000,GREEN_G=11111111,GREEN_B=00000000,MAGENTA_R=11111111,MAGENTA_G=00000000,MAGENTA_B=11111111,RED_R=11111111,RED_G=00000000,RED_B=00000000,BLUE_R=00000000,BLUE_G=00000000,BLUE_B=11111111,BLACK_R=00000000,BLACK_G=00000000,BLACK_B=00000000}" *)
(* IP_DEFINITION_SOURCE = "module_ref" *)
(* DowngradeIPIdentifiedWarnings = "yes" *)
module PL_HDMI_color_bar_0_0 (
  clk,
  rst,
  hs,
  vs,
  de,
  rgb_r,
  rgb_g,
  rgb_b
);

(* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 clk CLK" *)
(* X_INTERFACE_MODE = "slave" *)
(* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME clk, ASSOCIATED_RESET rst, FREQ_HZ 39996000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_0_clk_out1, INSERT_VIP 0" *)
input wire clk;
(* X_INTERFACE_INFO = "xilinx.com:signal:reset:1.0 rst RST" *)
(* X_INTERFACE_MODE = "slave" *)
(* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME rst, POLARITY ACTIVE_LOW, INSERT_VIP 0" *)
input wire rst;
output wire hs;
output wire vs;
output wire de;
output wire [7 : 0] rgb_r;
output wire [7 : 0] rgb_g;
output wire [7 : 0] rgb_b;

  color_bar #(
    .H_ACTIVE(16'H0320),
    .H_FP(16'H0028),
    .H_SYNC(16'H0080),
    .H_BP(16'H0058),
    .V_ACTIVE(16'H0258),
    .V_FP(16'H0001),
    .V_SYNC(16'H0004),
    .V_BP(16'H0017),
    .HS_POL(1'B1),
    .VS_POL(1'B1),
    .H_TOTAL(1056),
    .V_TOTAL(628),
    .WHITE_R(8'B11111111),
    .WHITE_G(8'B11111111),
    .WHITE_B(8'B11111111),
    .YELLOW_R(8'B11111111),
    .YELLOW_G(8'B11111111),
    .YELLOW_B(8'B00000000),
    .CYAN_R(8'B00000000),
    .CYAN_G(8'B11111111),
    .CYAN_B(8'B11111111),
    .GREEN_R(8'B00000000),
    .GREEN_G(8'B11111111),
    .GREEN_B(8'B00000000),
    .MAGENTA_R(8'B11111111),
    .MAGENTA_G(8'B00000000),
    .MAGENTA_B(8'B11111111),
    .RED_R(8'B11111111),
    .RED_G(8'B00000000),
    .RED_B(8'B00000000),
    .BLUE_R(8'B00000000),
    .BLUE_G(8'B00000000),
    .BLUE_B(8'B11111111),
    .BLACK_R(8'B00000000),
    .BLACK_G(8'B00000000),
    .BLACK_B(8'B00000000)
  ) inst (
    .clk(clk),
    .rst(rst),
    .hs(hs),
    .vs(vs),
    .de(de),
    .rgb_r(rgb_r),
    .rgb_g(rgb_g),
    .rgb_b(rgb_b)
  );
endmodule
