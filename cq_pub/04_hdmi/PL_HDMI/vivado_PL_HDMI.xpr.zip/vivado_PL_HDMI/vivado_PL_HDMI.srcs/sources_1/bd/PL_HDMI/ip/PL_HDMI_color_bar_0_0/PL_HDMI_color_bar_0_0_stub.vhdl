-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2024.2 (win64) Build 5239630 Fri Nov 08 22:35:27 MST 2024
-- Date        : Sat Jun  6 09:06:08 2026
-- Host        : MASAO running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode synth_stub
--               v:/IPI/vivado_PL_HDMI/vivado_PL_HDMI.srcs/sources_1/bd/PL_HDMI/ip/PL_HDMI_color_bar_0_0/PL_HDMI_color_bar_0_0_stub.vhdl
-- Design      : PL_HDMI_color_bar_0_0
-- Purpose     : Stub declaration of top-level module interface
-- Device      : xc7z010clg400-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity PL_HDMI_color_bar_0_0 is
  Port ( 
    clk : in STD_LOGIC;
    rst : in STD_LOGIC;
    hs : out STD_LOGIC;
    vs : out STD_LOGIC;
    de : out STD_LOGIC;
    rgb_r : out STD_LOGIC_VECTOR ( 7 downto 0 );
    rgb_g : out STD_LOGIC_VECTOR ( 7 downto 0 );
    rgb_b : out STD_LOGIC_VECTOR ( 7 downto 0 )
  );

  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of PL_HDMI_color_bar_0_0 : entity is "PL_HDMI_color_bar_0_0,color_bar,{}";
  attribute CORE_GENERATION_INFO : string;
  attribute CORE_GENERATION_INFO of PL_HDMI_color_bar_0_0 : entity is "PL_HDMI_color_bar_0_0,color_bar,{x_ipProduct=Vivado 2024.2,x_ipVendor=xilinx.com,x_ipLibrary=module_ref,x_ipName=color_bar,x_ipVersion=1.0,x_ipCoreRevision=1,x_ipLanguage=VERILOG,x_ipSimLanguage=MIXED,H_ACTIVE=0x0320,H_FP=0x0028,H_SYNC=0x0080,H_BP=0x0058,V_ACTIVE=0x0258,V_FP=0x0001,V_SYNC=0x0004,V_BP=0x0017,HS_POL=1,VS_POL=1,H_TOTAL=1056,V_TOTAL=628,WHITE_R=11111111,WHITE_G=11111111,WHITE_B=11111111,YELLOW_R=11111111,YELLOW_G=11111111,YELLOW_B=00000000,CYAN_R=00000000,CYAN_G=11111111,CYAN_B=11111111,GREEN_R=00000000,GREEN_G=11111111,GREEN_B=00000000,MAGENTA_R=11111111,MAGENTA_G=00000000,MAGENTA_B=11111111,RED_R=11111111,RED_G=00000000,RED_B=00000000,BLUE_R=00000000,BLUE_G=00000000,BLUE_B=11111111,BLACK_R=00000000,BLACK_G=00000000,BLACK_B=00000000}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of PL_HDMI_color_bar_0_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of PL_HDMI_color_bar_0_0 : entity is "module_ref";
end PL_HDMI_color_bar_0_0;

architecture stub of PL_HDMI_color_bar_0_0 is
  attribute syn_black_box : boolean;
  attribute black_box_pad_pin : string;
  attribute syn_black_box of stub : architecture is true;
  attribute black_box_pad_pin of stub : architecture is "clk,rst,hs,vs,de,rgb_r[7:0],rgb_g[7:0],rgb_b[7:0]";
  attribute X_INTERFACE_INFO : string;
  attribute X_INTERFACE_INFO of clk : signal is "xilinx.com:signal:clock:1.0 clk CLK";
  attribute X_INTERFACE_MODE : string;
  attribute X_INTERFACE_MODE of clk : signal is "slave";
  attribute X_INTERFACE_PARAMETER : string;
  attribute X_INTERFACE_PARAMETER of clk : signal is "XIL_INTERFACENAME clk, ASSOCIATED_RESET rst, FREQ_HZ 39996000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_0_clk_out1, INSERT_VIP 0";
  attribute X_INTERFACE_INFO of rst : signal is "xilinx.com:signal:reset:1.0 rst RST";
  attribute X_INTERFACE_MODE of rst : signal is "slave";
  attribute X_INTERFACE_PARAMETER of rst : signal is "XIL_INTERFACENAME rst, POLARITY ACTIVE_LOW, INSERT_VIP 0";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of stub : architecture is "color_bar,Vivado 2024.2";
begin
end;
