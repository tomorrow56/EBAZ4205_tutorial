// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2024.2.2 (lin64) Build 6060944 Thu Mar 06 19:10:09 MST 2025
// Date        : Sun May 10 11:17:48 2026
// Host        : firebat running 64-bit Ubuntu 24.04.4 LTS
// Command     : write_verilog -force -mode funcsim
//               /home/tomorrow56/ws/vivado/hdmi_axi_test/vivado_hdmi_axi_720p_mod/vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ip/system_pattern_multi_0_0/system_pattern_multi_0_0_sim_netlist.v
// Design      : system_pattern_multi_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7z010clg400-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "system_pattern_multi_0_0,pattern_multi,{}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* IP_DEFINITION_SOURCE = "module_ref" *) 
(* X_CORE_INFO = "pattern_multi,Vivado 2024.2.2" *) 
(* NotValidForBitStream *)
module system_pattern_multi_0_0
   (CLK,
    RST,
    timing_sel,
    timing_sel_imm,
    pattern_sel,
    reconfig_req,
    VGA_R,
    VGA_G,
    VGA_B,
    VGA_HS,
    VGA_VS,
    VGA_DE,
    PCK,
    SerialClk,
    locked,
    reconfig_done);
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 CLK CLK" *) (* X_INTERFACE_MODE = "slave" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME CLK, ASSOCIATED_RESET RST, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN system_processing_system7_0_0_FCLK_CLK0, INSERT_VIP 0" *) input CLK;
  (* X_INTERFACE_INFO = "xilinx.com:signal:reset:1.0 RST RST" *) (* X_INTERFACE_MODE = "slave" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME RST, POLARITY ACTIVE_HIGH, INSERT_VIP 0" *) input RST;
  input [1:0]timing_sel;
  input [1:0]timing_sel_imm;
  input [3:0]pattern_sel;
  input reconfig_req;
  output [7:0]VGA_R;
  output [7:0]VGA_G;
  output [7:0]VGA_B;
  output VGA_HS;
  output VGA_VS;
  output VGA_DE;
  output PCK;
  output SerialClk;
  output locked;
  output reconfig_done;

  wire CLK;
  wire PCK;
  wire RST;
  wire SerialClk;
  wire [7:0]VGA_B;
  wire VGA_DE;
  wire [7:0]VGA_G;
  wire VGA_HS;
  wire [7:0]VGA_R;
  wire VGA_VS;
  wire locked;
  wire [3:0]pattern_sel;
  wire reconfig_done;
  wire reconfig_req;
  wire [1:0]timing_sel;
  wire [1:0]timing_sel_imm;

  system_pattern_multi_0_0_pattern_multi inst
       (.CLK(CLK),
        .PCK(PCK),
        .RST(RST),
        .SerialClk(SerialClk),
        .VGA_B(VGA_B),
        .VGA_DE(VGA_DE),
        .VGA_G(VGA_G),
        .VGA_HS(VGA_HS),
        .VGA_R(VGA_R),
        .VGA_VS(VGA_VS),
        .locked(locked),
        .pattern_sel(pattern_sel),
        .reconfig_done(reconfig_done),
        .reconfig_req(reconfig_req),
        .timing_sel(timing_sel),
        .timing_sel_imm(timing_sel_imm));
endmodule

(* ORIG_REF_NAME = "mmcm_drp" *) 
module system_pattern_multi_0_0_mmcm_drp
   (DI,
    \FSM_sequential_state_reg[1] ,
    DWE,
    DEN,
    DADDR,
    mmcm_rst,
    drp_drdy,
    DO,
    timing_sel_imm,
    state,
    reconfig_req,
    CLK,
    \ram_reg[26][0]_0 ,
    \ram_addr_reg[0]_0 ,
    locked);
  output [15:0]DI;
  output \FSM_sequential_state_reg[1] ;
  output DWE;
  output DEN;
  output [6:0]DADDR;
  output mmcm_rst;
  input drp_drdy;
  input [14:0]DO;
  input [1:0]timing_sel_imm;
  input [2:0]state;
  input reconfig_req;
  input CLK;
  input \ram_reg[26][0]_0 ;
  input \ram_addr_reg[0]_0 ;
  input locked;

  wire CLK;
  wire [6:0]DADDR;
  wire \DADDR[6]_i_1_n_0 ;
  wire \DADDR[6]_i_2_n_0 ;
  wire DEN;
  wire [15:0]DI;
  wire \DI[0]_i_1_n_0 ;
  wire \DI[10]_i_1_n_0 ;
  wire \DI[11]_i_1_n_0 ;
  wire \DI[12]_i_1_n_0 ;
  wire \DI[13]_i_1_n_0 ;
  wire \DI[14]_i_1_n_0 ;
  wire \DI[15]_i_1_n_0 ;
  wire \DI[15]_i_2_n_0 ;
  wire \DI[15]_i_3_n_0 ;
  wire \DI[1]_i_1_n_0 ;
  wire \DI[2]_i_1_n_0 ;
  wire \DI[3]_i_1_n_0 ;
  wire \DI[4]_i_1_n_0 ;
  wire \DI[5]_i_1_n_0 ;
  wire \DI[6]_i_1_n_0 ;
  wire \DI[7]_i_1_n_0 ;
  wire \DI[8]_i_1_n_0 ;
  wire \DI[9]_i_1_n_0 ;
  wire [14:0]DO;
  wire DWE;
  wire \FSM_sequential_state_reg[1] ;
  wire RST_MMCM_PLL_i_1_n_0;
  (* DONT_TOUCH *) wire [3:0]current_state;
  wire \current_state[0]_i_2_n_0 ;
  wire \current_state[1]_i_2_n_0 ;
  wire \current_state[1]_i_3_n_0 ;
  wire \current_state[1]_i_4_n_0 ;
  wire \current_state[2]_i_2_n_0 ;
  wire drp_drdy;
  wire locked;
  wire mmcm_rst;
  wire next_den;
  wire next_dwe;
  wire next_srdy;
  wire [3:0]next_state;
  wire [9:0]p_17_in;
  wire [14:0]p_18_in;
  wire [14:0]p_19_in;
  wire [10:10]p_1_out;
  wire [15:8]p_20_in;
  wire [15:4]p_21_in;
  wire [38:0]ram;
  wire \ram[23][37]_i_1_n_0 ;
  wire \ram[25][10]_i_1_n_0 ;
  wire \ram[25][8]_i_1_n_0 ;
  wire \ram[26][5]_i_2_n_0 ;
  wire \ram[26][5]_i_3_n_0 ;
  wire \ram[26][5]_i_4_n_0 ;
  wire \ram[26][5]_i_5_n_0 ;
  wire \ram[26][5]_i_6_n_0 ;
  wire \ram[37][10]_i_1_n_0 ;
  wire \ram[38][0]_i_2_n_0 ;
  wire \ram[38][0]_i_3_n_0 ;
  wire \ram[38][0]_i_4_n_0 ;
  wire \ram[38][0]_i_5_n_0 ;
  wire \ram[38][6]_i_1_n_0 ;
  wire \ram[39][0]_i_1_n_0 ;
  wire \ram[39][10]_i_1_n_0 ;
  wire \ram[39][6]_i_1_n_0 ;
  wire \ram[39][7]_i_1_n_0 ;
  wire \ram[39][8]_i_1_n_0 ;
  wire \ram[39][9]_i_1_n_0 ;
  wire \ram[40][11]_i_1_n_0 ;
  wire \ram[40][12]_i_10_n_0 ;
  wire \ram[40][12]_i_11_n_0 ;
  wire \ram[40][12]_i_12_n_0 ;
  wire \ram[40][12]_i_13_n_0 ;
  wire \ram[40][12]_i_14_n_0 ;
  wire \ram[40][12]_i_15_n_0 ;
  wire \ram[40][12]_i_16_n_0 ;
  wire \ram[40][12]_i_17_n_0 ;
  wire \ram[40][12]_i_18_n_0 ;
  wire \ram[40][12]_i_1_n_0 ;
  wire \ram[40][12]_i_20_n_0 ;
  wire \ram[40][12]_i_21_n_0 ;
  wire \ram[40][12]_i_22_n_0 ;
  wire \ram[40][12]_i_23_n_0 ;
  wire \ram[40][12]_i_24_n_0 ;
  wire \ram[40][12]_i_25_n_0 ;
  wire \ram[40][12]_i_26_n_0 ;
  wire \ram[40][12]_i_27_n_0 ;
  wire \ram[40][12]_i_28_n_0 ;
  wire \ram[40][12]_i_5_n_0 ;
  wire \ram[40][12]_i_6_n_0 ;
  wire \ram[40][12]_i_7_n_0 ;
  wire \ram[40][12]_i_8_n_0 ;
  wire \ram[40][13]_i_1_n_0 ;
  wire \ram[41][4]_i_2_n_0 ;
  wire \ram[41][5]_i_2_n_0 ;
  wire \ram[41][6]_i_2_n_0 ;
  wire \ram[41][7]_i_2_n_0 ;
  wire \ram[41][8]_i_2_n_0 ;
  wire \ram[41][9]_i_2_n_0 ;
  wire \ram[42][0]_i_2_n_0 ;
  wire \ram[42][10]_i_2_n_0 ;
  wire \ram[42][11]_i_2_n_0 ;
  wire \ram[42][12]_i_2_n_0 ;
  wire \ram[42][12]_i_3_n_0 ;
  wire \ram[42][13]_i_2_n_0 ;
  wire \ram[42][14]_i_2_n_0 ;
  wire \ram[42][1]_i_2_n_0 ;
  wire \ram[42][2]_i_2_n_0 ;
  wire \ram[42][3]_i_2_n_0 ;
  wire \ram[42][3]_i_3_n_0 ;
  wire \ram[42][4]_i_2_n_0 ;
  wire \ram[42][4]_i_3_n_0 ;
  wire \ram[42][5]_i_2_n_0 ;
  wire \ram[42][5]_i_3_n_0 ;
  wire \ram[42][6]_i_2_n_0 ;
  wire \ram[42][6]_i_3_n_0 ;
  wire \ram[42][7]_i_2_n_0 ;
  wire \ram[42][7]_i_3_n_0 ;
  wire \ram[42][8]_i_3_n_0 ;
  wire \ram[42][8]_i_4_n_0 ;
  wire \ram[42][8]_i_5_n_0 ;
  wire \ram[42][8]_i_6_n_0 ;
  wire \ram[42][9]_i_3_n_0 ;
  wire \ram[42][9]_i_4_n_0 ;
  wire \ram[42][9]_i_5_n_0 ;
  wire \ram[42][9]_i_6_n_0 ;
  wire \ram[43][0]_i_3_n_0 ;
  wire \ram[43][0]_i_4_n_0 ;
  wire \ram[43][0]_i_5_n_0 ;
  wire \ram[43][10]_i_2_n_0 ;
  wire \ram[43][10]_i_3_n_0 ;
  wire \ram[43][10]_i_4_n_0 ;
  wire \ram[43][10]_i_5_n_0 ;
  wire \ram[43][10]_i_6_n_0 ;
  wire \ram[43][11]_i_2_n_0 ;
  wire \ram[43][11]_i_3_n_0 ;
  wire \ram[43][11]_i_4_n_0 ;
  wire \ram[43][11]_i_5_n_0 ;
  wire \ram[43][12]_i_2_n_0 ;
  wire \ram[43][12]_i_3_n_0 ;
  wire \ram[43][12]_i_4_n_0 ;
  wire \ram[43][12]_i_5_n_0 ;
  wire \ram[43][13]_i_2_n_0 ;
  wire \ram[43][13]_i_3_n_0 ;
  wire \ram[43][13]_i_4_n_0 ;
  wire \ram[43][13]_i_5_n_0 ;
  wire \ram[43][14]_i_10_n_0 ;
  wire \ram[43][14]_i_11_n_0 ;
  wire \ram[43][14]_i_12_n_0 ;
  wire \ram[43][14]_i_13_n_0 ;
  wire \ram[43][14]_i_14_n_0 ;
  wire \ram[43][14]_i_15_n_0 ;
  wire \ram[43][14]_i_16_n_0 ;
  wire \ram[43][14]_i_2_n_0 ;
  wire \ram[43][14]_i_4_n_0 ;
  wire \ram[43][14]_i_5_n_0 ;
  wire \ram[43][14]_i_6_n_0 ;
  wire \ram[43][14]_i_9_n_0 ;
  wire \ram[43][1]_i_3_n_0 ;
  wire \ram[43][1]_i_4_n_0 ;
  wire \ram[43][1]_i_5_n_0 ;
  wire \ram[43][1]_i_6_n_0 ;
  wire \ram[43][2]_i_3_n_0 ;
  wire \ram[43][2]_i_4_n_0 ;
  wire \ram[43][2]_i_5_n_0 ;
  wire \ram[43][2]_i_6_n_0 ;
  wire \ram[43][3]_i_3_n_0 ;
  wire \ram[43][3]_i_4_n_0 ;
  wire \ram[43][3]_i_5_n_0 ;
  wire \ram[43][3]_i_6_n_0 ;
  wire \ram[43][4]_i_3_n_0 ;
  wire \ram[43][4]_i_4_n_0 ;
  wire \ram[43][4]_i_5_n_0 ;
  wire \ram[43][4]_i_6_n_0 ;
  wire \ram[43][5]_i_3_n_0 ;
  wire \ram[43][5]_i_4_n_0 ;
  wire \ram[43][5]_i_5_n_0 ;
  wire \ram[43][5]_i_6_n_0 ;
  wire \ram[43][6]_i_2_n_0 ;
  wire \ram[43][6]_i_3_n_0 ;
  wire \ram[43][6]_i_4_n_0 ;
  wire \ram[43][6]_i_5_n_0 ;
  wire \ram[43][6]_i_6_n_0 ;
  wire \ram[43][7]_i_2_n_0 ;
  wire \ram[43][7]_i_3_n_0 ;
  wire \ram[43][7]_i_4_n_0 ;
  wire \ram[43][7]_i_5_n_0 ;
  wire \ram[43][8]_i_2_n_0 ;
  wire \ram[43][8]_i_3_n_0 ;
  wire \ram[43][8]_i_4_n_0 ;
  wire \ram[43][8]_i_5_n_0 ;
  wire \ram[43][9]_i_2_n_0 ;
  wire \ram[44][11]_i_2_n_0 ;
  wire \ram[44][12]_i_2_n_0 ;
  wire \ram[44][12]_i_3_n_0 ;
  wire \ram[44][15]_i_2_n_0 ;
  wire \ram[44][15]_i_3_n_0 ;
  wire \ram[44][38]_i_1_n_0 ;
  wire \ram[44][8]_i_2_n_0 ;
  wire \ram[45][11]_i_10_n_0 ;
  wire \ram[45][11]_i_11_n_0 ;
  wire \ram[45][11]_i_12_n_0 ;
  wire \ram[45][11]_i_13_n_0 ;
  wire \ram[45][11]_i_14_n_0 ;
  wire \ram[45][11]_i_15_n_0 ;
  wire \ram[45][11]_i_16_n_0 ;
  wire \ram[45][11]_i_17_n_0 ;
  wire \ram[45][11]_i_18_n_0 ;
  wire \ram[45][11]_i_19_n_0 ;
  wire \ram[45][11]_i_2_n_0 ;
  wire \ram[45][11]_i_4_n_0 ;
  wire \ram[45][11]_i_6_n_0 ;
  wire \ram[45][11]_i_9_n_0 ;
  wire \ram[45][12]_i_2_n_0 ;
  wire \ram[45][12]_i_3_n_0 ;
  wire \ram[45][12]_i_4_n_0 ;
  wire \ram[45][12]_i_5_n_0 ;
  wire \ram[45][15]_i_2_n_0 ;
  wire \ram[45][15]_i_3_n_0 ;
  wire \ram[45][15]_i_4_n_0 ;
  wire \ram[45][15]_i_5_n_0 ;
  wire \ram[45][15]_i_6_n_0 ;
  wire \ram[45][4]_i_2_n_0 ;
  wire \ram[45][4]_i_3_n_0 ;
  wire \ram[45][7]_i_2_n_0 ;
  wire \ram[45][7]_i_3_n_0 ;
  wire \ram[45][8]_i_2_n_0 ;
  wire \ram[45][8]_i_3_n_0 ;
  wire \ram[45][8]_i_5_n_0 ;
  wire \ram[45][8]_i_6_n_0 ;
  wire [5:0]ram_addr;
  wire \ram_addr[0]_i_1_n_0 ;
  wire \ram_addr[1]_i_1_n_0 ;
  wire \ram_addr[2]_i_1_n_0 ;
  wire \ram_addr[3]_i_1_n_0 ;
  wire \ram_addr[4]_i_1_n_0 ;
  wire \ram_addr[4]_i_2_n_0 ;
  wire \ram_addr[4]_i_3_n_0 ;
  wire \ram_addr[5]_i_1_n_0 ;
  wire \ram_addr[5]_i_2_n_0 ;
  wire \ram_addr_reg[0]_0 ;
  wire [38:0]ram_do;
  wire \ram_do[0]_i_2_n_0 ;
  wire \ram_do[0]_i_3_n_0 ;
  wire \ram_do[0]_i_4_n_0 ;
  wire \ram_do[0]_i_5_n_0 ;
  wire \ram_do[0]_i_6_n_0 ;
  wire \ram_do[10]_i_3_n_0 ;
  wire \ram_do[10]_i_4_n_0 ;
  wire \ram_do[10]_i_5_n_0 ;
  wire \ram_do[10]_i_6_n_0 ;
  wire \ram_do[11]_i_2_n_0 ;
  wire \ram_do[11]_i_3_n_0 ;
  wire \ram_do[11]_i_4_n_0 ;
  wire \ram_do[11]_i_5_n_0 ;
  wire \ram_do[12]_i_2_n_0 ;
  wire \ram_do[12]_i_3_n_0 ;
  wire \ram_do[12]_i_4_n_0 ;
  wire \ram_do[12]_i_5_n_0 ;
  wire \ram_do[13]_i_2_n_0 ;
  wire \ram_do[13]_i_3_n_0 ;
  wire \ram_do[13]_i_4_n_0 ;
  wire \ram_do[14]_i_2_n_0 ;
  wire \ram_do[14]_i_3_n_0 ;
  wire \ram_do[15]_i_2_n_0 ;
  wire \ram_do[15]_i_3_n_0 ;
  wire \ram_do[1]_i_2_n_0 ;
  wire \ram_do[1]_i_3_n_0 ;
  wire \ram_do[1]_i_4_n_0 ;
  wire \ram_do[1]_i_5_n_0 ;
  wire \ram_do[23]_i_2_n_0 ;
  wire \ram_do[23]_i_3_n_0 ;
  wire \ram_do[27]_i_2_n_0 ;
  wire \ram_do[27]_i_3_n_0 ;
  wire \ram_do[28]_i_2_n_0 ;
  wire \ram_do[28]_i_3_n_0 ;
  wire \ram_do[29]_i_2_n_0 ;
  wire \ram_do[29]_i_3_n_0 ;
  wire \ram_do[2]_i_2_n_0 ;
  wire \ram_do[2]_i_3_n_0 ;
  wire \ram_do[2]_i_4_n_0 ;
  wire \ram_do[2]_i_5_n_0 ;
  wire \ram_do[30]_i_2_n_0 ;
  wire \ram_do[30]_i_3_n_0 ;
  wire \ram_do[31]_i_2_n_0 ;
  wire \ram_do[31]_i_3_n_0 ;
  wire \ram_do[32]_i_2_n_0 ;
  wire \ram_do[32]_i_3_n_0 ;
  wire \ram_do[33]_i_2_n_0 ;
  wire \ram_do[33]_i_3_n_0 ;
  wire \ram_do[34]_i_2_n_0 ;
  wire \ram_do[34]_i_3_n_0 ;
  wire \ram_do[35]_i_2_n_0 ;
  wire \ram_do[35]_i_3_n_0 ;
  wire \ram_do[35]_i_4_n_0 ;
  wire \ram_do[36]_i_2_n_0 ;
  wire \ram_do[36]_i_3_n_0 ;
  wire \ram_do[37]_i_2_n_0 ;
  wire \ram_do[37]_i_3_n_0 ;
  wire \ram_do[38]_i_2_n_0 ;
  wire \ram_do[38]_i_3_n_0 ;
  wire \ram_do[3]_i_3_n_0 ;
  wire \ram_do[3]_i_4_n_0 ;
  wire \ram_do[3]_i_5_n_0 ;
  wire \ram_do[4]_i_2_n_0 ;
  wire \ram_do[4]_i_3_n_0 ;
  wire \ram_do[4]_i_4_n_0 ;
  wire \ram_do[4]_i_5_n_0 ;
  wire \ram_do[4]_i_6_n_0 ;
  wire \ram_do[4]_i_7_n_0 ;
  wire \ram_do[5]_i_3_n_0 ;
  wire \ram_do[5]_i_4_n_0 ;
  wire \ram_do[5]_i_5_n_0 ;
  wire \ram_do[6]_i_2_n_0 ;
  wire \ram_do[6]_i_3_n_0 ;
  wire \ram_do[6]_i_4_n_0 ;
  wire \ram_do[6]_i_5_n_0 ;
  wire \ram_do[7]_i_2_n_0 ;
  wire \ram_do[7]_i_3_n_0 ;
  wire \ram_do[7]_i_4_n_0 ;
  wire \ram_do[7]_i_5_n_0 ;
  wire \ram_do[7]_i_6_n_0 ;
  wire \ram_do[8]_i_2_n_0 ;
  wire \ram_do[8]_i_3_n_0 ;
  wire \ram_do[8]_i_4_n_0 ;
  wire \ram_do[8]_i_5_n_0 ;
  wire \ram_do[9]_i_2_n_0 ;
  wire \ram_do[9]_i_3_n_0 ;
  wire \ram_do[9]_i_4_n_0 ;
  wire \ram_do[9]_i_5_n_0 ;
  wire \ram_do_reg[10]_i_2_n_0 ;
  wire \ram_do_reg[3]_i_2_n_0 ;
  wire \ram_do_reg[5]_i_2_n_0 ;
  wire [37:37]\ram_reg[23]_11 ;
  wire [10:8]\ram_reg[25]_10 ;
  wire \ram_reg[26][0]_0 ;
  wire \ram_reg[26][5]_i_1_n_1 ;
  wire \ram_reg[26][5]_i_1_n_2 ;
  wire \ram_reg[26][5]_i_1_n_3 ;
  wire \ram_reg[26][5]_i_1_n_4 ;
  wire \ram_reg[26][5]_i_1_n_5 ;
  wire \ram_reg[26][5]_i_1_n_6 ;
  wire \ram_reg[26][5]_i_1_n_7 ;
  wire [5:0]\ram_reg[26]_9 ;
  wire [13:10]\ram_reg[37]_8 ;
  wire \ram_reg[38][0]_i_1_n_0 ;
  wire \ram_reg[38][0]_i_1_n_1 ;
  wire \ram_reg[38][0]_i_1_n_2 ;
  wire \ram_reg[38][0]_i_1_n_3 ;
  wire \ram_reg[38][0]_i_1_n_4 ;
  wire \ram_reg[38][0]_i_1_n_5 ;
  wire \ram_reg[38][0]_i_1_n_6 ;
  wire \ram_reg[38][0]_i_1_n_7 ;
  wire \ram_reg[38][5]_i_1_n_3 ;
  wire \ram_reg[38][5]_i_1_n_6 ;
  wire \ram_reg[38][5]_i_1_n_7 ;
  wire [13:0]\ram_reg[38]_7 ;
  wire [10:0]\ram_reg[39]_6 ;
  wire \ram_reg[40][12]_i_19_n_0 ;
  wire \ram_reg[40][12]_i_19_n_1 ;
  wire \ram_reg[40][12]_i_19_n_2 ;
  wire \ram_reg[40][12]_i_19_n_3 ;
  wire \ram_reg[40][12]_i_2_n_0 ;
  wire \ram_reg[40][12]_i_2_n_2 ;
  wire \ram_reg[40][12]_i_2_n_3 ;
  wire \ram_reg[40][12]_i_2_n_5 ;
  wire \ram_reg[40][12]_i_2_n_6 ;
  wire \ram_reg[40][12]_i_2_n_7 ;
  wire \ram_reg[40][12]_i_3_n_2 ;
  wire \ram_reg[40][12]_i_3_n_3 ;
  wire \ram_reg[40][12]_i_4_n_0 ;
  wire \ram_reg[40][12]_i_4_n_1 ;
  wire \ram_reg[40][12]_i_4_n_2 ;
  wire \ram_reg[40][12]_i_4_n_3 ;
  wire \ram_reg[40][12]_i_4_n_4 ;
  wire \ram_reg[40][12]_i_4_n_5 ;
  wire \ram_reg[40][12]_i_4_n_6 ;
  wire \ram_reg[40][12]_i_4_n_7 ;
  wire \ram_reg[40][12]_i_9_n_0 ;
  wire \ram_reg[40][12]_i_9_n_1 ;
  wire \ram_reg[40][12]_i_9_n_2 ;
  wire \ram_reg[40][12]_i_9_n_3 ;
  wire [14:7]\ram_reg[40]_5 ;
  wire [9:0]\ram_reg[41]_4 ;
  wire \ram_reg[42][8]_i_2_n_0 ;
  wire \ram_reg[42][9]_i_2_n_0 ;
  wire [14:0]\ram_reg[42]_3 ;
  wire \ram_reg[43][0]_i_2_n_0 ;
  wire \ram_reg[43][14]_i_3_n_1 ;
  wire \ram_reg[43][14]_i_3_n_3 ;
  wire \ram_reg[43][14]_i_3_n_6 ;
  wire \ram_reg[43][14]_i_3_n_7 ;
  wire \ram_reg[43][14]_i_7_n_0 ;
  wire \ram_reg[43][14]_i_7_n_1 ;
  wire \ram_reg[43][14]_i_7_n_2 ;
  wire \ram_reg[43][14]_i_7_n_3 ;
  wire \ram_reg[43][14]_i_7_n_4 ;
  wire \ram_reg[43][14]_i_7_n_5 ;
  wire \ram_reg[43][14]_i_7_n_6 ;
  wire \ram_reg[43][14]_i_7_n_7 ;
  wire \ram_reg[43][14]_i_8_n_3 ;
  wire \ram_reg[43][1]_i_2_n_0 ;
  wire \ram_reg[43][2]_i_2_n_0 ;
  wire \ram_reg[43][3]_i_2_n_0 ;
  wire \ram_reg[43][4]_i_2_n_0 ;
  wire \ram_reg[43][5]_i_2_n_0 ;
  wire [14:0]\ram_reg[43]_2 ;
  wire [38:8]\ram_reg[44]_1 ;
  wire \ram_reg[45][11]_i_3_n_1 ;
  wire \ram_reg[45][11]_i_3_n_3 ;
  wire \ram_reg[45][11]_i_3_n_6 ;
  wire \ram_reg[45][11]_i_5_n_0 ;
  wire \ram_reg[45][11]_i_7_n_0 ;
  wire \ram_reg[45][11]_i_7_n_1 ;
  wire \ram_reg[45][11]_i_7_n_2 ;
  wire \ram_reg[45][11]_i_7_n_3 ;
  wire \ram_reg[45][11]_i_7_n_4 ;
  wire \ram_reg[45][11]_i_7_n_5 ;
  wire \ram_reg[45][11]_i_7_n_6 ;
  wire \ram_reg[45][11]_i_8_n_3 ;
  wire \ram_reg[45][8]_i_4_n_0 ;
  wire [15:4]\ram_reg[45]_0 ;
  wire reconfig_req;
  wire [5:5]s2_clkfbout_mult;
  wire srdy;
  wire [2:0]state;
  wire [4:0]state_count;
  wire \state_count[0]_i_1_n_0 ;
  wire \state_count[1]_i_1_n_0 ;
  wire \state_count[2]_i_1_n_0 ;
  wire \state_count[3]_i_1_n_0 ;
  wire \state_count[4]_i_1_n_0 ;
  wire \state_count[4]_i_2_n_0 ;
  wire \state_count[4]_i_3_n_0 ;
  wire [1:0]timing_sel_imm;
  wire [3:3]\NLW_ram_reg[26][5]_i_1_CO_UNCONNECTED ;
  wire [3:1]\NLW_ram_reg[38][5]_i_1_CO_UNCONNECTED ;
  wire [3:2]\NLW_ram_reg[38][5]_i_1_O_UNCONNECTED ;
  wire [3:0]\NLW_ram_reg[40][12]_i_19_O_UNCONNECTED ;
  wire [2:2]\NLW_ram_reg[40][12]_i_2_CO_UNCONNECTED ;
  wire [3:3]\NLW_ram_reg[40][12]_i_2_O_UNCONNECTED ;
  wire [3:2]\NLW_ram_reg[40][12]_i_3_CO_UNCONNECTED ;
  wire [3:0]\NLW_ram_reg[40][12]_i_3_O_UNCONNECTED ;
  wire [3:0]\NLW_ram_reg[40][12]_i_9_O_UNCONNECTED ;
  wire [3:1]\NLW_ram_reg[43][14]_i_3_CO_UNCONNECTED ;
  wire [3:2]\NLW_ram_reg[43][14]_i_3_O_UNCONNECTED ;
  wire [3:1]\NLW_ram_reg[43][14]_i_8_CO_UNCONNECTED ;
  wire [3:0]\NLW_ram_reg[43][14]_i_8_O_UNCONNECTED ;
  wire [3:1]\NLW_ram_reg[45][11]_i_3_CO_UNCONNECTED ;
  wire [3:0]\NLW_ram_reg[45][11]_i_3_O_UNCONNECTED ;
  wire [0:0]\NLW_ram_reg[45][11]_i_7_O_UNCONNECTED ;
  wire [3:1]\NLW_ram_reg[45][11]_i_8_CO_UNCONNECTED ;
  wire [3:0]\NLW_ram_reg[45][11]_i_8_O_UNCONNECTED ;

  LUT4 #(
    .INIT(16'h0010)) 
    \DADDR[6]_i_1 
       (.I0(current_state[1]),
        .I1(current_state[3]),
        .I2(current_state[0]),
        .I3(current_state[2]),
        .O(\DADDR[6]_i_1_n_0 ));
  LUT4 #(
    .INIT(16'h0006)) 
    \DADDR[6]_i_2 
       (.I0(current_state[2]),
        .I1(current_state[0]),
        .I2(current_state[3]),
        .I3(current_state[1]),
        .O(\DADDR[6]_i_2_n_0 ));
  FDRE \DADDR_reg[0] 
       (.C(CLK),
        .CE(\DADDR[6]_i_2_n_0 ),
        .D(ram_do[32]),
        .Q(DADDR[0]),
        .R(\DADDR[6]_i_1_n_0 ));
  FDRE \DADDR_reg[1] 
       (.C(CLK),
        .CE(\DADDR[6]_i_2_n_0 ),
        .D(ram_do[33]),
        .Q(DADDR[1]),
        .R(\DADDR[6]_i_1_n_0 ));
  FDRE \DADDR_reg[2] 
       (.C(CLK),
        .CE(\DADDR[6]_i_2_n_0 ),
        .D(ram_do[34]),
        .Q(DADDR[2]),
        .R(\DADDR[6]_i_1_n_0 ));
  FDRE \DADDR_reg[3] 
       (.C(CLK),
        .CE(\DADDR[6]_i_2_n_0 ),
        .D(ram_do[35]),
        .Q(DADDR[3]),
        .R(\DADDR[6]_i_1_n_0 ));
  FDRE \DADDR_reg[4] 
       (.C(CLK),
        .CE(\DADDR[6]_i_2_n_0 ),
        .D(ram_do[36]),
        .Q(DADDR[4]),
        .R(\DADDR[6]_i_1_n_0 ));
  FDRE \DADDR_reg[5] 
       (.C(CLK),
        .CE(\DADDR[6]_i_2_n_0 ),
        .D(ram_do[37]),
        .Q(DADDR[5]),
        .R(\DADDR[6]_i_1_n_0 ));
  FDRE \DADDR_reg[6] 
       (.C(CLK),
        .CE(\DADDR[6]_i_2_n_0 ),
        .D(ram_do[38]),
        .Q(DADDR[6]),
        .R(\DADDR[6]_i_1_n_0 ));
  LUT4 #(
    .INIT(16'h0006)) 
    DEN_i_1
       (.I0(current_state[3]),
        .I1(current_state[2]),
        .I2(current_state[0]),
        .I3(current_state[1]),
        .O(next_den));
  FDRE DEN_reg
       (.C(CLK),
        .CE(1'b1),
        .D(next_den),
        .Q(DEN),
        .R(1'b0));
  LUT5 #(
    .INIT(32'hF8F8F808)) 
    \DI[0]_i_1 
       (.I0(ram_do[38]),
        .I1(DO[0]),
        .I2(current_state[0]),
        .I3(ram_do[0]),
        .I4(DI[0]),
        .O(\DI[0]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hF8F8F808)) 
    \DI[10]_i_1 
       (.I0(ram_do[29]),
        .I1(DO[9]),
        .I2(current_state[0]),
        .I3(ram_do[10]),
        .I4(DI[10]),
        .O(\DI[10]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hF8F8F808)) 
    \DI[11]_i_1 
       (.I0(ram_do[27]),
        .I1(DO[10]),
        .I2(current_state[0]),
        .I3(ram_do[11]),
        .I4(DI[11]),
        .O(\DI[11]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hF8F8F808)) 
    \DI[12]_i_1 
       (.I0(ram_do[28]),
        .I1(DO[11]),
        .I2(current_state[0]),
        .I3(ram_do[12]),
        .I4(DI[12]),
        .O(\DI[12]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hF8F8F808)) 
    \DI[13]_i_1 
       (.I0(ram_do[29]),
        .I1(DO[12]),
        .I2(current_state[0]),
        .I3(ram_do[13]),
        .I4(DI[13]),
        .O(\DI[13]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hF8F8F808)) 
    \DI[14]_i_1 
       (.I0(ram_do[30]),
        .I1(DO[13]),
        .I2(current_state[0]),
        .I3(ram_do[14]),
        .I4(DI[14]),
        .O(\DI[14]_i_1_n_0 ));
  LUT4 #(
    .INIT(16'h0004)) 
    \DI[15]_i_1 
       (.I0(current_state[3]),
        .I1(current_state[0]),
        .I2(current_state[2]),
        .I3(current_state[1]),
        .O(\DI[15]_i_1_n_0 ));
  LUT4 #(
    .INIT(16'h00A4)) 
    \DI[15]_i_2 
       (.I0(current_state[2]),
        .I1(current_state[0]),
        .I2(current_state[1]),
        .I3(current_state[3]),
        .O(\DI[15]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hF8F8F808)) 
    \DI[15]_i_3 
       (.I0(ram_do[31]),
        .I1(DO[14]),
        .I2(current_state[0]),
        .I3(ram_do[15]),
        .I4(DI[15]),
        .O(\DI[15]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hF8F8F808)) 
    \DI[1]_i_1 
       (.I0(ram_do[38]),
        .I1(DO[1]),
        .I2(current_state[0]),
        .I3(ram_do[1]),
        .I4(DI[1]),
        .O(\DI[1]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hF8F8F808)) 
    \DI[2]_i_1 
       (.I0(ram_do[38]),
        .I1(DO[2]),
        .I2(current_state[0]),
        .I3(ram_do[2]),
        .I4(DI[2]),
        .O(\DI[2]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hF8F8F808)) 
    \DI[3]_i_1 
       (.I0(ram_do[38]),
        .I1(DO[3]),
        .I2(current_state[0]),
        .I3(ram_do[3]),
        .I4(DI[3]),
        .O(\DI[3]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hF8F8F808)) 
    \DI[4]_i_1 
       (.I0(ram_do[23]),
        .I1(DO[4]),
        .I2(current_state[0]),
        .I3(ram_do[4]),
        .I4(DI[4]),
        .O(\DI[4]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hF8F8F808)) 
    \DI[5]_i_1 
       (.I0(ram_do[38]),
        .I1(DO[5]),
        .I2(current_state[0]),
        .I3(ram_do[5]),
        .I4(DI[5]),
        .O(\DI[5]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hF8F8F808)) 
    \DI[6]_i_1 
       (.I0(ram_do[38]),
        .I1(DO[6]),
        .I2(current_state[0]),
        .I3(ram_do[6]),
        .I4(DI[6]),
        .O(\DI[6]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hF8F8F808)) 
    \DI[7]_i_1 
       (.I0(ram_do[23]),
        .I1(DO[7]),
        .I2(current_state[0]),
        .I3(ram_do[7]),
        .I4(DI[7]),
        .O(\DI[7]_i_1_n_0 ));
  LUT3 #(
    .INIT(8'hE0)) 
    \DI[8]_i_1 
       (.I0(DI[8]),
        .I1(ram_do[8]),
        .I2(current_state[0]),
        .O(\DI[8]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hF8F8F808)) 
    \DI[9]_i_1 
       (.I0(ram_do[38]),
        .I1(DO[8]),
        .I2(current_state[0]),
        .I3(ram_do[9]),
        .I4(DI[9]),
        .O(\DI[9]_i_1_n_0 ));
  FDRE \DI_reg[0] 
       (.C(CLK),
        .CE(\DI[15]_i_2_n_0 ),
        .D(\DI[0]_i_1_n_0 ),
        .Q(DI[0]),
        .R(\DI[15]_i_1_n_0 ));
  FDRE \DI_reg[10] 
       (.C(CLK),
        .CE(\DI[15]_i_2_n_0 ),
        .D(\DI[10]_i_1_n_0 ),
        .Q(DI[10]),
        .R(\DI[15]_i_1_n_0 ));
  FDRE \DI_reg[11] 
       (.C(CLK),
        .CE(\DI[15]_i_2_n_0 ),
        .D(\DI[11]_i_1_n_0 ),
        .Q(DI[11]),
        .R(\DI[15]_i_1_n_0 ));
  FDRE \DI_reg[12] 
       (.C(CLK),
        .CE(\DI[15]_i_2_n_0 ),
        .D(\DI[12]_i_1_n_0 ),
        .Q(DI[12]),
        .R(\DI[15]_i_1_n_0 ));
  FDRE \DI_reg[13] 
       (.C(CLK),
        .CE(\DI[15]_i_2_n_0 ),
        .D(\DI[13]_i_1_n_0 ),
        .Q(DI[13]),
        .R(\DI[15]_i_1_n_0 ));
  FDRE \DI_reg[14] 
       (.C(CLK),
        .CE(\DI[15]_i_2_n_0 ),
        .D(\DI[14]_i_1_n_0 ),
        .Q(DI[14]),
        .R(\DI[15]_i_1_n_0 ));
  FDRE \DI_reg[15] 
       (.C(CLK),
        .CE(\DI[15]_i_2_n_0 ),
        .D(\DI[15]_i_3_n_0 ),
        .Q(DI[15]),
        .R(\DI[15]_i_1_n_0 ));
  FDRE \DI_reg[1] 
       (.C(CLK),
        .CE(\DI[15]_i_2_n_0 ),
        .D(\DI[1]_i_1_n_0 ),
        .Q(DI[1]),
        .R(\DI[15]_i_1_n_0 ));
  FDRE \DI_reg[2] 
       (.C(CLK),
        .CE(\DI[15]_i_2_n_0 ),
        .D(\DI[2]_i_1_n_0 ),
        .Q(DI[2]),
        .R(\DI[15]_i_1_n_0 ));
  FDRE \DI_reg[3] 
       (.C(CLK),
        .CE(\DI[15]_i_2_n_0 ),
        .D(\DI[3]_i_1_n_0 ),
        .Q(DI[3]),
        .R(\DI[15]_i_1_n_0 ));
  FDRE \DI_reg[4] 
       (.C(CLK),
        .CE(\DI[15]_i_2_n_0 ),
        .D(\DI[4]_i_1_n_0 ),
        .Q(DI[4]),
        .R(\DI[15]_i_1_n_0 ));
  FDRE \DI_reg[5] 
       (.C(CLK),
        .CE(\DI[15]_i_2_n_0 ),
        .D(\DI[5]_i_1_n_0 ),
        .Q(DI[5]),
        .R(\DI[15]_i_1_n_0 ));
  FDRE \DI_reg[6] 
       (.C(CLK),
        .CE(\DI[15]_i_2_n_0 ),
        .D(\DI[6]_i_1_n_0 ),
        .Q(DI[6]),
        .R(\DI[15]_i_1_n_0 ));
  FDRE \DI_reg[7] 
       (.C(CLK),
        .CE(\DI[15]_i_2_n_0 ),
        .D(\DI[7]_i_1_n_0 ),
        .Q(DI[7]),
        .R(\DI[15]_i_1_n_0 ));
  FDRE \DI_reg[8] 
       (.C(CLK),
        .CE(\DI[15]_i_2_n_0 ),
        .D(\DI[8]_i_1_n_0 ),
        .Q(DI[8]),
        .R(\DI[15]_i_1_n_0 ));
  FDRE \DI_reg[9] 
       (.C(CLK),
        .CE(\DI[15]_i_2_n_0 ),
        .D(\DI[9]_i_1_n_0 ),
        .Q(DI[9]),
        .R(\DI[15]_i_1_n_0 ));
  LUT4 #(
    .INIT(16'h0010)) 
    DWE_i_1
       (.I0(current_state[0]),
        .I1(current_state[2]),
        .I2(current_state[3]),
        .I3(current_state[1]),
        .O(next_dwe));
  FDRE DWE_reg
       (.C(CLK),
        .CE(1'b1),
        .D(next_dwe),
        .Q(DWE),
        .R(1'b0));
  LUT5 #(
    .INIT(32'hCD77CD22)) 
    \FSM_sequential_state[0]_i_1 
       (.I0(state[1]),
        .I1(state[2]),
        .I2(reconfig_req),
        .I3(state[0]),
        .I4(srdy),
        .O(\FSM_sequential_state_reg[1] ));
  LUT5 #(
    .INIT(32'hFFEF0006)) 
    RST_MMCM_PLL_i_1
       (.I0(current_state[0]),
        .I1(current_state[2]),
        .I2(current_state[1]),
        .I3(current_state[3]),
        .I4(mmcm_rst),
        .O(RST_MMCM_PLL_i_1_n_0));
  FDRE RST_MMCM_PLL_reg
       (.C(CLK),
        .CE(1'b1),
        .D(RST_MMCM_PLL_i_1_n_0),
        .Q(mmcm_rst),
        .R(1'b0));
  LUT5 #(
    .INIT(32'h00000020)) 
    SRDY_i_1
       (.I0(current_state[1]),
        .I1(current_state[2]),
        .I2(locked),
        .I3(current_state[3]),
        .I4(current_state[0]),
        .O(next_srdy));
  FDRE SRDY_reg
       (.C(CLK),
        .CE(1'b1),
        .D(next_srdy),
        .Q(srdy),
        .R(1'b0));
  LUT6 #(
    .INIT(64'hFDFFFFFFFDFF0000)) 
    \current_state[0]_i_1 
       (.I0(drp_drdy),
        .I1(current_state[2]),
        .I2(current_state[1]),
        .I3(current_state[0]),
        .I4(current_state[3]),
        .I5(\current_state[0]_i_2_n_0 ),
        .O(next_state[0]));
  LUT6 #(
    .INIT(64'h03034444FFCCFFFF)) 
    \current_state[0]_i_2 
       (.I0(drp_drdy),
        .I1(current_state[2]),
        .I2(\ram_addr_reg[0]_0 ),
        .I3(locked),
        .I4(current_state[1]),
        .I5(current_state[0]),
        .O(\current_state[0]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'h03BBFF00)) 
    \current_state[1]_i_2 
       (.I0(drp_drdy),
        .I1(current_state[2]),
        .I2(\ram_addr_reg[0]_0 ),
        .I3(current_state[1]),
        .I4(current_state[0]),
        .O(\current_state[1]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'h00000020)) 
    \current_state[1]_i_3 
       (.I0(drp_drdy),
        .I1(\current_state[1]_i_4_n_0 ),
        .I2(current_state[0]),
        .I3(current_state[2]),
        .I4(current_state[1]),
        .O(\current_state[1]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    \current_state[1]_i_4 
       (.I0(state_count[1]),
        .I1(state_count[4]),
        .I2(state_count[0]),
        .I3(state_count[2]),
        .I4(state_count[3]),
        .O(\current_state[1]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h0338003830303030)) 
    \current_state[2]_i_1 
       (.I0(\current_state[2]_i_2_n_0 ),
        .I1(current_state[3]),
        .I2(current_state[2]),
        .I3(current_state[1]),
        .I4(\ram_addr_reg[0]_0 ),
        .I5(current_state[0]),
        .O(next_state[2]));
  LUT6 #(
    .INIT(64'hAAAAAAAAAAAAAAA8)) 
    \current_state[2]_i_2 
       (.I0(drp_drdy),
        .I1(state_count[3]),
        .I2(state_count[2]),
        .I3(state_count[0]),
        .I4(state_count[4]),
        .I5(state_count[1]),
        .O(\current_state[2]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'h3000040C)) 
    \current_state[3]_i_1 
       (.I0(drp_drdy),
        .I1(current_state[3]),
        .I2(current_state[2]),
        .I3(current_state[0]),
        .I4(current_state[1]),
        .O(next_state[3]));
  (* DONT_TOUCH *) 
  (* FSM_ENCODED_STATES = "RESTART:0001,WAIT_LOCK:0010,WAIT_SEN:0011,ADDRESS:0100,WAIT_A_DRDY:0101,BITMASK:0110,BITSET:0111,WRITE:1000,WAIT_DRDY:1001" *) 
  (* KEEP = "yes" *) 
  FDRE #(
    .INIT(1'b1)) 
    \current_state_reg[0] 
       (.C(CLK),
        .CE(1'b1),
        .D(next_state[0]),
        .Q(current_state[0]),
        .R(1'b0));
  (* DONT_TOUCH *) 
  (* FSM_ENCODED_STATES = "RESTART:0001,WAIT_LOCK:0010,WAIT_SEN:0011,ADDRESS:0100,WAIT_A_DRDY:0101,BITMASK:0110,BITSET:0111,WRITE:1000,WAIT_DRDY:1001" *) 
  (* KEEP = "yes" *) 
  FDRE #(
    .INIT(1'b0)) 
    \current_state_reg[1] 
       (.C(CLK),
        .CE(1'b1),
        .D(next_state[1]),
        .Q(current_state[1]),
        .R(1'b0));
  MUXF7 \current_state_reg[1]_i_1 
       (.I0(\current_state[1]_i_2_n_0 ),
        .I1(\current_state[1]_i_3_n_0 ),
        .O(next_state[1]),
        .S(current_state[3]));
  (* DONT_TOUCH *) 
  (* FSM_ENCODED_STATES = "RESTART:0001,WAIT_LOCK:0010,WAIT_SEN:0011,ADDRESS:0100,WAIT_A_DRDY:0101,BITMASK:0110,BITSET:0111,WRITE:1000,WAIT_DRDY:1001" *) 
  (* KEEP = "yes" *) 
  FDRE #(
    .INIT(1'b0)) 
    \current_state_reg[2] 
       (.C(CLK),
        .CE(1'b1),
        .D(next_state[2]),
        .Q(current_state[2]),
        .R(1'b0));
  (* DONT_TOUCH *) 
  (* FSM_ENCODED_STATES = "RESTART:0001,WAIT_LOCK:0010,WAIT_SEN:0011,ADDRESS:0100,WAIT_A_DRDY:0101,BITMASK:0110,BITSET:0111,WRITE:1000,WAIT_DRDY:1001" *) 
  (* KEEP = "yes" *) 
  FDRE #(
    .INIT(1'b0)) 
    \current_state_reg[3] 
       (.C(CLK),
        .CE(1'b1),
        .D(next_state[3]),
        .Q(current_state[3]),
        .R(1'b0));
  (* SOFT_HLUTNM = "soft_lutpair19" *) 
  LUT2 #(
    .INIT(4'hE)) 
    \ram[23][37]_i_1 
       (.I0(\ram_reg[23]_11 ),
        .I1(\ram_reg[26][0]_0 ),
        .O(\ram[23][37]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT2 #(
    .INIT(4'hB)) 
    \ram[25][10]_i_1 
       (.I0(timing_sel_imm[0]),
        .I1(timing_sel_imm[1]),
        .O(\ram[25][10]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \ram[25][8]_i_1 
       (.I0(timing_sel_imm[1]),
        .I1(timing_sel_imm[0]),
        .O(\ram[25][8]_i_1_n_0 ));
  LUT2 #(
    .INIT(4'hB)) 
    \ram[26][5]_i_2 
       (.I0(timing_sel_imm[0]),
        .I1(timing_sel_imm[1]),
        .O(\ram[26][5]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'hB)) 
    \ram[26][5]_i_3 
       (.I0(timing_sel_imm[0]),
        .I1(timing_sel_imm[1]),
        .O(\ram[26][5]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \ram[26][5]_i_4 
       (.I0(timing_sel_imm[1]),
        .I1(timing_sel_imm[0]),
        .O(\ram[26][5]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'hB)) 
    \ram[26][5]_i_5 
       (.I0(timing_sel_imm[0]),
        .I1(timing_sel_imm[1]),
        .O(\ram[26][5]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'hB)) 
    \ram[26][5]_i_6 
       (.I0(timing_sel_imm[0]),
        .I1(timing_sel_imm[1]),
        .O(\ram[26][5]_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT4 #(
    .INIT(16'h6662)) 
    \ram[37][10]_i_1 
       (.I0(timing_sel_imm[1]),
        .I1(timing_sel_imm[0]),
        .I2(\ram_reg[40][12]_i_2_n_0 ),
        .I3(\ram_reg[40][12]_i_3_n_2 ),
        .O(\ram[37][10]_i_1_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \ram[38][0]_i_2 
       (.I0(timing_sel_imm[0]),
        .I1(timing_sel_imm[1]),
        .O(\ram[38][0]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \ram[38][0]_i_3 
       (.I0(timing_sel_imm[1]),
        .I1(timing_sel_imm[0]),
        .O(\ram[38][0]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \ram[38][0]_i_4 
       (.I0(timing_sel_imm[0]),
        .I1(timing_sel_imm[1]),
        .O(\ram[38][0]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \ram[38][0]_i_5 
       (.I0(timing_sel_imm[1]),
        .I1(timing_sel_imm[0]),
        .O(\ram[38][0]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \ram[38][13]_i_1 
       (.I0(timing_sel_imm[0]),
        .I1(timing_sel_imm[1]),
        .O(s2_clkfbout_mult));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT2 #(
    .INIT(4'h9)) 
    \ram[38][6]_i_1 
       (.I0(timing_sel_imm[1]),
        .I1(timing_sel_imm[0]),
        .O(\ram[38][6]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT4 #(
    .INIT(16'h2226)) 
    \ram[39][0]_i_1 
       (.I0(timing_sel_imm[1]),
        .I1(timing_sel_imm[0]),
        .I2(\ram_reg[40][12]_i_2_n_0 ),
        .I3(\ram_reg[40][12]_i_3_n_2 ),
        .O(\ram[39][0]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair17" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \ram[39][10]_i_1 
       (.I0(timing_sel_imm[1]),
        .I1(timing_sel_imm[0]),
        .O(\ram[39][10]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT4 #(
    .INIT(16'h0FE0)) 
    \ram[39][6]_i_1 
       (.I0(\ram_reg[40][12]_i_2_n_0 ),
        .I1(\ram_reg[40][12]_i_3_n_2 ),
        .I2(timing_sel_imm[1]),
        .I3(timing_sel_imm[0]),
        .O(\ram[39][6]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT4 #(
    .INIT(16'h0F10)) 
    \ram[39][7]_i_1 
       (.I0(\ram_reg[40][12]_i_3_n_2 ),
        .I1(\ram_reg[40][12]_i_2_n_0 ),
        .I2(timing_sel_imm[1]),
        .I3(timing_sel_imm[0]),
        .O(\ram[39][7]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair18" *) 
  LUT2 #(
    .INIT(4'h4)) 
    \ram[39][8]_i_1 
       (.I0(timing_sel_imm[1]),
        .I1(timing_sel_imm[0]),
        .O(\ram[39][8]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair18" *) 
  LUT2 #(
    .INIT(4'h9)) 
    \ram[39][9]_i_1 
       (.I0(timing_sel_imm[1]),
        .I1(timing_sel_imm[0]),
        .O(\ram[39][9]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT4 #(
    .INIT(16'h4440)) 
    \ram[40][10]_i_1 
       (.I0(timing_sel_imm[0]),
        .I1(timing_sel_imm[1]),
        .I2(\ram_reg[40][12]_i_3_n_2 ),
        .I3(\ram_reg[40][12]_i_2_n_0 ),
        .O(p_1_out));
  (* SOFT_HLUTNM = "soft_lutpair19" *) 
  LUT2 #(
    .INIT(4'hE)) 
    \ram[40][11]_i_1 
       (.I0(\ram_reg[26][0]_0 ),
        .I1(\ram_reg[40]_5 [11]),
        .O(\ram[40][11]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT4 #(
    .INIT(16'h3E13)) 
    \ram[40][12]_i_1 
       (.I0(\ram_reg[40][12]_i_2_n_0 ),
        .I1(\ram_reg[40][12]_i_3_n_2 ),
        .I2(timing_sel_imm[1]),
        .I3(timing_sel_imm[0]),
        .O(\ram[40][12]_i_1_n_0 ));
  LUT3 #(
    .INIT(8'h8A)) 
    \ram[40][12]_i_10 
       (.I0(\ram_reg[40][12]_i_2_n_6 ),
        .I1(timing_sel_imm[1]),
        .I2(timing_sel_imm[0]),
        .O(\ram[40][12]_i_10_n_0 ));
  LUT4 #(
    .INIT(16'h6996)) 
    \ram[40][12]_i_11 
       (.I0(\ram_reg[40][12]_i_2_n_5 ),
        .I1(\ram_reg[40][12]_i_2_n_0 ),
        .I2(timing_sel_imm[1]),
        .I3(timing_sel_imm[0]),
        .O(\ram[40][12]_i_11_n_0 ));
  LUT4 #(
    .INIT(16'hD02F)) 
    \ram[40][12]_i_12 
       (.I0(timing_sel_imm[0]),
        .I1(timing_sel_imm[1]),
        .I2(\ram_reg[40][12]_i_2_n_6 ),
        .I3(\ram_reg[40][12]_i_2_n_5 ),
        .O(\ram[40][12]_i_12_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \ram[40][12]_i_13 
       (.I0(timing_sel_imm[0]),
        .I1(timing_sel_imm[1]),
        .O(\ram[40][12]_i_13_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \ram[40][12]_i_14 
       (.I0(timing_sel_imm[1]),
        .I1(timing_sel_imm[0]),
        .O(\ram[40][12]_i_14_n_0 ));
  LUT2 #(
    .INIT(4'hD)) 
    \ram[40][12]_i_15 
       (.I0(timing_sel_imm[1]),
        .I1(timing_sel_imm[0]),
        .O(\ram[40][12]_i_15_n_0 ));
  LUT2 #(
    .INIT(4'hD)) 
    \ram[40][12]_i_16 
       (.I0(timing_sel_imm[1]),
        .I1(timing_sel_imm[0]),
        .O(\ram[40][12]_i_16_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \ram[40][12]_i_17 
       (.I0(timing_sel_imm[0]),
        .I1(timing_sel_imm[1]),
        .O(\ram[40][12]_i_17_n_0 ));
  LUT2 #(
    .INIT(4'hD)) 
    \ram[40][12]_i_18 
       (.I0(timing_sel_imm[1]),
        .I1(timing_sel_imm[0]),
        .O(\ram[40][12]_i_18_n_0 ));
  LUT3 #(
    .INIT(8'hEB)) 
    \ram[40][12]_i_20 
       (.I0(\ram_reg[40][12]_i_4_n_6 ),
        .I1(timing_sel_imm[1]),
        .I2(timing_sel_imm[0]),
        .O(\ram[40][12]_i_20_n_0 ));
  LUT4 #(
    .INIT(16'h9969)) 
    \ram[40][12]_i_21 
       (.I0(\ram_reg[40][12]_i_2_n_7 ),
        .I1(\ram_reg[40][12]_i_2_n_6 ),
        .I2(timing_sel_imm[0]),
        .I3(timing_sel_imm[1]),
        .O(\ram[40][12]_i_21_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \ram[40][12]_i_22 
       (.I0(\ram_reg[40][12]_i_4_n_4 ),
        .I1(\ram_reg[40][12]_i_2_n_7 ),
        .O(\ram[40][12]_i_22_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \ram[40][12]_i_23 
       (.I0(\ram_reg[40][12]_i_4_n_5 ),
        .I1(\ram_reg[40][12]_i_4_n_4 ),
        .O(\ram[40][12]_i_23_n_0 ));
  LUT4 #(
    .INIT(16'hF906)) 
    \ram[40][12]_i_24 
       (.I0(timing_sel_imm[0]),
        .I1(timing_sel_imm[1]),
        .I2(\ram_reg[40][12]_i_4_n_6 ),
        .I3(\ram_reg[40][12]_i_4_n_5 ),
        .O(\ram[40][12]_i_24_n_0 ));
  LUT3 #(
    .INIT(8'hEF)) 
    \ram[40][12]_i_25 
       (.I0(\ram_reg[40][12]_i_4_n_7 ),
        .I1(timing_sel_imm[0]),
        .I2(timing_sel_imm[1]),
        .O(\ram[40][12]_i_25_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \ram[40][12]_i_26 
       (.I0(timing_sel_imm[0]),
        .I1(timing_sel_imm[1]),
        .O(\ram[40][12]_i_26_n_0 ));
  LUT4 #(
    .INIT(16'h39C3)) 
    \ram[40][12]_i_27 
       (.I0(\ram_reg[40][12]_i_4_n_7 ),
        .I1(\ram_reg[40][12]_i_4_n_6 ),
        .I2(timing_sel_imm[0]),
        .I3(timing_sel_imm[1]),
        .O(\ram[40][12]_i_27_n_0 ));
  LUT3 #(
    .INIT(8'hB4)) 
    \ram[40][12]_i_28 
       (.I0(timing_sel_imm[0]),
        .I1(timing_sel_imm[1]),
        .I2(\ram_reg[40][12]_i_4_n_7 ),
        .O(\ram[40][12]_i_28_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \ram[40][12]_i_5 
       (.I0(timing_sel_imm[1]),
        .I1(timing_sel_imm[0]),
        .O(\ram[40][12]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \ram[40][12]_i_6 
       (.I0(timing_sel_imm[1]),
        .I1(timing_sel_imm[0]),
        .O(\ram[40][12]_i_6_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \ram[40][12]_i_7 
       (.I0(timing_sel_imm[0]),
        .I1(timing_sel_imm[1]),
        .O(\ram[40][12]_i_7_n_0 ));
  LUT2 #(
    .INIT(4'hD)) 
    \ram[40][12]_i_8 
       (.I0(timing_sel_imm[1]),
        .I1(timing_sel_imm[0]),
        .O(\ram[40][12]_i_8_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT4 #(
    .INIT(16'h0004)) 
    \ram[40][13]_i_1 
       (.I0(\ram_reg[40][12]_i_2_n_0 ),
        .I1(timing_sel_imm[0]),
        .I2(timing_sel_imm[1]),
        .I3(\ram_reg[40][12]_i_3_n_2 ),
        .O(\ram[40][13]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hB8B8B8B8FF33CC00)) 
    \ram[41][0]_i_1 
       (.I0(\ram[43][11]_i_2_n_0 ),
        .I1(\ram_reg[43][14]_i_3_n_6 ),
        .I2(\ram[43][11]_i_3_n_0 ),
        .I3(\ram[43][11]_i_5_n_0 ),
        .I4(\ram[42][4]_i_2_n_0 ),
        .I5(\ram_reg[43][14]_i_3_n_7 ),
        .O(p_17_in[0]));
  LUT6 #(
    .INIT(64'hFF33CC00B8B8B8B8)) 
    \ram[41][1]_i_1 
       (.I0(\ram[43][12]_i_5_n_0 ),
        .I1(\ram_reg[43][14]_i_3_n_6 ),
        .I2(\ram[42][5]_i_2_n_0 ),
        .I3(\ram[43][12]_i_2_n_0 ),
        .I4(\ram[43][12]_i_3_n_0 ),
        .I5(\ram_reg[43][14]_i_3_n_7 ),
        .O(p_17_in[1]));
  LUT6 #(
    .INIT(64'hB8B8B8B8FF33CC00)) 
    \ram[41][2]_i_1 
       (.I0(\ram[43][13]_i_2_n_0 ),
        .I1(\ram_reg[43][14]_i_3_n_6 ),
        .I2(\ram[43][13]_i_3_n_0 ),
        .I3(\ram[43][13]_i_5_n_0 ),
        .I4(\ram[42][6]_i_2_n_0 ),
        .I5(\ram_reg[43][14]_i_3_n_7 ),
        .O(p_17_in[2]));
  LUT6 #(
    .INIT(64'hFF33CC00B8B8B8B8)) 
    \ram[41][3]_i_1 
       (.I0(\ram[43][14]_i_6_n_0 ),
        .I1(\ram_reg[43][14]_i_3_n_6 ),
        .I2(\ram[42][7]_i_2_n_0 ),
        .I3(\ram[43][14]_i_2_n_0 ),
        .I4(\ram[43][14]_i_4_n_0 ),
        .I5(\ram_reg[43][14]_i_3_n_7 ),
        .O(p_17_in[3]));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \ram[41][4]_i_1 
       (.I0(\ram[41][4]_i_2_n_0 ),
        .I1(\ram_reg[43][14]_i_3_n_6 ),
        .I2(\ram[42][8]_i_3_n_0 ),
        .I3(\ram_reg[43][14]_i_3_n_7 ),
        .I4(\ram_reg[42][8]_i_2_n_0 ),
        .O(p_17_in[4]));
  LUT6 #(
    .INIT(64'h0000040E7E7F97DB)) 
    \ram[41][4]_i_2 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_7_n_4 ),
        .I3(\ram_reg[43][14]_i_7_n_6 ),
        .I4(\ram_reg[43][14]_i_7_n_5 ),
        .I5(\ram_reg[43][14]_i_8_n_3 ),
        .O(\ram[41][4]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \ram[41][5]_i_1 
       (.I0(\ram[41][5]_i_2_n_0 ),
        .I1(\ram_reg[43][14]_i_3_n_6 ),
        .I2(\ram[42][9]_i_3_n_0 ),
        .I3(\ram_reg[43][14]_i_3_n_7 ),
        .I4(\ram_reg[42][9]_i_2_n_0 ),
        .O(p_17_in[5]));
  LUT6 #(
    .INIT(64'h0B060815010B0D6A)) 
    \ram[41][5]_i_2 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_4 ),
        .I4(\ram_reg[43][14]_i_7_n_5 ),
        .I5(\ram_reg[43][14]_i_7_n_6 ),
        .O(\ram[41][5]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \ram[41][6]_i_1 
       (.I0(\ram[41][6]_i_2_n_0 ),
        .I1(\ram_reg[43][14]_i_3_n_6 ),
        .I2(\ram[43][0]_i_3_n_0 ),
        .I3(\ram_reg[43][14]_i_3_n_7 ),
        .I4(\ram_reg[43][0]_i_2_n_0 ),
        .O(p_17_in[6]));
  LUT6 #(
    .INIT(64'h0B070D0B0E3D0F7E)) 
    \ram[41][6]_i_2 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_4 ),
        .I4(\ram_reg[43][14]_i_7_n_6 ),
        .I5(\ram_reg[43][14]_i_7_n_5 ),
        .O(\ram[41][6]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \ram[41][7]_i_1 
       (.I0(\ram[41][7]_i_2_n_0 ),
        .I1(\ram_reg[43][14]_i_3_n_6 ),
        .I2(\ram[43][1]_i_3_n_0 ),
        .I3(\ram_reg[43][14]_i_3_n_7 ),
        .I4(\ram_reg[43][1]_i_2_n_0 ),
        .O(p_17_in[7]));
  LUT6 #(
    .INIT(64'h0B060815050B0D4A)) 
    \ram[41][7]_i_2 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_4 ),
        .I4(\ram_reg[43][14]_i_7_n_5 ),
        .I5(\ram_reg[43][14]_i_7_n_6 ),
        .O(\ram[41][7]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \ram[41][8]_i_1 
       (.I0(\ram[41][8]_i_2_n_0 ),
        .I1(\ram_reg[43][14]_i_3_n_6 ),
        .I2(\ram[43][2]_i_3_n_0 ),
        .I3(\ram_reg[43][14]_i_3_n_7 ),
        .I4(\ram_reg[43][2]_i_2_n_0 ),
        .O(p_17_in[8]));
  LUT6 #(
    .INIT(64'h03020A5004010408)) 
    \ram[41][8]_i_2 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_4 ),
        .I4(\ram_reg[43][14]_i_7_n_5 ),
        .I5(\ram_reg[43][14]_i_7_n_6 ),
        .O(\ram[41][8]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \ram[41][9]_i_1 
       (.I0(\ram[41][9]_i_2_n_0 ),
        .I1(\ram_reg[43][14]_i_3_n_6 ),
        .I2(\ram[43][3]_i_3_n_0 ),
        .I3(\ram_reg[43][14]_i_3_n_7 ),
        .I4(\ram_reg[43][3]_i_2_n_0 ),
        .O(p_17_in[9]));
  LUT6 #(
    .INIT(64'h090708030C79063C)) 
    \ram[41][9]_i_2 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_4 ),
        .I4(\ram_reg[43][14]_i_7_n_6 ),
        .I5(\ram_reg[43][14]_i_7_n_5 ),
        .O(\ram[41][9]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \ram[42][0]_i_1 
       (.I0(\ram[43][6]_i_4_n_0 ),
        .I1(\ram_reg[43][14]_i_3_n_7 ),
        .I2(\ram[43][6]_i_3_n_0 ),
        .I3(\ram_reg[43][14]_i_3_n_6 ),
        .I4(\ram[42][0]_i_2_n_0 ),
        .O(p_18_in[0]));
  LUT6 #(
    .INIT(64'h09070D0B0E6D0F3E)) 
    \ram[42][0]_i_2 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_4 ),
        .I4(\ram_reg[43][14]_i_7_n_6 ),
        .I5(\ram_reg[43][14]_i_7_n_5 ),
        .O(\ram[42][0]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \ram[42][10]_i_1 
       (.I0(\ram[42][10]_i_2_n_0 ),
        .I1(\ram_reg[43][14]_i_3_n_6 ),
        .I2(\ram[43][4]_i_3_n_0 ),
        .I3(\ram_reg[43][14]_i_3_n_7 ),
        .I4(\ram_reg[43][4]_i_2_n_0 ),
        .O(p_18_in[10]));
  LUT6 #(
    .INIT(64'h0000000294AD294A)) 
    \ram[42][10]_i_2 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_7_n_6 ),
        .I3(\ram_reg[43][14]_i_7_n_5 ),
        .I4(\ram_reg[43][14]_i_7_n_4 ),
        .I5(\ram_reg[43][14]_i_8_n_3 ),
        .O(\ram[42][10]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \ram[42][11]_i_1 
       (.I0(\ram[42][11]_i_2_n_0 ),
        .I1(\ram_reg[43][14]_i_3_n_6 ),
        .I2(\ram[43][5]_i_3_n_0 ),
        .I3(\ram_reg[43][14]_i_3_n_7 ),
        .I4(\ram_reg[43][5]_i_2_n_0 ),
        .O(p_18_in[11]));
  LUT6 #(
    .INIT(64'h09070C0B0E3D0F7E)) 
    \ram[42][11]_i_2 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_4 ),
        .I4(\ram_reg[43][14]_i_7_n_6 ),
        .I5(\ram_reg[43][14]_i_7_n_5 ),
        .O(\ram[42][11]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFF33CC00B8B8B8B8)) 
    \ram[42][12]_i_1 
       (.I0(\ram[43][6]_i_2_n_0 ),
        .I1(\ram_reg[43][14]_i_3_n_6 ),
        .I2(\ram[43][6]_i_3_n_0 ),
        .I3(\ram[42][12]_i_2_n_0 ),
        .I4(\ram[42][12]_i_3_n_0 ),
        .I5(\ram_reg[43][14]_i_3_n_7 ),
        .O(p_18_in[12]));
  LUT6 #(
    .INIT(64'h0B070D0B0E7D073E)) 
    \ram[42][12]_i_2 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_4 ),
        .I4(\ram_reg[43][14]_i_7_n_6 ),
        .I5(\ram_reg[43][14]_i_7_n_5 ),
        .O(\ram[42][12]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h0E0D0F0E079F0B97)) 
    \ram[42][12]_i_3 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_4 ),
        .I4(\ram_reg[43][14]_i_7_n_6 ),
        .I5(\ram_reg[43][14]_i_7_n_5 ),
        .O(\ram[42][12]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFF33CC00B8B8B8B8)) 
    \ram[42][13]_i_1 
       (.I0(\ram[43][7]_i_2_n_0 ),
        .I1(\ram_reg[43][14]_i_3_n_6 ),
        .I2(\ram[43][7]_i_3_n_0 ),
        .I3(\ram[42][13]_i_2_n_0 ),
        .I4(\ram[43][7]_i_4_n_0 ),
        .I5(\ram_reg[43][14]_i_3_n_7 ),
        .O(p_18_in[13]));
  LUT6 #(
    .INIT(64'h0A06053D0C0B0A56)) 
    \ram[42][13]_i_2 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_5 ),
        .I4(\ram_reg[43][14]_i_7_n_4 ),
        .I5(\ram_reg[43][14]_i_7_n_6 ),
        .O(\ram[42][13]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFF33CC00B8B8B8B8)) 
    \ram[42][14]_i_1 
       (.I0(\ram[43][8]_i_2_n_0 ),
        .I1(\ram_reg[43][14]_i_3_n_6 ),
        .I2(\ram[43][8]_i_3_n_0 ),
        .I3(\ram[42][14]_i_2_n_0 ),
        .I4(\ram[43][8]_i_4_n_0 ),
        .I5(\ram_reg[43][14]_i_3_n_7 ),
        .O(p_18_in[14]));
  LUT6 #(
    .INIT(64'h0E0D0E0E072F03D7)) 
    \ram[42][14]_i_2 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_4 ),
        .I4(\ram_reg[43][14]_i_7_n_6 ),
        .I5(\ram_reg[43][14]_i_7_n_5 ),
        .O(\ram[42][14]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hB8FFB833B8CCB800)) 
    \ram[42][1]_i_1 
       (.I0(\ram[43][7]_i_4_n_0 ),
        .I1(\ram_reg[43][14]_i_3_n_6 ),
        .I2(\ram[43][7]_i_5_n_0 ),
        .I3(\ram_reg[43][14]_i_3_n_7 ),
        .I4(\ram[43][7]_i_3_n_0 ),
        .I5(\ram[42][1]_i_2_n_0 ),
        .O(p_18_in[1]));
  LUT6 #(
    .INIT(64'h00A60A5D00D305A6)) 
    \ram[42][1]_i_2 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_7_n_5 ),
        .I3(\ram_reg[43][14]_i_8_n_3 ),
        .I4(\ram_reg[43][14]_i_7_n_4 ),
        .I5(\ram_reg[43][14]_i_7_n_6 ),
        .O(\ram[42][1]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hB8FFB833B8CCB800)) 
    \ram[42][2]_i_1 
       (.I0(\ram[43][8]_i_4_n_0 ),
        .I1(\ram_reg[43][14]_i_3_n_6 ),
        .I2(\ram[43][8]_i_5_n_0 ),
        .I3(\ram_reg[43][14]_i_3_n_7 ),
        .I4(\ram[43][8]_i_3_n_0 ),
        .I5(\ram[42][2]_i_2_n_0 ),
        .O(p_18_in[2]));
  LUT6 #(
    .INIT(64'h0C0D0F0E07BF03D7)) 
    \ram[42][2]_i_2 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_4 ),
        .I4(\ram_reg[43][14]_i_7_n_6 ),
        .I5(\ram_reg[43][14]_i_7_n_5 ),
        .O(\ram[42][2]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hB8FFB833B8CCB800)) 
    \ram[42][3]_i_1 
       (.I0(\ram[43][10]_i_3_n_0 ),
        .I1(\ram_reg[43][14]_i_3_n_6 ),
        .I2(\ram[43][9]_i_2_n_0 ),
        .I3(\ram_reg[43][14]_i_3_n_7 ),
        .I4(\ram[42][3]_i_2_n_0 ),
        .I5(\ram[42][3]_i_3_n_0 ),
        .O(p_18_in[3]));
  LUT6 #(
    .INIT(64'h0B060895050B0D6A)) 
    \ram[42][3]_i_2 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_4 ),
        .I4(\ram_reg[43][14]_i_7_n_5 ),
        .I5(\ram_reg[43][14]_i_7_n_6 ),
        .O(\ram[42][3]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h080605BD0C030A56)) 
    \ram[42][3]_i_3 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_5 ),
        .I4(\ram_reg[43][14]_i_7_n_4 ),
        .I5(\ram_reg[43][14]_i_7_n_6 ),
        .O(\ram[42][3]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hB8FFB833B8CCB800)) 
    \ram[42][4]_i_1 
       (.I0(\ram[43][11]_i_5_n_0 ),
        .I1(\ram_reg[43][14]_i_3_n_6 ),
        .I2(\ram[42][4]_i_2_n_0 ),
        .I3(\ram_reg[43][14]_i_3_n_7 ),
        .I4(\ram[43][11]_i_3_n_0 ),
        .I5(\ram[42][4]_i_3_n_0 ),
        .O(p_18_in[4]));
  LUT6 #(
    .INIT(64'h010105280A000694)) 
    \ram[42][4]_i_2 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_4 ),
        .I4(\ram_reg[43][14]_i_7_n_5 ),
        .I5(\ram_reg[43][14]_i_7_n_6 ),
        .O(\ram[42][4]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h0086090400D90482)) 
    \ram[42][4]_i_3 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_7_n_5 ),
        .I3(\ram_reg[43][14]_i_8_n_3 ),
        .I4(\ram_reg[43][14]_i_7_n_4 ),
        .I5(\ram_reg[43][14]_i_7_n_6 ),
        .O(\ram[42][4]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hB8FFB833B8CCB800)) 
    \ram[42][5]_i_1 
       (.I0(\ram[43][12]_i_5_n_0 ),
        .I1(\ram_reg[43][14]_i_3_n_6 ),
        .I2(\ram[42][5]_i_2_n_0 ),
        .I3(\ram_reg[43][14]_i_3_n_7 ),
        .I4(\ram[43][12]_i_3_n_0 ),
        .I5(\ram[42][5]_i_3_n_0 ),
        .O(p_18_in[5]));
  LUT6 #(
    .INIT(64'h0C0C03090E073C9E)) 
    \ram[42][5]_i_2 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_6 ),
        .I4(\ram_reg[43][14]_i_7_n_4 ),
        .I5(\ram_reg[43][14]_i_7_n_5 ),
        .O(\ram[42][5]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h0E09038E0E0C03D7)) 
    \ram[42][5]_i_3 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_4 ),
        .I4(\ram_reg[43][14]_i_7_n_5 ),
        .I5(\ram_reg[43][14]_i_7_n_6 ),
        .O(\ram[42][5]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hB8FFB833B8CCB800)) 
    \ram[42][6]_i_1 
       (.I0(\ram[43][13]_i_5_n_0 ),
        .I1(\ram_reg[43][14]_i_3_n_6 ),
        .I2(\ram[42][6]_i_2_n_0 ),
        .I3(\ram_reg[43][14]_i_3_n_7 ),
        .I4(\ram[43][13]_i_3_n_0 ),
        .I5(\ram[42][6]_i_3_n_0 ),
        .O(p_18_in[6]));
  LUT6 #(
    .INIT(64'h05090D2A0A040235)) 
    \ram[42][6]_i_2 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_4 ),
        .I4(\ram_reg[43][14]_i_7_n_5 ),
        .I5(\ram_reg[43][14]_i_7_n_6 ),
        .O(\ram[42][6]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h0A04050A06050912)) 
    \ram[42][6]_i_3 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_4 ),
        .I4(\ram_reg[43][14]_i_7_n_6 ),
        .I5(\ram_reg[43][14]_i_7_n_5 ),
        .O(\ram[42][6]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hB8FFB833B8CCB800)) 
    \ram[42][7]_i_1 
       (.I0(\ram[43][14]_i_6_n_0 ),
        .I1(\ram_reg[43][14]_i_3_n_6 ),
        .I2(\ram[42][7]_i_2_n_0 ),
        .I3(\ram_reg[43][14]_i_3_n_7 ),
        .I4(\ram[43][14]_i_4_n_0 ),
        .I5(\ram[42][7]_i_3_n_0 ),
        .O(p_18_in[7]));
  LUT6 #(
    .INIT(64'h0D0B0F5E0E0D039F)) 
    \ram[42][7]_i_2 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_4 ),
        .I4(\ram_reg[43][14]_i_7_n_5 ),
        .I5(\ram_reg[43][14]_i_7_n_6 ),
        .O(\ram[42][7]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h0E0D0F0E03BF0B97)) 
    \ram[42][7]_i_3 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_4 ),
        .I4(\ram_reg[43][14]_i_7_n_6 ),
        .I5(\ram_reg[43][14]_i_7_n_5 ),
        .O(\ram[42][7]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \ram[42][8]_i_1 
       (.I0(\ram_reg[42][8]_i_2_n_0 ),
        .I1(\ram_reg[43][14]_i_3_n_7 ),
        .I2(\ram[42][8]_i_3_n_0 ),
        .I3(\ram_reg[43][14]_i_3_n_6 ),
        .I4(\ram[42][8]_i_4_n_0 ),
        .O(p_18_in[8]));
  LUT6 #(
    .INIT(64'h0B070D0B0E6D073E)) 
    \ram[42][8]_i_3 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_4 ),
        .I4(\ram_reg[43][14]_i_7_n_6 ),
        .I5(\ram_reg[43][14]_i_7_n_5 ),
        .O(\ram[42][8]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h0E0D0F0E039F0BC7)) 
    \ram[42][8]_i_4 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_4 ),
        .I4(\ram_reg[43][14]_i_7_n_6 ),
        .I5(\ram_reg[43][14]_i_7_n_5 ),
        .O(\ram[42][8]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h0C0B0F3E0E0D079F)) 
    \ram[42][8]_i_5 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_4 ),
        .I4(\ram_reg[43][14]_i_7_n_5 ),
        .I5(\ram_reg[43][14]_i_7_n_6 ),
        .O(\ram[42][8]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h003900CE00F747BD)) 
    \ram[42][8]_i_6 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_7_n_6 ),
        .I3(\ram_reg[43][14]_i_8_n_3 ),
        .I4(\ram_reg[43][14]_i_7_n_5 ),
        .I5(\ram_reg[43][14]_i_7_n_4 ),
        .O(\ram[42][8]_i_6_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \ram[42][9]_i_1 
       (.I0(\ram_reg[42][9]_i_2_n_0 ),
        .I1(\ram_reg[43][14]_i_3_n_7 ),
        .I2(\ram[42][9]_i_3_n_0 ),
        .I3(\ram_reg[43][14]_i_3_n_6 ),
        .I4(\ram[42][9]_i_4_n_0 ),
        .O(p_18_in[9]));
  LUT6 #(
    .INIT(64'h0A0605AD0C0B0A56)) 
    \ram[42][9]_i_3 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_5 ),
        .I4(\ram_reg[43][14]_i_7_n_4 ),
        .I5(\ram_reg[43][14]_i_7_n_6 ),
        .O(\ram[42][9]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h060D0306012B0AD5)) 
    \ram[42][9]_i_4 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_4 ),
        .I4(\ram_reg[43][14]_i_7_n_6 ),
        .I5(\ram_reg[43][14]_i_7_n_5 ),
        .O(\ram[42][9]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h0C030A5606010D0B)) 
    \ram[42][9]_i_5 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_5 ),
        .I4(\ram_reg[43][14]_i_7_n_4 ),
        .I5(\ram_reg[43][14]_i_7_n_6 ),
        .O(\ram[42][9]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h010B0D6A0A0506BD)) 
    \ram[42][9]_i_6 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_4 ),
        .I4(\ram_reg[43][14]_i_7_n_5 ),
        .I5(\ram_reg[43][14]_i_7_n_6 ),
        .O(\ram[42][9]_i_6_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \ram[43][0]_i_1 
       (.I0(\ram_reg[43][0]_i_2_n_0 ),
        .I1(\ram_reg[43][14]_i_3_n_7 ),
        .I2(\ram[43][0]_i_3_n_0 ),
        .I3(\ram_reg[43][14]_i_3_n_6 ),
        .I4(\ram[43][14]_i_6_n_0 ),
        .O(p_19_in[0]));
  LUT6 #(
    .INIT(64'h0C0D0E0E07BF03D7)) 
    \ram[43][0]_i_3 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_4 ),
        .I4(\ram_reg[43][14]_i_7_n_6 ),
        .I5(\ram_reg[43][14]_i_7_n_5 ),
        .O(\ram[43][0]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h00EE007F0DB70C9B)) 
    \ram[43][0]_i_4 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_7_n_4 ),
        .I3(\ram_reg[43][14]_i_8_n_3 ),
        .I4(\ram_reg[43][14]_i_7_n_6 ),
        .I5(\ram_reg[43][14]_i_7_n_5 ),
        .O(\ram[43][0]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h090B0E5E0C0D07BF)) 
    \ram[43][0]_i_5 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_4 ),
        .I4(\ram_reg[43][14]_i_7_n_5 ),
        .I5(\ram_reg[43][14]_i_7_n_6 ),
        .O(\ram[43][0]_i_5_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \ram[43][10]_i_1 
       (.I0(\ram[43][10]_i_2_n_0 ),
        .I1(\ram_reg[43][14]_i_3_n_6 ),
        .I2(\ram[43][10]_i_3_n_0 ),
        .I3(\ram_reg[43][14]_i_3_n_7 ),
        .I4(\ram[43][10]_i_4_n_0 ),
        .O(p_19_in[10]));
  LUT6 #(
    .INIT(64'h0086025D00D305A6)) 
    \ram[43][10]_i_2 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_7_n_5 ),
        .I3(\ram_reg[43][14]_i_8_n_3 ),
        .I4(\ram_reg[43][14]_i_7_n_4 ),
        .I5(\ram_reg[43][14]_i_7_n_6 ),
        .O(\ram[43][10]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h0000020C61B8DB65)) 
    \ram[43][10]_i_3 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_7_n_5 ),
        .I3(\ram_reg[43][14]_i_7_n_6 ),
        .I4(\ram_reg[43][14]_i_7_n_4 ),
        .I5(\ram_reg[43][14]_i_8_n_3 ),
        .O(\ram[43][10]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \ram[43][10]_i_4 
       (.I0(\ram[43][10]_i_5_n_0 ),
        .I1(\ram_reg[43][14]_i_3_n_1 ),
        .I2(\ram[43][10]_i_6_n_0 ),
        .I3(\ram_reg[43][14]_i_3_n_6 ),
        .I4(\ram[42][3]_i_2_n_0 ),
        .O(\ram[43][10]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT5 #(
    .INIT(32'h2312110F)) 
    \ram[43][10]_i_5 
       (.I0(\ram_reg[43][14]_i_7_n_7 ),
        .I1(\ram_reg[43][14]_i_8_n_3 ),
        .I2(\ram_reg[43][14]_i_7_n_4 ),
        .I3(\ram_reg[43][14]_i_7_n_6 ),
        .I4(\ram_reg[43][14]_i_7_n_5 ),
        .O(\ram[43][10]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT5 #(
    .INIT(32'h210E2131)) 
    \ram[43][10]_i_6 
       (.I0(\ram_reg[43][14]_i_7_n_7 ),
        .I1(\ram_reg[43][14]_i_8_n_3 ),
        .I2(\ram_reg[43][14]_i_7_n_5 ),
        .I3(\ram_reg[43][14]_i_7_n_4 ),
        .I4(\ram_reg[43][14]_i_7_n_6 ),
        .O(\ram[43][10]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hFF33CC00B8B8B8B8)) 
    \ram[43][11]_i_1 
       (.I0(\ram[43][11]_i_2_n_0 ),
        .I1(\ram_reg[43][14]_i_3_n_6 ),
        .I2(\ram[43][11]_i_3_n_0 ),
        .I3(\ram[43][11]_i_4_n_0 ),
        .I4(\ram[43][11]_i_5_n_0 ),
        .I5(\ram_reg[43][14]_i_3_n_7 ),
        .O(p_19_in[11]));
  LUT6 #(
    .INIT(64'h0000004A46B48421)) 
    \ram[43][11]_i_2 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_7_n_6 ),
        .I3(\ram_reg[43][14]_i_7_n_5 ),
        .I4(\ram_reg[43][14]_i_7_n_4 ),
        .I5(\ram_reg[43][14]_i_8_n_3 ),
        .O(\ram[43][11]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h03020A1004010428)) 
    \ram[43][11]_i_3 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_4 ),
        .I4(\ram_reg[43][14]_i_7_n_5 ),
        .I5(\ram_reg[43][14]_i_7_n_6 ),
        .O(\ram[43][11]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h0082010400DB0482)) 
    \ram[43][11]_i_4 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_7_n_5 ),
        .I3(\ram_reg[43][14]_i_8_n_3 ),
        .I4(\ram_reg[43][14]_i_7_n_4 ),
        .I5(\ram_reg[43][14]_i_7_n_6 ),
        .O(\ram[43][11]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h02040B0204A10A10)) 
    \ram[43][11]_i_5 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_4 ),
        .I4(\ram_reg[43][14]_i_7_n_6 ),
        .I5(\ram_reg[43][14]_i_7_n_5 ),
        .O(\ram[43][11]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hFF33CC00B8B8B8B8)) 
    \ram[43][12]_i_1 
       (.I0(\ram[43][12]_i_2_n_0 ),
        .I1(\ram_reg[43][14]_i_3_n_6 ),
        .I2(\ram[43][12]_i_3_n_0 ),
        .I3(\ram[43][12]_i_4_n_0 ),
        .I4(\ram[43][12]_i_5_n_0 ),
        .I5(\ram_reg[43][14]_i_3_n_7 ),
        .O(p_19_in[12]));
  LUT6 #(
    .INIT(64'h00000052DF25F24F)) 
    \ram[43][12]_i_2 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_6 ),
        .I2(\ram_reg[43][14]_i_7_n_7 ),
        .I3(\ram_reg[43][14]_i_7_n_5 ),
        .I4(\ram_reg[43][14]_i_7_n_4 ),
        .I5(\ram_reg[43][14]_i_8_n_3 ),
        .O(\ram[43][12]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h0B0708030C39063C)) 
    \ram[43][12]_i_3 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_4 ),
        .I4(\ram_reg[43][14]_i_7_n_6 ),
        .I5(\ram_reg[43][14]_i_7_n_5 ),
        .O(\ram[43][12]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h0E09071E060C03C7)) 
    \ram[43][12]_i_4 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_4 ),
        .I4(\ram_reg[43][14]_i_7_n_5 ),
        .I5(\ram_reg[43][14]_i_7_n_6 ),
        .O(\ram[43][12]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h070E010708E30C39)) 
    \ram[43][12]_i_5 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_4 ),
        .I4(\ram_reg[43][14]_i_7_n_6 ),
        .I5(\ram_reg[43][14]_i_7_n_5 ),
        .O(\ram[43][12]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hFF33CC00B8B8B8B8)) 
    \ram[43][13]_i_1 
       (.I0(\ram[43][13]_i_2_n_0 ),
        .I1(\ram_reg[43][14]_i_3_n_6 ),
        .I2(\ram[43][13]_i_3_n_0 ),
        .I3(\ram[43][13]_i_4_n_0 ),
        .I4(\ram[43][13]_i_5_n_0 ),
        .I5(\ram_reg[43][14]_i_3_n_7 ),
        .O(p_19_in[13]));
  LUT6 #(
    .INIT(64'h00000000E7188A65)) 
    \ram[43][13]_i_2 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_5 ),
        .I2(\ram_reg[43][14]_i_7_n_7 ),
        .I3(\ram_reg[43][14]_i_7_n_6 ),
        .I4(\ram_reg[43][14]_i_7_n_4 ),
        .I5(\ram_reg[43][14]_i_8_n_3 ),
        .O(\ram[43][13]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h0B020A5404090D2A)) 
    \ram[43][13]_i_3 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_4 ),
        .I4(\ram_reg[43][14]_i_7_n_5 ),
        .I5(\ram_reg[43][14]_i_7_n_6 ),
        .O(\ram[43][13]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h0A040D0A06150912)) 
    \ram[43][13]_i_4 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_4 ),
        .I4(\ram_reg[43][14]_i_7_n_6 ),
        .I5(\ram_reg[43][14]_i_7_n_5 ),
        .O(\ram[43][13]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h02050529090A0254)) 
    \ram[43][13]_i_5 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_5 ),
        .I4(\ram_reg[43][14]_i_7_n_4 ),
        .I5(\ram_reg[43][14]_i_7_n_6 ),
        .O(\ram[43][13]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hFF33CC00B8B8B8B8)) 
    \ram[43][14]_i_1 
       (.I0(\ram[43][14]_i_2_n_0 ),
        .I1(\ram_reg[43][14]_i_3_n_6 ),
        .I2(\ram[43][14]_i_4_n_0 ),
        .I3(\ram[43][14]_i_5_n_0 ),
        .I4(\ram[43][14]_i_6_n_0 ),
        .I5(\ram_reg[43][14]_i_3_n_7 ),
        .O(p_19_in[14]));
  LUT2 #(
    .INIT(4'h6)) 
    \ram[43][14]_i_10 
       (.I0(timing_sel_imm[0]),
        .I1(timing_sel_imm[1]),
        .O(\ram[43][14]_i_10_n_0 ));
  LUT2 #(
    .INIT(4'hB)) 
    \ram[43][14]_i_11 
       (.I0(timing_sel_imm[1]),
        .I1(timing_sel_imm[0]),
        .O(\ram[43][14]_i_11_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \ram[43][14]_i_12 
       (.I0(timing_sel_imm[1]),
        .I1(timing_sel_imm[0]),
        .O(\ram[43][14]_i_12_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \ram[43][14]_i_13 
       (.I0(timing_sel_imm[0]),
        .I1(timing_sel_imm[1]),
        .O(\ram[43][14]_i_13_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \ram[43][14]_i_14 
       (.I0(timing_sel_imm[1]),
        .I1(timing_sel_imm[0]),
        .O(\ram[43][14]_i_14_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \ram[43][14]_i_15 
       (.I0(timing_sel_imm[0]),
        .I1(timing_sel_imm[1]),
        .O(\ram[43][14]_i_15_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \ram[43][14]_i_16 
       (.I0(timing_sel_imm[1]),
        .I1(timing_sel_imm[0]),
        .O(\ram[43][14]_i_16_n_0 ));
  LUT6 #(
    .INIT(64'h0F09070D0E570FCB)) 
    \ram[43][14]_i_2 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_5 ),
        .I4(\ram_reg[43][14]_i_7_n_6 ),
        .I5(\ram_reg[43][14]_i_7_n_4 ),
        .O(\ram[43][14]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h0B070C0B0EAD0F7E)) 
    \ram[43][14]_i_4 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_4 ),
        .I4(\ram_reg[43][14]_i_7_n_6 ),
        .I5(\ram_reg[43][14]_i_7_n_5 ),
        .O(\ram[43][14]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h0000020CE7F9DFE7)) 
    \ram[43][14]_i_5 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_7_n_5 ),
        .I3(\ram_reg[43][14]_i_7_n_6 ),
        .I4(\ram_reg[43][14]_i_7_n_4 ),
        .I5(\ram_reg[43][14]_i_8_n_3 ),
        .O(\ram[43][14]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h070D0B0E0F6B07FD)) 
    \ram[43][14]_i_6 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_5 ),
        .I4(\ram_reg[43][14]_i_7_n_6 ),
        .I5(\ram_reg[43][14]_i_7_n_4 ),
        .O(\ram[43][14]_i_6_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \ram[43][14]_i_9 
       (.I0(timing_sel_imm[1]),
        .I1(timing_sel_imm[0]),
        .O(\ram[43][14]_i_9_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \ram[43][1]_i_1 
       (.I0(\ram_reg[43][1]_i_2_n_0 ),
        .I1(\ram_reg[43][14]_i_3_n_7 ),
        .I2(\ram[43][1]_i_3_n_0 ),
        .I3(\ram_reg[43][14]_i_3_n_6 ),
        .I4(\ram[43][1]_i_4_n_0 ),
        .O(p_19_in[1]));
  LUT6 #(
    .INIT(64'h00860B5D00D305A6)) 
    \ram[43][1]_i_3 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_7_n_5 ),
        .I3(\ram_reg[43][14]_i_8_n_3 ),
        .I4(\ram_reg[43][14]_i_7_n_4 ),
        .I5(\ram_reg[43][14]_i_7_n_6 ),
        .O(\ram[43][1]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h060D0B06012B0A95)) 
    \ram[43][1]_i_4 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_4 ),
        .I4(\ram_reg[43][14]_i_7_n_6 ),
        .I5(\ram_reg[43][14]_i_7_n_5 ),
        .O(\ram[43][1]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h0C030A5606010D2B)) 
    \ram[43][1]_i_5 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_5 ),
        .I4(\ram_reg[43][14]_i_7_n_4 ),
        .I5(\ram_reg[43][14]_i_7_n_6 ),
        .O(\ram[43][1]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h050B0C6A0A0506BD)) 
    \ram[43][1]_i_6 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_4 ),
        .I4(\ram_reg[43][14]_i_7_n_5 ),
        .I5(\ram_reg[43][14]_i_7_n_6 ),
        .O(\ram[43][1]_i_6_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \ram[43][2]_i_1 
       (.I0(\ram_reg[43][2]_i_2_n_0 ),
        .I1(\ram_reg[43][14]_i_3_n_7 ),
        .I2(\ram[43][2]_i_3_n_0 ),
        .I3(\ram_reg[43][14]_i_3_n_6 ),
        .I4(\ram[43][2]_i_4_n_0 ),
        .O(p_19_in[2]));
  LUT6 #(
    .INIT(64'h00820804005B0582)) 
    \ram[43][2]_i_3 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_7_n_5 ),
        .I3(\ram_reg[43][14]_i_8_n_3 ),
        .I4(\ram_reg[43][14]_i_7_n_4 ),
        .I5(\ram_reg[43][14]_i_7_n_6 ),
        .O(\ram[43][2]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h00000A0064984120)) 
    \ram[43][2]_i_4 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_7_n_5 ),
        .I3(\ram_reg[43][14]_i_7_n_6 ),
        .I4(\ram_reg[43][14]_i_7_n_4 ),
        .I5(\ram_reg[43][14]_i_8_n_3 ),
        .O(\ram[43][2]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h0000004A42B48421)) 
    \ram[43][2]_i_5 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_7_n_6 ),
        .I3(\ram_reg[43][14]_i_7_n_5 ),
        .I4(\ram_reg[43][14]_i_7_n_4 ),
        .I5(\ram_reg[43][14]_i_8_n_3 ),
        .O(\ram[43][2]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h00010D280A000694)) 
    \ram[43][2]_i_6 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_4 ),
        .I4(\ram_reg[43][14]_i_7_n_5 ),
        .I5(\ram_reg[43][14]_i_7_n_6 ),
        .O(\ram[43][2]_i_6_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \ram[43][3]_i_1 
       (.I0(\ram_reg[43][3]_i_2_n_0 ),
        .I1(\ram_reg[43][14]_i_3_n_7 ),
        .I2(\ram[43][3]_i_3_n_0 ),
        .I3(\ram_reg[43][14]_i_3_n_6 ),
        .I4(\ram[43][3]_i_4_n_0 ),
        .O(p_19_in[3]));
  LUT6 #(
    .INIT(64'h0000008CE6739CE7)) 
    \ram[43][3]_i_3 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_7_n_6 ),
        .I3(\ram_reg[43][14]_i_7_n_5 ),
        .I4(\ram_reg[43][14]_i_7_n_4 ),
        .I5(\ram_reg[43][14]_i_8_n_3 ),
        .O(\ram[43][3]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h030E010708E30C79)) 
    \ram[43][3]_i_4 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_4 ),
        .I4(\ram_reg[43][14]_i_7_n_6 ),
        .I5(\ram_reg[43][14]_i_7_n_5 ),
        .O(\ram[43][3]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h000000F25F25F24F)) 
    \ram[43][3]_i_5 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_6 ),
        .I2(\ram_reg[43][14]_i_7_n_7 ),
        .I3(\ram_reg[43][14]_i_7_n_5 ),
        .I4(\ram_reg[43][14]_i_7_n_4 ),
        .I5(\ram_reg[43][14]_i_8_n_3 ),
        .O(\ram[43][3]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h0D0C03090E071C9E)) 
    \ram[43][3]_i_6 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_6 ),
        .I4(\ram_reg[43][14]_i_7_n_4 ),
        .I5(\ram_reg[43][14]_i_7_n_5 ),
        .O(\ram[43][3]_i_6_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \ram[43][4]_i_1 
       (.I0(\ram_reg[43][4]_i_2_n_0 ),
        .I1(\ram_reg[43][14]_i_3_n_7 ),
        .I2(\ram[43][4]_i_3_n_0 ),
        .I3(\ram_reg[43][14]_i_3_n_6 ),
        .I4(\ram[43][4]_i_4_n_0 ),
        .O(p_19_in[4]));
  LUT6 #(
    .INIT(64'h00000004A6D945A2)) 
    \ram[43][4]_i_3 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_7_n_5 ),
        .I3(\ram_reg[43][14]_i_7_n_6 ),
        .I4(\ram_reg[43][14]_i_7_n_4 ),
        .I5(\ram_reg[43][14]_i_8_n_3 ),
        .O(\ram[43][4]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h02050509090A0254)) 
    \ram[43][4]_i_4 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_5 ),
        .I4(\ram_reg[43][14]_i_7_n_4 ),
        .I5(\ram_reg[43][14]_i_7_n_6 ),
        .O(\ram[43][4]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h00000002E7188A65)) 
    \ram[43][4]_i_5 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_5 ),
        .I2(\ram_reg[43][14]_i_7_n_7 ),
        .I3(\ram_reg[43][14]_i_7_n_6 ),
        .I4(\ram_reg[43][14]_i_7_n_4 ),
        .I5(\ram_reg[43][14]_i_8_n_3 ),
        .O(\ram[43][4]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h05090D2A0A040295)) 
    \ram[43][4]_i_6 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_4 ),
        .I4(\ram_reg[43][14]_i_7_n_5 ),
        .I5(\ram_reg[43][14]_i_7_n_6 ),
        .O(\ram[43][4]_i_6_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \ram[43][5]_i_1 
       (.I0(\ram_reg[43][5]_i_2_n_0 ),
        .I1(\ram_reg[43][14]_i_3_n_7 ),
        .I2(\ram[43][5]_i_3_n_0 ),
        .I3(\ram_reg[43][14]_i_3_n_6 ),
        .I4(\ram[43][5]_i_4_n_0 ),
        .O(p_19_in[5]));
  LUT6 #(
    .INIT(64'h0E0D070E07BF0997)) 
    \ram[43][5]_i_3 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_4 ),
        .I4(\ram_reg[43][14]_i_7_n_6 ),
        .I5(\ram_reg[43][14]_i_7_n_5 ),
        .O(\ram[43][5]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h030D090E0F6B07FD)) 
    \ram[43][5]_i_4 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_5 ),
        .I4(\ram_reg[43][14]_i_7_n_6 ),
        .I5(\ram_reg[43][14]_i_7_n_4 ),
        .O(\ram[43][5]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h0F09030D0E970FEB)) 
    \ram[43][5]_i_5 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_5 ),
        .I4(\ram_reg[43][14]_i_7_n_6 ),
        .I5(\ram_reg[43][14]_i_7_n_4 ),
        .O(\ram[43][5]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h0C0B075E0E0D03BF)) 
    \ram[43][5]_i_6 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_4 ),
        .I4(\ram_reg[43][14]_i_7_n_5 ),
        .I5(\ram_reg[43][14]_i_7_n_6 ),
        .O(\ram[43][5]_i_6_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \ram[43][6]_i_1 
       (.I0(\ram[43][6]_i_2_n_0 ),
        .I1(\ram_reg[43][14]_i_3_n_6 ),
        .I2(\ram[43][6]_i_3_n_0 ),
        .I3(\ram_reg[43][14]_i_3_n_7 ),
        .I4(\ram[43][6]_i_4_n_0 ),
        .O(p_19_in[6]));
  LUT6 #(
    .INIT(64'h0C0B0F3E0E0D071F)) 
    \ram[43][6]_i_2 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_4 ),
        .I4(\ram_reg[43][14]_i_7_n_5 ),
        .I5(\ram_reg[43][14]_i_7_n_6 ),
        .O(\ram[43][6]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h0000080EFE3F97DB)) 
    \ram[43][6]_i_3 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_7_n_4 ),
        .I3(\ram_reg[43][14]_i_7_n_6 ),
        .I4(\ram_reg[43][14]_i_7_n_5 ),
        .I5(\ram_reg[43][14]_i_8_n_3 ),
        .O(\ram[43][6]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \ram[43][6]_i_4 
       (.I0(\ram[42][12]_i_3_n_0 ),
        .I1(\ram_reg[43][14]_i_3_n_6 ),
        .I2(\ram[43][6]_i_5_n_0 ),
        .I3(\ram_reg[43][14]_i_3_n_1 ),
        .I4(\ram[43][6]_i_6_n_0 ),
        .O(\ram[43][6]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT5 #(
    .INIT(32'h13312F36)) 
    \ram[43][6]_i_5 
       (.I0(\ram_reg[43][14]_i_7_n_7 ),
        .I1(\ram_reg[43][14]_i_8_n_3 ),
        .I2(\ram_reg[43][14]_i_7_n_4 ),
        .I3(\ram_reg[43][14]_i_7_n_6 ),
        .I4(\ram_reg[43][14]_i_7_n_5 ),
        .O(\ram[43][6]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT5 #(
    .INIT(32'h0D0A0FB7)) 
    \ram[43][6]_i_6 
       (.I0(\ram_reg[43][14]_i_7_n_7 ),
        .I1(\ram_reg[43][14]_i_7_n_6 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_5 ),
        .I4(\ram_reg[43][14]_i_7_n_4 ),
        .O(\ram[43][6]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hB8B8B8B8FF33CC00)) 
    \ram[43][7]_i_1 
       (.I0(\ram[43][7]_i_2_n_0 ),
        .I1(\ram_reg[43][14]_i_3_n_6 ),
        .I2(\ram[43][7]_i_3_n_0 ),
        .I3(\ram[43][7]_i_4_n_0 ),
        .I4(\ram[43][7]_i_5_n_0 ),
        .I5(\ram_reg[43][14]_i_3_n_7 ),
        .O(p_19_in[7]));
  LUT6 #(
    .INIT(64'h0D0B0A5606010D2B)) 
    \ram[43][7]_i_2 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_5 ),
        .I4(\ram_reg[43][14]_i_7_n_4 ),
        .I5(\ram_reg[43][14]_i_7_n_6 ),
        .O(\ram[43][7]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h0B0608D5010B0D6A)) 
    \ram[43][7]_i_3 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_4 ),
        .I4(\ram_reg[43][14]_i_7_n_5 ),
        .I5(\ram_reg[43][14]_i_7_n_6 ),
        .O(\ram[43][7]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h060D0B06012B08D5)) 
    \ram[43][7]_i_4 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_4 ),
        .I4(\ram_reg[43][14]_i_7_n_6 ),
        .I5(\ram_reg[43][14]_i_7_n_5 ),
        .O(\ram[43][7]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h050B0D6A080506BD)) 
    \ram[43][7]_i_5 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_4 ),
        .I4(\ram_reg[43][14]_i_7_n_5 ),
        .I5(\ram_reg[43][14]_i_7_n_6 ),
        .O(\ram[43][7]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hB8B8B8B8FF33CC00)) 
    \ram[43][8]_i_1 
       (.I0(\ram[43][8]_i_2_n_0 ),
        .I1(\ram_reg[43][14]_i_3_n_6 ),
        .I2(\ram[43][8]_i_3_n_0 ),
        .I3(\ram[43][8]_i_4_n_0 ),
        .I4(\ram[43][8]_i_5_n_0 ),
        .I5(\ram_reg[43][14]_i_3_n_7 ),
        .O(p_19_in[8]));
  LUT6 #(
    .INIT(64'h00EE007F05B70E9B)) 
    \ram[43][8]_i_2 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_7_n_4 ),
        .I3(\ram_reg[43][14]_i_8_n_3 ),
        .I4(\ram_reg[43][14]_i_7_n_6 ),
        .I5(\ram_reg[43][14]_i_7_n_5 ),
        .O(\ram[43][8]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h03070D0B0EBD0F7E)) 
    \ram[43][8]_i_3 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_4 ),
        .I4(\ram_reg[43][14]_i_7_n_6 ),
        .I5(\ram_reg[43][14]_i_7_n_5 ),
        .O(\ram[43][8]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h0000060E7FB7DBCD)) 
    \ram[43][8]_i_4 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_7_n_4 ),
        .I3(\ram_reg[43][14]_i_7_n_6 ),
        .I4(\ram_reg[43][14]_i_7_n_5 ),
        .I5(\ram_reg[43][14]_i_8_n_3 ),
        .O(\ram[43][8]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h0D0B0E5E0C0D07BF)) 
    \ram[43][8]_i_5 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_4 ),
        .I4(\ram_reg[43][14]_i_7_n_5 ),
        .I5(\ram_reg[43][14]_i_7_n_6 ),
        .O(\ram[43][8]_i_5_n_0 ));
  LUT5 #(
    .INIT(32'hFF00B8B8)) 
    \ram[43][9]_i_1 
       (.I0(\ram[43][10]_i_3_n_0 ),
        .I1(\ram_reg[43][14]_i_3_n_6 ),
        .I2(\ram[43][9]_i_2_n_0 ),
        .I3(\ram[43][10]_i_4_n_0 ),
        .I4(\ram_reg[43][14]_i_3_n_7 ),
        .O(p_19_in[9]));
  LUT6 #(
    .INIT(64'h010B0C4A0A0506BD)) 
    \ram[43][9]_i_2 
       (.I0(\ram_reg[43][14]_i_3_n_1 ),
        .I1(\ram_reg[43][14]_i_7_n_7 ),
        .I2(\ram_reg[43][14]_i_8_n_3 ),
        .I3(\ram_reg[43][14]_i_7_n_4 ),
        .I4(\ram_reg[43][14]_i_7_n_5 ),
        .I5(\ram_reg[43][14]_i_7_n_6 ),
        .O(\ram[43][9]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFB08FBFBFB080808)) 
    \ram[44][11]_i_1 
       (.I0(\ram_reg[45][11]_i_5_n_0 ),
        .I1(timing_sel_imm[0]),
        .I2(timing_sel_imm[1]),
        .I3(\ram[44][11]_i_2_n_0 ),
        .I4(\ram_reg[45][11]_i_3_n_6 ),
        .I5(\ram[45][11]_i_2_n_0 ),
        .O(p_20_in[11]));
  LUT6 #(
    .INIT(64'h008C0048006930C6)) 
    \ram[44][11]_i_2 
       (.I0(\ram_reg[45][11]_i_3_n_1 ),
        .I1(\ram[45][11]_i_6_n_0 ),
        .I2(\ram_reg[45][11]_i_7_n_6 ),
        .I3(\ram_reg[45][11]_i_8_n_3 ),
        .I4(\ram_reg[45][11]_i_7_n_4 ),
        .I5(\ram_reg[45][11]_i_7_n_5 ),
        .O(\ram[44][11]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFB08FBFBFB080808)) 
    \ram[44][12]_i_1 
       (.I0(\ram[45][12]_i_3_n_0 ),
        .I1(timing_sel_imm[0]),
        .I2(timing_sel_imm[1]),
        .I3(\ram[44][12]_i_2_n_0 ),
        .I4(\ram_reg[45][11]_i_3_n_6 ),
        .I5(\ram[44][12]_i_3_n_0 ),
        .O(p_20_in[12]));
  LUT6 #(
    .INIT(64'h0000028002040020)) 
    \ram[44][12]_i_2 
       (.I0(\ram_reg[45][11]_i_3_n_1 ),
        .I1(\ram_reg[45][11]_i_7_n_5 ),
        .I2(\ram_reg[45][11]_i_7_n_4 ),
        .I3(\ram_reg[45][11]_i_8_n_3 ),
        .I4(\ram_reg[45][11]_i_7_n_6 ),
        .I5(\ram[45][11]_i_6_n_0 ),
        .O(\ram[44][12]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h0000450810228040)) 
    \ram[44][12]_i_3 
       (.I0(\ram_reg[45][11]_i_3_n_1 ),
        .I1(\ram_reg[45][11]_i_7_n_5 ),
        .I2(\ram[45][11]_i_6_n_0 ),
        .I3(\ram_reg[45][11]_i_7_n_6 ),
        .I4(\ram_reg[45][11]_i_8_n_3 ),
        .I5(\ram_reg[45][11]_i_7_n_4 ),
        .O(\ram[44][12]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFB08FBFBFB080808)) 
    \ram[44][15]_i_1 
       (.I0(\ram[45][15]_i_3_n_0 ),
        .I1(timing_sel_imm[0]),
        .I2(timing_sel_imm[1]),
        .I3(\ram[44][15]_i_2_n_0 ),
        .I4(\ram_reg[45][11]_i_3_n_6 ),
        .I5(\ram[44][15]_i_3_n_0 ),
        .O(p_20_in[15]));
  LUT6 #(
    .INIT(64'h0063005A00522D31)) 
    \ram[44][15]_i_2 
       (.I0(\ram_reg[45][11]_i_3_n_1 ),
        .I1(\ram[45][11]_i_6_n_0 ),
        .I2(\ram_reg[45][11]_i_7_n_6 ),
        .I3(\ram_reg[45][11]_i_8_n_3 ),
        .I4(\ram_reg[45][11]_i_7_n_5 ),
        .I5(\ram_reg[45][11]_i_7_n_4 ),
        .O(\ram[44][15]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h000048D20069958C)) 
    \ram[44][15]_i_3 
       (.I0(\ram_reg[45][11]_i_3_n_1 ),
        .I1(\ram[45][11]_i_6_n_0 ),
        .I2(\ram_reg[45][11]_i_7_n_6 ),
        .I3(\ram_reg[45][11]_i_7_n_5 ),
        .I4(\ram_reg[45][11]_i_8_n_3 ),
        .I5(\ram_reg[45][11]_i_7_n_4 ),
        .O(\ram[44][15]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \ram[44][38]_i_1 
       (.I0(\ram_reg[44]_1 [38]),
        .I1(\ram_reg[26][0]_0 ),
        .O(\ram[44][38]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFB08FBFBFB080808)) 
    \ram[44][8]_i_1 
       (.I0(\ram_reg[45][8]_i_4_n_0 ),
        .I1(timing_sel_imm[0]),
        .I2(timing_sel_imm[1]),
        .I3(\ram[44][8]_i_2_n_0 ),
        .I4(\ram_reg[45][11]_i_3_n_6 ),
        .I5(\ram[45][8]_i_2_n_0 ),
        .O(p_20_in[8]));
  LUT6 #(
    .INIT(64'h0004020000100180)) 
    \ram[44][8]_i_2 
       (.I0(\ram_reg[45][11]_i_3_n_1 ),
        .I1(\ram[45][11]_i_6_n_0 ),
        .I2(\ram_reg[45][11]_i_7_n_4 ),
        .I3(\ram_reg[45][11]_i_8_n_3 ),
        .I4(\ram_reg[45][11]_i_7_n_5 ),
        .I5(\ram_reg[45][11]_i_7_n_6 ),
        .O(\ram[44][8]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFB8FF0000B800)) 
    \ram[45][11]_i_1 
       (.I0(\ram[45][11]_i_2_n_0 ),
        .I1(\ram_reg[45][11]_i_3_n_6 ),
        .I2(\ram[45][11]_i_4_n_0 ),
        .I3(timing_sel_imm[0]),
        .I4(timing_sel_imm[1]),
        .I5(\ram_reg[45][11]_i_5_n_0 ),
        .O(p_21_in[11]));
  LUT2 #(
    .INIT(4'h6)) 
    \ram[45][11]_i_10 
       (.I0(timing_sel_imm[0]),
        .I1(timing_sel_imm[1]),
        .O(\ram[45][11]_i_10_n_0 ));
  LUT2 #(
    .INIT(4'hB)) 
    \ram[45][11]_i_11 
       (.I0(timing_sel_imm[1]),
        .I1(timing_sel_imm[0]),
        .O(\ram[45][11]_i_11_n_0 ));
  LUT6 #(
    .INIT(64'h000000D291A52B18)) 
    \ram[45][11]_i_12 
       (.I0(\ram_reg[45][11]_i_3_n_1 ),
        .I1(\ram[45][11]_i_6_n_0 ),
        .I2(\ram_reg[45][11]_i_7_n_6 ),
        .I3(\ram_reg[45][11]_i_7_n_5 ),
        .I4(\ram_reg[45][11]_i_7_n_4 ),
        .I5(\ram_reg[45][11]_i_8_n_3 ),
        .O(\ram[45][11]_i_12_n_0 ));
  LUT6 #(
    .INIT(64'h0000C6A40058B463)) 
    \ram[45][11]_i_13 
       (.I0(\ram_reg[45][11]_i_3_n_1 ),
        .I1(\ram[45][11]_i_6_n_0 ),
        .I2(\ram_reg[45][11]_i_7_n_6 ),
        .I3(\ram_reg[45][11]_i_7_n_4 ),
        .I4(\ram_reg[45][11]_i_8_n_3 ),
        .I5(\ram_reg[45][11]_i_7_n_5 ),
        .O(\ram[45][11]_i_13_n_0 ));
  LUT2 #(
    .INIT(4'hB)) 
    \ram[45][11]_i_14 
       (.I0(timing_sel_imm[1]),
        .I1(timing_sel_imm[0]),
        .O(\ram[45][11]_i_14_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \ram[45][11]_i_15 
       (.I0(timing_sel_imm[1]),
        .I1(timing_sel_imm[0]),
        .O(\ram[45][11]_i_15_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \ram[45][11]_i_16 
       (.I0(timing_sel_imm[0]),
        .I1(timing_sel_imm[1]),
        .O(\ram[45][11]_i_16_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \ram[45][11]_i_17 
       (.I0(timing_sel_imm[1]),
        .I1(timing_sel_imm[0]),
        .O(\ram[45][11]_i_17_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \ram[45][11]_i_18 
       (.I0(timing_sel_imm[0]),
        .I1(timing_sel_imm[1]),
        .O(\ram[45][11]_i_18_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \ram[45][11]_i_19 
       (.I0(timing_sel_imm[1]),
        .I1(timing_sel_imm[0]),
        .O(\ram[45][11]_i_19_n_0 ));
  LUT6 #(
    .INIT(64'h0063004A0052A531)) 
    \ram[45][11]_i_2 
       (.I0(\ram_reg[45][11]_i_3_n_1 ),
        .I1(\ram[45][11]_i_6_n_0 ),
        .I2(\ram_reg[45][11]_i_7_n_6 ),
        .I3(\ram_reg[45][11]_i_8_n_3 ),
        .I4(\ram_reg[45][11]_i_7_n_5 ),
        .I5(\ram_reg[45][11]_i_7_n_4 ),
        .O(\ram[45][11]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h000018D20061918C)) 
    \ram[45][11]_i_4 
       (.I0(\ram_reg[45][11]_i_3_n_1 ),
        .I1(\ram[45][11]_i_6_n_0 ),
        .I2(\ram_reg[45][11]_i_7_n_6 ),
        .I3(\ram_reg[45][11]_i_7_n_5 ),
        .I4(\ram_reg[45][11]_i_8_n_3 ),
        .I5(\ram_reg[45][11]_i_7_n_4 ),
        .O(\ram[45][11]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair17" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \ram[45][11]_i_6 
       (.I0(timing_sel_imm[0]),
        .I1(timing_sel_imm[1]),
        .O(\ram[45][11]_i_6_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \ram[45][11]_i_9 
       (.I0(timing_sel_imm[1]),
        .I1(timing_sel_imm[0]),
        .O(\ram[45][11]_i_9_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT4 #(
    .INIT(16'hFB08)) 
    \ram[45][12]_i_1 
       (.I0(\ram[45][12]_i_2_n_0 ),
        .I1(timing_sel_imm[0]),
        .I2(timing_sel_imm[1]),
        .I3(\ram[45][12]_i_3_n_0 ),
        .O(p_21_in[12]));
  (* SOFT_HLUTNM = "soft_lutpair16" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \ram[45][12]_i_2 
       (.I0(\ram[44][12]_i_3_n_0 ),
        .I1(\ram_reg[45][11]_i_3_n_6 ),
        .I2(\ram[45][12]_i_4_n_0 ),
        .O(\ram[45][12]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair16" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \ram[45][12]_i_3 
       (.I0(\ram[45][12]_i_5_n_0 ),
        .I1(\ram_reg[45][11]_i_3_n_6 ),
        .I2(\ram[45][4]_i_2_n_0 ),
        .O(\ram[45][12]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h0000102000500400)) 
    \ram[45][12]_i_4 
       (.I0(\ram_reg[45][11]_i_3_n_1 ),
        .I1(\ram[45][11]_i_6_n_0 ),
        .I2(\ram_reg[45][11]_i_7_n_6 ),
        .I3(\ram_reg[45][11]_i_7_n_4 ),
        .I4(\ram_reg[45][11]_i_8_n_3 ),
        .I5(\ram_reg[45][11]_i_7_n_5 ),
        .O(\ram[45][12]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h00A4000800011400)) 
    \ram[45][12]_i_5 
       (.I0(\ram_reg[45][11]_i_3_n_1 ),
        .I1(\ram[45][11]_i_6_n_0 ),
        .I2(\ram_reg[45][11]_i_7_n_6 ),
        .I3(\ram_reg[45][11]_i_8_n_3 ),
        .I4(\ram_reg[45][11]_i_7_n_4 ),
        .I5(\ram_reg[45][11]_i_7_n_5 ),
        .O(\ram[45][12]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT4 #(
    .INIT(16'hFB08)) 
    \ram[45][15]_i_1 
       (.I0(\ram[45][15]_i_2_n_0 ),
        .I1(timing_sel_imm[0]),
        .I2(timing_sel_imm[1]),
        .I3(\ram[45][15]_i_3_n_0 ),
        .O(p_21_in[15]));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \ram[45][15]_i_2 
       (.I0(\ram[44][15]_i_3_n_0 ),
        .I1(\ram_reg[45][11]_i_3_n_6 ),
        .I2(\ram[45][15]_i_4_n_0 ),
        .I3(\ram_reg[45][11]_i_3_n_1 ),
        .I4(\ram[45][15]_i_5_n_0 ),
        .O(\ram[45][15]_i_2_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \ram[45][15]_i_3 
       (.I0(\ram[45][15]_i_6_n_0 ),
        .I1(\ram_reg[45][11]_i_3_n_6 ),
        .I2(\ram[45][7]_i_2_n_0 ),
        .O(\ram[45][15]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h002D00F000F00FDD)) 
    \ram[45][15]_i_4 
       (.I0(timing_sel_imm[0]),
        .I1(timing_sel_imm[1]),
        .I2(\ram_reg[45][11]_i_7_n_6 ),
        .I3(\ram_reg[45][11]_i_8_n_3 ),
        .I4(\ram_reg[45][11]_i_7_n_5 ),
        .I5(\ram_reg[45][11]_i_7_n_4 ),
        .O(\ram[45][15]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h0000220200F0D22D)) 
    \ram[45][15]_i_5 
       (.I0(timing_sel_imm[0]),
        .I1(timing_sel_imm[1]),
        .I2(\ram_reg[45][11]_i_7_n_6 ),
        .I3(\ram_reg[45][11]_i_7_n_4 ),
        .I4(\ram_reg[45][11]_i_8_n_3 ),
        .I5(\ram_reg[45][11]_i_7_n_5 ),
        .O(\ram[45][15]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h0000004691A52B18)) 
    \ram[45][15]_i_6 
       (.I0(\ram_reg[45][11]_i_3_n_1 ),
        .I1(\ram[45][11]_i_6_n_0 ),
        .I2(\ram_reg[45][11]_i_7_n_6 ),
        .I3(\ram_reg[45][11]_i_7_n_5 ),
        .I4(\ram_reg[45][11]_i_7_n_4 ),
        .I5(\ram_reg[45][11]_i_8_n_3 ),
        .O(\ram[45][15]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFB8FF0000B800)) 
    \ram[45][4]_i_1 
       (.I0(\ram[45][4]_i_2_n_0 ),
        .I1(\ram_reg[45][11]_i_3_n_6 ),
        .I2(\ram[45][4]_i_3_n_0 ),
        .I3(timing_sel_imm[0]),
        .I4(timing_sel_imm[1]),
        .I5(\ram[45][12]_i_2_n_0 ),
        .O(p_21_in[4]));
  LUT6 #(
    .INIT(64'h00040A0000100480)) 
    \ram[45][4]_i_2 
       (.I0(\ram_reg[45][11]_i_3_n_1 ),
        .I1(\ram[45][11]_i_6_n_0 ),
        .I2(\ram_reg[45][11]_i_7_n_4 ),
        .I3(\ram_reg[45][11]_i_8_n_3 ),
        .I4(\ram_reg[45][11]_i_7_n_5 ),
        .I5(\ram_reg[45][11]_i_7_n_6 ),
        .O(\ram[45][4]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h0000481000290200)) 
    \ram[45][4]_i_3 
       (.I0(\ram_reg[45][11]_i_3_n_1 ),
        .I1(\ram[45][11]_i_6_n_0 ),
        .I2(\ram_reg[45][11]_i_7_n_6 ),
        .I3(\ram_reg[45][11]_i_7_n_4 ),
        .I4(\ram_reg[45][11]_i_8_n_3 ),
        .I5(\ram_reg[45][11]_i_7_n_5 ),
        .O(\ram[45][4]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFB8FF0000B800)) 
    \ram[45][7]_i_1 
       (.I0(\ram[45][7]_i_2_n_0 ),
        .I1(\ram_reg[45][11]_i_3_n_6 ),
        .I2(\ram[45][7]_i_3_n_0 ),
        .I3(timing_sel_imm[0]),
        .I4(timing_sel_imm[1]),
        .I5(\ram[45][15]_i_2_n_0 ),
        .O(p_21_in[7]));
  LUT6 #(
    .INIT(64'h008C00480069B1C6)) 
    \ram[45][7]_i_2 
       (.I0(\ram_reg[45][11]_i_3_n_1 ),
        .I1(\ram[45][11]_i_6_n_0 ),
        .I2(\ram_reg[45][11]_i_7_n_6 ),
        .I3(\ram_reg[45][11]_i_8_n_3 ),
        .I4(\ram_reg[45][11]_i_7_n_4 ),
        .I5(\ram_reg[45][11]_i_7_n_5 ),
        .O(\ram[45][7]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h0023004A00568D31)) 
    \ram[45][7]_i_3 
       (.I0(\ram_reg[45][11]_i_3_n_1 ),
        .I1(\ram[45][11]_i_6_n_0 ),
        .I2(\ram_reg[45][11]_i_7_n_6 ),
        .I3(\ram_reg[45][11]_i_8_n_3 ),
        .I4(\ram_reg[45][11]_i_7_n_5 ),
        .I5(\ram_reg[45][11]_i_7_n_4 ),
        .O(\ram[45][7]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFB8FF0000B800)) 
    \ram[45][8]_i_1 
       (.I0(\ram[45][8]_i_2_n_0 ),
        .I1(\ram_reg[45][11]_i_3_n_6 ),
        .I2(\ram[45][8]_i_3_n_0 ),
        .I3(timing_sel_imm[0]),
        .I4(timing_sel_imm[1]),
        .I5(\ram_reg[45][8]_i_4_n_0 ),
        .O(p_21_in[8]));
  LUT6 #(
    .INIT(64'h0000082000240210)) 
    \ram[45][8]_i_2 
       (.I0(\ram_reg[45][11]_i_3_n_1 ),
        .I1(\ram_reg[45][11]_i_7_n_5 ),
        .I2(\ram_reg[45][11]_i_8_n_3 ),
        .I3(\ram_reg[45][11]_i_7_n_4 ),
        .I4(\ram_reg[45][11]_i_7_n_6 ),
        .I5(\ram[45][11]_i_6_n_0 ),
        .O(\ram[45][8]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h0000004202108000)) 
    \ram[45][8]_i_3 
       (.I0(\ram_reg[45][11]_i_3_n_1 ),
        .I1(\ram[45][11]_i_6_n_0 ),
        .I2(\ram_reg[45][11]_i_7_n_6 ),
        .I3(\ram_reg[45][11]_i_7_n_5 ),
        .I4(\ram_reg[45][11]_i_7_n_4 ),
        .I5(\ram_reg[45][11]_i_8_n_3 ),
        .O(\ram[45][8]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h0008A00000044180)) 
    \ram[45][8]_i_5 
       (.I0(\ram_reg[45][11]_i_3_n_1 ),
        .I1(\ram[45][11]_i_6_n_0 ),
        .I2(\ram_reg[45][11]_i_7_n_5 ),
        .I3(\ram_reg[45][11]_i_7_n_4 ),
        .I4(\ram_reg[45][11]_i_8_n_3 ),
        .I5(\ram_reg[45][11]_i_7_n_6 ),
        .O(\ram[45][8]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h0000000400522000)) 
    \ram[45][8]_i_6 
       (.I0(\ram_reg[45][11]_i_3_n_1 ),
        .I1(\ram[45][11]_i_6_n_0 ),
        .I2(\ram_reg[45][11]_i_7_n_6 ),
        .I3(\ram_reg[45][11]_i_7_n_5 ),
        .I4(\ram_reg[45][11]_i_8_n_3 ),
        .I5(\ram_reg[45][11]_i_7_n_4 ),
        .O(\ram[45][8]_i_6_n_0 ));
  LUT2 #(
    .INIT(4'h7)) 
    \ram_addr[0]_i_1 
       (.I0(current_state[2]),
        .I1(ram_addr[0]),
        .O(\ram_addr[0]_i_1_n_0 ));
  LUT3 #(
    .INIT(8'h6F)) 
    \ram_addr[1]_i_1 
       (.I0(ram_addr[1]),
        .I1(ram_addr[0]),
        .I2(current_state[2]),
        .O(\ram_addr[1]_i_1_n_0 ));
  LUT4 #(
    .INIT(16'h6AFF)) 
    \ram_addr[2]_i_1 
       (.I0(ram_addr[2]),
        .I1(ram_addr[1]),
        .I2(ram_addr[0]),
        .I3(current_state[2]),
        .O(\ram_addr[2]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h2AAAFFFF80000000)) 
    \ram_addr[3]_i_1 
       (.I0(current_state[2]),
        .I1(ram_addr[2]),
        .I2(ram_addr[0]),
        .I3(ram_addr[1]),
        .I4(\ram_addr[4]_i_2_n_0 ),
        .I5(ram_addr[3]),
        .O(\ram_addr[3]_i_1_n_0 ));
  LUT4 #(
    .INIT(16'h0004)) 
    \ram_addr[4]_i_1 
       (.I0(current_state[2]),
        .I1(current_state[0]),
        .I2(current_state[3]),
        .I3(current_state[1]),
        .O(\ram_addr[4]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'h40444004)) 
    \ram_addr[4]_i_2 
       (.I0(current_state[3]),
        .I1(current_state[0]),
        .I2(current_state[1]),
        .I3(current_state[2]),
        .I4(\ram_addr_reg[0]_0 ),
        .O(\ram_addr[4]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h6AAAAAAAFFFFFFFF)) 
    \ram_addr[4]_i_3 
       (.I0(ram_addr[4]),
        .I1(ram_addr[3]),
        .I2(ram_addr[1]),
        .I3(ram_addr[0]),
        .I4(ram_addr[2]),
        .I5(current_state[2]),
        .O(\ram_addr[4]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'h2AFF8000)) 
    \ram_addr[5]_i_1 
       (.I0(current_state[2]),
        .I1(ram_addr[4]),
        .I2(\ram_addr[5]_i_2_n_0 ),
        .I3(\ram_addr[4]_i_2_n_0 ),
        .I4(ram_addr[5]),
        .O(\ram_addr[5]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT4 #(
    .INIT(16'h8000)) 
    \ram_addr[5]_i_2 
       (.I0(ram_addr[3]),
        .I1(ram_addr[1]),
        .I2(ram_addr[0]),
        .I3(ram_addr[2]),
        .O(\ram_addr[5]_i_2_n_0 ));
  FDRE \ram_addr_reg[0] 
       (.C(CLK),
        .CE(\ram_addr[4]_i_2_n_0 ),
        .D(\ram_addr[0]_i_1_n_0 ),
        .Q(ram_addr[0]),
        .R(\ram_addr[4]_i_1_n_0 ));
  FDRE \ram_addr_reg[1] 
       (.C(CLK),
        .CE(\ram_addr[4]_i_2_n_0 ),
        .D(\ram_addr[1]_i_1_n_0 ),
        .Q(ram_addr[1]),
        .R(\ram_addr[4]_i_1_n_0 ));
  FDRE \ram_addr_reg[2] 
       (.C(CLK),
        .CE(\ram_addr[4]_i_2_n_0 ),
        .D(\ram_addr[2]_i_1_n_0 ),
        .Q(ram_addr[2]),
        .R(\ram_addr[4]_i_1_n_0 ));
  FDRE \ram_addr_reg[3] 
       (.C(CLK),
        .CE(1'b1),
        .D(\ram_addr[3]_i_1_n_0 ),
        .Q(ram_addr[3]),
        .R(1'b0));
  FDRE \ram_addr_reg[4] 
       (.C(CLK),
        .CE(\ram_addr[4]_i_2_n_0 ),
        .D(\ram_addr[4]_i_3_n_0 ),
        .Q(ram_addr[4]),
        .R(\ram_addr[4]_i_1_n_0 ));
  FDRE \ram_addr_reg[5] 
       (.C(CLK),
        .CE(1'b1),
        .D(\ram_addr[5]_i_1_n_0 ),
        .Q(ram_addr[5]),
        .R(1'b0));
  LUT6 #(
    .INIT(64'h00E2FFFF00E20000)) 
    \ram_do[0]_i_1 
       (.I0(\ram_do[0]_i_2_n_0 ),
        .I1(ram_addr[3]),
        .I2(\ram_do[0]_i_3_n_0 ),
        .I3(ram_addr[4]),
        .I4(ram_addr[5]),
        .I5(\ram_do[0]_i_4_n_0 ),
        .O(ram[0]));
  LUT6 #(
    .INIT(64'hA000A000CFFFC000)) 
    \ram_do[0]_i_2 
       (.I0(\ram_reg[39]_6 [0]),
        .I1(\ram_reg[38]_7 [0]),
        .I2(ram_addr[1]),
        .I3(ram_addr[2]),
        .I4(\ram_reg[40]_5 [7]),
        .I5(ram_addr[0]),
        .O(\ram_do[0]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000F8C83808)) 
    \ram_do[0]_i_3 
       (.I0(\ram_reg[41]_4 [0]),
        .I1(ram_addr[0]),
        .I2(ram_addr[1]),
        .I3(\ram_reg[42]_3 [0]),
        .I4(\ram_reg[43]_2 [0]),
        .I5(ram_addr[2]),
        .O(\ram_do[0]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hBBB8BBB88888888B)) 
    \ram_do[0]_i_4 
       (.I0(\ram_do[0]_i_5_n_0 ),
        .I1(ram_addr[4]),
        .I2(ram_addr[3]),
        .I3(ram_addr[2]),
        .I4(ram_addr[1]),
        .I5(ram_addr[0]),
        .O(\ram_do[0]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hB888BBBB88BB8888)) 
    \ram_do[0]_i_5 
       (.I0(\ram_do[0]_i_6_n_0 ),
        .I1(ram_addr[3]),
        .I2(\ram_reg[23]_11 ),
        .I3(ram_addr[0]),
        .I4(ram_addr[2]),
        .I5(ram_addr[1]),
        .O(\ram_do[0]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h0033B8880000B888)) 
    \ram_do[0]_i_6 
       (.I0(\ram_reg[40]_5 [7]),
        .I1(ram_addr[2]),
        .I2(\ram_reg[26]_9 [0]),
        .I3(ram_addr[1]),
        .I4(ram_addr[0]),
        .I5(\ram_reg[25]_10 [8]),
        .O(\ram_do[0]_i_6_n_0 ));
  LUT5 #(
    .INIT(32'h30BB3088)) 
    \ram_do[10]_i_1 
       (.I0(\ram_do_reg[10]_i_2_n_0 ),
        .I1(ram_addr[5]),
        .I2(\ram_do[10]_i_3_n_0 ),
        .I3(ram_addr[4]),
        .I4(\ram_do[10]_i_4_n_0 ),
        .O(ram[10]));
  LUT6 #(
    .INIT(64'h3033008800003300)) 
    \ram_do[10]_i_3 
       (.I0(\ram_reg[25]_10 [10]),
        .I1(ram_addr[3]),
        .I2(\ram_reg[23]_11 ),
        .I3(ram_addr[2]),
        .I4(ram_addr[1]),
        .I5(ram_addr[0]),
        .O(\ram_do[10]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'h01)) 
    \ram_do[10]_i_4 
       (.I0(ram_addr[0]),
        .I1(ram_addr[2]),
        .I2(ram_addr[3]),
        .O(\ram_do[10]_i_4_n_0 ));
  LUT5 #(
    .INIT(32'hA0800080)) 
    \ram_do[10]_i_5 
       (.I0(ram_addr[2]),
        .I1(\ram_reg[37]_8 [10]),
        .I2(ram_addr[0]),
        .I3(ram_addr[1]),
        .I4(\ram_reg[39]_6 [10]),
        .O(\ram_do[10]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h00000000F4A45404)) 
    \ram_do[10]_i_6 
       (.I0(ram_addr[0]),
        .I1(\ram_reg[40]_5 [10]),
        .I2(ram_addr[1]),
        .I3(\ram_reg[42]_3 [10]),
        .I4(\ram_reg[43]_2 [10]),
        .I5(ram_addr[2]),
        .O(\ram_do[10]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h00E2FFFF00E20000)) 
    \ram_do[11]_i_1 
       (.I0(\ram_do[11]_i_2_n_0 ),
        .I1(ram_addr[3]),
        .I2(\ram_do[11]_i_3_n_0 ),
        .I3(ram_addr[4]),
        .I4(ram_addr[5]),
        .I5(\ram_do[11]_i_4_n_0 ),
        .O(ram[11]));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT4 #(
    .INIT(16'h0080)) 
    \ram_do[11]_i_2 
       (.I0(ram_addr[2]),
        .I1(\ram_reg[40]_5 [13]),
        .I2(ram_addr[0]),
        .I3(ram_addr[1]),
        .O(\ram_do[11]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00E2FFFF00E20000)) 
    \ram_do[11]_i_3 
       (.I0(\ram_reg[44]_1 [11]),
        .I1(ram_addr[0]),
        .I2(\ram_reg[45]_0 [11]),
        .I3(ram_addr[1]),
        .I4(ram_addr[2]),
        .I5(\ram_do[11]_i_5_n_0 ),
        .O(\ram_do[11]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h000000008CCC00C3)) 
    \ram_do[11]_i_4 
       (.I0(\ram_reg[23]_11 ),
        .I1(ram_addr[4]),
        .I2(ram_addr[2]),
        .I3(ram_addr[1]),
        .I4(ram_addr[0]),
        .I5(ram_addr[3]),
        .O(\ram_do[11]_i_4_n_0 ));
  LUT5 #(
    .INIT(32'hA0A0CFC0)) 
    \ram_do[11]_i_5 
       (.I0(\ram_reg[43]_2 [11]),
        .I1(\ram_reg[42]_3 [11]),
        .I2(ram_addr[1]),
        .I3(\ram_reg[40]_5 [11]),
        .I4(ram_addr[0]),
        .O(\ram_do[11]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h00E2FFFF00E20000)) 
    \ram_do[12]_i_1 
       (.I0(\ram_do[12]_i_2_n_0 ),
        .I1(ram_addr[3]),
        .I2(\ram_do[12]_i_3_n_0 ),
        .I3(ram_addr[4]),
        .I4(ram_addr[5]),
        .I5(\ram_do[12]_i_4_n_0 ),
        .O(ram[12]));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT4 #(
    .INIT(16'h0080)) 
    \ram_do[12]_i_2 
       (.I0(ram_addr[2]),
        .I1(ram_addr[0]),
        .I2(\ram_reg[40]_5 [14]),
        .I3(ram_addr[1]),
        .O(\ram_do[12]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00E2FFFF00E20000)) 
    \ram_do[12]_i_3 
       (.I0(\ram_reg[44]_1 [12]),
        .I1(ram_addr[0]),
        .I2(\ram_reg[45]_0 [12]),
        .I3(ram_addr[1]),
        .I4(ram_addr[2]),
        .I5(\ram_do[12]_i_5_n_0 ),
        .O(\ram_do[12]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h083C0C0C0C000C03)) 
    \ram_do[12]_i_4 
       (.I0(\ram_reg[23]_11 ),
        .I1(ram_addr[4]),
        .I2(ram_addr[3]),
        .I3(ram_addr[0]),
        .I4(ram_addr[1]),
        .I5(ram_addr[2]),
        .O(\ram_do[12]_i_4_n_0 ));
  LUT5 #(
    .INIT(32'hA0A0CFC0)) 
    \ram_do[12]_i_5 
       (.I0(\ram_reg[43]_2 [12]),
        .I1(\ram_reg[42]_3 [12]),
        .I2(ram_addr[1]),
        .I3(\ram_reg[40]_5 [12]),
        .I4(ram_addr[0]),
        .O(\ram_do[12]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h00E2FFFF00E20000)) 
    \ram_do[13]_i_1 
       (.I0(\ram_do[13]_i_2_n_0 ),
        .I1(ram_addr[3]),
        .I2(\ram_do[13]_i_3_n_0 ),
        .I3(ram_addr[4]),
        .I4(ram_addr[5]),
        .I5(\ram_do[13]_i_4_n_0 ),
        .O(ram[13]));
  LUT5 #(
    .INIT(32'h0A800080)) 
    \ram_do[13]_i_2 
       (.I0(ram_addr[2]),
        .I1(\ram_reg[37]_8 [13]),
        .I2(ram_addr[0]),
        .I3(ram_addr[1]),
        .I4(\ram_reg[38]_7 [13]),
        .O(\ram_do[13]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000F4A45404)) 
    \ram_do[13]_i_3 
       (.I0(ram_addr[0]),
        .I1(\ram_reg[40]_5 [13]),
        .I2(ram_addr[1]),
        .I3(\ram_reg[42]_3 [13]),
        .I4(\ram_reg[43]_2 [13]),
        .I5(ram_addr[2]),
        .O(\ram_do[13]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h0830000C0C000003)) 
    \ram_do[13]_i_4 
       (.I0(\ram_reg[23]_11 ),
        .I1(ram_addr[4]),
        .I2(ram_addr[3]),
        .I3(ram_addr[0]),
        .I4(ram_addr[1]),
        .I5(ram_addr[2]),
        .O(\ram_do[13]_i_4_n_0 ));
  LUT5 #(
    .INIT(32'h08FF0800)) 
    \ram_do[14]_i_1 
       (.I0(\ram_do[14]_i_2_n_0 ),
        .I1(ram_addr[3]),
        .I2(ram_addr[4]),
        .I3(ram_addr[5]),
        .I4(\ram_do[14]_i_3_n_0 ),
        .O(ram[14]));
  LUT6 #(
    .INIT(64'h00000000F4A45404)) 
    \ram_do[14]_i_2 
       (.I0(ram_addr[0]),
        .I1(\ram_reg[40]_5 [14]),
        .I2(ram_addr[1]),
        .I3(\ram_reg[42]_3 [14]),
        .I4(\ram_reg[43]_2 [14]),
        .I5(ram_addr[2]),
        .O(\ram_do[14]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h000000008C0C00C3)) 
    \ram_do[14]_i_3 
       (.I0(\ram_reg[23]_11 ),
        .I1(ram_addr[4]),
        .I2(ram_addr[2]),
        .I3(ram_addr[1]),
        .I4(ram_addr[0]),
        .I5(ram_addr[3]),
        .O(\ram_do[14]_i_3_n_0 ));
  LUT4 #(
    .INIT(16'h2F20)) 
    \ram_do[15]_i_1 
       (.I0(\ram_do[15]_i_2_n_0 ),
        .I1(ram_addr[4]),
        .I2(ram_addr[5]),
        .I3(\ram_do[15]_i_3_n_0 ),
        .O(ram[15]));
  LUT6 #(
    .INIT(64'h0000A80800000000)) 
    \ram_do[15]_i_2 
       (.I0(ram_addr[3]),
        .I1(\ram_reg[44]_1 [15]),
        .I2(ram_addr[0]),
        .I3(\ram_reg[45]_0 [15]),
        .I4(ram_addr[1]),
        .I5(ram_addr[2]),
        .O(\ram_do[15]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h0000000080C00003)) 
    \ram_do[15]_i_3 
       (.I0(\ram_reg[23]_11 ),
        .I1(ram_addr[4]),
        .I2(ram_addr[2]),
        .I3(ram_addr[1]),
        .I4(ram_addr[0]),
        .I5(ram_addr[3]),
        .O(\ram_do[15]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h00E2FFFF00E20000)) 
    \ram_do[1]_i_1 
       (.I0(\ram_do[1]_i_2_n_0 ),
        .I1(ram_addr[3]),
        .I2(\ram_do[1]_i_3_n_0 ),
        .I3(ram_addr[4]),
        .I4(ram_addr[5]),
        .I5(\ram_do[1]_i_4_n_0 ),
        .O(ram[1]));
  LUT5 #(
    .INIT(32'h8A800000)) 
    \ram_do[1]_i_2 
       (.I0(ram_addr[2]),
        .I1(\ram_reg[39]_6 [8]),
        .I2(ram_addr[0]),
        .I3(\ram_reg[38]_7 [1]),
        .I4(ram_addr[1]),
        .O(\ram_do[1]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000F8C83808)) 
    \ram_do[1]_i_3 
       (.I0(\ram_reg[41]_4 [1]),
        .I1(ram_addr[0]),
        .I2(ram_addr[1]),
        .I3(\ram_reg[42]_3 [1]),
        .I4(\ram_reg[43]_2 [1]),
        .I5(ram_addr[2]),
        .O(\ram_do[1]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hA0A0A0A0C0C0C0CF)) 
    \ram_do[1]_i_4 
       (.I0(\ram_do[1]_i_5_n_0 ),
        .I1(\ram_do[4]_i_7_n_0 ),
        .I2(ram_addr[4]),
        .I3(ram_addr[0]),
        .I4(ram_addr[2]),
        .I5(ram_addr[3]),
        .O(\ram_do[1]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT5 #(
    .INIT(32'h00003808)) 
    \ram_do[1]_i_5 
       (.I0(\ram_reg[25]_10 [10]),
        .I1(ram_addr[0]),
        .I2(ram_addr[1]),
        .I3(\ram_reg[26]_9 [1]),
        .I4(ram_addr[2]),
        .O(\ram_do[1]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h0830000008000000)) 
    \ram_do[23]_i_1 
       (.I0(\ram_do[23]_i_2_n_0 ),
        .I1(ram_addr[5]),
        .I2(ram_addr[4]),
        .I3(ram_addr[3]),
        .I4(ram_addr[2]),
        .I5(\ram_do[23]_i_3_n_0 ),
        .O(ram[23]));
  (* SOFT_HLUTNM = "soft_lutpair15" *) 
  LUT3 #(
    .INIT(8'h04)) 
    \ram_do[23]_i_2 
       (.I0(ram_addr[0]),
        .I1(\ram_reg[44]_1 [38]),
        .I2(ram_addr[1]),
        .O(\ram_do[23]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \ram_do[23]_i_3 
       (.I0(ram_addr[0]),
        .I1(ram_addr[1]),
        .O(\ram_do[23]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hA0008000000F0FC0)) 
    \ram_do[27]_i_2 
       (.I0(\ram_reg[44]_1 [38]),
        .I1(ram_addr[1]),
        .I2(ram_addr[4]),
        .I3(ram_addr[3]),
        .I4(ram_addr[2]),
        .I5(ram_addr[0]),
        .O(\ram_do[27]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'h00000040)) 
    \ram_do[27]_i_3 
       (.I0(ram_addr[2]),
        .I1(\ram_reg[44]_1 [38]),
        .I2(ram_addr[0]),
        .I3(ram_addr[1]),
        .I4(ram_addr[4]),
        .O(\ram_do[27]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h8833BB3FB833B30C)) 
    \ram_do[28]_i_2 
       (.I0(\ram_reg[44]_1 [38]),
        .I1(ram_addr[4]),
        .I2(ram_addr[0]),
        .I3(ram_addr[3]),
        .I4(ram_addr[2]),
        .I5(ram_addr[1]),
        .O(\ram_do[28]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h000000000020822A)) 
    \ram_do[28]_i_3 
       (.I0(\ram_reg[44]_1 [38]),
        .I1(ram_addr[1]),
        .I2(ram_addr[0]),
        .I3(ram_addr[2]),
        .I4(ram_addr[3]),
        .I5(ram_addr[4]),
        .O(\ram_do[28]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hA030800000CF0FC0)) 
    \ram_do[29]_i_2 
       (.I0(\ram_reg[44]_1 [38]),
        .I1(ram_addr[1]),
        .I2(ram_addr[4]),
        .I3(ram_addr[3]),
        .I4(ram_addr[2]),
        .I5(ram_addr[0]),
        .O(\ram_do[29]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000E80040)) 
    \ram_do[29]_i_3 
       (.I0(ram_addr[2]),
        .I1(\ram_reg[44]_1 [38]),
        .I2(ram_addr[0]),
        .I3(ram_addr[1]),
        .I4(ram_addr[3]),
        .I5(ram_addr[4]),
        .O(\ram_do[29]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h00E2FFFF00E20000)) 
    \ram_do[2]_i_1 
       (.I0(\ram_do[2]_i_2_n_0 ),
        .I1(ram_addr[3]),
        .I2(\ram_do[2]_i_3_n_0 ),
        .I3(ram_addr[4]),
        .I4(ram_addr[5]),
        .I5(\ram_do[2]_i_4_n_0 ),
        .O(ram[2]));
  LUT5 #(
    .INIT(32'h8A800000)) 
    \ram_do[2]_i_2 
       (.I0(ram_addr[2]),
        .I1(\ram_reg[39]_6 [8]),
        .I2(ram_addr[0]),
        .I3(\ram_reg[38]_7 [2]),
        .I4(ram_addr[1]),
        .O(\ram_do[2]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000F8C83808)) 
    \ram_do[2]_i_3 
       (.I0(\ram_reg[41]_4 [2]),
        .I1(ram_addr[0]),
        .I2(ram_addr[1]),
        .I3(\ram_reg[42]_3 [2]),
        .I4(\ram_reg[43]_2 [2]),
        .I5(ram_addr[2]),
        .O(\ram_do[2]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hA0A0A0A0C0C0C0CF)) 
    \ram_do[2]_i_4 
       (.I0(\ram_do[2]_i_5_n_0 ),
        .I1(\ram_do[4]_i_7_n_0 ),
        .I2(ram_addr[4]),
        .I3(ram_addr[2]),
        .I4(\ram_do[38]_i_3_n_0 ),
        .I5(ram_addr[3]),
        .O(\ram_do[2]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT5 #(
    .INIT(32'h00003808)) 
    \ram_do[2]_i_5 
       (.I0(\ram_reg[25]_10 [8]),
        .I1(ram_addr[0]),
        .I2(ram_addr[1]),
        .I3(\ram_reg[26]_9 [2]),
        .I4(ram_addr[2]),
        .O(\ram_do[2]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hB80C800033F333C0)) 
    \ram_do[30]_i_2 
       (.I0(\ram_reg[44]_1 [38]),
        .I1(ram_addr[4]),
        .I2(ram_addr[1]),
        .I3(ram_addr[3]),
        .I4(ram_addr[2]),
        .I5(ram_addr[0]),
        .O(\ram_do[30]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000E82888)) 
    \ram_do[30]_i_3 
       (.I0(\ram_reg[44]_1 [38]),
        .I1(ram_addr[0]),
        .I2(ram_addr[2]),
        .I3(ram_addr[1]),
        .I4(ram_addr[3]),
        .I5(ram_addr[4]),
        .O(\ram_do[30]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hB08C333C800F3FB0)) 
    \ram_do[31]_i_2 
       (.I0(\ram_reg[44]_1 [38]),
        .I1(ram_addr[4]),
        .I2(ram_addr[3]),
        .I3(ram_addr[2]),
        .I4(ram_addr[0]),
        .I5(ram_addr[1]),
        .O(\ram_do[31]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h000000000A0A2888)) 
    \ram_do[31]_i_3 
       (.I0(\ram_reg[44]_1 [38]),
        .I1(ram_addr[0]),
        .I2(ram_addr[2]),
        .I3(ram_addr[1]),
        .I4(ram_addr[3]),
        .I5(ram_addr[4]),
        .O(\ram_do[31]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h808C3F30800F33B0)) 
    \ram_do[32]_i_2 
       (.I0(\ram_reg[44]_1 [38]),
        .I1(ram_addr[4]),
        .I2(ram_addr[3]),
        .I3(ram_addr[2]),
        .I4(ram_addr[0]),
        .I5(ram_addr[1]),
        .O(\ram_do[32]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h0000000002C20888)) 
    \ram_do[32]_i_3 
       (.I0(\ram_reg[44]_1 [38]),
        .I1(ram_addr[0]),
        .I2(ram_addr[2]),
        .I3(ram_addr[1]),
        .I4(ram_addr[3]),
        .I5(ram_addr[4]),
        .O(\ram_do[32]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hB3B33C00BC803F30)) 
    \ram_do[33]_i_2 
       (.I0(\ram_reg[44]_1 [38]),
        .I1(ram_addr[4]),
        .I2(ram_addr[3]),
        .I3(ram_addr[2]),
        .I4(ram_addr[1]),
        .I5(ram_addr[0]),
        .O(\ram_do[33]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000382028A8)) 
    \ram_do[33]_i_3 
       (.I0(\ram_reg[44]_1 [38]),
        .I1(ram_addr[1]),
        .I2(ram_addr[2]),
        .I3(ram_addr[0]),
        .I4(ram_addr[3]),
        .I5(ram_addr[4]),
        .O(\ram_do[33]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hB3308F0C8F00B03C)) 
    \ram_do[34]_i_2 
       (.I0(\ram_reg[44]_1 [38]),
        .I1(ram_addr[4]),
        .I2(ram_addr[3]),
        .I3(ram_addr[2]),
        .I4(ram_addr[1]),
        .I5(ram_addr[0]),
        .O(\ram_do[34]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h0000000038280828)) 
    \ram_do[34]_i_3 
       (.I0(\ram_reg[44]_1 [38]),
        .I1(ram_addr[1]),
        .I2(ram_addr[3]),
        .I3(ram_addr[0]),
        .I4(ram_addr[2]),
        .I5(ram_addr[4]),
        .O(\ram_do[34]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h8888888BBBBBBBBB)) 
    \ram_do[35]_i_2 
       (.I0(\ram_do[35]_i_4_n_0 ),
        .I1(ram_addr[4]),
        .I2(ram_addr[2]),
        .I3(ram_addr[1]),
        .I4(ram_addr[0]),
        .I5(ram_addr[3]),
        .O(\ram_do[35]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h000000007E280000)) 
    \ram_do[35]_i_3 
       (.I0(ram_addr[2]),
        .I1(ram_addr[1]),
        .I2(ram_addr[0]),
        .I3(\ram_reg[44]_1 [38]),
        .I4(ram_addr[3]),
        .I5(ram_addr[4]),
        .O(\ram_do[35]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hBB8BBBBBBBBB8888)) 
    \ram_do[35]_i_4 
       (.I0(\ram_reg[44]_1 [38]),
        .I1(ram_addr[3]),
        .I2(ram_addr[0]),
        .I3(\ram_reg[23]_11 ),
        .I4(ram_addr[2]),
        .I5(ram_addr[1]),
        .O(\ram_do[35]_i_4_n_0 ));
  LUT5 #(
    .INIT(32'h44422662)) 
    \ram_do[36]_i_2 
       (.I0(ram_addr[4]),
        .I1(ram_addr[3]),
        .I2(ram_addr[0]),
        .I3(ram_addr[1]),
        .I4(ram_addr[2]),
        .O(\ram_do[36]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'h00000CC4)) 
    \ram_do[36]_i_3 
       (.I0(ram_addr[1]),
        .I1(\ram_reg[44]_1 [38]),
        .I2(ram_addr[2]),
        .I3(ram_addr[3]),
        .I4(ram_addr[4]),
        .O(\ram_do[36]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h0000000080000003)) 
    \ram_do[37]_i_2 
       (.I0(\ram_reg[23]_11 ),
        .I1(ram_addr[4]),
        .I2(ram_addr[2]),
        .I3(ram_addr[1]),
        .I4(ram_addr[0]),
        .I5(ram_addr[3]),
        .O(\ram_do[37]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'h00002000)) 
    \ram_do[37]_i_3 
       (.I0(ram_addr[2]),
        .I1(ram_addr[0]),
        .I2(ram_addr[1]),
        .I3(ram_addr[3]),
        .I4(ram_addr[4]),
        .O(\ram_do[37]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h0830000008000000)) 
    \ram_do[38]_i_1 
       (.I0(\ram_do[38]_i_2_n_0 ),
        .I1(ram_addr[5]),
        .I2(ram_addr[4]),
        .I3(ram_addr[3]),
        .I4(ram_addr[2]),
        .I5(\ram_do[38]_i_3_n_0 ),
        .O(ram[38]));
  (* SOFT_HLUTNM = "soft_lutpair15" *) 
  LUT3 #(
    .INIT(8'h0E)) 
    \ram_do[38]_i_2 
       (.I0(\ram_reg[44]_1 [38]),
        .I1(ram_addr[0]),
        .I2(ram_addr[1]),
        .O(\ram_do[38]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \ram_do[38]_i_3 
       (.I0(ram_addr[1]),
        .I1(ram_addr[0]),
        .O(\ram_do[38]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'h30BB3088)) 
    \ram_do[3]_i_1 
       (.I0(\ram_do_reg[3]_i_2_n_0 ),
        .I1(ram_addr[5]),
        .I2(\ram_do[3]_i_3_n_0 ),
        .I3(ram_addr[4]),
        .I4(\ram_do[9]_i_4_n_0 ),
        .O(ram[3]));
  LUT6 #(
    .INIT(64'h300000000033BB33)) 
    \ram_do[3]_i_3 
       (.I0(\ram_reg[26]_9 [5]),
        .I1(ram_addr[3]),
        .I2(\ram_reg[23]_11 ),
        .I3(ram_addr[1]),
        .I4(ram_addr[2]),
        .I5(ram_addr[0]),
        .O(\ram_do[3]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'h8A800000)) 
    \ram_do[3]_i_4 
       (.I0(ram_addr[2]),
        .I1(\ram_reg[39]_6 [9]),
        .I2(ram_addr[0]),
        .I3(\ram_reg[38]_7 [3]),
        .I4(ram_addr[1]),
        .O(\ram_do[3]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h00000000F8C83808)) 
    \ram_do[3]_i_5 
       (.I0(\ram_reg[41]_4 [3]),
        .I1(ram_addr[0]),
        .I2(ram_addr[1]),
        .I3(\ram_reg[42]_3 [3]),
        .I4(\ram_reg[43]_2 [3]),
        .I5(ram_addr[2]),
        .O(\ram_do[3]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h00E2FFFF00E20000)) 
    \ram_do[4]_i_1 
       (.I0(\ram_do[4]_i_2_n_0 ),
        .I1(ram_addr[3]),
        .I2(\ram_do[4]_i_3_n_0 ),
        .I3(ram_addr[4]),
        .I4(ram_addr[5]),
        .I5(\ram_do[4]_i_4_n_0 ),
        .O(ram[4]));
  LUT5 #(
    .INIT(32'h8A800000)) 
    \ram_do[4]_i_2 
       (.I0(ram_addr[2]),
        .I1(\ram_reg[39]_6 [10]),
        .I2(ram_addr[0]),
        .I3(\ram_reg[38]_7 [4]),
        .I4(ram_addr[1]),
        .O(\ram_do[4]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'h08FF0800)) 
    \ram_do[4]_i_3 
       (.I0(\ram_reg[45]_0 [4]),
        .I1(ram_addr[0]),
        .I2(ram_addr[1]),
        .I3(ram_addr[2]),
        .I4(\ram_do[4]_i_5_n_0 ),
        .O(\ram_do[4]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hA0A0A0A0C0C0C0CF)) 
    \ram_do[4]_i_4 
       (.I0(\ram_do[4]_i_6_n_0 ),
        .I1(\ram_do[4]_i_7_n_0 ),
        .I2(ram_addr[4]),
        .I3(ram_addr[0]),
        .I4(ram_addr[2]),
        .I5(ram_addr[3]),
        .O(\ram_do[4]_i_4_n_0 ));
  LUT5 #(
    .INIT(32'hAFC0A0C0)) 
    \ram_do[4]_i_5 
       (.I0(\ram_reg[43]_2 [4]),
        .I1(\ram_reg[42]_3 [4]),
        .I2(ram_addr[1]),
        .I3(ram_addr[0]),
        .I4(\ram_reg[41]_4 [4]),
        .O(\ram_do[4]_i_5_n_0 ));
  LUT5 #(
    .INIT(32'h00003808)) 
    \ram_do[4]_i_6 
       (.I0(\ram_reg[25]_10 [10]),
        .I1(ram_addr[0]),
        .I2(ram_addr[1]),
        .I3(\ram_reg[26]_9 [5]),
        .I4(ram_addr[2]),
        .O(\ram_do[4]_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT4 #(
    .INIT(16'h8030)) 
    \ram_do[4]_i_7 
       (.I0(\ram_reg[23]_11 ),
        .I1(ram_addr[2]),
        .I2(ram_addr[1]),
        .I3(ram_addr[0]),
        .O(\ram_do[4]_i_7_n_0 ));
  LUT5 #(
    .INIT(32'h30BB3088)) 
    \ram_do[5]_i_1 
       (.I0(\ram_do_reg[5]_i_2_n_0 ),
        .I1(ram_addr[5]),
        .I2(\ram_do[5]_i_3_n_0 ),
        .I3(ram_addr[4]),
        .I4(\ram_do[9]_i_4_n_0 ),
        .O(ram[5]));
  LUT6 #(
    .INIT(64'h3000000000BB3300)) 
    \ram_do[5]_i_3 
       (.I0(\ram_reg[26]_9 [5]),
        .I1(ram_addr[3]),
        .I2(\ram_reg[23]_11 ),
        .I3(ram_addr[2]),
        .I4(ram_addr[1]),
        .I5(ram_addr[0]),
        .O(\ram_do[5]_i_3_n_0 ));
  LUT4 #(
    .INIT(16'h2000)) 
    \ram_do[5]_i_4 
       (.I0(ram_addr[2]),
        .I1(ram_addr[0]),
        .I2(\ram_reg[38]_7 [5]),
        .I3(ram_addr[1]),
        .O(\ram_do[5]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h00000000F8C83808)) 
    \ram_do[5]_i_5 
       (.I0(\ram_reg[41]_4 [5]),
        .I1(ram_addr[0]),
        .I2(ram_addr[1]),
        .I3(\ram_reg[42]_3 [5]),
        .I4(\ram_reg[43]_2 [5]),
        .I5(ram_addr[2]),
        .O(\ram_do[5]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h00E2FFFF00E20000)) 
    \ram_do[6]_i_1 
       (.I0(\ram_do[6]_i_2_n_0 ),
        .I1(ram_addr[3]),
        .I2(\ram_do[6]_i_3_n_0 ),
        .I3(ram_addr[4]),
        .I4(ram_addr[5]),
        .I5(\ram_do[6]_i_4_n_0 ),
        .O(ram[6]));
  LUT6 #(
    .INIT(64'hB8FFFFFFB8000000)) 
    \ram_do[6]_i_2 
       (.I0(\ram_reg[39]_6 [6]),
        .I1(ram_addr[0]),
        .I2(\ram_reg[38]_7 [6]),
        .I3(ram_addr[1]),
        .I4(ram_addr[2]),
        .I5(\ram_reg[40]_5 [7]),
        .O(\ram_do[6]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000F8C83808)) 
    \ram_do[6]_i_3 
       (.I0(\ram_reg[41]_4 [6]),
        .I1(ram_addr[0]),
        .I2(ram_addr[1]),
        .I3(\ram_reg[42]_3 [6]),
        .I4(\ram_reg[43]_2 [6]),
        .I5(ram_addr[2]),
        .O(\ram_do[6]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hBBBBBBB8BBBBB8BB)) 
    \ram_do[6]_i_4 
       (.I0(\ram_do[6]_i_5_n_0 ),
        .I1(ram_addr[4]),
        .I2(ram_addr[3]),
        .I3(ram_addr[0]),
        .I4(ram_addr[1]),
        .I5(ram_addr[2]),
        .O(\ram_do[6]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hB08888B0808888B0)) 
    \ram_do[6]_i_5 
       (.I0(\ram_reg[40]_5 [7]),
        .I1(ram_addr[3]),
        .I2(ram_addr[2]),
        .I3(ram_addr[0]),
        .I4(ram_addr[1]),
        .I5(\ram_reg[23]_11 ),
        .O(\ram_do[6]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h00E2FFFF00E20000)) 
    \ram_do[7]_i_1 
       (.I0(\ram_do[7]_i_2_n_0 ),
        .I1(ram_addr[3]),
        .I2(\ram_do[7]_i_3_n_0 ),
        .I3(ram_addr[4]),
        .I4(ram_addr[5]),
        .I5(\ram_do[7]_i_4_n_0 ),
        .O(ram[7]));
  LUT5 #(
    .INIT(32'h8A800000)) 
    \ram_do[7]_i_2 
       (.I0(ram_addr[2]),
        .I1(\ram_reg[39]_6 [7]),
        .I2(ram_addr[0]),
        .I3(\ram_reg[38]_7 [13]),
        .I4(ram_addr[1]),
        .O(\ram_do[7]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'h08FF0800)) 
    \ram_do[7]_i_3 
       (.I0(\ram_reg[45]_0 [7]),
        .I1(ram_addr[0]),
        .I2(ram_addr[1]),
        .I3(ram_addr[2]),
        .I4(\ram_do[7]_i_5_n_0 ),
        .O(\ram_do[7]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h88888888888BBB8B)) 
    \ram_do[7]_i_4 
       (.I0(\ram_do[7]_i_6_n_0 ),
        .I1(ram_addr[4]),
        .I2(ram_addr[1]),
        .I3(ram_addr[0]),
        .I4(ram_addr[2]),
        .I5(ram_addr[3]),
        .O(\ram_do[7]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \ram_do[7]_i_5 
       (.I0(\ram_reg[43]_2 [7]),
        .I1(\ram_reg[42]_3 [7]),
        .I2(ram_addr[1]),
        .I3(\ram_reg[41]_4 [7]),
        .I4(ram_addr[0]),
        .I5(\ram_reg[40]_5 [7]),
        .O(\ram_do[7]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h3088008800333388)) 
    \ram_do[7]_i_6 
       (.I0(\ram_reg[25]_10 [10]),
        .I1(ram_addr[3]),
        .I2(\ram_reg[23]_11 ),
        .I3(ram_addr[2]),
        .I4(ram_addr[0]),
        .I5(ram_addr[1]),
        .O(\ram_do[7]_i_6_n_0 ));
  LUT5 #(
    .INIT(32'h30BB3088)) 
    \ram_do[8]_i_1 
       (.I0(\ram_do[8]_i_2_n_0 ),
        .I1(ram_addr[5]),
        .I2(\ram_do[8]_i_3_n_0 ),
        .I3(ram_addr[4]),
        .I4(\ram_do[9]_i_4_n_0 ),
        .O(ram[8]));
  LUT6 #(
    .INIT(64'hB888888888888888)) 
    \ram_do[8]_i_2 
       (.I0(\ram_do[8]_i_4_n_0 ),
        .I1(ram_addr[3]),
        .I2(ram_addr[2]),
        .I3(ram_addr[0]),
        .I4(\ram_reg[39]_6 [8]),
        .I5(ram_addr[1]),
        .O(\ram_do[8]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h3038003830303030)) 
    \ram_do[8]_i_3 
       (.I0(\ram_reg[25]_10 [8]),
        .I1(ram_addr[3]),
        .I2(ram_addr[2]),
        .I3(ram_addr[1]),
        .I4(\ram_reg[23]_11 ),
        .I5(ram_addr[0]),
        .O(\ram_do[8]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h00E2FFFF00E20000)) 
    \ram_do[8]_i_4 
       (.I0(\ram_reg[44]_1 [8]),
        .I1(ram_addr[0]),
        .I2(\ram_reg[45]_0 [8]),
        .I3(ram_addr[1]),
        .I4(ram_addr[2]),
        .I5(\ram_do[8]_i_5_n_0 ),
        .O(\ram_do[8]_i_4_n_0 ));
  LUT5 #(
    .INIT(32'hAFC0A0C0)) 
    \ram_do[8]_i_5 
       (.I0(\ram_reg[43]_2 [8]),
        .I1(\ram_reg[42]_3 [8]),
        .I2(ram_addr[1]),
        .I3(ram_addr[0]),
        .I4(\ram_reg[41]_4 [8]),
        .O(\ram_do[8]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h0030BBBB00308888)) 
    \ram_do[9]_i_1 
       (.I0(\ram_do[9]_i_2_n_0 ),
        .I1(ram_addr[5]),
        .I2(\ram_do[9]_i_3_n_0 ),
        .I3(ram_addr[3]),
        .I4(ram_addr[4]),
        .I5(\ram_do[9]_i_4_n_0 ),
        .O(ram[9]));
  LUT6 #(
    .INIT(64'hB888888888888888)) 
    \ram_do[9]_i_2 
       (.I0(\ram_do[9]_i_5_n_0 ),
        .I1(ram_addr[3]),
        .I2(ram_addr[2]),
        .I3(ram_addr[0]),
        .I4(\ram_reg[39]_6 [9]),
        .I5(ram_addr[1]),
        .O(\ram_do[9]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT4 #(
    .INIT(16'h803F)) 
    \ram_do[9]_i_3 
       (.I0(\ram_reg[23]_11 ),
        .I1(ram_addr[1]),
        .I2(ram_addr[2]),
        .I3(ram_addr[0]),
        .O(\ram_do[9]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT4 #(
    .INIT(16'h0001)) 
    \ram_do[9]_i_4 
       (.I0(ram_addr[2]),
        .I1(ram_addr[1]),
        .I2(ram_addr[0]),
        .I3(ram_addr[3]),
        .O(\ram_do[9]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h00000000F8C83808)) 
    \ram_do[9]_i_5 
       (.I0(\ram_reg[41]_4 [9]),
        .I1(ram_addr[0]),
        .I2(ram_addr[1]),
        .I3(\ram_reg[42]_3 [9]),
        .I4(\ram_reg[43]_2 [9]),
        .I5(ram_addr[2]),
        .O(\ram_do[9]_i_5_n_0 ));
  FDRE \ram_do_reg[0] 
       (.C(CLK),
        .CE(1'b1),
        .D(ram[0]),
        .Q(ram_do[0]),
        .R(1'b0));
  FDRE \ram_do_reg[10] 
       (.C(CLK),
        .CE(1'b1),
        .D(ram[10]),
        .Q(ram_do[10]),
        .R(1'b0));
  MUXF7 \ram_do_reg[10]_i_2 
       (.I0(\ram_do[10]_i_5_n_0 ),
        .I1(\ram_do[10]_i_6_n_0 ),
        .O(\ram_do_reg[10]_i_2_n_0 ),
        .S(ram_addr[3]));
  FDRE \ram_do_reg[11] 
       (.C(CLK),
        .CE(1'b1),
        .D(ram[11]),
        .Q(ram_do[11]),
        .R(1'b0));
  FDRE \ram_do_reg[12] 
       (.C(CLK),
        .CE(1'b1),
        .D(ram[12]),
        .Q(ram_do[12]),
        .R(1'b0));
  FDRE \ram_do_reg[13] 
       (.C(CLK),
        .CE(1'b1),
        .D(ram[13]),
        .Q(ram_do[13]),
        .R(1'b0));
  FDRE \ram_do_reg[14] 
       (.C(CLK),
        .CE(1'b1),
        .D(ram[14]),
        .Q(ram_do[14]),
        .R(1'b0));
  FDRE \ram_do_reg[15] 
       (.C(CLK),
        .CE(1'b1),
        .D(ram[15]),
        .Q(ram_do[15]),
        .R(1'b0));
  FDRE \ram_do_reg[1] 
       (.C(CLK),
        .CE(1'b1),
        .D(ram[1]),
        .Q(ram_do[1]),
        .R(1'b0));
  FDRE \ram_do_reg[23] 
       (.C(CLK),
        .CE(1'b1),
        .D(ram[23]),
        .Q(ram_do[23]),
        .R(1'b0));
  FDRE \ram_do_reg[27] 
       (.C(CLK),
        .CE(1'b1),
        .D(ram[27]),
        .Q(ram_do[27]),
        .R(1'b0));
  MUXF7 \ram_do_reg[27]_i_1 
       (.I0(\ram_do[27]_i_2_n_0 ),
        .I1(\ram_do[27]_i_3_n_0 ),
        .O(ram[27]),
        .S(ram_addr[5]));
  FDRE \ram_do_reg[28] 
       (.C(CLK),
        .CE(1'b1),
        .D(ram[28]),
        .Q(ram_do[28]),
        .R(1'b0));
  MUXF7 \ram_do_reg[28]_i_1 
       (.I0(\ram_do[28]_i_2_n_0 ),
        .I1(\ram_do[28]_i_3_n_0 ),
        .O(ram[28]),
        .S(ram_addr[5]));
  FDRE \ram_do_reg[29] 
       (.C(CLK),
        .CE(1'b1),
        .D(ram[29]),
        .Q(ram_do[29]),
        .R(1'b0));
  MUXF7 \ram_do_reg[29]_i_1 
       (.I0(\ram_do[29]_i_2_n_0 ),
        .I1(\ram_do[29]_i_3_n_0 ),
        .O(ram[29]),
        .S(ram_addr[5]));
  FDRE \ram_do_reg[2] 
       (.C(CLK),
        .CE(1'b1),
        .D(ram[2]),
        .Q(ram_do[2]),
        .R(1'b0));
  FDRE \ram_do_reg[30] 
       (.C(CLK),
        .CE(1'b1),
        .D(ram[30]),
        .Q(ram_do[30]),
        .R(1'b0));
  MUXF7 \ram_do_reg[30]_i_1 
       (.I0(\ram_do[30]_i_2_n_0 ),
        .I1(\ram_do[30]_i_3_n_0 ),
        .O(ram[30]),
        .S(ram_addr[5]));
  FDRE \ram_do_reg[31] 
       (.C(CLK),
        .CE(1'b1),
        .D(ram[31]),
        .Q(ram_do[31]),
        .R(1'b0));
  MUXF7 \ram_do_reg[31]_i_1 
       (.I0(\ram_do[31]_i_2_n_0 ),
        .I1(\ram_do[31]_i_3_n_0 ),
        .O(ram[31]),
        .S(ram_addr[5]));
  FDRE \ram_do_reg[32] 
       (.C(CLK),
        .CE(1'b1),
        .D(ram[32]),
        .Q(ram_do[32]),
        .R(1'b0));
  MUXF7 \ram_do_reg[32]_i_1 
       (.I0(\ram_do[32]_i_2_n_0 ),
        .I1(\ram_do[32]_i_3_n_0 ),
        .O(ram[32]),
        .S(ram_addr[5]));
  FDRE \ram_do_reg[33] 
       (.C(CLK),
        .CE(1'b1),
        .D(ram[33]),
        .Q(ram_do[33]),
        .R(1'b0));
  MUXF7 \ram_do_reg[33]_i_1 
       (.I0(\ram_do[33]_i_2_n_0 ),
        .I1(\ram_do[33]_i_3_n_0 ),
        .O(ram[33]),
        .S(ram_addr[5]));
  FDRE \ram_do_reg[34] 
       (.C(CLK),
        .CE(1'b1),
        .D(ram[34]),
        .Q(ram_do[34]),
        .R(1'b0));
  MUXF7 \ram_do_reg[34]_i_1 
       (.I0(\ram_do[34]_i_2_n_0 ),
        .I1(\ram_do[34]_i_3_n_0 ),
        .O(ram[34]),
        .S(ram_addr[5]));
  FDRE \ram_do_reg[35] 
       (.C(CLK),
        .CE(1'b1),
        .D(ram[35]),
        .Q(ram_do[35]),
        .R(1'b0));
  MUXF7 \ram_do_reg[35]_i_1 
       (.I0(\ram_do[35]_i_2_n_0 ),
        .I1(\ram_do[35]_i_3_n_0 ),
        .O(ram[35]),
        .S(ram_addr[5]));
  FDRE \ram_do_reg[36] 
       (.C(CLK),
        .CE(1'b1),
        .D(ram[36]),
        .Q(ram_do[36]),
        .R(1'b0));
  MUXF7 \ram_do_reg[36]_i_1 
       (.I0(\ram_do[36]_i_2_n_0 ),
        .I1(\ram_do[36]_i_3_n_0 ),
        .O(ram[36]),
        .S(ram_addr[5]));
  FDRE \ram_do_reg[37] 
       (.C(CLK),
        .CE(1'b1),
        .D(ram[37]),
        .Q(ram_do[37]),
        .R(1'b0));
  MUXF7 \ram_do_reg[37]_i_1 
       (.I0(\ram_do[37]_i_2_n_0 ),
        .I1(\ram_do[37]_i_3_n_0 ),
        .O(ram[37]),
        .S(ram_addr[5]));
  FDRE \ram_do_reg[38] 
       (.C(CLK),
        .CE(1'b1),
        .D(ram[38]),
        .Q(ram_do[38]),
        .R(1'b0));
  FDRE \ram_do_reg[3] 
       (.C(CLK),
        .CE(1'b1),
        .D(ram[3]),
        .Q(ram_do[3]),
        .R(1'b0));
  MUXF7 \ram_do_reg[3]_i_2 
       (.I0(\ram_do[3]_i_4_n_0 ),
        .I1(\ram_do[3]_i_5_n_0 ),
        .O(\ram_do_reg[3]_i_2_n_0 ),
        .S(ram_addr[3]));
  FDRE \ram_do_reg[4] 
       (.C(CLK),
        .CE(1'b1),
        .D(ram[4]),
        .Q(ram_do[4]),
        .R(1'b0));
  FDRE \ram_do_reg[5] 
       (.C(CLK),
        .CE(1'b1),
        .D(ram[5]),
        .Q(ram_do[5]),
        .R(1'b0));
  MUXF7 \ram_do_reg[5]_i_2 
       (.I0(\ram_do[5]_i_4_n_0 ),
        .I1(\ram_do[5]_i_5_n_0 ),
        .O(\ram_do_reg[5]_i_2_n_0 ),
        .S(ram_addr[3]));
  FDRE \ram_do_reg[6] 
       (.C(CLK),
        .CE(1'b1),
        .D(ram[6]),
        .Q(ram_do[6]),
        .R(1'b0));
  FDRE \ram_do_reg[7] 
       (.C(CLK),
        .CE(1'b1),
        .D(ram[7]),
        .Q(ram_do[7]),
        .R(1'b0));
  FDRE \ram_do_reg[8] 
       (.C(CLK),
        .CE(1'b1),
        .D(ram[8]),
        .Q(ram_do[8]),
        .R(1'b0));
  FDRE \ram_do_reg[9] 
       (.C(CLK),
        .CE(1'b1),
        .D(ram[9]),
        .Q(ram_do[9]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[23][37] 
       (.C(CLK),
        .CE(1'b1),
        .D(\ram[23][37]_i_1_n_0 ),
        .Q(\ram_reg[23]_11 ),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[25][10] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(\ram[25][10]_i_1_n_0 ),
        .Q(\ram_reg[25]_10 [10]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[25][8] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(\ram[25][8]_i_1_n_0 ),
        .Q(\ram_reg[25]_10 [8]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[26][0] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(\ram_reg[26][5]_i_1_n_7 ),
        .Q(\ram_reg[26]_9 [0]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[26][1] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(\ram_reg[26][5]_i_1_n_6 ),
        .Q(\ram_reg[26]_9 [1]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[26][2] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(\ram_reg[26][5]_i_1_n_5 ),
        .Q(\ram_reg[26]_9 [2]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[26][5] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(\ram_reg[26][5]_i_1_n_4 ),
        .Q(\ram_reg[26]_9 [5]),
        .R(1'b0));
  CARRY4 \ram_reg[26][5]_i_1 
       (.CI(1'b0),
        .CO({\NLW_ram_reg[26][5]_i_1_CO_UNCONNECTED [3],\ram_reg[26][5]_i_1_n_1 ,\ram_reg[26][5]_i_1_n_2 ,\ram_reg[26][5]_i_1_n_3 }),
        .CYINIT(1'b1),
        .DI({1'b0,\ram[26][5]_i_2_n_0 ,1'b1,\ram[26][5]_i_3_n_0 }),
        .O({\ram_reg[26][5]_i_1_n_4 ,\ram_reg[26][5]_i_1_n_5 ,\ram_reg[26][5]_i_1_n_6 ,\ram_reg[26][5]_i_1_n_7 }),
        .S({1'b1,\ram[26][5]_i_4_n_0 ,\ram[26][5]_i_5_n_0 ,\ram[26][5]_i_6_n_0 }));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[37][10] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(\ram[37][10]_i_1_n_0 ),
        .Q(\ram_reg[37]_8 [10]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[37][13] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(1'b1),
        .Q(\ram_reg[37]_8 [13]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[38][0] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(\ram_reg[38][0]_i_1_n_7 ),
        .Q(\ram_reg[38]_7 [0]),
        .R(1'b0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \ram_reg[38][0]_i_1 
       (.CI(1'b0),
        .CO({\ram_reg[38][0]_i_1_n_0 ,\ram_reg[38][0]_i_1_n_1 ,\ram_reg[38][0]_i_1_n_2 ,\ram_reg[38][0]_i_1_n_3 }),
        .CYINIT(1'b1),
        .DI({1'b0,\ram[38][0]_i_2_n_0 ,\ram[38][0]_i_3_n_0 ,\ram[38][0]_i_4_n_0 }),
        .O({\ram_reg[38][0]_i_1_n_4 ,\ram_reg[38][0]_i_1_n_5 ,\ram_reg[38][0]_i_1_n_6 ,\ram_reg[38][0]_i_1_n_7 }),
        .S({1'b1,\ram[38][0]_i_5_n_0 ,1'b0,1'b0}));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[38][13] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(s2_clkfbout_mult),
        .Q(\ram_reg[38]_7 [13]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[38][1] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(\ram_reg[38][0]_i_1_n_6 ),
        .Q(\ram_reg[38]_7 [1]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[38][2] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(\ram_reg[38][0]_i_1_n_5 ),
        .Q(\ram_reg[38]_7 [2]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[38][3] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(\ram_reg[38][0]_i_1_n_4 ),
        .Q(\ram_reg[38]_7 [3]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[38][4] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(\ram_reg[38][5]_i_1_n_7 ),
        .Q(\ram_reg[38]_7 [4]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[38][5] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(\ram_reg[38][5]_i_1_n_6 ),
        .Q(\ram_reg[38]_7 [5]),
        .R(1'b0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \ram_reg[38][5]_i_1 
       (.CI(\ram_reg[38][0]_i_1_n_0 ),
        .CO({\NLW_ram_reg[38][5]_i_1_CO_UNCONNECTED [3:1],\ram_reg[38][5]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_ram_reg[38][5]_i_1_O_UNCONNECTED [3:2],\ram_reg[38][5]_i_1_n_6 ,\ram_reg[38][5]_i_1_n_7 }),
        .S({1'b0,1'b0,1'b1,1'b1}));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[38][6] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(\ram[38][6]_i_1_n_0 ),
        .Q(\ram_reg[38]_7 [6]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[39][0] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(\ram[39][0]_i_1_n_0 ),
        .Q(\ram_reg[39]_6 [0]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[39][10] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(\ram[39][10]_i_1_n_0 ),
        .Q(\ram_reg[39]_6 [10]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[39][6] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(\ram[39][6]_i_1_n_0 ),
        .Q(\ram_reg[39]_6 [6]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[39][7] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(\ram[39][7]_i_1_n_0 ),
        .Q(\ram_reg[39]_6 [7]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[39][8] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(\ram[39][8]_i_1_n_0 ),
        .Q(\ram_reg[39]_6 [8]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[39][9] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(\ram[39][9]_i_1_n_0 ),
        .Q(\ram_reg[39]_6 [9]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[40][10] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(p_1_out),
        .Q(\ram_reg[40]_5 [10]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[40][11] 
       (.C(CLK),
        .CE(1'b1),
        .D(\ram[40][11]_i_1_n_0 ),
        .Q(\ram_reg[40]_5 [11]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[40][12] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(\ram[40][12]_i_1_n_0 ),
        .Q(\ram_reg[40]_5 [12]),
        .R(1'b0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \ram_reg[40][12]_i_19 
       (.CI(1'b0),
        .CO({\ram_reg[40][12]_i_19_n_0 ,\ram_reg[40][12]_i_19_n_1 ,\ram_reg[40][12]_i_19_n_2 ,\ram_reg[40][12]_i_19_n_3 }),
        .CYINIT(1'b0),
        .DI({\ram[40][12]_i_25_n_0 ,1'b0,\ram[40][12]_i_26_n_0 ,1'b0}),
        .O(\NLW_ram_reg[40][12]_i_19_O_UNCONNECTED [3:0]),
        .S({\ram[40][12]_i_27_n_0 ,\ram[40][12]_i_28_n_0 ,1'b1,1'b1}));
  CARRY4 \ram_reg[40][12]_i_2 
       (.CI(\ram_reg[40][12]_i_4_n_0 ),
        .CO({\ram_reg[40][12]_i_2_n_0 ,\NLW_ram_reg[40][12]_i_2_CO_UNCONNECTED [2],\ram_reg[40][12]_i_2_n_2 ,\ram_reg[40][12]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\ram[40][12]_i_5_n_0 ,1'b0}),
        .O({\NLW_ram_reg[40][12]_i_2_O_UNCONNECTED [3],\ram_reg[40][12]_i_2_n_5 ,\ram_reg[40][12]_i_2_n_6 ,\ram_reg[40][12]_i_2_n_7 }),
        .S({1'b1,\ram[40][12]_i_6_n_0 ,\ram[40][12]_i_7_n_0 ,\ram[40][12]_i_8_n_0 }));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \ram_reg[40][12]_i_3 
       (.CI(\ram_reg[40][12]_i_9_n_0 ),
        .CO({\NLW_ram_reg[40][12]_i_3_CO_UNCONNECTED [3:2],\ram_reg[40][12]_i_3_n_2 ,\ram_reg[40][12]_i_3_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\ram_reg[40][12]_i_2_n_5 ,\ram[40][12]_i_10_n_0 }),
        .O(\NLW_ram_reg[40][12]_i_3_O_UNCONNECTED [3:0]),
        .S({1'b0,1'b0,\ram[40][12]_i_11_n_0 ,\ram[40][12]_i_12_n_0 }));
  CARRY4 \ram_reg[40][12]_i_4 
       (.CI(1'b0),
        .CO({\ram_reg[40][12]_i_4_n_0 ,\ram_reg[40][12]_i_4_n_1 ,\ram_reg[40][12]_i_4_n_2 ,\ram_reg[40][12]_i_4_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\ram[40][12]_i_13_n_0 ,\ram[40][12]_i_14_n_0 }),
        .O({\ram_reg[40][12]_i_4_n_4 ,\ram_reg[40][12]_i_4_n_5 ,\ram_reg[40][12]_i_4_n_6 ,\ram_reg[40][12]_i_4_n_7 }),
        .S({\ram[40][12]_i_15_n_0 ,\ram[40][12]_i_16_n_0 ,\ram[40][12]_i_17_n_0 ,\ram[40][12]_i_18_n_0 }));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \ram_reg[40][12]_i_9 
       (.CI(\ram_reg[40][12]_i_19_n_0 ),
        .CO({\ram_reg[40][12]_i_9_n_0 ,\ram_reg[40][12]_i_9_n_1 ,\ram_reg[40][12]_i_9_n_2 ,\ram_reg[40][12]_i_9_n_3 }),
        .CYINIT(1'b0),
        .DI({\ram_reg[40][12]_i_2_n_7 ,\ram_reg[40][12]_i_4_n_4 ,\ram_reg[40][12]_i_4_n_5 ,\ram[40][12]_i_20_n_0 }),
        .O(\NLW_ram_reg[40][12]_i_9_O_UNCONNECTED [3:0]),
        .S({\ram[40][12]_i_21_n_0 ,\ram[40][12]_i_22_n_0 ,\ram[40][12]_i_23_n_0 ,\ram[40][12]_i_24_n_0 }));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[40][13] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(\ram[40][13]_i_1_n_0 ),
        .Q(\ram_reg[40]_5 [13]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[40][14] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(\ram[38][6]_i_1_n_0 ),
        .Q(\ram_reg[40]_5 [14]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[40][7] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(1'b1),
        .Q(\ram_reg[40]_5 [7]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[41][0] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(p_17_in[0]),
        .Q(\ram_reg[41]_4 [0]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[41][1] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(p_17_in[1]),
        .Q(\ram_reg[41]_4 [1]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[41][2] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(p_17_in[2]),
        .Q(\ram_reg[41]_4 [2]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[41][3] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(p_17_in[3]),
        .Q(\ram_reg[41]_4 [3]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[41][4] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(p_17_in[4]),
        .Q(\ram_reg[41]_4 [4]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[41][5] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(p_17_in[5]),
        .Q(\ram_reg[41]_4 [5]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[41][6] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(p_17_in[6]),
        .Q(\ram_reg[41]_4 [6]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[41][7] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(p_17_in[7]),
        .Q(\ram_reg[41]_4 [7]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[41][8] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(p_17_in[8]),
        .Q(\ram_reg[41]_4 [8]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[41][9] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(p_17_in[9]),
        .Q(\ram_reg[41]_4 [9]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[42][0] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(p_18_in[0]),
        .Q(\ram_reg[42]_3 [0]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[42][10] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(p_18_in[10]),
        .Q(\ram_reg[42]_3 [10]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[42][11] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(p_18_in[11]),
        .Q(\ram_reg[42]_3 [11]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[42][12] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(p_18_in[12]),
        .Q(\ram_reg[42]_3 [12]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[42][13] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(p_18_in[13]),
        .Q(\ram_reg[42]_3 [13]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[42][14] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(p_18_in[14]),
        .Q(\ram_reg[42]_3 [14]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[42][1] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(p_18_in[1]),
        .Q(\ram_reg[42]_3 [1]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[42][2] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(p_18_in[2]),
        .Q(\ram_reg[42]_3 [2]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[42][3] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(p_18_in[3]),
        .Q(\ram_reg[42]_3 [3]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[42][4] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(p_18_in[4]),
        .Q(\ram_reg[42]_3 [4]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[42][5] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(p_18_in[5]),
        .Q(\ram_reg[42]_3 [5]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[42][6] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(p_18_in[6]),
        .Q(\ram_reg[42]_3 [6]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[42][7] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(p_18_in[7]),
        .Q(\ram_reg[42]_3 [7]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[42][8] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(p_18_in[8]),
        .Q(\ram_reg[42]_3 [8]),
        .R(1'b0));
  MUXF7 \ram_reg[42][8]_i_2 
       (.I0(\ram[42][8]_i_5_n_0 ),
        .I1(\ram[42][8]_i_6_n_0 ),
        .O(\ram_reg[42][8]_i_2_n_0 ),
        .S(\ram_reg[43][14]_i_3_n_6 ));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[42][9] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(p_18_in[9]),
        .Q(\ram_reg[42]_3 [9]),
        .R(1'b0));
  MUXF7 \ram_reg[42][9]_i_2 
       (.I0(\ram[42][9]_i_5_n_0 ),
        .I1(\ram[42][9]_i_6_n_0 ),
        .O(\ram_reg[42][9]_i_2_n_0 ),
        .S(\ram_reg[43][14]_i_3_n_6 ));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[43][0] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(p_19_in[0]),
        .Q(\ram_reg[43]_2 [0]),
        .R(1'b0));
  MUXF7 \ram_reg[43][0]_i_2 
       (.I0(\ram[43][0]_i_4_n_0 ),
        .I1(\ram[43][0]_i_5_n_0 ),
        .O(\ram_reg[43][0]_i_2_n_0 ),
        .S(\ram_reg[43][14]_i_3_n_6 ));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[43][10] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(p_19_in[10]),
        .Q(\ram_reg[43]_2 [10]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[43][11] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(p_19_in[11]),
        .Q(\ram_reg[43]_2 [11]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[43][12] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(p_19_in[12]),
        .Q(\ram_reg[43]_2 [12]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[43][13] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(p_19_in[13]),
        .Q(\ram_reg[43]_2 [13]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[43][14] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(p_19_in[14]),
        .Q(\ram_reg[43]_2 [14]),
        .R(1'b0));
  CARRY4 \ram_reg[43][14]_i_3 
       (.CI(1'b0),
        .CO({\NLW_ram_reg[43][14]_i_3_CO_UNCONNECTED [3],\ram_reg[43][14]_i_3_n_1 ,\NLW_ram_reg[43][14]_i_3_CO_UNCONNECTED [1],\ram_reg[43][14]_i_3_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\ram[43][14]_i_9_n_0 ,1'b0}),
        .O({\NLW_ram_reg[43][14]_i_3_O_UNCONNECTED [3:2],\ram_reg[43][14]_i_3_n_6 ,\ram_reg[43][14]_i_3_n_7 }),
        .S({1'b0,1'b1,\ram[43][14]_i_10_n_0 ,\ram[43][14]_i_11_n_0 }));
  CARRY4 \ram_reg[43][14]_i_7 
       (.CI(1'b0),
        .CO({\ram_reg[43][14]_i_7_n_0 ,\ram_reg[43][14]_i_7_n_1 ,\ram_reg[43][14]_i_7_n_2 ,\ram_reg[43][14]_i_7_n_3 }),
        .CYINIT(\ram[45][11]_i_14_n_0 ),
        .DI({1'b0,1'b0,\ram[43][14]_i_12_n_0 ,\ram[43][14]_i_13_n_0 }),
        .O({\ram_reg[43][14]_i_7_n_4 ,\ram_reg[43][14]_i_7_n_5 ,\ram_reg[43][14]_i_7_n_6 ,\ram_reg[43][14]_i_7_n_7 }),
        .S({\ram[43][14]_i_14_n_0 ,\ram[43][14]_i_15_n_0 ,\ram[43][14]_i_16_n_0 ,1'b1}));
  CARRY4 \ram_reg[43][14]_i_8 
       (.CI(\ram_reg[43][14]_i_7_n_0 ),
        .CO({\NLW_ram_reg[43][14]_i_8_CO_UNCONNECTED [3:1],\ram_reg[43][14]_i_8_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(\NLW_ram_reg[43][14]_i_8_O_UNCONNECTED [3:0]),
        .S({1'b0,1'b0,1'b0,1'b1}));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[43][1] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(p_19_in[1]),
        .Q(\ram_reg[43]_2 [1]),
        .R(1'b0));
  MUXF7 \ram_reg[43][1]_i_2 
       (.I0(\ram[43][1]_i_5_n_0 ),
        .I1(\ram[43][1]_i_6_n_0 ),
        .O(\ram_reg[43][1]_i_2_n_0 ),
        .S(\ram_reg[43][14]_i_3_n_6 ));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[43][2] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(p_19_in[2]),
        .Q(\ram_reg[43]_2 [2]),
        .R(1'b0));
  MUXF7 \ram_reg[43][2]_i_2 
       (.I0(\ram[43][2]_i_5_n_0 ),
        .I1(\ram[43][2]_i_6_n_0 ),
        .O(\ram_reg[43][2]_i_2_n_0 ),
        .S(\ram_reg[43][14]_i_3_n_6 ));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[43][3] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(p_19_in[3]),
        .Q(\ram_reg[43]_2 [3]),
        .R(1'b0));
  MUXF7 \ram_reg[43][3]_i_2 
       (.I0(\ram[43][3]_i_5_n_0 ),
        .I1(\ram[43][3]_i_6_n_0 ),
        .O(\ram_reg[43][3]_i_2_n_0 ),
        .S(\ram_reg[43][14]_i_3_n_6 ));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[43][4] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(p_19_in[4]),
        .Q(\ram_reg[43]_2 [4]),
        .R(1'b0));
  MUXF7 \ram_reg[43][4]_i_2 
       (.I0(\ram[43][4]_i_5_n_0 ),
        .I1(\ram[43][4]_i_6_n_0 ),
        .O(\ram_reg[43][4]_i_2_n_0 ),
        .S(\ram_reg[43][14]_i_3_n_6 ));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[43][5] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(p_19_in[5]),
        .Q(\ram_reg[43]_2 [5]),
        .R(1'b0));
  MUXF7 \ram_reg[43][5]_i_2 
       (.I0(\ram[43][5]_i_5_n_0 ),
        .I1(\ram[43][5]_i_6_n_0 ),
        .O(\ram_reg[43][5]_i_2_n_0 ),
        .S(\ram_reg[43][14]_i_3_n_6 ));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[43][6] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(p_19_in[6]),
        .Q(\ram_reg[43]_2 [6]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[43][7] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(p_19_in[7]),
        .Q(\ram_reg[43]_2 [7]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[43][8] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(p_19_in[8]),
        .Q(\ram_reg[43]_2 [8]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[43][9] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(p_19_in[9]),
        .Q(\ram_reg[43]_2 [9]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[44][11] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(p_20_in[11]),
        .Q(\ram_reg[44]_1 [11]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[44][12] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(p_20_in[12]),
        .Q(\ram_reg[44]_1 [12]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[44][15] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(p_20_in[15]),
        .Q(\ram_reg[44]_1 [15]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[44][38] 
       (.C(CLK),
        .CE(1'b1),
        .D(\ram[44][38]_i_1_n_0 ),
        .Q(\ram_reg[44]_1 [38]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ram_reg[44][8] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(p_20_in[8]),
        .Q(\ram_reg[44]_1 [8]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE \ram_reg[45][11] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(p_21_in[11]),
        .Q(\ram_reg[45]_0 [11]),
        .R(1'b0));
  CARRY4 \ram_reg[45][11]_i_3 
       (.CI(1'b0),
        .CO({\NLW_ram_reg[45][11]_i_3_CO_UNCONNECTED [3],\ram_reg[45][11]_i_3_n_1 ,\NLW_ram_reg[45][11]_i_3_CO_UNCONNECTED [1],\ram_reg[45][11]_i_3_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\ram[45][11]_i_9_n_0 ,1'b0}),
        .O({\NLW_ram_reg[45][11]_i_3_O_UNCONNECTED [3:2],\ram_reg[45][11]_i_3_n_6 ,\NLW_ram_reg[45][11]_i_3_O_UNCONNECTED [0]}),
        .S({1'b0,1'b1,\ram[45][11]_i_10_n_0 ,\ram[45][11]_i_11_n_0 }));
  MUXF7 \ram_reg[45][11]_i_5 
       (.I0(\ram[45][11]_i_12_n_0 ),
        .I1(\ram[45][11]_i_13_n_0 ),
        .O(\ram_reg[45][11]_i_5_n_0 ),
        .S(\ram_reg[45][11]_i_3_n_6 ));
  CARRY4 \ram_reg[45][11]_i_7 
       (.CI(1'b0),
        .CO({\ram_reg[45][11]_i_7_n_0 ,\ram_reg[45][11]_i_7_n_1 ,\ram_reg[45][11]_i_7_n_2 ,\ram_reg[45][11]_i_7_n_3 }),
        .CYINIT(\ram[45][11]_i_14_n_0 ),
        .DI({1'b0,1'b0,\ram[45][11]_i_15_n_0 ,\ram[45][11]_i_16_n_0 }),
        .O({\ram_reg[45][11]_i_7_n_4 ,\ram_reg[45][11]_i_7_n_5 ,\ram_reg[45][11]_i_7_n_6 ,\NLW_ram_reg[45][11]_i_7_O_UNCONNECTED [0]}),
        .S({\ram[45][11]_i_17_n_0 ,\ram[45][11]_i_18_n_0 ,\ram[45][11]_i_19_n_0 ,1'b1}));
  CARRY4 \ram_reg[45][11]_i_8 
       (.CI(\ram_reg[45][11]_i_7_n_0 ),
        .CO({\NLW_ram_reg[45][11]_i_8_CO_UNCONNECTED [3:1],\ram_reg[45][11]_i_8_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(\NLW_ram_reg[45][11]_i_8_O_UNCONNECTED [3:0]),
        .S({1'b0,1'b0,1'b0,1'b1}));
  (* RAM_STYLE = "distributed" *) 
  FDRE \ram_reg[45][12] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(p_21_in[12]),
        .Q(\ram_reg[45]_0 [12]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE \ram_reg[45][15] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(p_21_in[15]),
        .Q(\ram_reg[45]_0 [15]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE \ram_reg[45][4] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(p_21_in[4]),
        .Q(\ram_reg[45]_0 [4]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE \ram_reg[45][7] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(p_21_in[7]),
        .Q(\ram_reg[45]_0 [7]),
        .R(1'b0));
  (* RAM_STYLE = "distributed" *) 
  FDRE \ram_reg[45][8] 
       (.C(CLK),
        .CE(\ram_reg[26][0]_0 ),
        .D(p_21_in[8]),
        .Q(\ram_reg[45]_0 [8]),
        .R(1'b0));
  MUXF7 \ram_reg[45][8]_i_4 
       (.I0(\ram[45][8]_i_5_n_0 ),
        .I1(\ram[45][8]_i_6_n_0 ),
        .O(\ram_reg[45][8]_i_4_n_0 ),
        .S(\ram_reg[45][11]_i_3_n_6 ));
  LUT1 #(
    .INIT(2'h1)) 
    \state_count[0]_i_1 
       (.I0(state_count[0]),
        .O(\state_count[0]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT2 #(
    .INIT(4'h9)) 
    \state_count[1]_i_1 
       (.I0(state_count[0]),
        .I1(state_count[1]),
        .O(\state_count[1]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT3 #(
    .INIT(8'hE1)) 
    \state_count[2]_i_1 
       (.I0(state_count[1]),
        .I1(state_count[0]),
        .I2(state_count[2]),
        .O(\state_count[2]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAAA8FFFF00020000)) 
    \state_count[3]_i_1 
       (.I0(current_state[3]),
        .I1(state_count[1]),
        .I2(state_count[0]),
        .I3(state_count[2]),
        .I4(\state_count[4]_i_2_n_0 ),
        .I5(state_count[3]),
        .O(\state_count[3]_i_1_n_0 ));
  LUT4 #(
    .INIT(16'h0010)) 
    \state_count[4]_i_1 
       (.I0(current_state[2]),
        .I1(current_state[0]),
        .I2(current_state[1]),
        .I3(current_state[3]),
        .O(\state_count[4]_i_1_n_0 ));
  LUT4 #(
    .INIT(16'h0006)) 
    \state_count[4]_i_2 
       (.I0(current_state[3]),
        .I1(current_state[1]),
        .I2(current_state[0]),
        .I3(current_state[2]),
        .O(\state_count[4]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'hFFFE0001)) 
    \state_count[4]_i_3 
       (.I0(state_count[3]),
        .I1(state_count[1]),
        .I2(state_count[0]),
        .I3(state_count[2]),
        .I4(state_count[4]),
        .O(\state_count[4]_i_3_n_0 ));
  FDSE #(
    .INIT(1'b1)) 
    \state_count_reg[0] 
       (.C(CLK),
        .CE(\state_count[4]_i_2_n_0 ),
        .D(\state_count[0]_i_1_n_0 ),
        .Q(state_count[0]),
        .S(\state_count[4]_i_1_n_0 ));
  FDSE #(
    .INIT(1'b1)) 
    \state_count_reg[1] 
       (.C(CLK),
        .CE(\state_count[4]_i_2_n_0 ),
        .D(\state_count[1]_i_1_n_0 ),
        .Q(state_count[1]),
        .S(\state_count[4]_i_1_n_0 ));
  FDSE #(
    .INIT(1'b1)) 
    \state_count_reg[2] 
       (.C(CLK),
        .CE(\state_count[4]_i_2_n_0 ),
        .D(\state_count[2]_i_1_n_0 ),
        .Q(state_count[2]),
        .S(\state_count[4]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \state_count_reg[3] 
       (.C(CLK),
        .CE(1'b1),
        .D(\state_count[3]_i_1_n_0 ),
        .Q(state_count[3]),
        .R(1'b0));
  FDSE #(
    .INIT(1'b1)) 
    \state_count_reg[4] 
       (.C(CLK),
        .CE(\state_count[4]_i_2_n_0 ),
        .D(\state_count[4]_i_3_n_0 ),
        .Q(state_count[4]),
        .S(\state_count[4]_i_1_n_0 ));
endmodule

(* ORIG_REF_NAME = "pattern_multi" *) 
module system_pattern_multi_0_0_pattern_multi
   (locked,
    PCK,
    SerialClk,
    reconfig_done,
    VGA_HS,
    VGA_VS,
    VGA_R,
    VGA_G,
    VGA_B,
    VGA_DE,
    timing_sel_imm,
    timing_sel,
    pattern_sel,
    CLK,
    reconfig_req,
    RST);
  output locked;
  output PCK;
  output SerialClk;
  output reconfig_done;
  output VGA_HS;
  output VGA_VS;
  output [7:0]VGA_R;
  output [7:0]VGA_G;
  output [7:0]VGA_B;
  output VGA_DE;
  input [1:0]timing_sel_imm;
  input [1:0]timing_sel;
  input [3:0]pattern_sel;
  input CLK;
  input reconfig_req;
  input RST;

  wire [10:6]A;
  wire CLK;
  wire [3:3]HBACK;
  wire [8:8]HPERIOD;
  wire [4:4]HWIDTH;
  wire PCK;
  wire RST;
  wire SerialClk;
  wire [7:0]VGA_B;
  wire VGA_DE;
  wire [7:0]VGA_G;
  wire VGA_HS;
  wire [7:0]VGA_R;
  wire \VGA_R[0]_i_10_n_0 ;
  wire \VGA_R[0]_i_12_n_0 ;
  wire \VGA_R[0]_i_13_n_0 ;
  wire \VGA_R[0]_i_14_n_0 ;
  wire \VGA_R[0]_i_15_n_0 ;
  wire \VGA_R[0]_i_16_n_0 ;
  wire \VGA_R[0]_i_17_n_0 ;
  wire \VGA_R[0]_i_18_n_0 ;
  wire \VGA_R[0]_i_19_n_0 ;
  wire \VGA_R[0]_i_20_n_0 ;
  wire \VGA_R[0]_i_21_n_0 ;
  wire \VGA_R[0]_i_22_n_0 ;
  wire \VGA_R[0]_i_23_n_0 ;
  wire \VGA_R[0]_i_24_n_0 ;
  wire \VGA_R[0]_i_25_n_0 ;
  wire \VGA_R[0]_i_27_n_0 ;
  wire \VGA_R[0]_i_29_n_0 ;
  wire \VGA_R[0]_i_2_n_0 ;
  wire \VGA_R[0]_i_31_n_0 ;
  wire \VGA_R[0]_i_8_n_0 ;
  wire \VGA_R[0]_i_9_n_0 ;
  wire \VGA_R[1]_i_10_n_0 ;
  wire \VGA_R[1]_i_12_n_0 ;
  wire \VGA_R[1]_i_13_n_0 ;
  wire \VGA_R[1]_i_14_n_0 ;
  wire \VGA_R[1]_i_15_n_0 ;
  wire \VGA_R[1]_i_16_n_0 ;
  wire \VGA_R[1]_i_17_n_0 ;
  wire \VGA_R[1]_i_18_n_0 ;
  wire \VGA_R[1]_i_19_n_0 ;
  wire \VGA_R[1]_i_20_n_0 ;
  wire \VGA_R[1]_i_21_n_0 ;
  wire \VGA_R[1]_i_22_n_0 ;
  wire \VGA_R[1]_i_23_n_0 ;
  wire \VGA_R[1]_i_24_n_0 ;
  wire \VGA_R[1]_i_25_n_0 ;
  wire \VGA_R[1]_i_27_n_0 ;
  wire \VGA_R[1]_i_2_n_0 ;
  wire \VGA_R[1]_i_8_n_0 ;
  wire \VGA_R[1]_i_9_n_0 ;
  wire \VGA_R[2]_i_10_n_0 ;
  wire \VGA_R[2]_i_12_n_0 ;
  wire \VGA_R[2]_i_13_n_0 ;
  wire \VGA_R[2]_i_14_n_0 ;
  wire \VGA_R[2]_i_15_n_0 ;
  wire \VGA_R[2]_i_16_n_0 ;
  wire \VGA_R[2]_i_17_n_0 ;
  wire \VGA_R[2]_i_18_n_0 ;
  wire \VGA_R[2]_i_19_n_0 ;
  wire \VGA_R[2]_i_20_n_0 ;
  wire \VGA_R[2]_i_21_n_0 ;
  wire \VGA_R[2]_i_22_n_0 ;
  wire \VGA_R[2]_i_23_n_0 ;
  wire \VGA_R[2]_i_24_n_0 ;
  wire \VGA_R[2]_i_25_n_0 ;
  wire \VGA_R[2]_i_27_n_0 ;
  wire \VGA_R[2]_i_2_n_0 ;
  wire \VGA_R[2]_i_8_n_0 ;
  wire \VGA_R[2]_i_9_n_0 ;
  wire \VGA_R[3]_i_10_n_0 ;
  wire \VGA_R[3]_i_11_n_0 ;
  wire \VGA_R[3]_i_12_n_0 ;
  wire \VGA_R[3]_i_14_n_0 ;
  wire \VGA_R[3]_i_15_n_0 ;
  wire \VGA_R[3]_i_16_n_0 ;
  wire \VGA_R[3]_i_17_n_0 ;
  wire \VGA_R[3]_i_18_n_0 ;
  wire \VGA_R[3]_i_19_n_0 ;
  wire \VGA_R[3]_i_20_n_0 ;
  wire \VGA_R[3]_i_21_n_0 ;
  wire \VGA_R[3]_i_22_n_0 ;
  wire \VGA_R[3]_i_23_n_0 ;
  wire \VGA_R[3]_i_24_n_0 ;
  wire \VGA_R[3]_i_25_n_0 ;
  wire \VGA_R[3]_i_26_n_0 ;
  wire \VGA_R[3]_i_27_n_0 ;
  wire \VGA_R[3]_i_29_n_0 ;
  wire \VGA_R[3]_i_9_n_0 ;
  wire \VGA_R[4]_i_13_n_0 ;
  wire \VGA_R[4]_i_14_n_0 ;
  wire \VGA_R[4]_i_15_n_0 ;
  wire \VGA_R[4]_i_16_n_0 ;
  wire \VGA_R[4]_i_18_n_0 ;
  wire \VGA_R[4]_i_19_n_0 ;
  wire \VGA_R[4]_i_20_n_0 ;
  wire \VGA_R[4]_i_21_n_0 ;
  wire \VGA_R[4]_i_30_n_0 ;
  wire \VGA_R[4]_i_31_n_0 ;
  wire \VGA_R[4]_i_32_n_0 ;
  wire \VGA_R[4]_i_33_n_0 ;
  wire \VGA_R[4]_i_34_n_0 ;
  wire \VGA_R[4]_i_35_n_0 ;
  wire \VGA_R[4]_i_36_n_0 ;
  wire \VGA_R[4]_i_37_n_0 ;
  wire \VGA_R[4]_i_38_n_0 ;
  wire \VGA_R[4]_i_39_n_0 ;
  wire \VGA_R[4]_i_41_n_0 ;
  wire \VGA_R[5]_i_101_n_0 ;
  wire \VGA_R[5]_i_102_n_0 ;
  wire \VGA_R[5]_i_103_n_0 ;
  wire \VGA_R[5]_i_104_n_0 ;
  wire \VGA_R[5]_i_105_n_0 ;
  wire \VGA_R[5]_i_106_n_0 ;
  wire \VGA_R[5]_i_107_n_0 ;
  wire \VGA_R[5]_i_109_n_0 ;
  wire \VGA_R[5]_i_111_n_0 ;
  wire \VGA_R[5]_i_112_n_0 ;
  wire \VGA_R[5]_i_113_n_0 ;
  wire \VGA_R[5]_i_115_n_0 ;
  wire \VGA_R[5]_i_116_n_0 ;
  wire \VGA_R[5]_i_118_n_0 ;
  wire \VGA_R[5]_i_119_n_0 ;
  wire \VGA_R[5]_i_120_n_0 ;
  wire \VGA_R[5]_i_121_n_0 ;
  wire \VGA_R[5]_i_122_n_0 ;
  wire \VGA_R[5]_i_124_n_0 ;
  wire \VGA_R[5]_i_125_n_0 ;
  wire \VGA_R[5]_i_126_n_0 ;
  wire \VGA_R[5]_i_127_n_0 ;
  wire \VGA_R[5]_i_128_n_0 ;
  wire \VGA_R[5]_i_129_n_0 ;
  wire \VGA_R[5]_i_130_n_0 ;
  wire \VGA_R[5]_i_131_n_0 ;
  wire \VGA_R[5]_i_132_n_0 ;
  wire \VGA_R[5]_i_133_n_0 ;
  wire \VGA_R[5]_i_134_n_0 ;
  wire \VGA_R[5]_i_135_n_0 ;
  wire \VGA_R[5]_i_136_n_0 ;
  wire \VGA_R[5]_i_137_n_0 ;
  wire \VGA_R[5]_i_138_n_0 ;
  wire \VGA_R[5]_i_139_n_0 ;
  wire \VGA_R[5]_i_140_n_0 ;
  wire \VGA_R[5]_i_22_n_0 ;
  wire \VGA_R[5]_i_23_n_0 ;
  wire \VGA_R[5]_i_24_n_0 ;
  wire \VGA_R[5]_i_25_n_0 ;
  wire \VGA_R[5]_i_27_n_0 ;
  wire \VGA_R[5]_i_28_n_0 ;
  wire \VGA_R[5]_i_29_n_0 ;
  wire \VGA_R[5]_i_30_n_0 ;
  wire \VGA_R[5]_i_5_n_0 ;
  wire \VGA_R[5]_i_60_n_0 ;
  wire \VGA_R[5]_i_61_n_0 ;
  wire \VGA_R[5]_i_62_n_0 ;
  wire \VGA_R[5]_i_63_n_0 ;
  wire \VGA_R[5]_i_64_n_0 ;
  wire \VGA_R[5]_i_65_n_0 ;
  wire \VGA_R[5]_i_66_n_0 ;
  wire \VGA_R[5]_i_67_n_0 ;
  wire \VGA_R[5]_i_68_n_0 ;
  wire \VGA_R[5]_i_69_n_0 ;
  wire \VGA_R[5]_i_96_n_0 ;
  wire \VGA_R[6]_i_10_n_0 ;
  wire \VGA_R[6]_i_11_n_0 ;
  wire \VGA_R[6]_i_13_n_0 ;
  wire \VGA_R[6]_i_14_n_0 ;
  wire \VGA_R[6]_i_15_n_0 ;
  wire \VGA_R[6]_i_16_n_0 ;
  wire \VGA_R[6]_i_17_n_0 ;
  wire \VGA_R[6]_i_18_n_0 ;
  wire \VGA_R[6]_i_19_n_0 ;
  wire \VGA_R[6]_i_20_n_0 ;
  wire \VGA_R[6]_i_21_n_0 ;
  wire \VGA_R[6]_i_22_n_0 ;
  wire \VGA_R[6]_i_23_n_0 ;
  wire \VGA_R[6]_i_24_n_0 ;
  wire \VGA_R[6]_i_25_n_0 ;
  wire \VGA_R[6]_i_26_n_0 ;
  wire \VGA_R[6]_i_29_n_0 ;
  wire \VGA_R[6]_i_30_n_0 ;
  wire \VGA_R[6]_i_31_n_0 ;
  wire \VGA_R[6]_i_32_n_0 ;
  wire \VGA_R[6]_i_33_n_0 ;
  wire \VGA_R[6]_i_8_n_0 ;
  wire \VGA_R[6]_i_9_n_0 ;
  wire \VGA_R[7]_i_112_n_0 ;
  wire \VGA_R[7]_i_113_n_0 ;
  wire \VGA_R[7]_i_114_n_0 ;
  wire \VGA_R[7]_i_115_n_0 ;
  wire \VGA_R[7]_i_119_n_0 ;
  wire \VGA_R[7]_i_120_n_0 ;
  wire \VGA_R[7]_i_129_n_0 ;
  wire \VGA_R[7]_i_131_n_0 ;
  wire \VGA_R[7]_i_176_n_0 ;
  wire \VGA_R[7]_i_177_n_0 ;
  wire \VGA_R[7]_i_178_n_0 ;
  wire \VGA_R[7]_i_179_n_0 ;
  wire \VGA_R[7]_i_180_n_0 ;
  wire \VGA_R[7]_i_183_n_0 ;
  wire \VGA_R[7]_i_184_n_0 ;
  wire \VGA_R[7]_i_185_n_0 ;
  wire \VGA_R[7]_i_186_n_0 ;
  wire \VGA_R[7]_i_187_n_0 ;
  wire \VGA_R[7]_i_188_n_0 ;
  wire \VGA_R[7]_i_189_n_0 ;
  wire \VGA_R[7]_i_190_n_0 ;
  wire \VGA_R[7]_i_191_n_0 ;
  wire \VGA_R[7]_i_192_n_0 ;
  wire \VGA_R[7]_i_205_n_0 ;
  wire \VGA_R[7]_i_206_n_0 ;
  wire \VGA_R[7]_i_207_n_0 ;
  wire \VGA_R[7]_i_208_n_0 ;
  wire \VGA_R[7]_i_209_n_0 ;
  wire \VGA_R[7]_i_210_n_0 ;
  wire \VGA_R[7]_i_242_n_0 ;
  wire \VGA_R[7]_i_243_n_0 ;
  wire \VGA_R[7]_i_244_n_0 ;
  wire \VGA_R[7]_i_245_n_0 ;
  wire \VGA_R[7]_i_246_n_0 ;
  wire \VGA_R[7]_i_247_n_0 ;
  wire \VGA_R[7]_i_248_n_0 ;
  wire \VGA_R[7]_i_249_n_0 ;
  wire \VGA_R[7]_i_25_n_0 ;
  wire \VGA_R[7]_i_270_n_0 ;
  wire \VGA_R[7]_i_271_n_0 ;
  wire \VGA_R[7]_i_272_n_0 ;
  wire \VGA_R[7]_i_273_n_0 ;
  wire \VGA_R[7]_i_274_n_0 ;
  wire \VGA_R[7]_i_277_n_0 ;
  wire \VGA_R[7]_i_278_n_0 ;
  wire \VGA_R[7]_i_279_n_0 ;
  wire \VGA_R[7]_i_280_n_0 ;
  wire \VGA_R[7]_i_281_n_0 ;
  wire \VGA_R[7]_i_282_n_0 ;
  wire \VGA_R[7]_i_283_n_0 ;
  wire \VGA_R[7]_i_284_n_0 ;
  wire \VGA_R[7]_i_285_n_0 ;
  wire \VGA_R[7]_i_286_n_0 ;
  wire \VGA_R[7]_i_29_n_0 ;
  wire \VGA_R[7]_i_310_n_0 ;
  wire \VGA_R[7]_i_311_n_0 ;
  wire \VGA_R[7]_i_312_n_0 ;
  wire \VGA_R[7]_i_313_n_0 ;
  wire \VGA_R[7]_i_314_n_0 ;
  wire \VGA_R[7]_i_315_n_0 ;
  wire \VGA_R[7]_i_316_n_0 ;
  wire \VGA_R[7]_i_319_n_0 ;
  wire \VGA_R[7]_i_34_n_0 ;
  wire \VGA_R[7]_i_366_n_0 ;
  wire \VGA_R[7]_i_369_n_0 ;
  wire \VGA_R[7]_i_370_n_0 ;
  wire \VGA_R[7]_i_371_n_0 ;
  wire \VGA_R[7]_i_372_n_0 ;
  wire \VGA_R[7]_i_373_n_0 ;
  wire \VGA_R[7]_i_374_n_0 ;
  wire \VGA_R[7]_i_375_n_0 ;
  wire \VGA_R[7]_i_376_n_0 ;
  wire \VGA_R[7]_i_377_n_0 ;
  wire \VGA_R[7]_i_379_n_0 ;
  wire \VGA_R[7]_i_380_n_0 ;
  wire \VGA_R[7]_i_381_n_0 ;
  wire \VGA_R[7]_i_382_n_0 ;
  wire \VGA_R[7]_i_383_n_0 ;
  wire \VGA_R[7]_i_384_n_0 ;
  wire \VGA_R[7]_i_385_n_0 ;
  wire \VGA_R[7]_i_386_n_0 ;
  wire \VGA_R[7]_i_387_n_0 ;
  wire \VGA_R[7]_i_388_n_0 ;
  wire \VGA_R[7]_i_389_n_0 ;
  wire \VGA_R[7]_i_390_n_0 ;
  wire \VGA_R[7]_i_391_n_0 ;
  wire \VGA_R[7]_i_392_n_0 ;
  wire \VGA_R[7]_i_419_n_0 ;
  wire \VGA_R[7]_i_420_n_0 ;
  wire \VGA_R[7]_i_421_n_0 ;
  wire \VGA_R[7]_i_423_n_0 ;
  wire \VGA_R[7]_i_424_n_0 ;
  wire \VGA_R[7]_i_425_n_0 ;
  wire \VGA_R[7]_i_426_n_0 ;
  wire \VGA_R[7]_i_427_n_0 ;
  wire \VGA_R[7]_i_438_n_0 ;
  wire \VGA_R[7]_i_439_n_0 ;
  wire \VGA_R[7]_i_440_n_0 ;
  wire \VGA_R[7]_i_441_n_0 ;
  wire \VGA_R[7]_i_442_n_0 ;
  wire \VGA_R[7]_i_443_n_0 ;
  wire \VGA_R[7]_i_444_n_0 ;
  wire \VGA_R[7]_i_445_n_0 ;
  wire \VGA_R[7]_i_446_n_0 ;
  wire \VGA_R[7]_i_461_n_0 ;
  wire \VGA_R[7]_i_464_n_0 ;
  wire \VGA_R[7]_i_465_n_0 ;
  wire \VGA_R[7]_i_466_n_0 ;
  wire \VGA_R[7]_i_467_n_0 ;
  wire \VGA_R[7]_i_468_n_0 ;
  wire \VGA_R[7]_i_469_n_0 ;
  wire \VGA_R[7]_i_470_n_0 ;
  wire \VGA_R[7]_i_471_n_0 ;
  wire \VGA_R[7]_i_472_n_0 ;
  wire \VGA_R[7]_i_475_n_0 ;
  wire \VGA_R[7]_i_479_n_0 ;
  wire \VGA_R[7]_i_480_n_0 ;
  wire \VGA_R[7]_i_481_n_0 ;
  wire \VGA_R[7]_i_482_n_0 ;
  wire \VGA_R[7]_i_484_n_0 ;
  wire \VGA_R[7]_i_485_n_0 ;
  wire \VGA_R[7]_i_486_n_0 ;
  wire \VGA_R[7]_i_487_n_0 ;
  wire \VGA_R[7]_i_488_n_0 ;
  wire \VGA_R[7]_i_489_n_0 ;
  wire \VGA_R[7]_i_490_n_0 ;
  wire \VGA_R[7]_i_491_n_0 ;
  wire \VGA_R[7]_i_492_n_0 ;
  wire \VGA_R[7]_i_495_n_0 ;
  wire \VGA_R[7]_i_496_n_0 ;
  wire \VGA_R[7]_i_497_n_0 ;
  wire \VGA_R[7]_i_498_n_0 ;
  wire \VGA_R[7]_i_514_n_0 ;
  wire \VGA_R[7]_i_515_n_0 ;
  wire \VGA_R[7]_i_516_n_0 ;
  wire \VGA_R[7]_i_517_n_0 ;
  wire \VGA_R[7]_i_518_n_0 ;
  wire \VGA_R[7]_i_519_n_0 ;
  wire \VGA_R[7]_i_520_n_0 ;
  wire \VGA_R[7]_i_521_n_0 ;
  wire \VGA_R[7]_i_522_n_0 ;
  wire \VGA_R[7]_i_523_n_0 ;
  wire \VGA_R[7]_i_524_n_0 ;
  wire \VGA_R[7]_i_525_n_0 ;
  wire \VGA_R[7]_i_526_n_0 ;
  wire \VGA_R[7]_i_529_n_0 ;
  wire \VGA_R[7]_i_531_n_0 ;
  wire \VGA_R[7]_i_532_n_0 ;
  wire \VGA_R[7]_i_533_n_0 ;
  wire \VGA_R[7]_i_534_n_0 ;
  wire \VGA_R[7]_i_535_n_0 ;
  wire \VGA_R[7]_i_536_n_0 ;
  wire \VGA_R[7]_i_537_n_0 ;
  wire \VGA_R[7]_i_538_n_0 ;
  wire \VGA_R[7]_i_539_n_0 ;
  wire \VGA_R[7]_i_541_n_0 ;
  wire \VGA_R[7]_i_542_n_0 ;
  wire \VGA_R[7]_i_543_n_0 ;
  wire \VGA_R[7]_i_544_n_0 ;
  wire \VGA_R[7]_i_545_n_0 ;
  wire \VGA_R[7]_i_546_n_0 ;
  wire \VGA_R[7]_i_547_n_0 ;
  wire \VGA_R[7]_i_548_n_0 ;
  wire \VGA_R[7]_i_549_n_0 ;
  wire \VGA_R[7]_i_550_n_0 ;
  wire \VGA_R[7]_i_551_n_0 ;
  wire \VGA_R[7]_i_553_n_0 ;
  wire \VGA_R[7]_i_554_n_0 ;
  wire \VGA_R[7]_i_555_n_0 ;
  wire \VGA_R[7]_i_561_n_0 ;
  wire \VGA_R[7]_i_562_n_0 ;
  wire \VGA_R[7]_i_563_n_0 ;
  wire \VGA_R[7]_i_564_n_0 ;
  wire \VGA_R[7]_i_565_n_0 ;
  wire \VGA_R[7]_i_566_n_0 ;
  wire \VGA_R[7]_i_567_n_0 ;
  wire \VGA_R[7]_i_568_n_0 ;
  wire \VGA_R[7]_i_569_n_0 ;
  wire \VGA_R[7]_i_570_n_0 ;
  wire \VGA_R[7]_i_573_n_0 ;
  wire \VGA_R[7]_i_575_n_0 ;
  wire \VGA_R[7]_i_576_n_0 ;
  wire \VGA_R[7]_i_577_n_0 ;
  wire \VGA_R[7]_i_578_n_0 ;
  wire \VGA_R[7]_i_579_n_0 ;
  wire \VGA_R[7]_i_580_n_0 ;
  wire \VGA_R[7]_i_581_n_0 ;
  wire \VGA_R[7]_i_582_n_0 ;
  wire \VGA_R[7]_i_583_n_0 ;
  wire \VGA_R[7]_i_585_n_0 ;
  wire \VGA_R[7]_i_586_n_0 ;
  wire \VGA_R[7]_i_587_n_0 ;
  wire \VGA_R[7]_i_588_n_0 ;
  wire \VGA_R[7]_i_589_n_0 ;
  wire \VGA_R[7]_i_590_n_0 ;
  wire \VGA_R[7]_i_591_n_0 ;
  wire \VGA_R[7]_i_594_n_0 ;
  wire \VGA_R[7]_i_596_n_0 ;
  wire \VGA_R[7]_i_597_n_0 ;
  wire \VGA_R[7]_i_598_n_0 ;
  wire \VGA_R[7]_i_599_n_0 ;
  wire \VGA_R[7]_i_600_n_0 ;
  wire \VGA_R[7]_i_601_n_0 ;
  wire \VGA_R[7]_i_602_n_0 ;
  wire \VGA_R[7]_i_603_n_0 ;
  wire \VGA_R[7]_i_604_n_0 ;
  wire \VGA_R[7]_i_606_n_0 ;
  wire \VGA_R[7]_i_607_n_0 ;
  wire \VGA_R[7]_i_608_n_0 ;
  wire \VGA_R[7]_i_60_n_0 ;
  wire \VGA_R[7]_i_610_n_0 ;
  wire \VGA_R[7]_i_611_n_0 ;
  wire \VGA_R[7]_i_612_n_0 ;
  wire \VGA_R[7]_i_613_n_0 ;
  wire \VGA_R[7]_i_614_n_0 ;
  wire \VGA_R[7]_i_615_n_0 ;
  wire \VGA_R[7]_i_616_n_0 ;
  wire \VGA_R[7]_i_617_n_0 ;
  wire \VGA_R[7]_i_618_n_0 ;
  wire \VGA_R[7]_i_619_n_0 ;
  wire \VGA_R[7]_i_620_n_0 ;
  wire \VGA_R[7]_i_621_n_0 ;
  wire \VGA_R[7]_i_622_n_0 ;
  wire \VGA_R[7]_i_623_n_0 ;
  wire \VGA_R[7]_i_624_n_0 ;
  wire \VGA_R[7]_i_625_n_0 ;
  wire \VGA_R[7]_i_626_n_0 ;
  wire \VGA_R[7]_i_627_n_0 ;
  wire \VGA_R[7]_i_628_n_0 ;
  wire \VGA_R[7]_i_629_n_0 ;
  wire \VGA_R[7]_i_630_n_0 ;
  wire \VGA_R[7]_i_631_n_0 ;
  wire \VGA_R[7]_i_632_n_0 ;
  wire \VGA_R[7]_i_82_n_0 ;
  wire \VGA_R[7]_i_83_n_0 ;
  wire \VGA_R[7]_i_84_n_0 ;
  wire \VGA_R[7]_i_85_n_0 ;
  wire \VGA_R_reg[0]_i_11_n_0 ;
  wire \VGA_R_reg[0]_i_11_n_1 ;
  wire \VGA_R_reg[0]_i_11_n_2 ;
  wire \VGA_R_reg[0]_i_11_n_3 ;
  wire \VGA_R_reg[0]_i_26_n_7 ;
  wire \VGA_R_reg[0]_i_28_n_7 ;
  wire \VGA_R_reg[0]_i_30_n_7 ;
  wire \VGA_R_reg[0]_i_5_n_2 ;
  wire \VGA_R_reg[0]_i_5_n_3 ;
  wire \VGA_R_reg[0]_i_6_n_1 ;
  wire \VGA_R_reg[0]_i_6_n_2 ;
  wire \VGA_R_reg[0]_i_6_n_3 ;
  wire \VGA_R_reg[0]_i_7_n_0 ;
  wire \VGA_R_reg[0]_i_7_n_1 ;
  wire \VGA_R_reg[0]_i_7_n_2 ;
  wire \VGA_R_reg[0]_i_7_n_3 ;
  wire \VGA_R_reg[1]_i_11_n_0 ;
  wire \VGA_R_reg[1]_i_11_n_1 ;
  wire \VGA_R_reg[1]_i_11_n_2 ;
  wire \VGA_R_reg[1]_i_11_n_3 ;
  wire \VGA_R_reg[1]_i_11_n_4 ;
  wire \VGA_R_reg[1]_i_11_n_5 ;
  wire \VGA_R_reg[1]_i_11_n_6 ;
  wire \VGA_R_reg[1]_i_11_n_7 ;
  wire \VGA_R_reg[1]_i_26_n_7 ;
  wire \VGA_R_reg[1]_i_5_n_2 ;
  wire \VGA_R_reg[1]_i_5_n_3 ;
  wire \VGA_R_reg[1]_i_5_n_6 ;
  wire \VGA_R_reg[1]_i_5_n_7 ;
  wire \VGA_R_reg[1]_i_6_n_1 ;
  wire \VGA_R_reg[1]_i_6_n_2 ;
  wire \VGA_R_reg[1]_i_6_n_3 ;
  wire \VGA_R_reg[1]_i_6_n_5 ;
  wire \VGA_R_reg[1]_i_6_n_6 ;
  wire \VGA_R_reg[1]_i_6_n_7 ;
  wire \VGA_R_reg[1]_i_7_n_0 ;
  wire \VGA_R_reg[1]_i_7_n_1 ;
  wire \VGA_R_reg[1]_i_7_n_2 ;
  wire \VGA_R_reg[1]_i_7_n_3 ;
  wire \VGA_R_reg[1]_i_7_n_4 ;
  wire \VGA_R_reg[1]_i_7_n_5 ;
  wire \VGA_R_reg[1]_i_7_n_6 ;
  wire \VGA_R_reg[1]_i_7_n_7 ;
  wire \VGA_R_reg[2]_i_11_n_0 ;
  wire \VGA_R_reg[2]_i_11_n_1 ;
  wire \VGA_R_reg[2]_i_11_n_2 ;
  wire \VGA_R_reg[2]_i_11_n_3 ;
  wire \VGA_R_reg[2]_i_11_n_4 ;
  wire \VGA_R_reg[2]_i_11_n_5 ;
  wire \VGA_R_reg[2]_i_11_n_6 ;
  wire \VGA_R_reg[2]_i_11_n_7 ;
  wire \VGA_R_reg[2]_i_26_n_7 ;
  wire \VGA_R_reg[2]_i_5_n_2 ;
  wire \VGA_R_reg[2]_i_5_n_3 ;
  wire \VGA_R_reg[2]_i_5_n_6 ;
  wire \VGA_R_reg[2]_i_5_n_7 ;
  wire \VGA_R_reg[2]_i_6_n_1 ;
  wire \VGA_R_reg[2]_i_6_n_2 ;
  wire \VGA_R_reg[2]_i_6_n_3 ;
  wire \VGA_R_reg[2]_i_6_n_5 ;
  wire \VGA_R_reg[2]_i_6_n_6 ;
  wire \VGA_R_reg[2]_i_6_n_7 ;
  wire \VGA_R_reg[2]_i_7_n_0 ;
  wire \VGA_R_reg[2]_i_7_n_1 ;
  wire \VGA_R_reg[2]_i_7_n_2 ;
  wire \VGA_R_reg[2]_i_7_n_3 ;
  wire \VGA_R_reg[2]_i_7_n_4 ;
  wire \VGA_R_reg[2]_i_7_n_5 ;
  wire \VGA_R_reg[2]_i_7_n_6 ;
  wire \VGA_R_reg[2]_i_7_n_7 ;
  wire \VGA_R_reg[3]_i_13_n_0 ;
  wire \VGA_R_reg[3]_i_13_n_1 ;
  wire \VGA_R_reg[3]_i_13_n_2 ;
  wire \VGA_R_reg[3]_i_13_n_3 ;
  wire \VGA_R_reg[3]_i_13_n_4 ;
  wire \VGA_R_reg[3]_i_13_n_5 ;
  wire \VGA_R_reg[3]_i_13_n_6 ;
  wire \VGA_R_reg[3]_i_13_n_7 ;
  wire \VGA_R_reg[3]_i_28_n_7 ;
  wire \VGA_R_reg[3]_i_6_n_2 ;
  wire \VGA_R_reg[3]_i_6_n_3 ;
  wire \VGA_R_reg[3]_i_6_n_4 ;
  wire \VGA_R_reg[3]_i_6_n_6 ;
  wire \VGA_R_reg[3]_i_6_n_7 ;
  wire \VGA_R_reg[3]_i_7_n_1 ;
  wire \VGA_R_reg[3]_i_7_n_2 ;
  wire \VGA_R_reg[3]_i_7_n_3 ;
  wire \VGA_R_reg[3]_i_7_n_5 ;
  wire \VGA_R_reg[3]_i_7_n_6 ;
  wire \VGA_R_reg[3]_i_7_n_7 ;
  wire \VGA_R_reg[3]_i_8_n_0 ;
  wire \VGA_R_reg[3]_i_8_n_1 ;
  wire \VGA_R_reg[3]_i_8_n_2 ;
  wire \VGA_R_reg[3]_i_8_n_3 ;
  wire \VGA_R_reg[3]_i_8_n_4 ;
  wire \VGA_R_reg[3]_i_8_n_5 ;
  wire \VGA_R_reg[3]_i_8_n_6 ;
  wire \VGA_R_reg[3]_i_8_n_7 ;
  wire \VGA_R_reg[4]_i_12_n_0 ;
  wire \VGA_R_reg[4]_i_12_n_1 ;
  wire \VGA_R_reg[4]_i_12_n_2 ;
  wire \VGA_R_reg[4]_i_12_n_3 ;
  wire \VGA_R_reg[4]_i_12_n_4 ;
  wire \VGA_R_reg[4]_i_12_n_5 ;
  wire \VGA_R_reg[4]_i_12_n_6 ;
  wire \VGA_R_reg[4]_i_12_n_7 ;
  wire \VGA_R_reg[4]_i_17_n_0 ;
  wire \VGA_R_reg[4]_i_17_n_1 ;
  wire \VGA_R_reg[4]_i_17_n_2 ;
  wire \VGA_R_reg[4]_i_17_n_3 ;
  wire \VGA_R_reg[4]_i_17_n_4 ;
  wire \VGA_R_reg[4]_i_17_n_5 ;
  wire \VGA_R_reg[4]_i_17_n_6 ;
  wire \VGA_R_reg[4]_i_17_n_7 ;
  wire \VGA_R_reg[4]_i_40_n_7 ;
  wire \VGA_R_reg[4]_i_6_n_2 ;
  wire \VGA_R_reg[4]_i_6_n_3 ;
  wire \VGA_R_reg[4]_i_6_n_4 ;
  wire \VGA_R_reg[4]_i_6_n_6 ;
  wire \VGA_R_reg[4]_i_6_n_7 ;
  wire \VGA_R_reg[4]_i_7_n_1 ;
  wire \VGA_R_reg[4]_i_7_n_2 ;
  wire \VGA_R_reg[4]_i_7_n_3 ;
  wire \VGA_R_reg[4]_i_7_n_5 ;
  wire \VGA_R_reg[4]_i_7_n_6 ;
  wire \VGA_R_reg[4]_i_7_n_7 ;
  wire \VGA_R_reg[5]_i_100_n_7 ;
  wire \VGA_R_reg[5]_i_108_n_1 ;
  wire \VGA_R_reg[5]_i_108_n_3 ;
  wire \VGA_R_reg[5]_i_108_n_6 ;
  wire \VGA_R_reg[5]_i_108_n_7 ;
  wire \VGA_R_reg[5]_i_10_n_1 ;
  wire \VGA_R_reg[5]_i_10_n_2 ;
  wire \VGA_R_reg[5]_i_10_n_3 ;
  wire \VGA_R_reg[5]_i_10_n_5 ;
  wire \VGA_R_reg[5]_i_10_n_6 ;
  wire \VGA_R_reg[5]_i_10_n_7 ;
  wire \VGA_R_reg[5]_i_110_n_0 ;
  wire \VGA_R_reg[5]_i_110_n_1 ;
  wire \VGA_R_reg[5]_i_110_n_2 ;
  wire \VGA_R_reg[5]_i_110_n_3 ;
  wire \VGA_R_reg[5]_i_114_n_0 ;
  wire \VGA_R_reg[5]_i_114_n_1 ;
  wire \VGA_R_reg[5]_i_114_n_2 ;
  wire \VGA_R_reg[5]_i_114_n_3 ;
  wire \VGA_R_reg[5]_i_114_n_4 ;
  wire \VGA_R_reg[5]_i_114_n_5 ;
  wire \VGA_R_reg[5]_i_114_n_6 ;
  wire \VGA_R_reg[5]_i_123_n_0 ;
  wire \VGA_R_reg[5]_i_123_n_1 ;
  wire \VGA_R_reg[5]_i_123_n_2 ;
  wire \VGA_R_reg[5]_i_123_n_3 ;
  wire \VGA_R_reg[5]_i_21_n_0 ;
  wire \VGA_R_reg[5]_i_21_n_1 ;
  wire \VGA_R_reg[5]_i_21_n_2 ;
  wire \VGA_R_reg[5]_i_21_n_3 ;
  wire \VGA_R_reg[5]_i_21_n_4 ;
  wire \VGA_R_reg[5]_i_21_n_5 ;
  wire \VGA_R_reg[5]_i_21_n_6 ;
  wire \VGA_R_reg[5]_i_21_n_7 ;
  wire \VGA_R_reg[5]_i_26_n_0 ;
  wire \VGA_R_reg[5]_i_26_n_1 ;
  wire \VGA_R_reg[5]_i_26_n_2 ;
  wire \VGA_R_reg[5]_i_26_n_3 ;
  wire \VGA_R_reg[5]_i_26_n_4 ;
  wire \VGA_R_reg[5]_i_26_n_5 ;
  wire \VGA_R_reg[5]_i_26_n_6 ;
  wire \VGA_R_reg[5]_i_26_n_7 ;
  wire \VGA_R_reg[5]_i_78_n_3 ;
  wire \VGA_R_reg[5]_i_78_n_6 ;
  wire \VGA_R_reg[5]_i_79_n_0 ;
  wire \VGA_R_reg[5]_i_79_n_2 ;
  wire \VGA_R_reg[5]_i_79_n_3 ;
  wire \VGA_R_reg[5]_i_79_n_5 ;
  wire \VGA_R_reg[5]_i_79_n_6 ;
  wire \VGA_R_reg[5]_i_79_n_7 ;
  wire \VGA_R_reg[5]_i_97_n_1 ;
  wire \VGA_R_reg[5]_i_97_n_3 ;
  wire \VGA_R_reg[5]_i_97_n_6 ;
  wire \VGA_R_reg[5]_i_98_n_2 ;
  wire \VGA_R_reg[5]_i_98_n_3 ;
  wire \VGA_R_reg[5]_i_99_n_1 ;
  wire \VGA_R_reg[5]_i_99_n_3 ;
  wire \VGA_R_reg[5]_i_99_n_6 ;
  wire \VGA_R_reg[5]_i_99_n_7 ;
  wire \VGA_R_reg[5]_i_9_n_2 ;
  wire \VGA_R_reg[5]_i_9_n_3 ;
  wire \VGA_R_reg[5]_i_9_n_4 ;
  wire \VGA_R_reg[5]_i_9_n_6 ;
  wire \VGA_R_reg[5]_i_9_n_7 ;
  wire \VGA_R_reg[6]_i_12_n_0 ;
  wire \VGA_R_reg[6]_i_12_n_1 ;
  wire \VGA_R_reg[6]_i_12_n_2 ;
  wire \VGA_R_reg[6]_i_12_n_3 ;
  wire \VGA_R_reg[6]_i_12_n_4 ;
  wire \VGA_R_reg[6]_i_12_n_5 ;
  wire \VGA_R_reg[6]_i_12_n_6 ;
  wire \VGA_R_reg[6]_i_12_n_7 ;
  wire \VGA_R_reg[6]_i_27_n_7 ;
  wire \VGA_R_reg[6]_i_28_n_1 ;
  wire \VGA_R_reg[6]_i_28_n_2 ;
  wire \VGA_R_reg[6]_i_28_n_3 ;
  wire \VGA_R_reg[6]_i_28_n_4 ;
  wire \VGA_R_reg[6]_i_28_n_6 ;
  wire \VGA_R_reg[6]_i_28_n_7 ;
  wire \VGA_R_reg[6]_i_5_n_1 ;
  wire \VGA_R_reg[6]_i_5_n_2 ;
  wire \VGA_R_reg[6]_i_5_n_3 ;
  wire \VGA_R_reg[6]_i_5_n_5 ;
  wire \VGA_R_reg[6]_i_5_n_6 ;
  wire \VGA_R_reg[6]_i_5_n_7 ;
  wire \VGA_R_reg[6]_i_6_n_2 ;
  wire \VGA_R_reg[6]_i_6_n_3 ;
  wire \VGA_R_reg[6]_i_6_n_4 ;
  wire \VGA_R_reg[6]_i_6_n_6 ;
  wire \VGA_R_reg[6]_i_6_n_7 ;
  wire \VGA_R_reg[6]_i_7_n_0 ;
  wire \VGA_R_reg[6]_i_7_n_1 ;
  wire \VGA_R_reg[6]_i_7_n_2 ;
  wire \VGA_R_reg[6]_i_7_n_3 ;
  wire \VGA_R_reg[6]_i_7_n_4 ;
  wire \VGA_R_reg[6]_i_7_n_5 ;
  wire \VGA_R_reg[6]_i_7_n_6 ;
  wire \VGA_R_reg[6]_i_7_n_7 ;
  wire \VGA_R_reg[7]_i_101_n_0 ;
  wire \VGA_R_reg[7]_i_101_n_1 ;
  wire \VGA_R_reg[7]_i_101_n_2 ;
  wire \VGA_R_reg[7]_i_101_n_3 ;
  wire \VGA_R_reg[7]_i_101_n_5 ;
  wire \VGA_R_reg[7]_i_101_n_6 ;
  wire \VGA_R_reg[7]_i_101_n_7 ;
  wire \VGA_R_reg[7]_i_109_n_0 ;
  wire \VGA_R_reg[7]_i_109_n_1 ;
  wire \VGA_R_reg[7]_i_109_n_2 ;
  wire \VGA_R_reg[7]_i_109_n_3 ;
  wire \VGA_R_reg[7]_i_109_n_4 ;
  wire \VGA_R_reg[7]_i_109_n_5 ;
  wire \VGA_R_reg[7]_i_109_n_6 ;
  wire \VGA_R_reg[7]_i_109_n_7 ;
  wire \VGA_R_reg[7]_i_110_n_1 ;
  wire \VGA_R_reg[7]_i_110_n_2 ;
  wire \VGA_R_reg[7]_i_110_n_3 ;
  wire \VGA_R_reg[7]_i_110_n_4 ;
  wire \VGA_R_reg[7]_i_110_n_6 ;
  wire \VGA_R_reg[7]_i_110_n_7 ;
  wire \VGA_R_reg[7]_i_111_n_0 ;
  wire \VGA_R_reg[7]_i_111_n_1 ;
  wire \VGA_R_reg[7]_i_111_n_2 ;
  wire \VGA_R_reg[7]_i_111_n_3 ;
  wire \VGA_R_reg[7]_i_111_n_4 ;
  wire \VGA_R_reg[7]_i_111_n_5 ;
  wire \VGA_R_reg[7]_i_111_n_6 ;
  wire \VGA_R_reg[7]_i_111_n_7 ;
  wire \VGA_R_reg[7]_i_127_n_0 ;
  wire \VGA_R_reg[7]_i_127_n_1 ;
  wire \VGA_R_reg[7]_i_127_n_2 ;
  wire \VGA_R_reg[7]_i_127_n_3 ;
  wire \VGA_R_reg[7]_i_127_n_4 ;
  wire \VGA_R_reg[7]_i_127_n_5 ;
  wire \VGA_R_reg[7]_i_127_n_6 ;
  wire \VGA_R_reg[7]_i_181_n_0 ;
  wire \VGA_R_reg[7]_i_181_n_1 ;
  wire \VGA_R_reg[7]_i_181_n_2 ;
  wire \VGA_R_reg[7]_i_181_n_3 ;
  wire \VGA_R_reg[7]_i_181_n_5 ;
  wire \VGA_R_reg[7]_i_181_n_6 ;
  wire \VGA_R_reg[7]_i_181_n_7 ;
  wire \VGA_R_reg[7]_i_182_n_0 ;
  wire \VGA_R_reg[7]_i_182_n_1 ;
  wire \VGA_R_reg[7]_i_182_n_2 ;
  wire \VGA_R_reg[7]_i_182_n_3 ;
  wire \VGA_R_reg[7]_i_182_n_4 ;
  wire \VGA_R_reg[7]_i_182_n_5 ;
  wire \VGA_R_reg[7]_i_182_n_6 ;
  wire \VGA_R_reg[7]_i_182_n_7 ;
  wire \VGA_R_reg[7]_i_203_n_0 ;
  wire \VGA_R_reg[7]_i_203_n_1 ;
  wire \VGA_R_reg[7]_i_203_n_2 ;
  wire \VGA_R_reg[7]_i_203_n_3 ;
  wire \VGA_R_reg[7]_i_203_n_4 ;
  wire \VGA_R_reg[7]_i_203_n_5 ;
  wire \VGA_R_reg[7]_i_203_n_6 ;
  wire \VGA_R_reg[7]_i_203_n_7 ;
  wire \VGA_R_reg[7]_i_204_n_0 ;
  wire \VGA_R_reg[7]_i_204_n_1 ;
  wire \VGA_R_reg[7]_i_204_n_2 ;
  wire \VGA_R_reg[7]_i_204_n_3 ;
  wire \VGA_R_reg[7]_i_204_n_4 ;
  wire \VGA_R_reg[7]_i_204_n_5 ;
  wire \VGA_R_reg[7]_i_204_n_6 ;
  wire \VGA_R_reg[7]_i_241_n_0 ;
  wire \VGA_R_reg[7]_i_241_n_1 ;
  wire \VGA_R_reg[7]_i_241_n_2 ;
  wire \VGA_R_reg[7]_i_241_n_3 ;
  wire \VGA_R_reg[7]_i_241_n_4 ;
  wire \VGA_R_reg[7]_i_241_n_5 ;
  wire \VGA_R_reg[7]_i_241_n_6 ;
  wire \VGA_R_reg[7]_i_241_n_7 ;
  wire \VGA_R_reg[7]_i_275_n_1 ;
  wire \VGA_R_reg[7]_i_275_n_2 ;
  wire \VGA_R_reg[7]_i_275_n_3 ;
  wire \VGA_R_reg[7]_i_275_n_4 ;
  wire \VGA_R_reg[7]_i_275_n_6 ;
  wire \VGA_R_reg[7]_i_275_n_7 ;
  wire \VGA_R_reg[7]_i_276_n_0 ;
  wire \VGA_R_reg[7]_i_276_n_1 ;
  wire \VGA_R_reg[7]_i_276_n_2 ;
  wire \VGA_R_reg[7]_i_276_n_3 ;
  wire \VGA_R_reg[7]_i_276_n_4 ;
  wire \VGA_R_reg[7]_i_276_n_5 ;
  wire \VGA_R_reg[7]_i_276_n_6 ;
  wire \VGA_R_reg[7]_i_276_n_7 ;
  wire \VGA_R_reg[7]_i_30_n_1 ;
  wire \VGA_R_reg[7]_i_30_n_2 ;
  wire \VGA_R_reg[7]_i_30_n_3 ;
  wire \VGA_R_reg[7]_i_30_n_5 ;
  wire \VGA_R_reg[7]_i_30_n_6 ;
  wire \VGA_R_reg[7]_i_30_n_7 ;
  wire \VGA_R_reg[7]_i_365_n_7 ;
  wire \VGA_R_reg[7]_i_367_n_0 ;
  wire \VGA_R_reg[7]_i_367_n_1 ;
  wire \VGA_R_reg[7]_i_367_n_2 ;
  wire \VGA_R_reg[7]_i_367_n_3 ;
  wire \VGA_R_reg[7]_i_367_n_5 ;
  wire \VGA_R_reg[7]_i_367_n_6 ;
  wire \VGA_R_reg[7]_i_367_n_7 ;
  wire \VGA_R_reg[7]_i_368_n_0 ;
  wire \VGA_R_reg[7]_i_368_n_1 ;
  wire \VGA_R_reg[7]_i_368_n_2 ;
  wire \VGA_R_reg[7]_i_368_n_3 ;
  wire \VGA_R_reg[7]_i_368_n_4 ;
  wire \VGA_R_reg[7]_i_368_n_5 ;
  wire \VGA_R_reg[7]_i_368_n_6 ;
  wire \VGA_R_reg[7]_i_368_n_7 ;
  wire \VGA_R_reg[7]_i_378_n_7 ;
  wire \VGA_R_reg[7]_i_40_n_2 ;
  wire \VGA_R_reg[7]_i_40_n_3 ;
  wire \VGA_R_reg[7]_i_40_n_4 ;
  wire \VGA_R_reg[7]_i_40_n_6 ;
  wire \VGA_R_reg[7]_i_40_n_7 ;
  wire \VGA_R_reg[7]_i_435_n_1 ;
  wire \VGA_R_reg[7]_i_435_n_2 ;
  wire \VGA_R_reg[7]_i_435_n_3 ;
  wire \VGA_R_reg[7]_i_435_n_4 ;
  wire \VGA_R_reg[7]_i_435_n_6 ;
  wire \VGA_R_reg[7]_i_435_n_7 ;
  wire \VGA_R_reg[7]_i_436_n_1 ;
  wire \VGA_R_reg[7]_i_436_n_2 ;
  wire \VGA_R_reg[7]_i_436_n_3 ;
  wire \VGA_R_reg[7]_i_436_n_4 ;
  wire \VGA_R_reg[7]_i_436_n_6 ;
  wire \VGA_R_reg[7]_i_436_n_7 ;
  wire \VGA_R_reg[7]_i_437_n_0 ;
  wire \VGA_R_reg[7]_i_437_n_1 ;
  wire \VGA_R_reg[7]_i_437_n_2 ;
  wire \VGA_R_reg[7]_i_437_n_3 ;
  wire \VGA_R_reg[7]_i_437_n_4 ;
  wire \VGA_R_reg[7]_i_437_n_5 ;
  wire \VGA_R_reg[7]_i_437_n_6 ;
  wire \VGA_R_reg[7]_i_437_n_7 ;
  wire \VGA_R_reg[7]_i_447_n_1 ;
  wire \VGA_R_reg[7]_i_447_n_2 ;
  wire \VGA_R_reg[7]_i_447_n_3 ;
  wire \VGA_R_reg[7]_i_447_n_4 ;
  wire \VGA_R_reg[7]_i_447_n_6 ;
  wire \VGA_R_reg[7]_i_447_n_7 ;
  wire \VGA_R_reg[7]_i_460_n_0 ;
  wire \VGA_R_reg[7]_i_460_n_1 ;
  wire \VGA_R_reg[7]_i_460_n_2 ;
  wire \VGA_R_reg[7]_i_460_n_3 ;
  wire \VGA_R_reg[7]_i_460_n_5 ;
  wire \VGA_R_reg[7]_i_460_n_6 ;
  wire \VGA_R_reg[7]_i_460_n_7 ;
  wire \VGA_R_reg[7]_i_462_n_0 ;
  wire \VGA_R_reg[7]_i_462_n_1 ;
  wire \VGA_R_reg[7]_i_462_n_2 ;
  wire \VGA_R_reg[7]_i_462_n_3 ;
  wire \VGA_R_reg[7]_i_462_n_5 ;
  wire \VGA_R_reg[7]_i_462_n_6 ;
  wire \VGA_R_reg[7]_i_462_n_7 ;
  wire \VGA_R_reg[7]_i_463_n_0 ;
  wire \VGA_R_reg[7]_i_463_n_1 ;
  wire \VGA_R_reg[7]_i_463_n_2 ;
  wire \VGA_R_reg[7]_i_463_n_3 ;
  wire \VGA_R_reg[7]_i_463_n_4 ;
  wire \VGA_R_reg[7]_i_463_n_5 ;
  wire \VGA_R_reg[7]_i_463_n_6 ;
  wire \VGA_R_reg[7]_i_463_n_7 ;
  wire \VGA_R_reg[7]_i_473_n_7 ;
  wire \VGA_R_reg[7]_i_474_n_0 ;
  wire \VGA_R_reg[7]_i_474_n_1 ;
  wire \VGA_R_reg[7]_i_474_n_2 ;
  wire \VGA_R_reg[7]_i_474_n_3 ;
  wire \VGA_R_reg[7]_i_474_n_5 ;
  wire \VGA_R_reg[7]_i_474_n_6 ;
  wire \VGA_R_reg[7]_i_474_n_7 ;
  wire \VGA_R_reg[7]_i_477_n_0 ;
  wire \VGA_R_reg[7]_i_477_n_1 ;
  wire \VGA_R_reg[7]_i_477_n_2 ;
  wire \VGA_R_reg[7]_i_477_n_3 ;
  wire \VGA_R_reg[7]_i_477_n_4 ;
  wire \VGA_R_reg[7]_i_477_n_5 ;
  wire \VGA_R_reg[7]_i_477_n_6 ;
  wire \VGA_R_reg[7]_i_477_n_7 ;
  wire \VGA_R_reg[7]_i_478_n_0 ;
  wire \VGA_R_reg[7]_i_478_n_1 ;
  wire \VGA_R_reg[7]_i_478_n_2 ;
  wire \VGA_R_reg[7]_i_478_n_3 ;
  wire \VGA_R_reg[7]_i_478_n_4 ;
  wire \VGA_R_reg[7]_i_478_n_5 ;
  wire \VGA_R_reg[7]_i_478_n_6 ;
  wire \VGA_R_reg[7]_i_478_n_7 ;
  wire \VGA_R_reg[7]_i_483_n_0 ;
  wire \VGA_R_reg[7]_i_483_n_1 ;
  wire \VGA_R_reg[7]_i_483_n_2 ;
  wire \VGA_R_reg[7]_i_483_n_3 ;
  wire \VGA_R_reg[7]_i_483_n_4 ;
  wire \VGA_R_reg[7]_i_483_n_5 ;
  wire \VGA_R_reg[7]_i_483_n_6 ;
  wire \VGA_R_reg[7]_i_483_n_7 ;
  wire \VGA_R_reg[7]_i_493_n_7 ;
  wire \VGA_R_reg[7]_i_494_n_0 ;
  wire \VGA_R_reg[7]_i_494_n_1 ;
  wire \VGA_R_reg[7]_i_494_n_2 ;
  wire \VGA_R_reg[7]_i_494_n_3 ;
  wire \VGA_R_reg[7]_i_494_n_5 ;
  wire \VGA_R_reg[7]_i_494_n_6 ;
  wire \VGA_R_reg[7]_i_494_n_7 ;
  wire \VGA_R_reg[7]_i_512_n_0 ;
  wire \VGA_R_reg[7]_i_512_n_1 ;
  wire \VGA_R_reg[7]_i_512_n_2 ;
  wire \VGA_R_reg[7]_i_512_n_3 ;
  wire \VGA_R_reg[7]_i_512_n_4 ;
  wire \VGA_R_reg[7]_i_512_n_5 ;
  wire \VGA_R_reg[7]_i_512_n_6 ;
  wire \VGA_R_reg[7]_i_512_n_7 ;
  wire \VGA_R_reg[7]_i_513_n_0 ;
  wire \VGA_R_reg[7]_i_513_n_1 ;
  wire \VGA_R_reg[7]_i_513_n_2 ;
  wire \VGA_R_reg[7]_i_513_n_3 ;
  wire \VGA_R_reg[7]_i_513_n_4 ;
  wire \VGA_R_reg[7]_i_513_n_5 ;
  wire \VGA_R_reg[7]_i_513_n_6 ;
  wire \VGA_R_reg[7]_i_513_n_7 ;
  wire \VGA_R_reg[7]_i_527_n_7 ;
  wire \VGA_R_reg[7]_i_528_n_0 ;
  wire \VGA_R_reg[7]_i_528_n_1 ;
  wire \VGA_R_reg[7]_i_528_n_2 ;
  wire \VGA_R_reg[7]_i_528_n_3 ;
  wire \VGA_R_reg[7]_i_528_n_5 ;
  wire \VGA_R_reg[7]_i_528_n_6 ;
  wire \VGA_R_reg[7]_i_528_n_7 ;
  wire \VGA_R_reg[7]_i_530_n_0 ;
  wire \VGA_R_reg[7]_i_530_n_1 ;
  wire \VGA_R_reg[7]_i_530_n_2 ;
  wire \VGA_R_reg[7]_i_530_n_3 ;
  wire \VGA_R_reg[7]_i_530_n_4 ;
  wire \VGA_R_reg[7]_i_530_n_5 ;
  wire \VGA_R_reg[7]_i_530_n_6 ;
  wire \VGA_R_reg[7]_i_530_n_7 ;
  wire \VGA_R_reg[7]_i_540_n_0 ;
  wire \VGA_R_reg[7]_i_540_n_1 ;
  wire \VGA_R_reg[7]_i_540_n_2 ;
  wire \VGA_R_reg[7]_i_540_n_3 ;
  wire \VGA_R_reg[7]_i_540_n_4 ;
  wire \VGA_R_reg[7]_i_540_n_5 ;
  wire \VGA_R_reg[7]_i_540_n_6 ;
  wire \VGA_R_reg[7]_i_540_n_7 ;
  wire \VGA_R_reg[7]_i_552_n_1 ;
  wire \VGA_R_reg[7]_i_552_n_3 ;
  wire \VGA_R_reg[7]_i_552_n_6 ;
  wire \VGA_R_reg[7]_i_552_n_7 ;
  wire \VGA_R_reg[7]_i_571_n_7 ;
  wire \VGA_R_reg[7]_i_572_n_0 ;
  wire \VGA_R_reg[7]_i_572_n_1 ;
  wire \VGA_R_reg[7]_i_572_n_2 ;
  wire \VGA_R_reg[7]_i_572_n_3 ;
  wire \VGA_R_reg[7]_i_572_n_5 ;
  wire \VGA_R_reg[7]_i_572_n_6 ;
  wire \VGA_R_reg[7]_i_572_n_7 ;
  wire \VGA_R_reg[7]_i_574_n_0 ;
  wire \VGA_R_reg[7]_i_574_n_1 ;
  wire \VGA_R_reg[7]_i_574_n_2 ;
  wire \VGA_R_reg[7]_i_574_n_3 ;
  wire \VGA_R_reg[7]_i_574_n_4 ;
  wire \VGA_R_reg[7]_i_574_n_5 ;
  wire \VGA_R_reg[7]_i_574_n_6 ;
  wire \VGA_R_reg[7]_i_574_n_7 ;
  wire \VGA_R_reg[7]_i_584_n_0 ;
  wire \VGA_R_reg[7]_i_584_n_1 ;
  wire \VGA_R_reg[7]_i_584_n_2 ;
  wire \VGA_R_reg[7]_i_584_n_3 ;
  wire \VGA_R_reg[7]_i_584_n_4 ;
  wire \VGA_R_reg[7]_i_584_n_5 ;
  wire \VGA_R_reg[7]_i_584_n_6 ;
  wire \VGA_R_reg[7]_i_584_n_7 ;
  wire \VGA_R_reg[7]_i_592_n_3 ;
  wire \VGA_R_reg[7]_i_592_n_6 ;
  wire \VGA_R_reg[7]_i_593_n_0 ;
  wire \VGA_R_reg[7]_i_593_n_1 ;
  wire \VGA_R_reg[7]_i_593_n_2 ;
  wire \VGA_R_reg[7]_i_593_n_3 ;
  wire \VGA_R_reg[7]_i_593_n_5 ;
  wire \VGA_R_reg[7]_i_593_n_6 ;
  wire \VGA_R_reg[7]_i_593_n_7 ;
  wire \VGA_R_reg[7]_i_595_n_0 ;
  wire \VGA_R_reg[7]_i_595_n_1 ;
  wire \VGA_R_reg[7]_i_595_n_2 ;
  wire \VGA_R_reg[7]_i_595_n_3 ;
  wire \VGA_R_reg[7]_i_595_n_4 ;
  wire \VGA_R_reg[7]_i_595_n_5 ;
  wire \VGA_R_reg[7]_i_595_n_6 ;
  wire \VGA_R_reg[7]_i_595_n_7 ;
  wire \VGA_R_reg[7]_i_605_n_1 ;
  wire \VGA_R_reg[7]_i_605_n_3 ;
  wire \VGA_R_reg[7]_i_605_n_6 ;
  wire \VGA_R_reg[7]_i_609_n_0 ;
  wire \VGA_R_reg[7]_i_609_n_1 ;
  wire \VGA_R_reg[7]_i_609_n_2 ;
  wire \VGA_R_reg[7]_i_609_n_3 ;
  wire \VGA_R_reg[7]_i_609_n_4 ;
  wire \VGA_R_reg[7]_i_609_n_5 ;
  wire \VGA_R_reg[7]_i_609_n_6 ;
  wire \VGA_R_reg[7]_i_79_n_0 ;
  wire \VGA_R_reg[7]_i_79_n_1 ;
  wire \VGA_R_reg[7]_i_79_n_2 ;
  wire \VGA_R_reg[7]_i_79_n_3 ;
  wire \VGA_R_reg[7]_i_79_n_4 ;
  wire \VGA_R_reg[7]_i_79_n_5 ;
  wire \VGA_R_reg[7]_i_79_n_6 ;
  wire \VGA_R_reg[7]_i_79_n_7 ;
  wire \VGA_R_reg[7]_i_80_n_0 ;
  wire \VGA_R_reg[7]_i_80_n_1 ;
  wire \VGA_R_reg[7]_i_80_n_2 ;
  wire \VGA_R_reg[7]_i_80_n_3 ;
  wire \VGA_R_reg[7]_i_80_n_5 ;
  wire \VGA_R_reg[7]_i_80_n_6 ;
  wire \VGA_R_reg[7]_i_80_n_7 ;
  wire \VGA_R_reg[7]_i_81_n_0 ;
  wire \VGA_R_reg[7]_i_81_n_1 ;
  wire \VGA_R_reg[7]_i_81_n_2 ;
  wire \VGA_R_reg[7]_i_81_n_3 ;
  wire \VGA_R_reg[7]_i_81_n_4 ;
  wire \VGA_R_reg[7]_i_81_n_5 ;
  wire \VGA_R_reg[7]_i_81_n_6 ;
  wire \VGA_R_reg[7]_i_81_n_7 ;
  wire \VGA_R_reg[7]_i_92_n_0 ;
  wire \VGA_R_reg[7]_i_92_n_1 ;
  wire \VGA_R_reg[7]_i_92_n_2 ;
  wire \VGA_R_reg[7]_i_92_n_3 ;
  wire \VGA_R_reg[7]_i_92_n_5 ;
  wire \VGA_R_reg[7]_i_92_n_6 ;
  wire \VGA_R_reg[7]_i_92_n_7 ;
  wire \VGA_R_reg[7]_i_93_n_3 ;
  wire VGA_VS;
  wire [7:0]data2;
  wire [7:0]data6;
  wire [7:0]data9;
  wire [1:1]disp_enable2;
  wire [5:0]disp_y;
  wire locked;
  wire [10:0]p_1_in;
  wire [7:0]pattern_b;
  wire pattern_b1__0_i_13_n_0;
  wire pattern_b1__0_n_100;
  wire pattern_b1__0_n_101;
  wire pattern_b1__0_n_102;
  wire pattern_b1__0_n_103;
  wire pattern_b1__0_n_104;
  wire pattern_b1__0_n_105;
  wire pattern_b1__0_n_87;
  wire pattern_b1__0_n_88;
  wire pattern_b1__0_n_89;
  wire pattern_b1__0_n_90;
  wire pattern_b1__0_n_91;
  wire pattern_b1__0_n_92;
  wire pattern_b1__0_n_93;
  wire pattern_b1__0_n_94;
  wire pattern_b1__0_n_95;
  wire pattern_b1__0_n_96;
  wire pattern_b1__0_n_97;
  wire pattern_b1__0_n_98;
  wire pattern_b1__0_n_99;
  wire pattern_b1_i_18_n_0;
  wire pattern_b1_i_18_n_1;
  wire pattern_b1_i_18_n_2;
  wire pattern_b1_i_18_n_3;
  wire pattern_b1_i_18_n_4;
  wire pattern_b1_i_18_n_5;
  wire pattern_b1_i_18_n_6;
  wire pattern_b1_i_23_n_0;
  wire pattern_b1_i_23_n_2;
  wire pattern_b1_i_23_n_3;
  wire pattern_b1_i_23_n_5;
  wire pattern_b1_i_23_n_6;
  wire pattern_b1_i_23_n_7;
  wire pattern_b1_i_24_n_3;
  wire pattern_b1_i_25_n_0;
  wire pattern_b1_i_26_n_0;
  wire pattern_b1_i_27_n_0;
  wire pattern_b1_i_28_n_0;
  wire pattern_b1_i_29_n_0;
  wire pattern_b1_i_30_n_0;
  wire pattern_b1_i_32_n_0;
  wire pattern_b1_i_33_n_0;
  wire pattern_b1_i_34_n_0;
  wire pattern_b1_i_35_n_0;
  wire pattern_b1_n_100;
  wire pattern_b1_n_101;
  wire pattern_b1_n_102;
  wire pattern_b1_n_103;
  wire pattern_b1_n_104;
  wire pattern_b1_n_105;
  wire pattern_b1_n_87;
  wire pattern_b1_n_88;
  wire pattern_b1_n_89;
  wire pattern_b1_n_90;
  wire pattern_b1_n_91;
  wire pattern_b1_n_92;
  wire pattern_b1_n_93;
  wire pattern_b1_n_94;
  wire pattern_b1_n_95;
  wire pattern_b1_n_96;
  wire pattern_b1_n_97;
  wire pattern_b1_n_98;
  wire pattern_b1_n_99;
  wire [7:0]pattern_g;
  wire [7:0]pattern_r;
  wire [3:0]pattern_sel;
  wire reconfig_done;
  wire reconfig_req;
  wire syncgen_multi_n_22;
  wire syncgen_multi_n_23;
  wire [1:0]timing_sel;
  wire [1:0]timing_sel_imm;
  wire zp_sum0_n_100;
  wire zp_sum0_n_101;
  wire zp_sum0_n_102;
  wire zp_sum0_n_103;
  wire zp_sum0_n_104;
  wire zp_sum0_n_105;
  wire zp_sum0_n_84;
  wire zp_sum0_n_85;
  wire zp_sum0_n_86;
  wire zp_sum0_n_87;
  wire zp_sum0_n_88;
  wire zp_sum0_n_89;
  wire zp_sum0_n_90;
  wire zp_sum0_n_91;
  wire zp_sum0_n_92;
  wire zp_sum0_n_93;
  wire zp_sum0_n_94;
  wire zp_sum0_n_95;
  wire zp_sum0_n_96;
  wire zp_sum0_n_97;
  wire zp_sum0_n_98;
  wire zp_sum0_n_99;
  wire zp_sum_n_101;
  wire zp_sum_n_102;
  wire zp_sum_n_103;
  wire zp_sum_n_104;
  wire zp_sum_n_105;
  wire [3:0]\NLW_VGA_R_reg[0]_i_11_O_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[0]_i_26_CO_UNCONNECTED ;
  wire [3:1]\NLW_VGA_R_reg[0]_i_26_O_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[0]_i_28_CO_UNCONNECTED ;
  wire [3:1]\NLW_VGA_R_reg[0]_i_28_O_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[0]_i_30_CO_UNCONNECTED ;
  wire [3:1]\NLW_VGA_R_reg[0]_i_30_O_UNCONNECTED ;
  wire [3:3]\NLW_VGA_R_reg[0]_i_5_CO_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[0]_i_5_O_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[0]_i_6_O_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[0]_i_7_O_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[1]_i_26_CO_UNCONNECTED ;
  wire [3:1]\NLW_VGA_R_reg[1]_i_26_O_UNCONNECTED ;
  wire [3:3]\NLW_VGA_R_reg[1]_i_5_CO_UNCONNECTED ;
  wire [3:2]\NLW_VGA_R_reg[1]_i_5_O_UNCONNECTED ;
  wire [3:3]\NLW_VGA_R_reg[1]_i_6_O_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[2]_i_26_CO_UNCONNECTED ;
  wire [3:1]\NLW_VGA_R_reg[2]_i_26_O_UNCONNECTED ;
  wire [3:3]\NLW_VGA_R_reg[2]_i_5_CO_UNCONNECTED ;
  wire [3:2]\NLW_VGA_R_reg[2]_i_5_O_UNCONNECTED ;
  wire [3:3]\NLW_VGA_R_reg[2]_i_6_O_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[3]_i_28_CO_UNCONNECTED ;
  wire [3:1]\NLW_VGA_R_reg[3]_i_28_O_UNCONNECTED ;
  wire [3:3]\NLW_VGA_R_reg[3]_i_6_CO_UNCONNECTED ;
  wire [2:2]\NLW_VGA_R_reg[3]_i_6_O_UNCONNECTED ;
  wire [3:3]\NLW_VGA_R_reg[3]_i_7_O_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[4]_i_40_CO_UNCONNECTED ;
  wire [3:1]\NLW_VGA_R_reg[4]_i_40_O_UNCONNECTED ;
  wire [3:3]\NLW_VGA_R_reg[4]_i_6_CO_UNCONNECTED ;
  wire [2:2]\NLW_VGA_R_reg[4]_i_6_O_UNCONNECTED ;
  wire [3:3]\NLW_VGA_R_reg[4]_i_7_O_UNCONNECTED ;
  wire [3:3]\NLW_VGA_R_reg[5]_i_10_O_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[5]_i_100_CO_UNCONNECTED ;
  wire [3:1]\NLW_VGA_R_reg[5]_i_100_O_UNCONNECTED ;
  wire [3:1]\NLW_VGA_R_reg[5]_i_108_CO_UNCONNECTED ;
  wire [3:2]\NLW_VGA_R_reg[5]_i_108_O_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[5]_i_110_O_UNCONNECTED ;
  wire [0:0]\NLW_VGA_R_reg[5]_i_114_O_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[5]_i_123_O_UNCONNECTED ;
  wire [3:1]\NLW_VGA_R_reg[5]_i_78_CO_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[5]_i_78_O_UNCONNECTED ;
  wire [2:2]\NLW_VGA_R_reg[5]_i_79_CO_UNCONNECTED ;
  wire [3:3]\NLW_VGA_R_reg[5]_i_79_O_UNCONNECTED ;
  wire [3:3]\NLW_VGA_R_reg[5]_i_9_CO_UNCONNECTED ;
  wire [2:2]\NLW_VGA_R_reg[5]_i_9_O_UNCONNECTED ;
  wire [3:1]\NLW_VGA_R_reg[5]_i_97_CO_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[5]_i_97_O_UNCONNECTED ;
  wire [3:2]\NLW_VGA_R_reg[5]_i_98_CO_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[5]_i_98_O_UNCONNECTED ;
  wire [3:1]\NLW_VGA_R_reg[5]_i_99_CO_UNCONNECTED ;
  wire [3:2]\NLW_VGA_R_reg[5]_i_99_O_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[6]_i_27_CO_UNCONNECTED ;
  wire [3:1]\NLW_VGA_R_reg[6]_i_27_O_UNCONNECTED ;
  wire [3:3]\NLW_VGA_R_reg[6]_i_28_CO_UNCONNECTED ;
  wire [2:2]\NLW_VGA_R_reg[6]_i_28_O_UNCONNECTED ;
  wire [3:3]\NLW_VGA_R_reg[6]_i_5_O_UNCONNECTED ;
  wire [3:3]\NLW_VGA_R_reg[6]_i_6_CO_UNCONNECTED ;
  wire [2:2]\NLW_VGA_R_reg[6]_i_6_O_UNCONNECTED ;
  wire [3:3]\NLW_VGA_R_reg[7]_i_101_O_UNCONNECTED ;
  wire [3:3]\NLW_VGA_R_reg[7]_i_110_CO_UNCONNECTED ;
  wire [2:2]\NLW_VGA_R_reg[7]_i_110_O_UNCONNECTED ;
  wire [0:0]\NLW_VGA_R_reg[7]_i_127_O_UNCONNECTED ;
  wire [3:3]\NLW_VGA_R_reg[7]_i_181_O_UNCONNECTED ;
  wire [0:0]\NLW_VGA_R_reg[7]_i_204_O_UNCONNECTED ;
  wire [3:3]\NLW_VGA_R_reg[7]_i_275_CO_UNCONNECTED ;
  wire [2:2]\NLW_VGA_R_reg[7]_i_275_O_UNCONNECTED ;
  wire [3:3]\NLW_VGA_R_reg[7]_i_30_O_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[7]_i_365_CO_UNCONNECTED ;
  wire [3:1]\NLW_VGA_R_reg[7]_i_365_O_UNCONNECTED ;
  wire [3:3]\NLW_VGA_R_reg[7]_i_367_O_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[7]_i_378_CO_UNCONNECTED ;
  wire [3:1]\NLW_VGA_R_reg[7]_i_378_O_UNCONNECTED ;
  wire [3:3]\NLW_VGA_R_reg[7]_i_40_CO_UNCONNECTED ;
  wire [2:2]\NLW_VGA_R_reg[7]_i_40_O_UNCONNECTED ;
  wire [3:3]\NLW_VGA_R_reg[7]_i_435_CO_UNCONNECTED ;
  wire [2:2]\NLW_VGA_R_reg[7]_i_435_O_UNCONNECTED ;
  wire [3:3]\NLW_VGA_R_reg[7]_i_436_CO_UNCONNECTED ;
  wire [2:2]\NLW_VGA_R_reg[7]_i_436_O_UNCONNECTED ;
  wire [3:3]\NLW_VGA_R_reg[7]_i_447_CO_UNCONNECTED ;
  wire [2:2]\NLW_VGA_R_reg[7]_i_447_O_UNCONNECTED ;
  wire [3:3]\NLW_VGA_R_reg[7]_i_460_O_UNCONNECTED ;
  wire [3:3]\NLW_VGA_R_reg[7]_i_462_O_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[7]_i_473_CO_UNCONNECTED ;
  wire [3:1]\NLW_VGA_R_reg[7]_i_473_O_UNCONNECTED ;
  wire [3:3]\NLW_VGA_R_reg[7]_i_474_O_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[7]_i_493_CO_UNCONNECTED ;
  wire [3:1]\NLW_VGA_R_reg[7]_i_493_O_UNCONNECTED ;
  wire [3:3]\NLW_VGA_R_reg[7]_i_494_O_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[7]_i_527_CO_UNCONNECTED ;
  wire [3:1]\NLW_VGA_R_reg[7]_i_527_O_UNCONNECTED ;
  wire [3:3]\NLW_VGA_R_reg[7]_i_528_O_UNCONNECTED ;
  wire [3:1]\NLW_VGA_R_reg[7]_i_552_CO_UNCONNECTED ;
  wire [3:2]\NLW_VGA_R_reg[7]_i_552_O_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[7]_i_571_CO_UNCONNECTED ;
  wire [3:1]\NLW_VGA_R_reg[7]_i_571_O_UNCONNECTED ;
  wire [3:3]\NLW_VGA_R_reg[7]_i_572_O_UNCONNECTED ;
  wire [3:1]\NLW_VGA_R_reg[7]_i_592_CO_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[7]_i_592_O_UNCONNECTED ;
  wire [3:3]\NLW_VGA_R_reg[7]_i_593_O_UNCONNECTED ;
  wire [3:1]\NLW_VGA_R_reg[7]_i_605_CO_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[7]_i_605_O_UNCONNECTED ;
  wire [0:0]\NLW_VGA_R_reg[7]_i_609_O_UNCONNECTED ;
  wire [3:3]\NLW_VGA_R_reg[7]_i_80_O_UNCONNECTED ;
  wire [3:3]\NLW_VGA_R_reg[7]_i_92_O_UNCONNECTED ;
  wire [3:1]\NLW_VGA_R_reg[7]_i_93_CO_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[7]_i_93_O_UNCONNECTED ;
  wire NLW_pattern_b1_CARRYCASCOUT_UNCONNECTED;
  wire NLW_pattern_b1_MULTSIGNOUT_UNCONNECTED;
  wire NLW_pattern_b1_OVERFLOW_UNCONNECTED;
  wire NLW_pattern_b1_PATTERNBDETECT_UNCONNECTED;
  wire NLW_pattern_b1_PATTERNDETECT_UNCONNECTED;
  wire NLW_pattern_b1_UNDERFLOW_UNCONNECTED;
  wire [29:0]NLW_pattern_b1_ACOUT_UNCONNECTED;
  wire [17:0]NLW_pattern_b1_BCOUT_UNCONNECTED;
  wire [3:0]NLW_pattern_b1_CARRYOUT_UNCONNECTED;
  wire [47:19]NLW_pattern_b1_P_UNCONNECTED;
  wire [47:0]NLW_pattern_b1_PCOUT_UNCONNECTED;
  wire NLW_pattern_b1__0_CARRYCASCOUT_UNCONNECTED;
  wire NLW_pattern_b1__0_MULTSIGNOUT_UNCONNECTED;
  wire NLW_pattern_b1__0_OVERFLOW_UNCONNECTED;
  wire NLW_pattern_b1__0_PATTERNBDETECT_UNCONNECTED;
  wire NLW_pattern_b1__0_PATTERNDETECT_UNCONNECTED;
  wire NLW_pattern_b1__0_UNDERFLOW_UNCONNECTED;
  wire [29:0]NLW_pattern_b1__0_ACOUT_UNCONNECTED;
  wire [17:0]NLW_pattern_b1__0_BCOUT_UNCONNECTED;
  wire [3:0]NLW_pattern_b1__0_CARRYOUT_UNCONNECTED;
  wire [47:19]NLW_pattern_b1__0_P_UNCONNECTED;
  wire [47:0]NLW_pattern_b1__0_PCOUT_UNCONNECTED;
  wire [0:0]NLW_pattern_b1_i_18_O_UNCONNECTED;
  wire [2:2]NLW_pattern_b1_i_23_CO_UNCONNECTED;
  wire [3:3]NLW_pattern_b1_i_23_O_UNCONNECTED;
  wire [3:1]NLW_pattern_b1_i_24_CO_UNCONNECTED;
  wire [3:0]NLW_pattern_b1_i_24_O_UNCONNECTED;
  wire NLW_zp_sum_CARRYCASCOUT_UNCONNECTED;
  wire NLW_zp_sum_MULTSIGNOUT_UNCONNECTED;
  wire NLW_zp_sum_OVERFLOW_UNCONNECTED;
  wire NLW_zp_sum_PATTERNBDETECT_UNCONNECTED;
  wire NLW_zp_sum_PATTERNDETECT_UNCONNECTED;
  wire NLW_zp_sum_UNDERFLOW_UNCONNECTED;
  wire [29:0]NLW_zp_sum_ACOUT_UNCONNECTED;
  wire [17:0]NLW_zp_sum_BCOUT_UNCONNECTED;
  wire [3:0]NLW_zp_sum_CARRYOUT_UNCONNECTED;
  wire [47:13]NLW_zp_sum_P_UNCONNECTED;
  wire [47:0]NLW_zp_sum_PCOUT_UNCONNECTED;
  wire NLW_zp_sum0_CARRYCASCOUT_UNCONNECTED;
  wire NLW_zp_sum0_MULTSIGNOUT_UNCONNECTED;
  wire NLW_zp_sum0_OVERFLOW_UNCONNECTED;
  wire NLW_zp_sum0_PATTERNBDETECT_UNCONNECTED;
  wire NLW_zp_sum0_PATTERNDETECT_UNCONNECTED;
  wire NLW_zp_sum0_UNDERFLOW_UNCONNECTED;
  wire [29:0]NLW_zp_sum0_ACOUT_UNCONNECTED;
  wire [17:0]NLW_zp_sum0_BCOUT_UNCONNECTED;
  wire [3:0]NLW_zp_sum0_CARRYOUT_UNCONNECTED;
  wire [47:22]NLW_zp_sum0_P_UNCONNECTED;
  wire [47:0]NLW_zp_sum0_PCOUT_UNCONNECTED;

  FDRE \VGA_B_reg[0] 
       (.C(PCK),
        .CE(1'b1),
        .D(pattern_b[0]),
        .Q(VGA_B[0]),
        .R(syncgen_multi_n_22));
  FDRE \VGA_B_reg[1] 
       (.C(PCK),
        .CE(1'b1),
        .D(pattern_b[1]),
        .Q(VGA_B[1]),
        .R(syncgen_multi_n_22));
  FDRE \VGA_B_reg[2] 
       (.C(PCK),
        .CE(1'b1),
        .D(pattern_b[2]),
        .Q(VGA_B[2]),
        .R(syncgen_multi_n_22));
  FDRE \VGA_B_reg[3] 
       (.C(PCK),
        .CE(1'b1),
        .D(pattern_b[3]),
        .Q(VGA_B[3]),
        .R(syncgen_multi_n_22));
  FDRE \VGA_B_reg[4] 
       (.C(PCK),
        .CE(1'b1),
        .D(pattern_b[4]),
        .Q(VGA_B[4]),
        .R(syncgen_multi_n_22));
  FDRE \VGA_B_reg[5] 
       (.C(PCK),
        .CE(1'b1),
        .D(pattern_b[5]),
        .Q(VGA_B[5]),
        .R(syncgen_multi_n_22));
  FDRE \VGA_B_reg[6] 
       (.C(PCK),
        .CE(1'b1),
        .D(pattern_b[6]),
        .Q(VGA_B[6]),
        .R(syncgen_multi_n_22));
  FDRE \VGA_B_reg[7] 
       (.C(PCK),
        .CE(1'b1),
        .D(pattern_b[7]),
        .Q(VGA_B[7]),
        .R(syncgen_multi_n_22));
  FDRE VGA_DE_reg
       (.C(PCK),
        .CE(1'b1),
        .D(syncgen_multi_n_23),
        .Q(VGA_DE),
        .R(1'b0));
  FDRE \VGA_G_reg[0] 
       (.C(PCK),
        .CE(1'b1),
        .D(pattern_g[0]),
        .Q(VGA_G[0]),
        .R(syncgen_multi_n_22));
  FDRE \VGA_G_reg[1] 
       (.C(PCK),
        .CE(1'b1),
        .D(pattern_g[1]),
        .Q(VGA_G[1]),
        .R(syncgen_multi_n_22));
  FDRE \VGA_G_reg[2] 
       (.C(PCK),
        .CE(1'b1),
        .D(pattern_g[2]),
        .Q(VGA_G[2]),
        .R(syncgen_multi_n_22));
  FDRE \VGA_G_reg[3] 
       (.C(PCK),
        .CE(1'b1),
        .D(pattern_g[3]),
        .Q(VGA_G[3]),
        .R(syncgen_multi_n_22));
  FDRE \VGA_G_reg[4] 
       (.C(PCK),
        .CE(1'b1),
        .D(pattern_g[4]),
        .Q(VGA_G[4]),
        .R(syncgen_multi_n_22));
  FDRE \VGA_G_reg[5] 
       (.C(PCK),
        .CE(1'b1),
        .D(pattern_g[5]),
        .Q(VGA_G[5]),
        .R(syncgen_multi_n_22));
  FDRE \VGA_G_reg[6] 
       (.C(PCK),
        .CE(1'b1),
        .D(pattern_g[6]),
        .Q(VGA_G[6]),
        .R(syncgen_multi_n_22));
  FDRE \VGA_G_reg[7] 
       (.C(PCK),
        .CE(1'b1),
        .D(pattern_g[7]),
        .Q(VGA_G[7]),
        .R(syncgen_multi_n_22));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[0]_i_10 
       (.I0(\VGA_R[7]_i_286_n_0 ),
        .I1(data6[1]),
        .I2(\VGA_R_reg[1]_i_7_n_4 ),
        .O(\VGA_R[0]_i_10_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[0]_i_12 
       (.I0(data2[1]),
        .I1(\VGA_R_reg[1]_i_6_n_5 ),
        .O(\VGA_R[0]_i_12_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[0]_i_13 
       (.I0(data2[1]),
        .I1(\VGA_R[7]_i_192_n_0 ),
        .I2(\VGA_R_reg[1]_i_6_n_6 ),
        .O(\VGA_R[0]_i_13_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[0]_i_14 
       (.I0(\VGA_R[7]_i_192_n_0 ),
        .I1(data2[1]),
        .I2(\VGA_R_reg[1]_i_6_n_7 ),
        .O(\VGA_R[0]_i_14_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[0]_i_15 
       (.I0(data2[1]),
        .I1(\VGA_R[7]_i_192_n_0 ),
        .I2(\VGA_R_reg[1]_i_11_n_4 ),
        .O(\VGA_R[0]_i_15_n_0 ));
  LUT1 #(
    .INIT(2'h2)) 
    \VGA_R[0]_i_16 
       (.I0(\VGA_R_reg[3]_i_6_n_4 ),
        .O(\VGA_R[0]_i_16_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \VGA_R[0]_i_17 
       (.I0(data6[1]),
        .I1(\VGA_R_reg[1]_i_7_n_5 ),
        .O(\VGA_R[0]_i_17_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \VGA_R[0]_i_18 
       (.I0(data6[1]),
        .I1(\VGA_R_reg[1]_i_7_n_6 ),
        .O(\VGA_R[0]_i_18_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[0]_i_19 
       (.I0(\VGA_R[7]_i_286_n_0 ),
        .I1(data6[1]),
        .I2(\VGA_R_reg[1]_i_7_n_7 ),
        .O(\VGA_R[0]_i_19_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair42" *) 
  LUT5 #(
    .INIT(32'h00080000)) 
    \VGA_R[0]_i_2 
       (.I0(pattern_sel[0]),
        .I1(pattern_sel[3]),
        .I2(pattern_sel[2]),
        .I3(pattern_sel[1]),
        .I4(data9[0]),
        .O(\VGA_R[0]_i_2_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[0]_i_20 
       (.I0(data6[1]),
        .I1(\VGA_R[7]_i_286_n_0 ),
        .I2(\VGA_R_reg[3]_i_6_n_4 ),
        .O(\VGA_R[0]_i_20_n_0 ));
  LUT1 #(
    .INIT(2'h2)) 
    \VGA_R[0]_i_21 
       (.I0(\VGA_R_reg[0]_i_26_n_7 ),
        .O(\VGA_R[0]_i_21_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[0]_i_22 
       (.I0(\VGA_R[7]_i_192_n_0 ),
        .I1(data2[1]),
        .I2(\VGA_R_reg[1]_i_11_n_5 ),
        .O(\VGA_R[0]_i_22_n_0 ));
  LUT4 #(
    .INIT(16'h659A)) 
    \VGA_R[0]_i_23 
       (.I0(data2[1]),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .I3(\VGA_R_reg[1]_i_11_n_6 ),
        .O(\VGA_R[0]_i_23_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[0]_i_24 
       (.I0(data2[1]),
        .I1(\VGA_R_reg[1]_i_11_n_7 ),
        .O(\VGA_R[0]_i_24_n_0 ));
  LUT4 #(
    .INIT(16'h659A)) 
    \VGA_R[0]_i_25 
       (.I0(data2[1]),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .I3(\VGA_R_reg[0]_i_26_n_7 ),
        .O(\VGA_R[0]_i_25_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[0]_i_27 
       (.I0(\VGA_R_reg[0]_i_28_n_7 ),
        .I1(data2[3]),
        .O(\VGA_R[0]_i_27_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[0]_i_29 
       (.I0(\VGA_R_reg[0]_i_30_n_7 ),
        .I1(data2[4]),
        .O(\VGA_R[0]_i_29_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[0]_i_31 
       (.I0(pattern_b1_n_101),
        .I1(data2[5]),
        .O(\VGA_R[0]_i_31_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[0]_i_8 
       (.I0(data6[1]),
        .I1(\VGA_R_reg[1]_i_5_n_6 ),
        .O(\VGA_R[0]_i_8_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[0]_i_9 
       (.I0(data6[1]),
        .I1(\VGA_R[7]_i_286_n_0 ),
        .I2(\VGA_R_reg[1]_i_5_n_7 ),
        .O(\VGA_R[0]_i_9_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[1]_i_10 
       (.I0(\VGA_R[7]_i_286_n_0 ),
        .I1(data6[2]),
        .I2(\VGA_R_reg[2]_i_7_n_4 ),
        .O(\VGA_R[1]_i_10_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[1]_i_12 
       (.I0(data2[2]),
        .I1(\VGA_R_reg[2]_i_6_n_5 ),
        .O(\VGA_R[1]_i_12_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[1]_i_13 
       (.I0(data2[2]),
        .I1(\VGA_R[7]_i_192_n_0 ),
        .I2(\VGA_R_reg[2]_i_6_n_6 ),
        .O(\VGA_R[1]_i_13_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[1]_i_14 
       (.I0(\VGA_R[7]_i_192_n_0 ),
        .I1(data2[2]),
        .I2(\VGA_R_reg[2]_i_6_n_7 ),
        .O(\VGA_R[1]_i_14_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[1]_i_15 
       (.I0(data2[2]),
        .I1(\VGA_R[7]_i_192_n_0 ),
        .I2(\VGA_R_reg[2]_i_11_n_4 ),
        .O(\VGA_R[1]_i_15_n_0 ));
  LUT1 #(
    .INIT(2'h2)) 
    \VGA_R[1]_i_16 
       (.I0(\VGA_R_reg[6]_i_6_n_4 ),
        .O(\VGA_R[1]_i_16_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \VGA_R[1]_i_17 
       (.I0(data6[2]),
        .I1(\VGA_R_reg[2]_i_7_n_5 ),
        .O(\VGA_R[1]_i_17_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \VGA_R[1]_i_18 
       (.I0(data6[2]),
        .I1(\VGA_R_reg[2]_i_7_n_6 ),
        .O(\VGA_R[1]_i_18_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[1]_i_19 
       (.I0(\VGA_R[7]_i_286_n_0 ),
        .I1(data6[2]),
        .I2(\VGA_R_reg[2]_i_7_n_7 ),
        .O(\VGA_R[1]_i_19_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair41" *) 
  LUT5 #(
    .INIT(32'h00080000)) 
    \VGA_R[1]_i_2 
       (.I0(pattern_sel[0]),
        .I1(pattern_sel[3]),
        .I2(pattern_sel[2]),
        .I3(pattern_sel[1]),
        .I4(data9[1]),
        .O(\VGA_R[1]_i_2_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[1]_i_20 
       (.I0(data6[2]),
        .I1(\VGA_R[7]_i_286_n_0 ),
        .I2(\VGA_R_reg[6]_i_6_n_4 ),
        .O(\VGA_R[1]_i_20_n_0 ));
  LUT1 #(
    .INIT(2'h2)) 
    \VGA_R[1]_i_21 
       (.I0(\VGA_R_reg[1]_i_26_n_7 ),
        .O(\VGA_R[1]_i_21_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[1]_i_22 
       (.I0(\VGA_R[7]_i_192_n_0 ),
        .I1(data2[2]),
        .I2(\VGA_R_reg[2]_i_11_n_5 ),
        .O(\VGA_R[1]_i_22_n_0 ));
  LUT4 #(
    .INIT(16'h659A)) 
    \VGA_R[1]_i_23 
       (.I0(data2[2]),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .I3(\VGA_R_reg[2]_i_11_n_6 ),
        .O(\VGA_R[1]_i_23_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[1]_i_24 
       (.I0(data2[2]),
        .I1(\VGA_R_reg[2]_i_11_n_7 ),
        .O(\VGA_R[1]_i_24_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[1]_i_25 
       (.I0(data2[2]),
        .I1(\VGA_R[7]_i_366_n_0 ),
        .I2(\VGA_R_reg[1]_i_26_n_7 ),
        .O(\VGA_R[1]_i_25_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[1]_i_27 
       (.I0(pattern_b1_n_100),
        .I1(data2[6]),
        .O(\VGA_R[1]_i_27_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[1]_i_8 
       (.I0(data6[2]),
        .I1(\VGA_R_reg[2]_i_5_n_6 ),
        .O(\VGA_R[1]_i_8_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[1]_i_9 
       (.I0(data6[2]),
        .I1(\VGA_R[7]_i_286_n_0 ),
        .I2(\VGA_R_reg[2]_i_5_n_7 ),
        .O(\VGA_R[1]_i_9_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[2]_i_10 
       (.I0(\VGA_R[7]_i_286_n_0 ),
        .I1(data6[3]),
        .I2(\VGA_R_reg[3]_i_8_n_4 ),
        .O(\VGA_R[2]_i_10_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[2]_i_12 
       (.I0(data2[3]),
        .I1(\VGA_R_reg[3]_i_7_n_5 ),
        .O(\VGA_R[2]_i_12_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[2]_i_13 
       (.I0(data2[3]),
        .I1(\VGA_R[7]_i_192_n_0 ),
        .I2(\VGA_R_reg[3]_i_7_n_6 ),
        .O(\VGA_R[2]_i_13_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[2]_i_14 
       (.I0(\VGA_R[7]_i_192_n_0 ),
        .I1(data2[3]),
        .I2(\VGA_R_reg[3]_i_7_n_7 ),
        .O(\VGA_R[2]_i_14_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[2]_i_15 
       (.I0(data2[3]),
        .I1(\VGA_R[7]_i_192_n_0 ),
        .I2(\VGA_R_reg[3]_i_13_n_4 ),
        .O(\VGA_R[2]_i_15_n_0 ));
  LUT1 #(
    .INIT(2'h2)) 
    \VGA_R[2]_i_16 
       (.I0(\VGA_R_reg[7]_i_40_n_4 ),
        .O(\VGA_R[2]_i_16_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \VGA_R[2]_i_17 
       (.I0(data6[3]),
        .I1(\VGA_R_reg[3]_i_8_n_5 ),
        .O(\VGA_R[2]_i_17_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \VGA_R[2]_i_18 
       (.I0(data6[3]),
        .I1(\VGA_R_reg[3]_i_8_n_6 ),
        .O(\VGA_R[2]_i_18_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[2]_i_19 
       (.I0(\VGA_R[7]_i_286_n_0 ),
        .I1(data6[3]),
        .I2(\VGA_R_reg[3]_i_8_n_7 ),
        .O(\VGA_R[2]_i_19_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair40" *) 
  LUT5 #(
    .INIT(32'h00080000)) 
    \VGA_R[2]_i_2 
       (.I0(pattern_sel[0]),
        .I1(pattern_sel[3]),
        .I2(pattern_sel[2]),
        .I3(pattern_sel[1]),
        .I4(data9[2]),
        .O(\VGA_R[2]_i_2_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[2]_i_20 
       (.I0(data6[3]),
        .I1(\VGA_R[7]_i_286_n_0 ),
        .I2(\VGA_R_reg[7]_i_40_n_4 ),
        .O(\VGA_R[2]_i_20_n_0 ));
  LUT1 #(
    .INIT(2'h2)) 
    \VGA_R[2]_i_21 
       (.I0(\VGA_R_reg[2]_i_26_n_7 ),
        .O(\VGA_R[2]_i_21_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[2]_i_22 
       (.I0(\VGA_R[7]_i_192_n_0 ),
        .I1(data2[3]),
        .I2(\VGA_R_reg[3]_i_13_n_5 ),
        .O(\VGA_R[2]_i_22_n_0 ));
  LUT4 #(
    .INIT(16'h659A)) 
    \VGA_R[2]_i_23 
       (.I0(data2[3]),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .I3(\VGA_R_reg[3]_i_13_n_6 ),
        .O(\VGA_R[2]_i_23_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[2]_i_24 
       (.I0(data2[3]),
        .I1(\VGA_R_reg[3]_i_13_n_7 ),
        .O(\VGA_R[2]_i_24_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[2]_i_25 
       (.I0(data2[3]),
        .I1(\VGA_R[7]_i_366_n_0 ),
        .I2(\VGA_R_reg[2]_i_26_n_7 ),
        .O(\VGA_R[2]_i_25_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[2]_i_27 
       (.I0(pattern_b1_n_99),
        .I1(data2[7]),
        .O(\VGA_R[2]_i_27_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[2]_i_8 
       (.I0(data6[3]),
        .I1(\VGA_R_reg[3]_i_6_n_6 ),
        .O(\VGA_R[2]_i_8_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[2]_i_9 
       (.I0(data6[3]),
        .I1(\VGA_R[7]_i_286_n_0 ),
        .I2(\VGA_R_reg[3]_i_6_n_7 ),
        .O(\VGA_R[2]_i_9_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[3]_i_10 
       (.I0(data6[4]),
        .I1(\VGA_R_reg[4]_i_6_n_6 ),
        .O(\VGA_R[3]_i_10_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[3]_i_11 
       (.I0(data6[4]),
        .I1(\VGA_R[7]_i_286_n_0 ),
        .I2(\VGA_R_reg[4]_i_6_n_7 ),
        .O(\VGA_R[3]_i_11_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[3]_i_12 
       (.I0(\VGA_R[7]_i_286_n_0 ),
        .I1(data6[4]),
        .I2(\VGA_R_reg[4]_i_12_n_4 ),
        .O(\VGA_R[3]_i_12_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[3]_i_14 
       (.I0(data2[4]),
        .I1(\VGA_R_reg[4]_i_7_n_5 ),
        .O(\VGA_R[3]_i_14_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[3]_i_15 
       (.I0(data2[4]),
        .I1(\VGA_R[7]_i_192_n_0 ),
        .I2(\VGA_R_reg[4]_i_7_n_6 ),
        .O(\VGA_R[3]_i_15_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[3]_i_16 
       (.I0(\VGA_R[7]_i_192_n_0 ),
        .I1(data2[4]),
        .I2(\VGA_R_reg[4]_i_7_n_7 ),
        .O(\VGA_R[3]_i_16_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[3]_i_17 
       (.I0(data2[4]),
        .I1(\VGA_R[7]_i_192_n_0 ),
        .I2(\VGA_R_reg[4]_i_17_n_4 ),
        .O(\VGA_R[3]_i_17_n_0 ));
  LUT1 #(
    .INIT(2'h2)) 
    \VGA_R[3]_i_18 
       (.I0(\VGA_R_reg[7]_i_110_n_4 ),
        .O(\VGA_R[3]_i_18_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \VGA_R[3]_i_19 
       (.I0(data6[4]),
        .I1(\VGA_R_reg[4]_i_12_n_5 ),
        .O(\VGA_R[3]_i_19_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \VGA_R[3]_i_20 
       (.I0(data6[4]),
        .I1(\VGA_R_reg[4]_i_12_n_6 ),
        .O(\VGA_R[3]_i_20_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[3]_i_21 
       (.I0(\VGA_R[7]_i_286_n_0 ),
        .I1(data6[4]),
        .I2(\VGA_R_reg[4]_i_12_n_7 ),
        .O(\VGA_R[3]_i_21_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[3]_i_22 
       (.I0(data6[4]),
        .I1(\VGA_R[7]_i_286_n_0 ),
        .I2(\VGA_R_reg[7]_i_110_n_4 ),
        .O(\VGA_R[3]_i_22_n_0 ));
  LUT1 #(
    .INIT(2'h2)) 
    \VGA_R[3]_i_23 
       (.I0(\VGA_R_reg[3]_i_28_n_7 ),
        .O(\VGA_R[3]_i_23_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[3]_i_24 
       (.I0(\VGA_R[7]_i_192_n_0 ),
        .I1(data2[4]),
        .I2(\VGA_R_reg[4]_i_17_n_5 ),
        .O(\VGA_R[3]_i_24_n_0 ));
  LUT4 #(
    .INIT(16'h659A)) 
    \VGA_R[3]_i_25 
       (.I0(data2[4]),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .I3(\VGA_R_reg[4]_i_17_n_6 ),
        .O(\VGA_R[3]_i_25_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[3]_i_26 
       (.I0(data2[4]),
        .I1(\VGA_R_reg[4]_i_17_n_7 ),
        .O(\VGA_R[3]_i_26_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[3]_i_27 
       (.I0(data2[4]),
        .I1(\VGA_R[7]_i_366_n_0 ),
        .I2(\VGA_R_reg[3]_i_28_n_7 ),
        .O(\VGA_R[3]_i_27_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[3]_i_29 
       (.I0(pattern_b1_n_98),
        .I1(\VGA_R_reg[7]_i_80_n_0 ),
        .O(\VGA_R[3]_i_29_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[3]_i_9 
       (.I0(data6[3]),
        .I1(\VGA_R_reg[4]_i_6_n_4 ),
        .O(\VGA_R[3]_i_9_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[4]_i_13 
       (.I0(data6[4]),
        .I1(\VGA_R_reg[5]_i_9_n_4 ),
        .O(\VGA_R[4]_i_13_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[4]_i_14 
       (.I0(data6[5]),
        .I1(\VGA_R_reg[5]_i_9_n_6 ),
        .O(\VGA_R[4]_i_14_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[4]_i_15 
       (.I0(data6[5]),
        .I1(\VGA_R[7]_i_286_n_0 ),
        .I2(\VGA_R_reg[5]_i_9_n_7 ),
        .O(\VGA_R[4]_i_15_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[4]_i_16 
       (.I0(\VGA_R[7]_i_286_n_0 ),
        .I1(data6[5]),
        .I2(\VGA_R_reg[5]_i_21_n_4 ),
        .O(\VGA_R[4]_i_16_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[4]_i_18 
       (.I0(data2[5]),
        .I1(\VGA_R_reg[5]_i_10_n_5 ),
        .O(\VGA_R[4]_i_18_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[4]_i_19 
       (.I0(data2[5]),
        .I1(\VGA_R[7]_i_192_n_0 ),
        .I2(\VGA_R_reg[5]_i_10_n_6 ),
        .O(\VGA_R[4]_i_19_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[4]_i_20 
       (.I0(\VGA_R[7]_i_192_n_0 ),
        .I1(data2[5]),
        .I2(\VGA_R_reg[5]_i_10_n_7 ),
        .O(\VGA_R[4]_i_20_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[4]_i_21 
       (.I0(data2[5]),
        .I1(\VGA_R[7]_i_192_n_0 ),
        .I2(\VGA_R_reg[5]_i_26_n_4 ),
        .O(\VGA_R[4]_i_21_n_0 ));
  LUT1 #(
    .INIT(2'h2)) 
    \VGA_R[4]_i_30 
       (.I0(\VGA_R_reg[7]_i_275_n_4 ),
        .O(\VGA_R[4]_i_30_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \VGA_R[4]_i_31 
       (.I0(data6[5]),
        .I1(\VGA_R_reg[5]_i_21_n_5 ),
        .O(\VGA_R[4]_i_31_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \VGA_R[4]_i_32 
       (.I0(data6[5]),
        .I1(\VGA_R_reg[5]_i_21_n_6 ),
        .O(\VGA_R[4]_i_32_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[4]_i_33 
       (.I0(\VGA_R[7]_i_286_n_0 ),
        .I1(data6[5]),
        .I2(\VGA_R_reg[5]_i_21_n_7 ),
        .O(\VGA_R[4]_i_33_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[4]_i_34 
       (.I0(data6[5]),
        .I1(\VGA_R[7]_i_286_n_0 ),
        .I2(\VGA_R_reg[7]_i_275_n_4 ),
        .O(\VGA_R[4]_i_34_n_0 ));
  LUT1 #(
    .INIT(2'h2)) 
    \VGA_R[4]_i_35 
       (.I0(\VGA_R_reg[4]_i_40_n_7 ),
        .O(\VGA_R[4]_i_35_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[4]_i_36 
       (.I0(\VGA_R[7]_i_192_n_0 ),
        .I1(data2[5]),
        .I2(\VGA_R_reg[5]_i_26_n_5 ),
        .O(\VGA_R[4]_i_36_n_0 ));
  LUT4 #(
    .INIT(16'h659A)) 
    \VGA_R[4]_i_37 
       (.I0(data2[5]),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .I3(\VGA_R_reg[5]_i_26_n_6 ),
        .O(\VGA_R[4]_i_37_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[4]_i_38 
       (.I0(data2[5]),
        .I1(\VGA_R_reg[5]_i_26_n_7 ),
        .O(\VGA_R[4]_i_38_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[4]_i_39 
       (.I0(data2[5]),
        .I1(\VGA_R[7]_i_366_n_0 ),
        .I2(\VGA_R_reg[4]_i_40_n_7 ),
        .O(\VGA_R[4]_i_39_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[4]_i_41 
       (.I0(pattern_b1_n_97),
        .I1(\VGA_R_reg[7]_i_181_n_0 ),
        .O(\VGA_R[4]_i_41_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair44" *) 
  LUT5 #(
    .INIT(32'hB44B44B4)) 
    \VGA_R[5]_i_101 
       (.I0(timing_sel[1]),
        .I1(timing_sel[0]),
        .I2(\VGA_R_reg[5]_i_78_n_6 ),
        .I3(\VGA_R_reg[5]_i_79_n_5 ),
        .I4(\VGA_R_reg[5]_i_79_n_6 ),
        .O(\VGA_R[5]_i_101_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair44" *) 
  LUT5 #(
    .INIT(32'h4242D642)) 
    \VGA_R[5]_i_102 
       (.I0(\VGA_R_reg[5]_i_79_n_5 ),
        .I1(\VGA_R_reg[5]_i_78_n_6 ),
        .I2(\VGA_R_reg[5]_i_79_n_6 ),
        .I3(timing_sel[0]),
        .I4(timing_sel[1]),
        .O(\VGA_R[5]_i_102_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \VGA_R[5]_i_103 
       (.I0(timing_sel[1]),
        .I1(timing_sel[0]),
        .O(\VGA_R[5]_i_103_n_0 ));
  LUT2 #(
    .INIT(4'hB)) 
    \VGA_R[5]_i_104 
       (.I0(timing_sel[0]),
        .I1(timing_sel[1]),
        .O(\VGA_R[5]_i_104_n_0 ));
  LUT3 #(
    .INIT(8'h2D)) 
    \VGA_R[5]_i_105 
       (.I0(timing_sel[0]),
        .I1(timing_sel[1]),
        .I2(\VGA_R[7]_i_286_n_0 ),
        .O(\VGA_R[5]_i_105_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \VGA_R[5]_i_106 
       (.I0(timing_sel[1]),
        .I1(timing_sel[0]),
        .O(\VGA_R[5]_i_106_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \VGA_R[5]_i_107 
       (.I0(timing_sel[0]),
        .I1(timing_sel[1]),
        .O(\VGA_R[5]_i_107_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \VGA_R[5]_i_109 
       (.I0(timing_sel[1]),
        .I1(timing_sel[0]),
        .O(\VGA_R[5]_i_109_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \VGA_R[5]_i_111 
       (.I0(\VGA_R_reg[5]_i_99_n_6 ),
        .I1(\VGA_R[7]_i_286_n_0 ),
        .O(\VGA_R[5]_i_111_n_0 ));
  LUT3 #(
    .INIT(8'h4B)) 
    \VGA_R[5]_i_112 
       (.I0(\VGA_R_reg[5]_i_99_n_6 ),
        .I1(\VGA_R[7]_i_286_n_0 ),
        .I2(\VGA_R_reg[5]_i_99_n_1 ),
        .O(\VGA_R[5]_i_112_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[5]_i_113 
       (.I0(\VGA_R_reg[5]_i_99_n_6 ),
        .I1(\VGA_R[7]_i_286_n_0 ),
        .O(\VGA_R[5]_i_113_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \VGA_R[5]_i_115 
       (.I0(timing_sel[1]),
        .I1(timing_sel[0]),
        .O(\VGA_R[5]_i_115_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \VGA_R[5]_i_116 
       (.I0(pattern_b1__0_i_13_n_0),
        .I1(\VGA_R_reg[5]_i_97_n_1 ),
        .O(\VGA_R[5]_i_116_n_0 ));
  LUT2 #(
    .INIT(4'hB)) 
    \VGA_R[5]_i_117 
       (.I0(timing_sel[0]),
        .I1(timing_sel[1]),
        .O(HPERIOD));
  LUT2 #(
    .INIT(4'hE)) 
    \VGA_R[5]_i_118 
       (.I0(\VGA_R[7]_i_286_n_0 ),
        .I1(\VGA_R_reg[5]_i_97_n_1 ),
        .O(\VGA_R[5]_i_118_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[5]_i_119 
       (.I0(pattern_b1_n_96),
        .I1(\VGA_R_reg[7]_i_367_n_0 ),
        .O(\VGA_R[5]_i_119_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \VGA_R[5]_i_120 
       (.I0(timing_sel[1]),
        .I1(timing_sel[0]),
        .O(\VGA_R[5]_i_120_n_0 ));
  LUT3 #(
    .INIT(8'h9A)) 
    \VGA_R[5]_i_121 
       (.I0(\VGA_R[7]_i_286_n_0 ),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .O(\VGA_R[5]_i_121_n_0 ));
  LUT2 #(
    .INIT(4'hB)) 
    \VGA_R[5]_i_122 
       (.I0(timing_sel[0]),
        .I1(timing_sel[1]),
        .O(\VGA_R[5]_i_122_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \VGA_R[5]_i_124 
       (.I0(\VGA_R_reg[5]_i_114_n_6 ),
        .I1(\VGA_R[7]_i_286_n_0 ),
        .O(\VGA_R[5]_i_124_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \VGA_R[5]_i_125 
       (.I0(\VGA_R_reg[5]_i_97_n_1 ),
        .O(\VGA_R[5]_i_125_n_0 ));
  LUT3 #(
    .INIT(8'h78)) 
    \VGA_R[5]_i_126 
       (.I0(\VGA_R[7]_i_286_n_0 ),
        .I1(\VGA_R_reg[5]_i_114_n_5 ),
        .I2(\VGA_R_reg[5]_i_114_n_4 ),
        .O(\VGA_R[5]_i_126_n_0 ));
  LUT3 #(
    .INIT(8'h1E)) 
    \VGA_R[5]_i_127 
       (.I0(\VGA_R_reg[5]_i_114_n_6 ),
        .I1(\VGA_R[7]_i_286_n_0 ),
        .I2(\VGA_R_reg[5]_i_114_n_5 ),
        .O(\VGA_R[5]_i_127_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[5]_i_128 
       (.I0(\VGA_R_reg[5]_i_97_n_1 ),
        .I1(\VGA_R[7]_i_286_n_0 ),
        .I2(\VGA_R_reg[5]_i_114_n_6 ),
        .O(\VGA_R[5]_i_128_n_0 ));
  LUT1 #(
    .INIT(2'h2)) 
    \VGA_R[5]_i_129 
       (.I0(\VGA_R_reg[5]_i_97_n_1 ),
        .O(\VGA_R[5]_i_129_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \VGA_R[5]_i_130 
       (.I0(\VGA_R_reg[5]_i_97_n_1 ),
        .I1(pattern_b1__0_i_13_n_0),
        .O(\VGA_R[5]_i_130_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \VGA_R[5]_i_131 
       (.I0(\VGA_R_reg[5]_i_97_n_1 ),
        .O(\VGA_R[5]_i_131_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \VGA_R[5]_i_132 
       (.I0(\VGA_R_reg[5]_i_97_n_1 ),
        .O(\VGA_R[5]_i_132_n_0 ));
  LUT1 #(
    .INIT(2'h2)) 
    \VGA_R[5]_i_133 
       (.I0(\VGA_R_reg[5]_i_97_n_1 ),
        .O(\VGA_R[5]_i_133_n_0 ));
  LUT2 #(
    .INIT(4'h4)) 
    \VGA_R[5]_i_134 
       (.I0(\VGA_R_reg[5]_i_97_n_1 ),
        .I1(pattern_b1__0_i_13_n_0),
        .O(\VGA_R[5]_i_134_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \VGA_R[5]_i_135 
       (.I0(pattern_b1__0_i_13_n_0),
        .O(\VGA_R[5]_i_135_n_0 ));
  LUT1 #(
    .INIT(2'h2)) 
    \VGA_R[5]_i_136 
       (.I0(\VGA_R_reg[5]_i_97_n_6 ),
        .O(\VGA_R[5]_i_136_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \VGA_R[5]_i_137 
       (.I0(\VGA_R_reg[5]_i_97_n_1 ),
        .O(\VGA_R[5]_i_137_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[5]_i_138 
       (.I0(\VGA_R_reg[5]_i_97_n_1 ),
        .I1(\VGA_R_reg[5]_i_97_n_6 ),
        .O(\VGA_R[5]_i_138_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[5]_i_139 
       (.I0(\VGA_R_reg[5]_i_97_n_6 ),
        .I1(\VGA_R_reg[5]_i_97_n_1 ),
        .O(\VGA_R[5]_i_139_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \VGA_R[5]_i_140 
       (.I0(\VGA_R_reg[5]_i_97_n_1 ),
        .O(\VGA_R[5]_i_140_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[5]_i_22 
       (.I0(data6[5]),
        .I1(pattern_b1__0_n_101),
        .O(\VGA_R[5]_i_22_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[5]_i_23 
       (.I0(data6[6]),
        .I1(\VGA_R_reg[6]_i_6_n_6 ),
        .O(\VGA_R[5]_i_23_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[5]_i_24 
       (.I0(data6[6]),
        .I1(\VGA_R[7]_i_286_n_0 ),
        .I2(\VGA_R_reg[6]_i_6_n_7 ),
        .O(\VGA_R[5]_i_24_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[5]_i_25 
       (.I0(\VGA_R[7]_i_286_n_0 ),
        .I1(data6[6]),
        .I2(\VGA_R_reg[6]_i_12_n_4 ),
        .O(\VGA_R[5]_i_25_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[5]_i_27 
       (.I0(data2[6]),
        .I1(\VGA_R_reg[6]_i_5_n_5 ),
        .O(\VGA_R[5]_i_27_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[5]_i_28 
       (.I0(data2[6]),
        .I1(\VGA_R[7]_i_192_n_0 ),
        .I2(\VGA_R_reg[6]_i_5_n_6 ),
        .O(\VGA_R[5]_i_28_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[5]_i_29 
       (.I0(\VGA_R[7]_i_192_n_0 ),
        .I1(data2[6]),
        .I2(\VGA_R_reg[6]_i_5_n_7 ),
        .O(\VGA_R[5]_i_29_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[5]_i_30 
       (.I0(data2[6]),
        .I1(\VGA_R[7]_i_192_n_0 ),
        .I2(\VGA_R_reg[6]_i_7_n_4 ),
        .O(\VGA_R[5]_i_30_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair41" *) 
  LUT3 #(
    .INIT(8'h02)) 
    \VGA_R[5]_i_5 
       (.I0(pattern_sel[3]),
        .I1(pattern_sel[2]),
        .I2(pattern_sel[1]),
        .O(\VGA_R[5]_i_5_n_0 ));
  LUT1 #(
    .INIT(2'h2)) 
    \VGA_R[5]_i_60 
       (.I0(\VGA_R_reg[7]_i_436_n_4 ),
        .O(\VGA_R[5]_i_60_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \VGA_R[5]_i_61 
       (.I0(data6[6]),
        .I1(\VGA_R_reg[6]_i_12_n_5 ),
        .O(\VGA_R[5]_i_61_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \VGA_R[5]_i_62 
       (.I0(data6[6]),
        .I1(\VGA_R_reg[6]_i_12_n_6 ),
        .O(\VGA_R[5]_i_62_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[5]_i_63 
       (.I0(\VGA_R[7]_i_286_n_0 ),
        .I1(data6[6]),
        .I2(\VGA_R_reg[6]_i_12_n_7 ),
        .O(\VGA_R[5]_i_63_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[5]_i_64 
       (.I0(data6[6]),
        .I1(\VGA_R[7]_i_286_n_0 ),
        .I2(\VGA_R_reg[7]_i_436_n_4 ),
        .O(\VGA_R[5]_i_64_n_0 ));
  LUT1 #(
    .INIT(2'h2)) 
    \VGA_R[5]_i_65 
       (.I0(\VGA_R_reg[5]_i_100_n_7 ),
        .O(\VGA_R[5]_i_65_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[5]_i_66 
       (.I0(\VGA_R[7]_i_192_n_0 ),
        .I1(data2[6]),
        .I2(\VGA_R_reg[6]_i_7_n_5 ),
        .O(\VGA_R[5]_i_66_n_0 ));
  LUT4 #(
    .INIT(16'h659A)) 
    \VGA_R[5]_i_67 
       (.I0(data2[6]),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .I3(\VGA_R_reg[6]_i_7_n_6 ),
        .O(\VGA_R[5]_i_67_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[5]_i_68 
       (.I0(data2[6]),
        .I1(\VGA_R_reg[6]_i_7_n_7 ),
        .O(\VGA_R[5]_i_68_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[5]_i_69 
       (.I0(data2[6]),
        .I1(\VGA_R[7]_i_366_n_0 ),
        .I2(\VGA_R_reg[5]_i_100_n_7 ),
        .O(\VGA_R[5]_i_69_n_0 ));
  LUT3 #(
    .INIT(8'h45)) 
    \VGA_R[5]_i_96 
       (.I0(\VGA_R_reg[5]_i_98_n_2 ),
        .I1(\VGA_R[7]_i_286_n_0 ),
        .I2(\VGA_R_reg[5]_i_99_n_1 ),
        .O(\VGA_R[5]_i_96_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[6]_i_10 
       (.I0(\VGA_R[7]_i_192_n_0 ),
        .I1(data2[7]),
        .I2(\VGA_R_reg[7]_i_30_n_7 ),
        .O(\VGA_R[6]_i_10_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[6]_i_11 
       (.I0(data2[7]),
        .I1(\VGA_R[7]_i_192_n_0 ),
        .I2(\VGA_R_reg[7]_i_79_n_4 ),
        .O(\VGA_R[6]_i_11_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[6]_i_13 
       (.I0(data6[6]),
        .I1(pattern_b1__0_n_100),
        .O(\VGA_R[6]_i_13_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[6]_i_14 
       (.I0(data6[7]),
        .I1(\VGA_R_reg[7]_i_40_n_6 ),
        .O(\VGA_R[6]_i_14_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[6]_i_15 
       (.I0(data6[7]),
        .I1(\VGA_R[7]_i_286_n_0 ),
        .I2(\VGA_R_reg[7]_i_40_n_7 ),
        .O(\VGA_R[6]_i_15_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[6]_i_16 
       (.I0(\VGA_R[7]_i_286_n_0 ),
        .I1(data6[7]),
        .I2(\VGA_R_reg[7]_i_109_n_4 ),
        .O(\VGA_R[6]_i_16_n_0 ));
  LUT1 #(
    .INIT(2'h2)) 
    \VGA_R[6]_i_17 
       (.I0(\VGA_R_reg[6]_i_27_n_7 ),
        .O(\VGA_R[6]_i_17_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[6]_i_18 
       (.I0(\VGA_R[7]_i_192_n_0 ),
        .I1(data2[7]),
        .I2(\VGA_R_reg[7]_i_79_n_5 ),
        .O(\VGA_R[6]_i_18_n_0 ));
  LUT4 #(
    .INIT(16'h659A)) 
    \VGA_R[6]_i_19 
       (.I0(data2[7]),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .I3(\VGA_R_reg[7]_i_79_n_6 ),
        .O(\VGA_R[6]_i_19_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[6]_i_20 
       (.I0(data2[7]),
        .I1(\VGA_R_reg[7]_i_79_n_7 ),
        .O(\VGA_R[6]_i_20_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[6]_i_21 
       (.I0(data2[7]),
        .I1(\VGA_R[7]_i_366_n_0 ),
        .I2(\VGA_R_reg[6]_i_27_n_7 ),
        .O(\VGA_R[6]_i_21_n_0 ));
  LUT1 #(
    .INIT(2'h2)) 
    \VGA_R[6]_i_22 
       (.I0(\VGA_R_reg[6]_i_28_n_4 ),
        .O(\VGA_R[6]_i_22_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \VGA_R[6]_i_23 
       (.I0(data6[7]),
        .I1(\VGA_R_reg[7]_i_109_n_5 ),
        .O(\VGA_R[6]_i_23_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \VGA_R[6]_i_24 
       (.I0(data6[7]),
        .I1(\VGA_R_reg[7]_i_109_n_6 ),
        .O(\VGA_R[6]_i_24_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[6]_i_25 
       (.I0(\VGA_R[7]_i_286_n_0 ),
        .I1(data6[7]),
        .I2(\VGA_R_reg[7]_i_109_n_7 ),
        .O(\VGA_R[6]_i_25_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[6]_i_26 
       (.I0(data6[7]),
        .I1(\VGA_R[7]_i_286_n_0 ),
        .I2(\VGA_R_reg[6]_i_28_n_4 ),
        .O(\VGA_R[6]_i_26_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[6]_i_29 
       (.I0(pattern_b1_n_95),
        .I1(\VGA_R_reg[7]_i_462_n_0 ),
        .O(\VGA_R[6]_i_29_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[6]_i_30 
       (.I0(\VGA_R_reg[6]_i_28_n_1 ),
        .I1(pattern_b1__0_n_95),
        .O(\VGA_R[6]_i_30_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[6]_i_31 
       (.I0(\VGA_R_reg[7]_i_435_n_1 ),
        .I1(\VGA_R_reg[7]_i_435_n_6 ),
        .O(\VGA_R[6]_i_31_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[6]_i_32 
       (.I0(\VGA_R_reg[7]_i_435_n_1 ),
        .I1(\VGA_R[7]_i_286_n_0 ),
        .I2(\VGA_R_reg[7]_i_435_n_7 ),
        .O(\VGA_R[6]_i_32_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[6]_i_33 
       (.I0(\VGA_R[7]_i_286_n_0 ),
        .I1(\VGA_R_reg[7]_i_435_n_1 ),
        .I2(\VGA_R_reg[7]_i_477_n_4 ),
        .O(\VGA_R[6]_i_33_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[6]_i_8 
       (.I0(data2[7]),
        .I1(\VGA_R_reg[7]_i_30_n_5 ),
        .O(\VGA_R[6]_i_8_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[6]_i_9 
       (.I0(data2[7]),
        .I1(\VGA_R[7]_i_192_n_0 ),
        .I2(\VGA_R_reg[7]_i_30_n_6 ),
        .O(\VGA_R[6]_i_9_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_112 
       (.I0(data6[7]),
        .I1(pattern_b1__0_n_99),
        .O(\VGA_R[7]_i_112_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_113 
       (.I0(\VGA_R_reg[7]_i_110_n_1 ),
        .I1(\VGA_R_reg[7]_i_110_n_6 ),
        .O(\VGA_R[7]_i_113_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_114 
       (.I0(\VGA_R_reg[7]_i_110_n_1 ),
        .I1(\VGA_R[7]_i_286_n_0 ),
        .I2(\VGA_R_reg[7]_i_110_n_7 ),
        .O(\VGA_R[7]_i_114_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_115 
       (.I0(\VGA_R[7]_i_286_n_0 ),
        .I1(\VGA_R_reg[7]_i_110_n_1 ),
        .I2(\VGA_R_reg[7]_i_111_n_4 ),
        .O(\VGA_R[7]_i_115_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair43" *) 
  LUT5 #(
    .INIT(32'h00000001)) 
    \VGA_R[7]_i_119 
       (.I0(pattern_b1_i_24_n_3),
        .I1(pattern_b1_i_18_n_5),
        .I2(pattern_b1_i_18_n_6),
        .I3(pattern_b1_i_18_n_4),
        .I4(pattern_b1_i_23_n_7),
        .O(\VGA_R[7]_i_119_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair43" *) 
  LUT3 #(
    .INIT(8'h01)) 
    \VGA_R[7]_i_120 
       (.I0(pattern_b1_i_18_n_5),
        .I1(pattern_b1_i_18_n_6),
        .I2(pattern_b1_i_18_n_4),
        .O(\VGA_R[7]_i_120_n_0 ));
  LUT2 #(
    .INIT(4'hB)) 
    \VGA_R[7]_i_129 
       (.I0(timing_sel[0]),
        .I1(timing_sel[1]),
        .O(\VGA_R[7]_i_129_n_0 ));
  LUT3 #(
    .INIT(8'h2D)) 
    \VGA_R[7]_i_131 
       (.I0(timing_sel[0]),
        .I1(timing_sel[1]),
        .I2(pattern_b1__0_i_13_n_0),
        .O(\VGA_R[7]_i_131_n_0 ));
  LUT1 #(
    .INIT(2'h2)) 
    \VGA_R[7]_i_176 
       (.I0(\VGA_R_reg[7]_i_365_n_7 ),
        .O(\VGA_R[7]_i_176_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_177 
       (.I0(\VGA_R[7]_i_192_n_0 ),
        .I1(\VGA_R_reg[7]_i_80_n_0 ),
        .I2(\VGA_R_reg[7]_i_81_n_5 ),
        .O(\VGA_R[7]_i_177_n_0 ));
  LUT4 #(
    .INIT(16'h659A)) 
    \VGA_R[7]_i_178 
       (.I0(\VGA_R_reg[7]_i_80_n_0 ),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .I3(\VGA_R_reg[7]_i_81_n_6 ),
        .O(\VGA_R[7]_i_178_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_179 
       (.I0(\VGA_R_reg[7]_i_80_n_0 ),
        .I1(\VGA_R_reg[7]_i_81_n_7 ),
        .O(\VGA_R[7]_i_179_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_180 
       (.I0(\VGA_R_reg[7]_i_80_n_0 ),
        .I1(\VGA_R[7]_i_366_n_0 ),
        .I2(\VGA_R_reg[7]_i_365_n_7 ),
        .O(\VGA_R[7]_i_180_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_183 
       (.I0(\VGA_R_reg[7]_i_181_n_0 ),
        .I1(\VGA_R_reg[7]_i_181_n_5 ),
        .O(\VGA_R[7]_i_183_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_184 
       (.I0(\VGA_R_reg[7]_i_181_n_0 ),
        .I1(\VGA_R[7]_i_192_n_0 ),
        .I2(\VGA_R_reg[7]_i_181_n_6 ),
        .O(\VGA_R[7]_i_184_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_185 
       (.I0(\VGA_R[7]_i_192_n_0 ),
        .I1(\VGA_R_reg[7]_i_181_n_0 ),
        .I2(\VGA_R_reg[7]_i_181_n_7 ),
        .O(\VGA_R[7]_i_185_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_186 
       (.I0(\VGA_R_reg[7]_i_181_n_0 ),
        .I1(\VGA_R[7]_i_192_n_0 ),
        .I2(\VGA_R_reg[7]_i_182_n_4 ),
        .O(\VGA_R[7]_i_186_n_0 ));
  LUT1 #(
    .INIT(2'h2)) 
    \VGA_R[7]_i_187 
       (.I0(\VGA_R_reg[7]_i_378_n_7 ),
        .O(\VGA_R[7]_i_187_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_188 
       (.I0(\VGA_R[7]_i_192_n_0 ),
        .I1(\VGA_R_reg[7]_i_181_n_0 ),
        .I2(\VGA_R_reg[7]_i_182_n_5 ),
        .O(\VGA_R[7]_i_188_n_0 ));
  LUT4 #(
    .INIT(16'h659A)) 
    \VGA_R[7]_i_189 
       (.I0(\VGA_R_reg[7]_i_181_n_0 ),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .I3(\VGA_R_reg[7]_i_182_n_6 ),
        .O(\VGA_R[7]_i_189_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_190 
       (.I0(\VGA_R_reg[7]_i_181_n_0 ),
        .I1(\VGA_R_reg[7]_i_182_n_7 ),
        .O(\VGA_R[7]_i_190_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_191 
       (.I0(\VGA_R_reg[7]_i_181_n_0 ),
        .I1(\VGA_R[7]_i_366_n_0 ),
        .I2(\VGA_R_reg[7]_i_378_n_7 ),
        .O(\VGA_R[7]_i_191_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \VGA_R[7]_i_192 
       (.I0(timing_sel[1]),
        .I1(timing_sel[0]),
        .O(\VGA_R[7]_i_192_n_0 ));
  LUT3 #(
    .INIT(8'h2D)) 
    \VGA_R[7]_i_205 
       (.I0(timing_sel[0]),
        .I1(timing_sel[1]),
        .I2(pattern_b1__0_i_13_n_0),
        .O(\VGA_R[7]_i_205_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_206 
       (.I0(\VGA_R_reg[7]_i_93_n_3 ),
        .I1(\VGA_R_reg[7]_i_204_n_4 ),
        .O(\VGA_R[7]_i_206_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_207 
       (.I0(\VGA_R_reg[7]_i_93_n_3 ),
        .I1(pattern_b1__0_i_13_n_0),
        .I2(\VGA_R_reg[7]_i_204_n_5 ),
        .O(\VGA_R[7]_i_207_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_208 
       (.I0(pattern_b1__0_i_13_n_0),
        .I1(\VGA_R_reg[7]_i_93_n_3 ),
        .I2(\VGA_R_reg[7]_i_204_n_6 ),
        .O(\VGA_R[7]_i_208_n_0 ));
  LUT3 #(
    .INIT(8'h65)) 
    \VGA_R[7]_i_209 
       (.I0(\VGA_R_reg[7]_i_93_n_3 ),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .O(\VGA_R[7]_i_209_n_0 ));
  LUT2 #(
    .INIT(4'hB)) 
    \VGA_R[7]_i_210 
       (.I0(timing_sel[0]),
        .I1(timing_sel[1]),
        .O(\VGA_R[7]_i_210_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_242 
       (.I0(\VGA_R_reg[7]_i_101_n_0 ),
        .I1(\VGA_R_reg[7]_i_101_n_5 ),
        .O(\VGA_R[7]_i_242_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_243 
       (.I0(\VGA_R_reg[7]_i_101_n_0 ),
        .I1(pattern_b1__0_i_13_n_0),
        .I2(\VGA_R_reg[7]_i_101_n_6 ),
        .O(\VGA_R[7]_i_243_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_244 
       (.I0(pattern_b1__0_i_13_n_0),
        .I1(\VGA_R_reg[7]_i_101_n_0 ),
        .I2(\VGA_R_reg[7]_i_101_n_7 ),
        .O(\VGA_R[7]_i_244_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_245 
       (.I0(\VGA_R_reg[7]_i_101_n_0 ),
        .I1(pattern_b1__0_i_13_n_0),
        .I2(\VGA_R_reg[7]_i_241_n_4 ),
        .O(\VGA_R[7]_i_245_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_246 
       (.I0(\VGA_R_reg[7]_i_92_n_0 ),
        .I1(\VGA_R_reg[7]_i_92_n_5 ),
        .O(\VGA_R[7]_i_246_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_247 
       (.I0(\VGA_R_reg[7]_i_92_n_0 ),
        .I1(pattern_b1__0_i_13_n_0),
        .I2(\VGA_R_reg[7]_i_92_n_6 ),
        .O(\VGA_R[7]_i_247_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_248 
       (.I0(pattern_b1__0_i_13_n_0),
        .I1(\VGA_R_reg[7]_i_92_n_0 ),
        .I2(\VGA_R_reg[7]_i_92_n_7 ),
        .O(\VGA_R[7]_i_248_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_249 
       (.I0(\VGA_R_reg[7]_i_92_n_0 ),
        .I1(pattern_b1__0_i_13_n_0),
        .I2(\VGA_R_reg[7]_i_203_n_4 ),
        .O(\VGA_R[7]_i_249_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair40" *) 
  LUT3 #(
    .INIT(8'h45)) 
    \VGA_R[7]_i_25 
       (.I0(pattern_sel[2]),
        .I1(pattern_sel[1]),
        .I2(pattern_sel[0]),
        .O(\VGA_R[7]_i_25_n_0 ));
  LUT1 #(
    .INIT(2'h2)) 
    \VGA_R[7]_i_270 
       (.I0(\VGA_R_reg[7]_i_435_n_4 ),
        .O(\VGA_R[7]_i_270_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \VGA_R[7]_i_271 
       (.I0(\VGA_R_reg[7]_i_110_n_1 ),
        .I1(\VGA_R_reg[7]_i_111_n_5 ),
        .O(\VGA_R[7]_i_271_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \VGA_R[7]_i_272 
       (.I0(\VGA_R_reg[7]_i_110_n_1 ),
        .I1(\VGA_R_reg[7]_i_111_n_6 ),
        .O(\VGA_R[7]_i_272_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_273 
       (.I0(\VGA_R[7]_i_286_n_0 ),
        .I1(\VGA_R_reg[7]_i_110_n_1 ),
        .I2(\VGA_R_reg[7]_i_111_n_7 ),
        .O(\VGA_R[7]_i_273_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_274 
       (.I0(\VGA_R_reg[7]_i_110_n_1 ),
        .I1(\VGA_R[7]_i_286_n_0 ),
        .I2(\VGA_R_reg[7]_i_435_n_4 ),
        .O(\VGA_R[7]_i_274_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_277 
       (.I0(\VGA_R_reg[7]_i_110_n_1 ),
        .I1(pattern_b1__0_n_98),
        .O(\VGA_R[7]_i_277_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_278 
       (.I0(\VGA_R_reg[7]_i_275_n_1 ),
        .I1(\VGA_R_reg[7]_i_275_n_6 ),
        .O(\VGA_R[7]_i_278_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_279 
       (.I0(\VGA_R_reg[7]_i_275_n_1 ),
        .I1(\VGA_R[7]_i_286_n_0 ),
        .I2(\VGA_R_reg[7]_i_275_n_7 ),
        .O(\VGA_R[7]_i_279_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_280 
       (.I0(\VGA_R[7]_i_286_n_0 ),
        .I1(\VGA_R_reg[7]_i_275_n_1 ),
        .I2(\VGA_R_reg[7]_i_276_n_4 ),
        .O(\VGA_R[7]_i_280_n_0 ));
  LUT1 #(
    .INIT(2'h2)) 
    \VGA_R[7]_i_281 
       (.I0(\VGA_R_reg[7]_i_447_n_4 ),
        .O(\VGA_R[7]_i_281_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \VGA_R[7]_i_282 
       (.I0(\VGA_R_reg[7]_i_275_n_1 ),
        .I1(\VGA_R_reg[7]_i_276_n_5 ),
        .O(\VGA_R[7]_i_282_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \VGA_R[7]_i_283 
       (.I0(\VGA_R_reg[7]_i_275_n_1 ),
        .I1(\VGA_R_reg[7]_i_276_n_6 ),
        .O(\VGA_R[7]_i_283_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_284 
       (.I0(\VGA_R[7]_i_286_n_0 ),
        .I1(\VGA_R_reg[7]_i_275_n_1 ),
        .I2(\VGA_R_reg[7]_i_276_n_7 ),
        .O(\VGA_R[7]_i_284_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_285 
       (.I0(\VGA_R_reg[7]_i_275_n_1 ),
        .I1(\VGA_R[7]_i_286_n_0 ),
        .I2(\VGA_R_reg[7]_i_447_n_4 ),
        .O(\VGA_R[7]_i_285_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \VGA_R[7]_i_286 
       (.I0(timing_sel[1]),
        .I1(timing_sel[0]),
        .O(\VGA_R[7]_i_286_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair42" *) 
  LUT2 #(
    .INIT(4'h1)) 
    \VGA_R[7]_i_29 
       (.I0(pattern_sel[1]),
        .I1(pattern_sel[2]),
        .O(\VGA_R[7]_i_29_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \VGA_R[7]_i_309 
       (.I0(timing_sel[0]),
        .I1(timing_sel[1]),
        .O(HWIDTH));
  LUT2 #(
    .INIT(4'h2)) 
    \VGA_R[7]_i_310 
       (.I0(timing_sel[1]),
        .I1(timing_sel[0]),
        .O(\VGA_R[7]_i_310_n_0 ));
  LUT2 #(
    .INIT(4'hB)) 
    \VGA_R[7]_i_311 
       (.I0(timing_sel[0]),
        .I1(timing_sel[1]),
        .O(\VGA_R[7]_i_311_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \VGA_R[7]_i_312 
       (.I0(timing_sel[1]),
        .I1(timing_sel[0]),
        .O(\VGA_R[7]_i_312_n_0 ));
  LUT2 #(
    .INIT(4'hB)) 
    \VGA_R[7]_i_313 
       (.I0(timing_sel[0]),
        .I1(timing_sel[1]),
        .O(\VGA_R[7]_i_313_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \VGA_R[7]_i_314 
       (.I0(timing_sel[1]),
        .I1(timing_sel[0]),
        .O(\VGA_R[7]_i_314_n_0 ));
  LUT3 #(
    .INIT(8'hEF)) 
    \VGA_R[7]_i_315 
       (.I0(pattern_b1__0_i_13_n_0),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .O(\VGA_R[7]_i_315_n_0 ));
  LUT2 #(
    .INIT(4'hB)) 
    \VGA_R[7]_i_316 
       (.I0(timing_sel[0]),
        .I1(timing_sel[1]),
        .O(\VGA_R[7]_i_316_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \VGA_R[7]_i_319 
       (.I0(timing_sel[0]),
        .I1(timing_sel[1]),
        .O(\VGA_R[7]_i_319_n_0 ));
  LUT3 #(
    .INIT(8'hFE)) 
    \VGA_R[7]_i_34 
       (.I0(pattern_sel[0]),
        .I1(\VGA_R_reg[7]_i_92_n_0 ),
        .I2(\VGA_R_reg[7]_i_93_n_3 ),
        .O(\VGA_R[7]_i_34_n_0 ));
  LUT2 #(
    .INIT(4'hB)) 
    \VGA_R[7]_i_366 
       (.I0(timing_sel[1]),
        .I1(timing_sel[0]),
        .O(\VGA_R[7]_i_366_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_369 
       (.I0(\VGA_R_reg[7]_i_367_n_0 ),
        .I1(\VGA_R_reg[7]_i_367_n_5 ),
        .O(\VGA_R[7]_i_369_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_370 
       (.I0(\VGA_R_reg[7]_i_367_n_0 ),
        .I1(\VGA_R[7]_i_192_n_0 ),
        .I2(\VGA_R_reg[7]_i_367_n_6 ),
        .O(\VGA_R[7]_i_370_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_371 
       (.I0(\VGA_R[7]_i_192_n_0 ),
        .I1(\VGA_R_reg[7]_i_367_n_0 ),
        .I2(\VGA_R_reg[7]_i_367_n_7 ),
        .O(\VGA_R[7]_i_371_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_372 
       (.I0(\VGA_R_reg[7]_i_367_n_0 ),
        .I1(\VGA_R[7]_i_192_n_0 ),
        .I2(\VGA_R_reg[7]_i_368_n_4 ),
        .O(\VGA_R[7]_i_372_n_0 ));
  LUT1 #(
    .INIT(2'h2)) 
    \VGA_R[7]_i_373 
       (.I0(\VGA_R_reg[7]_i_473_n_7 ),
        .O(\VGA_R[7]_i_373_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_374 
       (.I0(\VGA_R[7]_i_192_n_0 ),
        .I1(\VGA_R_reg[7]_i_367_n_0 ),
        .I2(\VGA_R_reg[7]_i_368_n_5 ),
        .O(\VGA_R[7]_i_374_n_0 ));
  LUT4 #(
    .INIT(16'h659A)) 
    \VGA_R[7]_i_375 
       (.I0(\VGA_R_reg[7]_i_367_n_0 ),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .I3(\VGA_R_reg[7]_i_368_n_6 ),
        .O(\VGA_R[7]_i_375_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_376 
       (.I0(\VGA_R_reg[7]_i_367_n_0 ),
        .I1(\VGA_R_reg[7]_i_368_n_7 ),
        .O(\VGA_R[7]_i_376_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_377 
       (.I0(\VGA_R_reg[7]_i_367_n_0 ),
        .I1(\VGA_R[7]_i_366_n_0 ),
        .I2(\VGA_R_reg[7]_i_473_n_7 ),
        .O(\VGA_R[7]_i_377_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \VGA_R[7]_i_379 
       (.I0(\VGA_R_reg[7]_i_93_n_3 ),
        .I1(pattern_b1__0_i_13_n_0),
        .O(\VGA_R[7]_i_379_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \VGA_R[7]_i_380 
       (.I0(timing_sel[0]),
        .I1(timing_sel[1]),
        .O(\VGA_R[7]_i_380_n_0 ));
  LUT3 #(
    .INIT(8'hD2)) 
    \VGA_R[7]_i_381 
       (.I0(timing_sel[0]),
        .I1(timing_sel[1]),
        .I2(\VGA_R_reg[7]_i_93_n_3 ),
        .O(\VGA_R[7]_i_381_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \VGA_R[7]_i_382 
       (.I0(\VGA_R_reg[7]_i_93_n_3 ),
        .I1(pattern_b1__0_i_13_n_0),
        .O(\VGA_R[7]_i_382_n_0 ));
  LUT1 #(
    .INIT(2'h2)) 
    \VGA_R[7]_i_383 
       (.I0(\VGA_R_reg[7]_i_93_n_3 ),
        .O(\VGA_R[7]_i_383_n_0 ));
  LUT3 #(
    .INIT(8'hA6)) 
    \VGA_R[7]_i_384 
       (.I0(\VGA_R_reg[7]_i_93_n_3 ),
        .I1(timing_sel[0]),
        .I2(timing_sel[1]),
        .O(\VGA_R[7]_i_384_n_0 ));
  LUT3 #(
    .INIT(8'hD2)) 
    \VGA_R[7]_i_385 
       (.I0(timing_sel[0]),
        .I1(timing_sel[1]),
        .I2(\VGA_R_reg[7]_i_93_n_3 ),
        .O(\VGA_R[7]_i_385_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \VGA_R[7]_i_386 
       (.I0(timing_sel[1]),
        .I1(timing_sel[0]),
        .O(\VGA_R[7]_i_386_n_0 ));
  LUT2 #(
    .INIT(4'hB)) 
    \VGA_R[7]_i_387 
       (.I0(timing_sel[0]),
        .I1(timing_sel[1]),
        .O(\VGA_R[7]_i_387_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \VGA_R[7]_i_388 
       (.I0(timing_sel[1]),
        .I1(timing_sel[0]),
        .O(\VGA_R[7]_i_388_n_0 ));
  LUT2 #(
    .INIT(4'hB)) 
    \VGA_R[7]_i_389 
       (.I0(timing_sel[0]),
        .I1(timing_sel[1]),
        .O(\VGA_R[7]_i_389_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \VGA_R[7]_i_390 
       (.I0(timing_sel[1]),
        .I1(timing_sel[0]),
        .O(\VGA_R[7]_i_390_n_0 ));
  LUT3 #(
    .INIT(8'hEF)) 
    \VGA_R[7]_i_391 
       (.I0(pattern_b1__0_i_13_n_0),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .O(\VGA_R[7]_i_391_n_0 ));
  LUT2 #(
    .INIT(4'hB)) 
    \VGA_R[7]_i_392 
       (.I0(timing_sel[0]),
        .I1(timing_sel[1]),
        .O(\VGA_R[7]_i_392_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_419 
       (.I0(pattern_b1__0_i_13_n_0),
        .I1(\VGA_R_reg[7]_i_101_n_0 ),
        .I2(\VGA_R_reg[7]_i_241_n_5 ),
        .O(\VGA_R[7]_i_419_n_0 ));
  LUT4 #(
    .INIT(16'h659A)) 
    \VGA_R[7]_i_420 
       (.I0(\VGA_R_reg[7]_i_101_n_0 ),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .I3(\VGA_R_reg[7]_i_241_n_6 ),
        .O(\VGA_R[7]_i_420_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_421 
       (.I0(\VGA_R_reg[7]_i_101_n_0 ),
        .I1(\VGA_R_reg[7]_i_241_n_7 ),
        .O(\VGA_R[7]_i_421_n_0 ));
  LUT3 #(
    .INIT(8'hD2)) 
    \VGA_R[7]_i_423 
       (.I0(timing_sel[0]),
        .I1(timing_sel[1]),
        .I2(\VGA_R_reg[7]_i_92_n_0 ),
        .O(\VGA_R[7]_i_423_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_424 
       (.I0(pattern_b1__0_i_13_n_0),
        .I1(\VGA_R_reg[7]_i_92_n_0 ),
        .I2(\VGA_R_reg[7]_i_203_n_5 ),
        .O(\VGA_R[7]_i_424_n_0 ));
  LUT4 #(
    .INIT(16'h659A)) 
    \VGA_R[7]_i_425 
       (.I0(\VGA_R_reg[7]_i_92_n_0 ),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .I3(\VGA_R_reg[7]_i_203_n_6 ),
        .O(\VGA_R[7]_i_425_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_426 
       (.I0(\VGA_R_reg[7]_i_92_n_0 ),
        .I1(\VGA_R_reg[7]_i_203_n_7 ),
        .O(\VGA_R[7]_i_426_n_0 ));
  LUT3 #(
    .INIT(8'hD2)) 
    \VGA_R[7]_i_427 
       (.I0(timing_sel[0]),
        .I1(timing_sel[1]),
        .I2(\VGA_R_reg[7]_i_92_n_0 ),
        .O(\VGA_R[7]_i_427_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_438 
       (.I0(\VGA_R_reg[7]_i_275_n_1 ),
        .I1(pattern_b1__0_n_97),
        .O(\VGA_R[7]_i_438_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_439 
       (.I0(\VGA_R_reg[7]_i_436_n_1 ),
        .I1(\VGA_R_reg[7]_i_436_n_6 ),
        .O(\VGA_R[7]_i_439_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_440 
       (.I0(\VGA_R_reg[7]_i_436_n_1 ),
        .I1(\VGA_R[7]_i_286_n_0 ),
        .I2(\VGA_R_reg[7]_i_436_n_7 ),
        .O(\VGA_R[7]_i_440_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_441 
       (.I0(\VGA_R[7]_i_286_n_0 ),
        .I1(\VGA_R_reg[7]_i_436_n_1 ),
        .I2(\VGA_R_reg[7]_i_437_n_4 ),
        .O(\VGA_R[7]_i_441_n_0 ));
  LUT1 #(
    .INIT(2'h2)) 
    \VGA_R[7]_i_442 
       (.I0(\VGA_R_reg[7]_i_493_n_7 ),
        .O(\VGA_R[7]_i_442_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \VGA_R[7]_i_443 
       (.I0(\VGA_R_reg[7]_i_436_n_1 ),
        .I1(\VGA_R_reg[7]_i_437_n_5 ),
        .O(\VGA_R[7]_i_443_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \VGA_R[7]_i_444 
       (.I0(\VGA_R_reg[7]_i_436_n_1 ),
        .I1(\VGA_R_reg[7]_i_437_n_6 ),
        .O(\VGA_R[7]_i_444_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_445 
       (.I0(\VGA_R[7]_i_286_n_0 ),
        .I1(\VGA_R_reg[7]_i_436_n_1 ),
        .I2(\VGA_R_reg[7]_i_437_n_7 ),
        .O(\VGA_R[7]_i_445_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_446 
       (.I0(\VGA_R_reg[7]_i_436_n_1 ),
        .I1(\VGA_R[7]_i_286_n_0 ),
        .I2(\VGA_R_reg[7]_i_493_n_7 ),
        .O(\VGA_R[7]_i_446_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_461 
       (.I0(pattern_b1_n_94),
        .I1(\VGA_R_reg[7]_i_460_n_0 ),
        .O(\VGA_R[7]_i_461_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_464 
       (.I0(\VGA_R_reg[7]_i_462_n_0 ),
        .I1(\VGA_R_reg[7]_i_462_n_5 ),
        .O(\VGA_R[7]_i_464_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_465 
       (.I0(\VGA_R_reg[7]_i_462_n_0 ),
        .I1(\VGA_R[7]_i_192_n_0 ),
        .I2(\VGA_R_reg[7]_i_462_n_6 ),
        .O(\VGA_R[7]_i_465_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_466 
       (.I0(\VGA_R[7]_i_192_n_0 ),
        .I1(\VGA_R_reg[7]_i_462_n_0 ),
        .I2(\VGA_R_reg[7]_i_462_n_7 ),
        .O(\VGA_R[7]_i_466_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_467 
       (.I0(\VGA_R_reg[7]_i_462_n_0 ),
        .I1(\VGA_R[7]_i_192_n_0 ),
        .I2(\VGA_R_reg[7]_i_463_n_4 ),
        .O(\VGA_R[7]_i_467_n_0 ));
  LUT1 #(
    .INIT(2'h2)) 
    \VGA_R[7]_i_468 
       (.I0(\VGA_R_reg[7]_i_527_n_7 ),
        .O(\VGA_R[7]_i_468_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_469 
       (.I0(\VGA_R[7]_i_192_n_0 ),
        .I1(\VGA_R_reg[7]_i_462_n_0 ),
        .I2(\VGA_R_reg[7]_i_463_n_5 ),
        .O(\VGA_R[7]_i_469_n_0 ));
  LUT4 #(
    .INIT(16'h659A)) 
    \VGA_R[7]_i_470 
       (.I0(\VGA_R_reg[7]_i_462_n_0 ),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .I3(\VGA_R_reg[7]_i_463_n_6 ),
        .O(\VGA_R[7]_i_470_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_471 
       (.I0(\VGA_R_reg[7]_i_462_n_0 ),
        .I1(\VGA_R_reg[7]_i_463_n_7 ),
        .O(\VGA_R[7]_i_471_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_472 
       (.I0(\VGA_R_reg[7]_i_462_n_0 ),
        .I1(\VGA_R[7]_i_366_n_0 ),
        .I2(\VGA_R_reg[7]_i_527_n_7 ),
        .O(\VGA_R[7]_i_472_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_475 
       (.I0(pattern_b1_n_93),
        .I1(\VGA_R_reg[7]_i_474_n_0 ),
        .O(\VGA_R[7]_i_475_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_479 
       (.I0(\VGA_R_reg[7]_i_435_n_1 ),
        .I1(pattern_b1__0_n_94),
        .O(\VGA_R[7]_i_479_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_480 
       (.I0(\VGA_R_reg[7]_i_447_n_1 ),
        .I1(\VGA_R_reg[7]_i_447_n_6 ),
        .O(\VGA_R[7]_i_480_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_481 
       (.I0(\VGA_R_reg[7]_i_447_n_1 ),
        .I1(\VGA_R[7]_i_286_n_0 ),
        .I2(\VGA_R_reg[7]_i_447_n_7 ),
        .O(\VGA_R[7]_i_481_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_482 
       (.I0(\VGA_R[7]_i_286_n_0 ),
        .I1(\VGA_R_reg[7]_i_447_n_1 ),
        .I2(\VGA_R_reg[7]_i_478_n_4 ),
        .O(\VGA_R[7]_i_482_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_484 
       (.I0(\VGA_R_reg[7]_i_436_n_1 ),
        .I1(pattern_b1__0_n_96),
        .O(\VGA_R[7]_i_484_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_485 
       (.I0(\VGA_R_reg[6]_i_28_n_1 ),
        .I1(\VGA_R_reg[6]_i_28_n_6 ),
        .O(\VGA_R[7]_i_485_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_486 
       (.I0(\VGA_R_reg[6]_i_28_n_1 ),
        .I1(\VGA_R[7]_i_286_n_0 ),
        .I2(\VGA_R_reg[6]_i_28_n_7 ),
        .O(\VGA_R[7]_i_486_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_487 
       (.I0(\VGA_R[7]_i_286_n_0 ),
        .I1(\VGA_R_reg[6]_i_28_n_1 ),
        .I2(\VGA_R_reg[7]_i_483_n_4 ),
        .O(\VGA_R[7]_i_487_n_0 ));
  LUT1 #(
    .INIT(2'h2)) 
    \VGA_R[7]_i_488 
       (.I0(pattern_b1__0_n_91),
        .O(\VGA_R[7]_i_488_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \VGA_R[7]_i_489 
       (.I0(\VGA_R_reg[6]_i_28_n_1 ),
        .I1(\VGA_R_reg[7]_i_483_n_5 ),
        .O(\VGA_R[7]_i_489_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \VGA_R[7]_i_490 
       (.I0(\VGA_R_reg[6]_i_28_n_1 ),
        .I1(\VGA_R_reg[7]_i_483_n_6 ),
        .O(\VGA_R[7]_i_490_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_491 
       (.I0(\VGA_R[7]_i_286_n_0 ),
        .I1(\VGA_R_reg[6]_i_28_n_1 ),
        .I2(\VGA_R_reg[7]_i_483_n_7 ),
        .O(\VGA_R[7]_i_491_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_492 
       (.I0(\VGA_R_reg[6]_i_28_n_1 ),
        .I1(\VGA_R[7]_i_286_n_0 ),
        .I2(pattern_b1__0_n_91),
        .O(\VGA_R[7]_i_492_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_495 
       (.I0(\VGA_R_reg[7]_i_447_n_1 ),
        .I1(pattern_b1__0_n_93),
        .O(\VGA_R[7]_i_495_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_496 
       (.I0(\VGA_R_reg[7]_i_494_n_0 ),
        .I1(\VGA_R_reg[7]_i_494_n_5 ),
        .O(\VGA_R[7]_i_496_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_497 
       (.I0(\VGA_R_reg[7]_i_494_n_0 ),
        .I1(\VGA_R[7]_i_286_n_0 ),
        .I2(\VGA_R_reg[7]_i_494_n_6 ),
        .O(\VGA_R[7]_i_497_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_498 
       (.I0(\VGA_R[7]_i_286_n_0 ),
        .I1(\VGA_R_reg[7]_i_494_n_0 ),
        .I2(\VGA_R_reg[7]_i_494_n_7 ),
        .O(\VGA_R[7]_i_498_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_514 
       (.I0(\VGA_R_reg[7]_i_474_n_0 ),
        .I1(\VGA_R_reg[7]_i_474_n_5 ),
        .O(\VGA_R[7]_i_514_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_515 
       (.I0(\VGA_R_reg[7]_i_474_n_0 ),
        .I1(\VGA_R[7]_i_192_n_0 ),
        .I2(\VGA_R_reg[7]_i_474_n_6 ),
        .O(\VGA_R[7]_i_515_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_516 
       (.I0(\VGA_R[7]_i_192_n_0 ),
        .I1(\VGA_R_reg[7]_i_474_n_0 ),
        .I2(\VGA_R_reg[7]_i_474_n_7 ),
        .O(\VGA_R[7]_i_516_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_517 
       (.I0(\VGA_R_reg[7]_i_474_n_0 ),
        .I1(\VGA_R[7]_i_192_n_0 ),
        .I2(\VGA_R_reg[7]_i_513_n_4 ),
        .O(\VGA_R[7]_i_517_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_518 
       (.I0(\VGA_R_reg[7]_i_460_n_0 ),
        .I1(\VGA_R_reg[7]_i_460_n_5 ),
        .O(\VGA_R[7]_i_518_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_519 
       (.I0(\VGA_R_reg[7]_i_460_n_0 ),
        .I1(\VGA_R[7]_i_192_n_0 ),
        .I2(\VGA_R_reg[7]_i_460_n_6 ),
        .O(\VGA_R[7]_i_519_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_520 
       (.I0(\VGA_R[7]_i_192_n_0 ),
        .I1(\VGA_R_reg[7]_i_460_n_0 ),
        .I2(\VGA_R_reg[7]_i_460_n_7 ),
        .O(\VGA_R[7]_i_520_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_521 
       (.I0(\VGA_R_reg[7]_i_460_n_0 ),
        .I1(\VGA_R[7]_i_192_n_0 ),
        .I2(\VGA_R_reg[7]_i_512_n_4 ),
        .O(\VGA_R[7]_i_521_n_0 ));
  LUT1 #(
    .INIT(2'h2)) 
    \VGA_R[7]_i_522 
       (.I0(\VGA_R_reg[7]_i_571_n_7 ),
        .O(\VGA_R[7]_i_522_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_523 
       (.I0(\VGA_R[7]_i_192_n_0 ),
        .I1(\VGA_R_reg[7]_i_460_n_0 ),
        .I2(\VGA_R_reg[7]_i_512_n_5 ),
        .O(\VGA_R[7]_i_523_n_0 ));
  LUT4 #(
    .INIT(16'h659A)) 
    \VGA_R[7]_i_524 
       (.I0(\VGA_R_reg[7]_i_460_n_0 ),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .I3(\VGA_R_reg[7]_i_512_n_6 ),
        .O(\VGA_R[7]_i_524_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_525 
       (.I0(\VGA_R_reg[7]_i_460_n_0 ),
        .I1(\VGA_R_reg[7]_i_512_n_7 ),
        .O(\VGA_R[7]_i_525_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_526 
       (.I0(\VGA_R_reg[7]_i_460_n_0 ),
        .I1(\VGA_R[7]_i_366_n_0 ),
        .I2(\VGA_R_reg[7]_i_571_n_7 ),
        .O(\VGA_R[7]_i_526_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_529 
       (.I0(pattern_b1_n_92),
        .I1(\VGA_R_reg[7]_i_528_n_0 ),
        .O(\VGA_R[7]_i_529_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_531 
       (.I0(\VGA_R_reg[7]_i_528_n_0 ),
        .I1(\VGA_R_reg[7]_i_528_n_5 ),
        .O(\VGA_R[7]_i_531_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_532 
       (.I0(\VGA_R_reg[7]_i_528_n_0 ),
        .I1(\VGA_R[7]_i_192_n_0 ),
        .I2(\VGA_R_reg[7]_i_528_n_6 ),
        .O(\VGA_R[7]_i_532_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_533 
       (.I0(\VGA_R[7]_i_192_n_0 ),
        .I1(\VGA_R_reg[7]_i_528_n_0 ),
        .I2(\VGA_R_reg[7]_i_528_n_7 ),
        .O(\VGA_R[7]_i_533_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_534 
       (.I0(\VGA_R_reg[7]_i_528_n_0 ),
        .I1(\VGA_R[7]_i_192_n_0 ),
        .I2(\VGA_R_reg[7]_i_530_n_4 ),
        .O(\VGA_R[7]_i_534_n_0 ));
  LUT1 #(
    .INIT(2'h2)) 
    \VGA_R[7]_i_535 
       (.I0(pattern_b1__0_n_89),
        .O(\VGA_R[7]_i_535_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \VGA_R[7]_i_536 
       (.I0(\VGA_R_reg[7]_i_447_n_1 ),
        .I1(\VGA_R_reg[7]_i_478_n_5 ),
        .O(\VGA_R[7]_i_536_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \VGA_R[7]_i_537 
       (.I0(\VGA_R_reg[7]_i_447_n_1 ),
        .I1(\VGA_R_reg[7]_i_478_n_6 ),
        .O(\VGA_R[7]_i_537_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_538 
       (.I0(\VGA_R[7]_i_286_n_0 ),
        .I1(\VGA_R_reg[7]_i_447_n_1 ),
        .I2(\VGA_R_reg[7]_i_478_n_7 ),
        .O(\VGA_R[7]_i_538_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_539 
       (.I0(\VGA_R_reg[7]_i_447_n_1 ),
        .I1(\VGA_R[7]_i_286_n_0 ),
        .I2(pattern_b1__0_n_89),
        .O(\VGA_R[7]_i_539_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \VGA_R[7]_i_541 
       (.I0(\VGA_R_reg[7]_i_494_n_0 ),
        .I1(\VGA_R_reg[7]_i_540_n_4 ),
        .O(\VGA_R[7]_i_541_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \VGA_R[7]_i_542 
       (.I0(\VGA_R_reg[7]_i_494_n_0 ),
        .I1(\VGA_R_reg[7]_i_540_n_5 ),
        .O(\VGA_R[7]_i_542_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_543 
       (.I0(\VGA_R[7]_i_286_n_0 ),
        .I1(\VGA_R_reg[7]_i_494_n_0 ),
        .I2(\VGA_R_reg[7]_i_540_n_6 ),
        .O(\VGA_R[7]_i_543_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_544 
       (.I0(\VGA_R_reg[7]_i_494_n_0 ),
        .I1(\VGA_R[7]_i_286_n_0 ),
        .I2(\VGA_R_reg[7]_i_540_n_7 ),
        .O(\VGA_R[7]_i_544_n_0 ));
  LUT1 #(
    .INIT(2'h2)) 
    \VGA_R[7]_i_545 
       (.I0(pattern_b1__0_n_90),
        .O(\VGA_R[7]_i_545_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \VGA_R[7]_i_546 
       (.I0(\VGA_R_reg[7]_i_435_n_1 ),
        .I1(\VGA_R_reg[7]_i_477_n_5 ),
        .O(\VGA_R[7]_i_546_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \VGA_R[7]_i_547 
       (.I0(\VGA_R_reg[7]_i_435_n_1 ),
        .I1(\VGA_R_reg[7]_i_477_n_6 ),
        .O(\VGA_R[7]_i_547_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_548 
       (.I0(\VGA_R[7]_i_286_n_0 ),
        .I1(\VGA_R_reg[7]_i_435_n_1 ),
        .I2(\VGA_R_reg[7]_i_477_n_7 ),
        .O(\VGA_R[7]_i_548_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_549 
       (.I0(\VGA_R_reg[7]_i_435_n_1 ),
        .I1(\VGA_R[7]_i_286_n_0 ),
        .I2(pattern_b1__0_n_90),
        .O(\VGA_R[7]_i_549_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_550 
       (.I0(\VGA_R_reg[7]_i_494_n_0 ),
        .I1(pattern_b1__0_n_92),
        .O(\VGA_R[7]_i_550_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \VGA_R[7]_i_551 
       (.I0(timing_sel[1]),
        .I1(timing_sel[0]),
        .O(\VGA_R[7]_i_551_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_553 
       (.I0(\VGA_R[7]_i_286_n_0 ),
        .I1(\VGA_R_reg[7]_i_552_n_6 ),
        .O(\VGA_R[7]_i_553_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \VGA_R[7]_i_554 
       (.I0(\VGA_R[7]_i_286_n_0 ),
        .I1(\VGA_R_reg[7]_i_552_n_7 ),
        .O(\VGA_R[7]_i_554_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \VGA_R[7]_i_555 
       (.I0(\VGA_R_reg[7]_i_584_n_4 ),
        .O(\VGA_R[7]_i_555_n_0 ));
  LUT1 #(
    .INIT(2'h2)) 
    \VGA_R[7]_i_561 
       (.I0(\VGA_R_reg[7]_i_592_n_6 ),
        .O(\VGA_R[7]_i_561_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_562 
       (.I0(\VGA_R[7]_i_192_n_0 ),
        .I1(\VGA_R_reg[7]_i_474_n_0 ),
        .I2(\VGA_R_reg[7]_i_513_n_5 ),
        .O(\VGA_R[7]_i_562_n_0 ));
  LUT4 #(
    .INIT(16'h659A)) 
    \VGA_R[7]_i_563 
       (.I0(\VGA_R_reg[7]_i_474_n_0 ),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .I3(\VGA_R_reg[7]_i_513_n_6 ),
        .O(\VGA_R[7]_i_563_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_564 
       (.I0(\VGA_R_reg[7]_i_474_n_0 ),
        .I1(\VGA_R_reg[7]_i_513_n_7 ),
        .O(\VGA_R[7]_i_564_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_565 
       (.I0(\VGA_R_reg[7]_i_474_n_0 ),
        .I1(\VGA_R[7]_i_366_n_0 ),
        .I2(\VGA_R_reg[7]_i_592_n_6 ),
        .O(\VGA_R[7]_i_565_n_0 ));
  LUT1 #(
    .INIT(2'h2)) 
    \VGA_R[7]_i_566 
       (.I0(pattern_b1_n_88),
        .O(\VGA_R[7]_i_566_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_567 
       (.I0(\VGA_R[7]_i_192_n_0 ),
        .I1(\VGA_R_reg[7]_i_528_n_0 ),
        .I2(\VGA_R_reg[7]_i_530_n_5 ),
        .O(\VGA_R[7]_i_567_n_0 ));
  LUT4 #(
    .INIT(16'h659A)) 
    \VGA_R[7]_i_568 
       (.I0(\VGA_R_reg[7]_i_528_n_0 ),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .I3(\VGA_R_reg[7]_i_530_n_6 ),
        .O(\VGA_R[7]_i_568_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_569 
       (.I0(\VGA_R_reg[7]_i_528_n_0 ),
        .I1(\VGA_R_reg[7]_i_530_n_7 ),
        .O(\VGA_R[7]_i_569_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_570 
       (.I0(\VGA_R_reg[7]_i_528_n_0 ),
        .I1(\VGA_R[7]_i_366_n_0 ),
        .I2(pattern_b1_n_88),
        .O(\VGA_R[7]_i_570_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_573 
       (.I0(pattern_b1_n_91),
        .I1(\VGA_R_reg[7]_i_572_n_0 ),
        .O(\VGA_R[7]_i_573_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_575 
       (.I0(\VGA_R_reg[7]_i_572_n_0 ),
        .I1(\VGA_R_reg[7]_i_572_n_5 ),
        .O(\VGA_R[7]_i_575_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_576 
       (.I0(\VGA_R_reg[7]_i_572_n_0 ),
        .I1(\VGA_R[7]_i_192_n_0 ),
        .I2(\VGA_R_reg[7]_i_572_n_6 ),
        .O(\VGA_R[7]_i_576_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_577 
       (.I0(\VGA_R[7]_i_192_n_0 ),
        .I1(\VGA_R_reg[7]_i_572_n_0 ),
        .I2(\VGA_R_reg[7]_i_572_n_7 ),
        .O(\VGA_R[7]_i_577_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_578 
       (.I0(\VGA_R_reg[7]_i_572_n_0 ),
        .I1(\VGA_R[7]_i_192_n_0 ),
        .I2(\VGA_R_reg[7]_i_574_n_4 ),
        .O(\VGA_R[7]_i_578_n_0 ));
  LUT1 #(
    .INIT(2'h2)) 
    \VGA_R[7]_i_579 
       (.I0(pattern_b1_n_87),
        .O(\VGA_R[7]_i_579_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_580 
       (.I0(\VGA_R[7]_i_192_n_0 ),
        .I1(\VGA_R_reg[7]_i_572_n_0 ),
        .I2(\VGA_R_reg[7]_i_574_n_5 ),
        .O(\VGA_R[7]_i_580_n_0 ));
  LUT4 #(
    .INIT(16'h659A)) 
    \VGA_R[7]_i_581 
       (.I0(\VGA_R_reg[7]_i_572_n_0 ),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .I3(\VGA_R_reg[7]_i_574_n_6 ),
        .O(\VGA_R[7]_i_581_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_582 
       (.I0(\VGA_R_reg[7]_i_572_n_0 ),
        .I1(\VGA_R_reg[7]_i_574_n_7 ),
        .O(\VGA_R[7]_i_582_n_0 ));
  LUT4 #(
    .INIT(16'h659A)) 
    \VGA_R[7]_i_583 
       (.I0(\VGA_R_reg[7]_i_572_n_0 ),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .I3(pattern_b1_n_87),
        .O(\VGA_R[7]_i_583_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \VGA_R[7]_i_585 
       (.I0(timing_sel[1]),
        .I1(timing_sel[0]),
        .O(\VGA_R[7]_i_585_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \VGA_R[7]_i_586 
       (.I0(\VGA_R_reg[7]_i_584_n_5 ),
        .O(\VGA_R[7]_i_586_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \VGA_R[7]_i_587 
       (.I0(\VGA_R[7]_i_286_n_0 ),
        .I1(\VGA_R_reg[7]_i_584_n_6 ),
        .O(\VGA_R[7]_i_587_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_588 
       (.I0(\VGA_R[7]_i_286_n_0 ),
        .I1(\VGA_R_reg[7]_i_584_n_7 ),
        .O(\VGA_R[7]_i_588_n_0 ));
  LUT2 #(
    .INIT(4'hB)) 
    \VGA_R[7]_i_589 
       (.I0(timing_sel[0]),
        .I1(timing_sel[1]),
        .O(\VGA_R[7]_i_589_n_0 ));
  LUT2 #(
    .INIT(4'hB)) 
    \VGA_R[7]_i_590 
       (.I0(timing_sel[0]),
        .I1(timing_sel[1]),
        .O(\VGA_R[7]_i_590_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \VGA_R[7]_i_591 
       (.I0(\VGA_R_reg[7]_i_605_n_1 ),
        .O(\VGA_R[7]_i_591_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_594 
       (.I0(pattern_b1_n_90),
        .I1(\VGA_R_reg[7]_i_593_n_0 ),
        .O(\VGA_R[7]_i_594_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_596 
       (.I0(\VGA_R_reg[7]_i_593_n_0 ),
        .I1(\VGA_R_reg[7]_i_593_n_5 ),
        .O(\VGA_R[7]_i_596_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_597 
       (.I0(\VGA_R_reg[7]_i_593_n_0 ),
        .I1(\VGA_R[7]_i_192_n_0 ),
        .I2(\VGA_R_reg[7]_i_593_n_6 ),
        .O(\VGA_R[7]_i_597_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_598 
       (.I0(\VGA_R[7]_i_192_n_0 ),
        .I1(\VGA_R_reg[7]_i_593_n_0 ),
        .I2(\VGA_R_reg[7]_i_593_n_7 ),
        .O(\VGA_R[7]_i_598_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_599 
       (.I0(\VGA_R_reg[7]_i_593_n_0 ),
        .I1(\VGA_R[7]_i_192_n_0 ),
        .I2(\VGA_R_reg[7]_i_595_n_4 ),
        .O(\VGA_R[7]_i_599_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000001)) 
    \VGA_R[7]_i_60 
       (.I0(pattern_b1_i_23_n_7),
        .I1(pattern_b1_i_18_n_4),
        .I2(pattern_b1_i_18_n_6),
        .I3(pattern_b1_i_18_n_5),
        .I4(pattern_b1_i_24_n_3),
        .I5(pattern_b1_i_23_n_6),
        .O(\VGA_R[7]_i_60_n_0 ));
  LUT3 #(
    .INIT(8'hD2)) 
    \VGA_R[7]_i_600 
       (.I0(timing_sel[0]),
        .I1(timing_sel[1]),
        .I2(\VGA_R_reg[7]_i_593_n_0 ),
        .O(\VGA_R[7]_i_600_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_601 
       (.I0(\VGA_R[7]_i_192_n_0 ),
        .I1(\VGA_R_reg[7]_i_593_n_0 ),
        .I2(\VGA_R_reg[7]_i_595_n_5 ),
        .O(\VGA_R[7]_i_601_n_0 ));
  LUT4 #(
    .INIT(16'h659A)) 
    \VGA_R[7]_i_602 
       (.I0(\VGA_R_reg[7]_i_593_n_0 ),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .I3(\VGA_R_reg[7]_i_595_n_6 ),
        .O(\VGA_R[7]_i_602_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_603 
       (.I0(\VGA_R_reg[7]_i_593_n_0 ),
        .I1(\VGA_R_reg[7]_i_595_n_7 ),
        .O(\VGA_R[7]_i_603_n_0 ));
  LUT3 #(
    .INIT(8'hD2)) 
    \VGA_R[7]_i_604 
       (.I0(timing_sel[0]),
        .I1(timing_sel[1]),
        .I2(\VGA_R_reg[7]_i_593_n_0 ),
        .O(\VGA_R[7]_i_604_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \VGA_R[7]_i_606 
       (.I0(timing_sel[1]),
        .I1(timing_sel[0]),
        .O(\VGA_R[7]_i_606_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \VGA_R[7]_i_607 
       (.I0(\VGA_R[7]_i_286_n_0 ),
        .I1(\VGA_R_reg[7]_i_605_n_6 ),
        .O(\VGA_R[7]_i_607_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \VGA_R[7]_i_608 
       (.I0(timing_sel[1]),
        .I1(timing_sel[0]),
        .O(\VGA_R[7]_i_608_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_610 
       (.I0(pattern_b1_n_89),
        .I1(\VGA_R_reg[7]_i_592_n_3 ),
        .O(\VGA_R[7]_i_610_n_0 ));
  LUT2 #(
    .INIT(4'hB)) 
    \VGA_R[7]_i_611 
       (.I0(timing_sel[0]),
        .I1(timing_sel[1]),
        .O(\VGA_R[7]_i_611_n_0 ));
  LUT3 #(
    .INIT(8'h2D)) 
    \VGA_R[7]_i_612 
       (.I0(timing_sel[0]),
        .I1(timing_sel[1]),
        .I2(\VGA_R[7]_i_192_n_0 ),
        .O(\VGA_R[7]_i_612_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_613 
       (.I0(\VGA_R_reg[7]_i_592_n_3 ),
        .I1(\VGA_R_reg[7]_i_609_n_4 ),
        .O(\VGA_R[7]_i_613_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_614 
       (.I0(\VGA_R_reg[7]_i_592_n_3 ),
        .I1(\VGA_R[7]_i_192_n_0 ),
        .I2(\VGA_R_reg[7]_i_609_n_5 ),
        .O(\VGA_R[7]_i_614_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_615 
       (.I0(\VGA_R[7]_i_192_n_0 ),
        .I1(\VGA_R_reg[7]_i_592_n_3 ),
        .I2(\VGA_R_reg[7]_i_609_n_6 ),
        .O(\VGA_R[7]_i_615_n_0 ));
  LUT3 #(
    .INIT(8'h65)) 
    \VGA_R[7]_i_616 
       (.I0(\VGA_R_reg[7]_i_592_n_3 ),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .O(\VGA_R[7]_i_616_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \VGA_R[7]_i_617 
       (.I0(\VGA_R_reg[7]_i_592_n_3 ),
        .I1(\VGA_R[7]_i_192_n_0 ),
        .O(\VGA_R[7]_i_617_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \VGA_R[7]_i_618 
       (.I0(timing_sel[0]),
        .I1(timing_sel[1]),
        .O(\VGA_R[7]_i_618_n_0 ));
  LUT3 #(
    .INIT(8'hD2)) 
    \VGA_R[7]_i_619 
       (.I0(timing_sel[0]),
        .I1(timing_sel[1]),
        .I2(\VGA_R_reg[7]_i_592_n_3 ),
        .O(\VGA_R[7]_i_619_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \VGA_R[7]_i_620 
       (.I0(\VGA_R_reg[7]_i_592_n_3 ),
        .I1(\VGA_R[7]_i_192_n_0 ),
        .O(\VGA_R[7]_i_620_n_0 ));
  LUT1 #(
    .INIT(2'h2)) 
    \VGA_R[7]_i_621 
       (.I0(\VGA_R_reg[7]_i_592_n_3 ),
        .O(\VGA_R[7]_i_621_n_0 ));
  LUT3 #(
    .INIT(8'hA6)) 
    \VGA_R[7]_i_622 
       (.I0(\VGA_R_reg[7]_i_592_n_3 ),
        .I1(timing_sel[0]),
        .I2(timing_sel[1]),
        .O(\VGA_R[7]_i_622_n_0 ));
  LUT3 #(
    .INIT(8'hD2)) 
    \VGA_R[7]_i_623 
       (.I0(timing_sel[0]),
        .I1(timing_sel[1]),
        .I2(\VGA_R_reg[7]_i_592_n_3 ),
        .O(\VGA_R[7]_i_623_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \VGA_R[7]_i_624 
       (.I0(timing_sel[1]),
        .I1(timing_sel[0]),
        .O(\VGA_R[7]_i_624_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \VGA_R[7]_i_625 
       (.I0(timing_sel[1]),
        .I1(timing_sel[0]),
        .O(\VGA_R[7]_i_625_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \VGA_R[7]_i_626 
       (.I0(timing_sel[1]),
        .I1(timing_sel[0]),
        .O(\VGA_R[7]_i_626_n_0 ));
  LUT2 #(
    .INIT(4'hB)) 
    \VGA_R[7]_i_627 
       (.I0(timing_sel[0]),
        .I1(timing_sel[1]),
        .O(\VGA_R[7]_i_627_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \VGA_R[7]_i_628 
       (.I0(timing_sel[1]),
        .I1(timing_sel[0]),
        .O(\VGA_R[7]_i_628_n_0 ));
  LUT2 #(
    .INIT(4'hB)) 
    \VGA_R[7]_i_629 
       (.I0(timing_sel[0]),
        .I1(timing_sel[1]),
        .O(\VGA_R[7]_i_629_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \VGA_R[7]_i_630 
       (.I0(timing_sel[1]),
        .I1(timing_sel[0]),
        .O(\VGA_R[7]_i_630_n_0 ));
  LUT3 #(
    .INIT(8'hEF)) 
    \VGA_R[7]_i_631 
       (.I0(\VGA_R[7]_i_192_n_0 ),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .O(\VGA_R[7]_i_631_n_0 ));
  LUT2 #(
    .INIT(4'hB)) 
    \VGA_R[7]_i_632 
       (.I0(timing_sel[0]),
        .I1(timing_sel[1]),
        .O(\VGA_R[7]_i_632_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_82 
       (.I0(\VGA_R_reg[7]_i_80_n_0 ),
        .I1(\VGA_R_reg[7]_i_80_n_5 ),
        .O(\VGA_R[7]_i_82_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_83 
       (.I0(\VGA_R_reg[7]_i_80_n_0 ),
        .I1(\VGA_R[7]_i_192_n_0 ),
        .I2(\VGA_R_reg[7]_i_80_n_6 ),
        .O(\VGA_R[7]_i_83_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_84 
       (.I0(\VGA_R[7]_i_192_n_0 ),
        .I1(\VGA_R_reg[7]_i_80_n_0 ),
        .I2(\VGA_R_reg[7]_i_80_n_7 ),
        .O(\VGA_R[7]_i_84_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_85 
       (.I0(\VGA_R_reg[7]_i_80_n_0 ),
        .I1(\VGA_R[7]_i_192_n_0 ),
        .I2(\VGA_R_reg[7]_i_81_n_4 ),
        .O(\VGA_R[7]_i_85_n_0 ));
  FDRE \VGA_R_reg[0] 
       (.C(PCK),
        .CE(1'b1),
        .D(pattern_r[0]),
        .Q(VGA_R[0]),
        .R(syncgen_multi_n_22));
  CARRY4 \VGA_R_reg[0]_i_11 
       (.CI(1'b0),
        .CO({\VGA_R_reg[0]_i_11_n_0 ,\VGA_R_reg[0]_i_11_n_1 ,\VGA_R_reg[0]_i_11_n_2 ,\VGA_R_reg[0]_i_11_n_3 }),
        .CYINIT(data2[1]),
        .DI({\VGA_R_reg[1]_i_11_n_5 ,\VGA_R_reg[1]_i_11_n_6 ,data2[1],\VGA_R[0]_i_21_n_0 }),
        .O(\NLW_VGA_R_reg[0]_i_11_O_UNCONNECTED [3:0]),
        .S({\VGA_R[0]_i_22_n_0 ,\VGA_R[0]_i_23_n_0 ,\VGA_R[0]_i_24_n_0 ,\VGA_R[0]_i_25_n_0 }));
  CARRY4 \VGA_R_reg[0]_i_26 
       (.CI(data2[3]),
        .CO(\NLW_VGA_R_reg[0]_i_26_CO_UNCONNECTED [3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_VGA_R_reg[0]_i_26_O_UNCONNECTED [3:1],\VGA_R_reg[0]_i_26_n_7 }),
        .S({1'b0,1'b0,1'b0,\VGA_R[0]_i_27_n_0 }));
  CARRY4 \VGA_R_reg[0]_i_28 
       (.CI(data2[4]),
        .CO(\NLW_VGA_R_reg[0]_i_28_CO_UNCONNECTED [3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_VGA_R_reg[0]_i_28_O_UNCONNECTED [3:1],\VGA_R_reg[0]_i_28_n_7 }),
        .S({1'b0,1'b0,1'b0,\VGA_R[0]_i_29_n_0 }));
  CARRY4 \VGA_R_reg[0]_i_30 
       (.CI(data2[5]),
        .CO(\NLW_VGA_R_reg[0]_i_30_CO_UNCONNECTED [3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_VGA_R_reg[0]_i_30_O_UNCONNECTED [3:1],\VGA_R_reg[0]_i_30_n_7 }),
        .S({1'b0,1'b0,1'b0,\VGA_R[0]_i_31_n_0 }));
  CARRY4 \VGA_R_reg[0]_i_5 
       (.CI(\VGA_R_reg[0]_i_7_n_0 ),
        .CO({\NLW_VGA_R_reg[0]_i_5_CO_UNCONNECTED [3],data6[0],\VGA_R_reg[0]_i_5_n_2 ,\VGA_R_reg[0]_i_5_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,data6[1],\VGA_R_reg[1]_i_5_n_7 ,\VGA_R_reg[1]_i_7_n_4 }),
        .O(\NLW_VGA_R_reg[0]_i_5_O_UNCONNECTED [3:0]),
        .S({1'b0,\VGA_R[0]_i_8_n_0 ,\VGA_R[0]_i_9_n_0 ,\VGA_R[0]_i_10_n_0 }));
  CARRY4 \VGA_R_reg[0]_i_6 
       (.CI(\VGA_R_reg[0]_i_11_n_0 ),
        .CO({data2[0],\VGA_R_reg[0]_i_6_n_1 ,\VGA_R_reg[0]_i_6_n_2 ,\VGA_R_reg[0]_i_6_n_3 }),
        .CYINIT(1'b0),
        .DI({data2[1],\VGA_R_reg[1]_i_6_n_6 ,\VGA_R_reg[1]_i_6_n_7 ,\VGA_R_reg[1]_i_11_n_4 }),
        .O(\NLW_VGA_R_reg[0]_i_6_O_UNCONNECTED [3:0]),
        .S({\VGA_R[0]_i_12_n_0 ,\VGA_R[0]_i_13_n_0 ,\VGA_R[0]_i_14_n_0 ,\VGA_R[0]_i_15_n_0 }));
  CARRY4 \VGA_R_reg[0]_i_7 
       (.CI(1'b0),
        .CO({\VGA_R_reg[0]_i_7_n_0 ,\VGA_R_reg[0]_i_7_n_1 ,\VGA_R_reg[0]_i_7_n_2 ,\VGA_R_reg[0]_i_7_n_3 }),
        .CYINIT(data6[1]),
        .DI({\VGA_R_reg[1]_i_7_n_5 ,\VGA_R_reg[1]_i_7_n_6 ,\VGA_R_reg[1]_i_7_n_7 ,\VGA_R[0]_i_16_n_0 }),
        .O(\NLW_VGA_R_reg[0]_i_7_O_UNCONNECTED [3:0]),
        .S({\VGA_R[0]_i_17_n_0 ,\VGA_R[0]_i_18_n_0 ,\VGA_R[0]_i_19_n_0 ,\VGA_R[0]_i_20_n_0 }));
  FDRE \VGA_R_reg[1] 
       (.C(PCK),
        .CE(1'b1),
        .D(pattern_r[1]),
        .Q(VGA_R[1]),
        .R(syncgen_multi_n_22));
  CARRY4 \VGA_R_reg[1]_i_11 
       (.CI(1'b0),
        .CO({\VGA_R_reg[1]_i_11_n_0 ,\VGA_R_reg[1]_i_11_n_1 ,\VGA_R_reg[1]_i_11_n_2 ,\VGA_R_reg[1]_i_11_n_3 }),
        .CYINIT(data2[2]),
        .DI({\VGA_R_reg[2]_i_11_n_5 ,\VGA_R_reg[2]_i_11_n_6 ,data2[2],\VGA_R[1]_i_21_n_0 }),
        .O({\VGA_R_reg[1]_i_11_n_4 ,\VGA_R_reg[1]_i_11_n_5 ,\VGA_R_reg[1]_i_11_n_6 ,\VGA_R_reg[1]_i_11_n_7 }),
        .S({\VGA_R[1]_i_22_n_0 ,\VGA_R[1]_i_23_n_0 ,\VGA_R[1]_i_24_n_0 ,\VGA_R[1]_i_25_n_0 }));
  CARRY4 \VGA_R_reg[1]_i_26 
       (.CI(data2[6]),
        .CO(\NLW_VGA_R_reg[1]_i_26_CO_UNCONNECTED [3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_VGA_R_reg[1]_i_26_O_UNCONNECTED [3:1],\VGA_R_reg[1]_i_26_n_7 }),
        .S({1'b0,1'b0,1'b0,\VGA_R[1]_i_27_n_0 }));
  CARRY4 \VGA_R_reg[1]_i_5 
       (.CI(\VGA_R_reg[1]_i_7_n_0 ),
        .CO({\NLW_VGA_R_reg[1]_i_5_CO_UNCONNECTED [3],data6[1],\VGA_R_reg[1]_i_5_n_2 ,\VGA_R_reg[1]_i_5_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,data6[2],\VGA_R_reg[2]_i_5_n_7 ,\VGA_R_reg[2]_i_7_n_4 }),
        .O({\NLW_VGA_R_reg[1]_i_5_O_UNCONNECTED [3:2],\VGA_R_reg[1]_i_5_n_6 ,\VGA_R_reg[1]_i_5_n_7 }),
        .S({1'b0,\VGA_R[1]_i_8_n_0 ,\VGA_R[1]_i_9_n_0 ,\VGA_R[1]_i_10_n_0 }));
  CARRY4 \VGA_R_reg[1]_i_6 
       (.CI(\VGA_R_reg[1]_i_11_n_0 ),
        .CO({data2[1],\VGA_R_reg[1]_i_6_n_1 ,\VGA_R_reg[1]_i_6_n_2 ,\VGA_R_reg[1]_i_6_n_3 }),
        .CYINIT(1'b0),
        .DI({data2[2],\VGA_R_reg[2]_i_6_n_6 ,\VGA_R_reg[2]_i_6_n_7 ,\VGA_R_reg[2]_i_11_n_4 }),
        .O({\NLW_VGA_R_reg[1]_i_6_O_UNCONNECTED [3],\VGA_R_reg[1]_i_6_n_5 ,\VGA_R_reg[1]_i_6_n_6 ,\VGA_R_reg[1]_i_6_n_7 }),
        .S({\VGA_R[1]_i_12_n_0 ,\VGA_R[1]_i_13_n_0 ,\VGA_R[1]_i_14_n_0 ,\VGA_R[1]_i_15_n_0 }));
  CARRY4 \VGA_R_reg[1]_i_7 
       (.CI(1'b0),
        .CO({\VGA_R_reg[1]_i_7_n_0 ,\VGA_R_reg[1]_i_7_n_1 ,\VGA_R_reg[1]_i_7_n_2 ,\VGA_R_reg[1]_i_7_n_3 }),
        .CYINIT(data6[2]),
        .DI({\VGA_R_reg[2]_i_7_n_5 ,\VGA_R_reg[2]_i_7_n_6 ,\VGA_R_reg[2]_i_7_n_7 ,\VGA_R[1]_i_16_n_0 }),
        .O({\VGA_R_reg[1]_i_7_n_4 ,\VGA_R_reg[1]_i_7_n_5 ,\VGA_R_reg[1]_i_7_n_6 ,\VGA_R_reg[1]_i_7_n_7 }),
        .S({\VGA_R[1]_i_17_n_0 ,\VGA_R[1]_i_18_n_0 ,\VGA_R[1]_i_19_n_0 ,\VGA_R[1]_i_20_n_0 }));
  FDRE \VGA_R_reg[2] 
       (.C(PCK),
        .CE(1'b1),
        .D(pattern_r[2]),
        .Q(VGA_R[2]),
        .R(syncgen_multi_n_22));
  CARRY4 \VGA_R_reg[2]_i_11 
       (.CI(1'b0),
        .CO({\VGA_R_reg[2]_i_11_n_0 ,\VGA_R_reg[2]_i_11_n_1 ,\VGA_R_reg[2]_i_11_n_2 ,\VGA_R_reg[2]_i_11_n_3 }),
        .CYINIT(data2[3]),
        .DI({\VGA_R_reg[3]_i_13_n_5 ,\VGA_R_reg[3]_i_13_n_6 ,data2[3],\VGA_R[2]_i_21_n_0 }),
        .O({\VGA_R_reg[2]_i_11_n_4 ,\VGA_R_reg[2]_i_11_n_5 ,\VGA_R_reg[2]_i_11_n_6 ,\VGA_R_reg[2]_i_11_n_7 }),
        .S({\VGA_R[2]_i_22_n_0 ,\VGA_R[2]_i_23_n_0 ,\VGA_R[2]_i_24_n_0 ,\VGA_R[2]_i_25_n_0 }));
  CARRY4 \VGA_R_reg[2]_i_26 
       (.CI(data2[7]),
        .CO(\NLW_VGA_R_reg[2]_i_26_CO_UNCONNECTED [3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_VGA_R_reg[2]_i_26_O_UNCONNECTED [3:1],\VGA_R_reg[2]_i_26_n_7 }),
        .S({1'b0,1'b0,1'b0,\VGA_R[2]_i_27_n_0 }));
  CARRY4 \VGA_R_reg[2]_i_5 
       (.CI(\VGA_R_reg[2]_i_7_n_0 ),
        .CO({\NLW_VGA_R_reg[2]_i_5_CO_UNCONNECTED [3],data6[2],\VGA_R_reg[2]_i_5_n_2 ,\VGA_R_reg[2]_i_5_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,data6[3],\VGA_R_reg[3]_i_6_n_7 ,\VGA_R_reg[3]_i_8_n_4 }),
        .O({\NLW_VGA_R_reg[2]_i_5_O_UNCONNECTED [3:2],\VGA_R_reg[2]_i_5_n_6 ,\VGA_R_reg[2]_i_5_n_7 }),
        .S({1'b0,\VGA_R[2]_i_8_n_0 ,\VGA_R[2]_i_9_n_0 ,\VGA_R[2]_i_10_n_0 }));
  CARRY4 \VGA_R_reg[2]_i_6 
       (.CI(\VGA_R_reg[2]_i_11_n_0 ),
        .CO({data2[2],\VGA_R_reg[2]_i_6_n_1 ,\VGA_R_reg[2]_i_6_n_2 ,\VGA_R_reg[2]_i_6_n_3 }),
        .CYINIT(1'b0),
        .DI({data2[3],\VGA_R_reg[3]_i_7_n_6 ,\VGA_R_reg[3]_i_7_n_7 ,\VGA_R_reg[3]_i_13_n_4 }),
        .O({\NLW_VGA_R_reg[2]_i_6_O_UNCONNECTED [3],\VGA_R_reg[2]_i_6_n_5 ,\VGA_R_reg[2]_i_6_n_6 ,\VGA_R_reg[2]_i_6_n_7 }),
        .S({\VGA_R[2]_i_12_n_0 ,\VGA_R[2]_i_13_n_0 ,\VGA_R[2]_i_14_n_0 ,\VGA_R[2]_i_15_n_0 }));
  CARRY4 \VGA_R_reg[2]_i_7 
       (.CI(1'b0),
        .CO({\VGA_R_reg[2]_i_7_n_0 ,\VGA_R_reg[2]_i_7_n_1 ,\VGA_R_reg[2]_i_7_n_2 ,\VGA_R_reg[2]_i_7_n_3 }),
        .CYINIT(data6[3]),
        .DI({\VGA_R_reg[3]_i_8_n_5 ,\VGA_R_reg[3]_i_8_n_6 ,\VGA_R_reg[3]_i_8_n_7 ,\VGA_R[2]_i_16_n_0 }),
        .O({\VGA_R_reg[2]_i_7_n_4 ,\VGA_R_reg[2]_i_7_n_5 ,\VGA_R_reg[2]_i_7_n_6 ,\VGA_R_reg[2]_i_7_n_7 }),
        .S({\VGA_R[2]_i_17_n_0 ,\VGA_R[2]_i_18_n_0 ,\VGA_R[2]_i_19_n_0 ,\VGA_R[2]_i_20_n_0 }));
  FDRE \VGA_R_reg[3] 
       (.C(PCK),
        .CE(1'b1),
        .D(pattern_r[3]),
        .Q(VGA_R[3]),
        .R(syncgen_multi_n_22));
  CARRY4 \VGA_R_reg[3]_i_13 
       (.CI(1'b0),
        .CO({\VGA_R_reg[3]_i_13_n_0 ,\VGA_R_reg[3]_i_13_n_1 ,\VGA_R_reg[3]_i_13_n_2 ,\VGA_R_reg[3]_i_13_n_3 }),
        .CYINIT(data2[4]),
        .DI({\VGA_R_reg[4]_i_17_n_5 ,\VGA_R_reg[4]_i_17_n_6 ,data2[4],\VGA_R[3]_i_23_n_0 }),
        .O({\VGA_R_reg[3]_i_13_n_4 ,\VGA_R_reg[3]_i_13_n_5 ,\VGA_R_reg[3]_i_13_n_6 ,\VGA_R_reg[3]_i_13_n_7 }),
        .S({\VGA_R[3]_i_24_n_0 ,\VGA_R[3]_i_25_n_0 ,\VGA_R[3]_i_26_n_0 ,\VGA_R[3]_i_27_n_0 }));
  CARRY4 \VGA_R_reg[3]_i_28 
       (.CI(\VGA_R_reg[7]_i_80_n_0 ),
        .CO(\NLW_VGA_R_reg[3]_i_28_CO_UNCONNECTED [3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_VGA_R_reg[3]_i_28_O_UNCONNECTED [3:1],\VGA_R_reg[3]_i_28_n_7 }),
        .S({1'b0,1'b0,1'b0,\VGA_R[3]_i_29_n_0 }));
  CARRY4 \VGA_R_reg[3]_i_6 
       (.CI(\VGA_R_reg[3]_i_8_n_0 ),
        .CO({\NLW_VGA_R_reg[3]_i_6_CO_UNCONNECTED [3],data6[3],\VGA_R_reg[3]_i_6_n_2 ,\VGA_R_reg[3]_i_6_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,data6[4],\VGA_R_reg[4]_i_6_n_7 ,\VGA_R_reg[4]_i_12_n_4 }),
        .O({\VGA_R_reg[3]_i_6_n_4 ,\NLW_VGA_R_reg[3]_i_6_O_UNCONNECTED [2],\VGA_R_reg[3]_i_6_n_6 ,\VGA_R_reg[3]_i_6_n_7 }),
        .S({\VGA_R[3]_i_9_n_0 ,\VGA_R[3]_i_10_n_0 ,\VGA_R[3]_i_11_n_0 ,\VGA_R[3]_i_12_n_0 }));
  CARRY4 \VGA_R_reg[3]_i_7 
       (.CI(\VGA_R_reg[3]_i_13_n_0 ),
        .CO({data2[3],\VGA_R_reg[3]_i_7_n_1 ,\VGA_R_reg[3]_i_7_n_2 ,\VGA_R_reg[3]_i_7_n_3 }),
        .CYINIT(1'b0),
        .DI({data2[4],\VGA_R_reg[4]_i_7_n_6 ,\VGA_R_reg[4]_i_7_n_7 ,\VGA_R_reg[4]_i_17_n_4 }),
        .O({\NLW_VGA_R_reg[3]_i_7_O_UNCONNECTED [3],\VGA_R_reg[3]_i_7_n_5 ,\VGA_R_reg[3]_i_7_n_6 ,\VGA_R_reg[3]_i_7_n_7 }),
        .S({\VGA_R[3]_i_14_n_0 ,\VGA_R[3]_i_15_n_0 ,\VGA_R[3]_i_16_n_0 ,\VGA_R[3]_i_17_n_0 }));
  CARRY4 \VGA_R_reg[3]_i_8 
       (.CI(1'b0),
        .CO({\VGA_R_reg[3]_i_8_n_0 ,\VGA_R_reg[3]_i_8_n_1 ,\VGA_R_reg[3]_i_8_n_2 ,\VGA_R_reg[3]_i_8_n_3 }),
        .CYINIT(data6[4]),
        .DI({\VGA_R_reg[4]_i_12_n_5 ,\VGA_R_reg[4]_i_12_n_6 ,\VGA_R_reg[4]_i_12_n_7 ,\VGA_R[3]_i_18_n_0 }),
        .O({\VGA_R_reg[3]_i_8_n_4 ,\VGA_R_reg[3]_i_8_n_5 ,\VGA_R_reg[3]_i_8_n_6 ,\VGA_R_reg[3]_i_8_n_7 }),
        .S({\VGA_R[3]_i_19_n_0 ,\VGA_R[3]_i_20_n_0 ,\VGA_R[3]_i_21_n_0 ,\VGA_R[3]_i_22_n_0 }));
  FDRE \VGA_R_reg[4] 
       (.C(PCK),
        .CE(1'b1),
        .D(pattern_r[4]),
        .Q(VGA_R[4]),
        .R(syncgen_multi_n_22));
  CARRY4 \VGA_R_reg[4]_i_12 
       (.CI(1'b0),
        .CO({\VGA_R_reg[4]_i_12_n_0 ,\VGA_R_reg[4]_i_12_n_1 ,\VGA_R_reg[4]_i_12_n_2 ,\VGA_R_reg[4]_i_12_n_3 }),
        .CYINIT(data6[5]),
        .DI({\VGA_R_reg[5]_i_21_n_5 ,\VGA_R_reg[5]_i_21_n_6 ,\VGA_R_reg[5]_i_21_n_7 ,\VGA_R[4]_i_30_n_0 }),
        .O({\VGA_R_reg[4]_i_12_n_4 ,\VGA_R_reg[4]_i_12_n_5 ,\VGA_R_reg[4]_i_12_n_6 ,\VGA_R_reg[4]_i_12_n_7 }),
        .S({\VGA_R[4]_i_31_n_0 ,\VGA_R[4]_i_32_n_0 ,\VGA_R[4]_i_33_n_0 ,\VGA_R[4]_i_34_n_0 }));
  CARRY4 \VGA_R_reg[4]_i_17 
       (.CI(1'b0),
        .CO({\VGA_R_reg[4]_i_17_n_0 ,\VGA_R_reg[4]_i_17_n_1 ,\VGA_R_reg[4]_i_17_n_2 ,\VGA_R_reg[4]_i_17_n_3 }),
        .CYINIT(data2[5]),
        .DI({\VGA_R_reg[5]_i_26_n_5 ,\VGA_R_reg[5]_i_26_n_6 ,data2[5],\VGA_R[4]_i_35_n_0 }),
        .O({\VGA_R_reg[4]_i_17_n_4 ,\VGA_R_reg[4]_i_17_n_5 ,\VGA_R_reg[4]_i_17_n_6 ,\VGA_R_reg[4]_i_17_n_7 }),
        .S({\VGA_R[4]_i_36_n_0 ,\VGA_R[4]_i_37_n_0 ,\VGA_R[4]_i_38_n_0 ,\VGA_R[4]_i_39_n_0 }));
  CARRY4 \VGA_R_reg[4]_i_40 
       (.CI(\VGA_R_reg[7]_i_181_n_0 ),
        .CO(\NLW_VGA_R_reg[4]_i_40_CO_UNCONNECTED [3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_VGA_R_reg[4]_i_40_O_UNCONNECTED [3:1],\VGA_R_reg[4]_i_40_n_7 }),
        .S({1'b0,1'b0,1'b0,\VGA_R[4]_i_41_n_0 }));
  CARRY4 \VGA_R_reg[4]_i_6 
       (.CI(\VGA_R_reg[4]_i_12_n_0 ),
        .CO({\NLW_VGA_R_reg[4]_i_6_CO_UNCONNECTED [3],data6[4],\VGA_R_reg[4]_i_6_n_2 ,\VGA_R_reg[4]_i_6_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,data6[5],\VGA_R_reg[5]_i_9_n_7 ,\VGA_R_reg[5]_i_21_n_4 }),
        .O({\VGA_R_reg[4]_i_6_n_4 ,\NLW_VGA_R_reg[4]_i_6_O_UNCONNECTED [2],\VGA_R_reg[4]_i_6_n_6 ,\VGA_R_reg[4]_i_6_n_7 }),
        .S({\VGA_R[4]_i_13_n_0 ,\VGA_R[4]_i_14_n_0 ,\VGA_R[4]_i_15_n_0 ,\VGA_R[4]_i_16_n_0 }));
  CARRY4 \VGA_R_reg[4]_i_7 
       (.CI(\VGA_R_reg[4]_i_17_n_0 ),
        .CO({data2[4],\VGA_R_reg[4]_i_7_n_1 ,\VGA_R_reg[4]_i_7_n_2 ,\VGA_R_reg[4]_i_7_n_3 }),
        .CYINIT(1'b0),
        .DI({data2[5],\VGA_R_reg[5]_i_10_n_6 ,\VGA_R_reg[5]_i_10_n_7 ,\VGA_R_reg[5]_i_26_n_4 }),
        .O({\NLW_VGA_R_reg[4]_i_7_O_UNCONNECTED [3],\VGA_R_reg[4]_i_7_n_5 ,\VGA_R_reg[4]_i_7_n_6 ,\VGA_R_reg[4]_i_7_n_7 }),
        .S({\VGA_R[4]_i_18_n_0 ,\VGA_R[4]_i_19_n_0 ,\VGA_R[4]_i_20_n_0 ,\VGA_R[4]_i_21_n_0 }));
  FDRE \VGA_R_reg[5] 
       (.C(PCK),
        .CE(1'b1),
        .D(pattern_r[5]),
        .Q(VGA_R[5]),
        .R(syncgen_multi_n_22));
  CARRY4 \VGA_R_reg[5]_i_10 
       (.CI(\VGA_R_reg[5]_i_26_n_0 ),
        .CO({data2[5],\VGA_R_reg[5]_i_10_n_1 ,\VGA_R_reg[5]_i_10_n_2 ,\VGA_R_reg[5]_i_10_n_3 }),
        .CYINIT(1'b0),
        .DI({data2[6],\VGA_R_reg[6]_i_5_n_6 ,\VGA_R_reg[6]_i_5_n_7 ,\VGA_R_reg[6]_i_7_n_4 }),
        .O({\NLW_VGA_R_reg[5]_i_10_O_UNCONNECTED [3],\VGA_R_reg[5]_i_10_n_5 ,\VGA_R_reg[5]_i_10_n_6 ,\VGA_R_reg[5]_i_10_n_7 }),
        .S({\VGA_R[5]_i_27_n_0 ,\VGA_R[5]_i_28_n_0 ,\VGA_R[5]_i_29_n_0 ,\VGA_R[5]_i_30_n_0 }));
  CARRY4 \VGA_R_reg[5]_i_100 
       (.CI(\VGA_R_reg[7]_i_367_n_0 ),
        .CO(\NLW_VGA_R_reg[5]_i_100_CO_UNCONNECTED [3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_VGA_R_reg[5]_i_100_O_UNCONNECTED [3:1],\VGA_R_reg[5]_i_100_n_7 }),
        .S({1'b0,1'b0,1'b0,\VGA_R[5]_i_119_n_0 }));
  CARRY4 \VGA_R_reg[5]_i_108 
       (.CI(1'b0),
        .CO({\NLW_VGA_R_reg[5]_i_108_CO_UNCONNECTED [3],\VGA_R_reg[5]_i_108_n_1 ,\NLW_VGA_R_reg[5]_i_108_CO_UNCONNECTED [1],\VGA_R_reg[5]_i_108_n_3 }),
        .CYINIT(HWIDTH),
        .DI({1'b0,1'b0,\VGA_R[5]_i_120_n_0 ,1'b0}),
        .O({\NLW_VGA_R_reg[5]_i_108_O_UNCONNECTED [3:2],\VGA_R_reg[5]_i_108_n_6 ,\VGA_R_reg[5]_i_108_n_7 }),
        .S({1'b0,1'b1,\VGA_R[5]_i_121_n_0 ,\VGA_R[5]_i_122_n_0 }));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \VGA_R_reg[5]_i_110 
       (.CI(\VGA_R_reg[5]_i_123_n_0 ),
        .CO({\VGA_R_reg[5]_i_110_n_0 ,\VGA_R_reg[5]_i_110_n_1 ,\VGA_R_reg[5]_i_110_n_2 ,\VGA_R_reg[5]_i_110_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\VGA_R_reg[5]_i_114_n_4 ,\VGA_R[5]_i_124_n_0 ,\VGA_R[5]_i_125_n_0 }),
        .O(\NLW_VGA_R_reg[5]_i_110_O_UNCONNECTED [3:0]),
        .S({\VGA_R_reg[5]_i_99_n_7 ,\VGA_R[5]_i_126_n_0 ,\VGA_R[5]_i_127_n_0 ,\VGA_R[5]_i_128_n_0 }));
  CARRY4 \VGA_R_reg[5]_i_114 
       (.CI(1'b0),
        .CO({\VGA_R_reg[5]_i_114_n_0 ,\VGA_R_reg[5]_i_114_n_1 ,\VGA_R_reg[5]_i_114_n_2 ,\VGA_R_reg[5]_i_114_n_3 }),
        .CYINIT(\VGA_R[5]_i_129_n_0 ),
        .DI({\VGA_R[5]_i_130_n_0 ,\VGA_R[5]_i_131_n_0 ,\VGA_R[5]_i_132_n_0 ,1'b0}),
        .O({\VGA_R_reg[5]_i_114_n_4 ,\VGA_R_reg[5]_i_114_n_5 ,\VGA_R_reg[5]_i_114_n_6 ,\NLW_VGA_R_reg[5]_i_114_O_UNCONNECTED [0]}),
        .S({\VGA_R[5]_i_133_n_0 ,\VGA_R[5]_i_134_n_0 ,\VGA_R[5]_i_135_n_0 ,1'b1}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \VGA_R_reg[5]_i_123 
       (.CI(1'b0),
        .CO({\VGA_R_reg[5]_i_123_n_0 ,\VGA_R_reg[5]_i_123_n_1 ,\VGA_R_reg[5]_i_123_n_2 ,\VGA_R_reg[5]_i_123_n_3 }),
        .CYINIT(1'b0),
        .DI({\VGA_R[5]_i_136_n_0 ,\VGA_R[5]_i_137_n_0 ,1'b1,1'b1}),
        .O(\NLW_VGA_R_reg[5]_i_123_O_UNCONNECTED [3:0]),
        .S({\VGA_R[5]_i_138_n_0 ,\VGA_R[5]_i_139_n_0 ,\VGA_R[5]_i_140_n_0 ,\VGA_R_reg[5]_i_97_n_6 }));
  CARRY4 \VGA_R_reg[5]_i_21 
       (.CI(1'b0),
        .CO({\VGA_R_reg[5]_i_21_n_0 ,\VGA_R_reg[5]_i_21_n_1 ,\VGA_R_reg[5]_i_21_n_2 ,\VGA_R_reg[5]_i_21_n_3 }),
        .CYINIT(data6[6]),
        .DI({\VGA_R_reg[6]_i_12_n_5 ,\VGA_R_reg[6]_i_12_n_6 ,\VGA_R_reg[6]_i_12_n_7 ,\VGA_R[5]_i_60_n_0 }),
        .O({\VGA_R_reg[5]_i_21_n_4 ,\VGA_R_reg[5]_i_21_n_5 ,\VGA_R_reg[5]_i_21_n_6 ,\VGA_R_reg[5]_i_21_n_7 }),
        .S({\VGA_R[5]_i_61_n_0 ,\VGA_R[5]_i_62_n_0 ,\VGA_R[5]_i_63_n_0 ,\VGA_R[5]_i_64_n_0 }));
  CARRY4 \VGA_R_reg[5]_i_26 
       (.CI(1'b0),
        .CO({\VGA_R_reg[5]_i_26_n_0 ,\VGA_R_reg[5]_i_26_n_1 ,\VGA_R_reg[5]_i_26_n_2 ,\VGA_R_reg[5]_i_26_n_3 }),
        .CYINIT(data2[6]),
        .DI({\VGA_R_reg[6]_i_7_n_5 ,\VGA_R_reg[6]_i_7_n_6 ,data2[6],\VGA_R[5]_i_65_n_0 }),
        .O({\VGA_R_reg[5]_i_26_n_4 ,\VGA_R_reg[5]_i_26_n_5 ,\VGA_R_reg[5]_i_26_n_6 ,\VGA_R_reg[5]_i_26_n_7 }),
        .S({\VGA_R[5]_i_66_n_0 ,\VGA_R[5]_i_67_n_0 ,\VGA_R[5]_i_68_n_0 ,\VGA_R[5]_i_69_n_0 }));
  CARRY4 \VGA_R_reg[5]_i_78 
       (.CI(1'b0),
        .CO({\NLW_VGA_R_reg[5]_i_78_CO_UNCONNECTED [3:1],\VGA_R_reg[5]_i_78_n_3 }),
        .CYINIT(\VGA_R_reg[5]_i_79_n_0 ),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_VGA_R_reg[5]_i_78_O_UNCONNECTED [3:2],\VGA_R_reg[5]_i_78_n_6 ,\NLW_VGA_R_reg[5]_i_78_O_UNCONNECTED [0]}),
        .S({1'b0,1'b0,\VGA_R[5]_i_103_n_0 ,1'b1}));
  CARRY4 \VGA_R_reg[5]_i_79 
       (.CI(1'b0),
        .CO({\VGA_R_reg[5]_i_79_n_0 ,\NLW_VGA_R_reg[5]_i_79_CO_UNCONNECTED [2],\VGA_R_reg[5]_i_79_n_2 ,\VGA_R_reg[5]_i_79_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\VGA_R[5]_i_104_n_0 ,1'b0,1'b1}),
        .O({\NLW_VGA_R_reg[5]_i_79_O_UNCONNECTED [3],\VGA_R_reg[5]_i_79_n_5 ,\VGA_R_reg[5]_i_79_n_6 ,\VGA_R_reg[5]_i_79_n_7 }),
        .S({1'b1,\VGA_R[5]_i_105_n_0 ,\VGA_R[5]_i_106_n_0 ,\VGA_R[5]_i_107_n_0 }));
  CARRY4 \VGA_R_reg[5]_i_9 
       (.CI(\VGA_R_reg[5]_i_21_n_0 ),
        .CO({\NLW_VGA_R_reg[5]_i_9_CO_UNCONNECTED [3],data6[5],\VGA_R_reg[5]_i_9_n_2 ,\VGA_R_reg[5]_i_9_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,data6[6],\VGA_R_reg[6]_i_6_n_7 ,\VGA_R_reg[6]_i_12_n_4 }),
        .O({\VGA_R_reg[5]_i_9_n_4 ,\NLW_VGA_R_reg[5]_i_9_O_UNCONNECTED [2],\VGA_R_reg[5]_i_9_n_6 ,\VGA_R_reg[5]_i_9_n_7 }),
        .S({\VGA_R[5]_i_22_n_0 ,\VGA_R[5]_i_23_n_0 ,\VGA_R[5]_i_24_n_0 ,\VGA_R[5]_i_25_n_0 }));
  CARRY4 \VGA_R_reg[5]_i_97 
       (.CI(1'b0),
        .CO({\NLW_VGA_R_reg[5]_i_97_CO_UNCONNECTED [3],\VGA_R_reg[5]_i_97_n_1 ,\NLW_VGA_R_reg[5]_i_97_CO_UNCONNECTED [1],\VGA_R_reg[5]_i_97_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\VGA_R[5]_i_109_n_0 ,1'b0}),
        .O({\NLW_VGA_R_reg[5]_i_97_O_UNCONNECTED [3:2],\VGA_R_reg[5]_i_97_n_6 ,\NLW_VGA_R_reg[5]_i_97_O_UNCONNECTED [0]}),
        .S({1'b0,1'b1,1'b1,1'b1}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \VGA_R_reg[5]_i_98 
       (.CI(\VGA_R_reg[5]_i_110_n_0 ),
        .CO({\NLW_VGA_R_reg[5]_i_98_CO_UNCONNECTED [3:2],\VGA_R_reg[5]_i_98_n_2 ,\VGA_R_reg[5]_i_98_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\VGA_R[5]_i_111_n_0 ,1'b0}),
        .O(\NLW_VGA_R_reg[5]_i_98_O_UNCONNECTED [3:0]),
        .S({1'b0,1'b0,\VGA_R[5]_i_112_n_0 ,\VGA_R[5]_i_113_n_0 }));
  CARRY4 \VGA_R_reg[5]_i_99 
       (.CI(\VGA_R_reg[5]_i_114_n_0 ),
        .CO({\NLW_VGA_R_reg[5]_i_99_CO_UNCONNECTED [3],\VGA_R_reg[5]_i_99_n_1 ,\NLW_VGA_R_reg[5]_i_99_CO_UNCONNECTED [1],\VGA_R_reg[5]_i_99_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\VGA_R[5]_i_115_n_0 ,\VGA_R[5]_i_116_n_0 }),
        .O({\NLW_VGA_R_reg[5]_i_99_O_UNCONNECTED [3:2],\VGA_R_reg[5]_i_99_n_6 ,\VGA_R_reg[5]_i_99_n_7 }),
        .S({1'b0,1'b1,HPERIOD,\VGA_R[5]_i_118_n_0 }));
  FDRE \VGA_R_reg[6] 
       (.C(PCK),
        .CE(1'b1),
        .D(pattern_r[6]),
        .Q(VGA_R[6]),
        .R(syncgen_multi_n_22));
  CARRY4 \VGA_R_reg[6]_i_12 
       (.CI(1'b0),
        .CO({\VGA_R_reg[6]_i_12_n_0 ,\VGA_R_reg[6]_i_12_n_1 ,\VGA_R_reg[6]_i_12_n_2 ,\VGA_R_reg[6]_i_12_n_3 }),
        .CYINIT(data6[7]),
        .DI({\VGA_R_reg[7]_i_109_n_5 ,\VGA_R_reg[7]_i_109_n_6 ,\VGA_R_reg[7]_i_109_n_7 ,\VGA_R[6]_i_22_n_0 }),
        .O({\VGA_R_reg[6]_i_12_n_4 ,\VGA_R_reg[6]_i_12_n_5 ,\VGA_R_reg[6]_i_12_n_6 ,\VGA_R_reg[6]_i_12_n_7 }),
        .S({\VGA_R[6]_i_23_n_0 ,\VGA_R[6]_i_24_n_0 ,\VGA_R[6]_i_25_n_0 ,\VGA_R[6]_i_26_n_0 }));
  CARRY4 \VGA_R_reg[6]_i_27 
       (.CI(\VGA_R_reg[7]_i_462_n_0 ),
        .CO(\NLW_VGA_R_reg[6]_i_27_CO_UNCONNECTED [3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_VGA_R_reg[6]_i_27_O_UNCONNECTED [3:1],\VGA_R_reg[6]_i_27_n_7 }),
        .S({1'b0,1'b0,1'b0,\VGA_R[6]_i_29_n_0 }));
  CARRY4 \VGA_R_reg[6]_i_28 
       (.CI(\VGA_R_reg[7]_i_483_n_0 ),
        .CO({\NLW_VGA_R_reg[6]_i_28_CO_UNCONNECTED [3],\VGA_R_reg[6]_i_28_n_1 ,\VGA_R_reg[6]_i_28_n_2 ,\VGA_R_reg[6]_i_28_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\VGA_R_reg[7]_i_435_n_1 ,\VGA_R_reg[7]_i_435_n_7 ,\VGA_R_reg[7]_i_477_n_4 }),
        .O({\VGA_R_reg[6]_i_28_n_4 ,\NLW_VGA_R_reg[6]_i_28_O_UNCONNECTED [2],\VGA_R_reg[6]_i_28_n_6 ,\VGA_R_reg[6]_i_28_n_7 }),
        .S({\VGA_R[6]_i_30_n_0 ,\VGA_R[6]_i_31_n_0 ,\VGA_R[6]_i_32_n_0 ,\VGA_R[6]_i_33_n_0 }));
  CARRY4 \VGA_R_reg[6]_i_5 
       (.CI(\VGA_R_reg[6]_i_7_n_0 ),
        .CO({data2[6],\VGA_R_reg[6]_i_5_n_1 ,\VGA_R_reg[6]_i_5_n_2 ,\VGA_R_reg[6]_i_5_n_3 }),
        .CYINIT(1'b0),
        .DI({data2[7],\VGA_R_reg[7]_i_30_n_6 ,\VGA_R_reg[7]_i_30_n_7 ,\VGA_R_reg[7]_i_79_n_4 }),
        .O({\NLW_VGA_R_reg[6]_i_5_O_UNCONNECTED [3],\VGA_R_reg[6]_i_5_n_5 ,\VGA_R_reg[6]_i_5_n_6 ,\VGA_R_reg[6]_i_5_n_7 }),
        .S({\VGA_R[6]_i_8_n_0 ,\VGA_R[6]_i_9_n_0 ,\VGA_R[6]_i_10_n_0 ,\VGA_R[6]_i_11_n_0 }));
  CARRY4 \VGA_R_reg[6]_i_6 
       (.CI(\VGA_R_reg[6]_i_12_n_0 ),
        .CO({\NLW_VGA_R_reg[6]_i_6_CO_UNCONNECTED [3],data6[6],\VGA_R_reg[6]_i_6_n_2 ,\VGA_R_reg[6]_i_6_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,data6[7],\VGA_R_reg[7]_i_40_n_7 ,\VGA_R_reg[7]_i_109_n_4 }),
        .O({\VGA_R_reg[6]_i_6_n_4 ,\NLW_VGA_R_reg[6]_i_6_O_UNCONNECTED [2],\VGA_R_reg[6]_i_6_n_6 ,\VGA_R_reg[6]_i_6_n_7 }),
        .S({\VGA_R[6]_i_13_n_0 ,\VGA_R[6]_i_14_n_0 ,\VGA_R[6]_i_15_n_0 ,\VGA_R[6]_i_16_n_0 }));
  CARRY4 \VGA_R_reg[6]_i_7 
       (.CI(1'b0),
        .CO({\VGA_R_reg[6]_i_7_n_0 ,\VGA_R_reg[6]_i_7_n_1 ,\VGA_R_reg[6]_i_7_n_2 ,\VGA_R_reg[6]_i_7_n_3 }),
        .CYINIT(data2[7]),
        .DI({\VGA_R_reg[7]_i_79_n_5 ,\VGA_R_reg[7]_i_79_n_6 ,data2[7],\VGA_R[6]_i_17_n_0 }),
        .O({\VGA_R_reg[6]_i_7_n_4 ,\VGA_R_reg[6]_i_7_n_5 ,\VGA_R_reg[6]_i_7_n_6 ,\VGA_R_reg[6]_i_7_n_7 }),
        .S({\VGA_R[6]_i_18_n_0 ,\VGA_R[6]_i_19_n_0 ,\VGA_R[6]_i_20_n_0 ,\VGA_R[6]_i_21_n_0 }));
  FDRE \VGA_R_reg[7] 
       (.C(PCK),
        .CE(1'b1),
        .D(pattern_r[7]),
        .Q(VGA_R[7]),
        .R(syncgen_multi_n_22));
  CARRY4 \VGA_R_reg[7]_i_101 
       (.CI(\VGA_R_reg[7]_i_241_n_0 ),
        .CO({\VGA_R_reg[7]_i_101_n_0 ,\VGA_R_reg[7]_i_101_n_1 ,\VGA_R_reg[7]_i_101_n_2 ,\VGA_R_reg[7]_i_101_n_3 }),
        .CYINIT(1'b0),
        .DI({\VGA_R_reg[7]_i_92_n_0 ,\VGA_R_reg[7]_i_92_n_6 ,\VGA_R_reg[7]_i_92_n_7 ,\VGA_R_reg[7]_i_203_n_4 }),
        .O({\NLW_VGA_R_reg[7]_i_101_O_UNCONNECTED [3],\VGA_R_reg[7]_i_101_n_5 ,\VGA_R_reg[7]_i_101_n_6 ,\VGA_R_reg[7]_i_101_n_7 }),
        .S({\VGA_R[7]_i_246_n_0 ,\VGA_R[7]_i_247_n_0 ,\VGA_R[7]_i_248_n_0 ,\VGA_R[7]_i_249_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_109 
       (.CI(1'b0),
        .CO({\VGA_R_reg[7]_i_109_n_0 ,\VGA_R_reg[7]_i_109_n_1 ,\VGA_R_reg[7]_i_109_n_2 ,\VGA_R_reg[7]_i_109_n_3 }),
        .CYINIT(\VGA_R_reg[7]_i_110_n_1 ),
        .DI({\VGA_R_reg[7]_i_111_n_5 ,\VGA_R_reg[7]_i_111_n_6 ,\VGA_R_reg[7]_i_111_n_7 ,\VGA_R[7]_i_270_n_0 }),
        .O({\VGA_R_reg[7]_i_109_n_4 ,\VGA_R_reg[7]_i_109_n_5 ,\VGA_R_reg[7]_i_109_n_6 ,\VGA_R_reg[7]_i_109_n_7 }),
        .S({\VGA_R[7]_i_271_n_0 ,\VGA_R[7]_i_272_n_0 ,\VGA_R[7]_i_273_n_0 ,\VGA_R[7]_i_274_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_110 
       (.CI(\VGA_R_reg[7]_i_111_n_0 ),
        .CO({\NLW_VGA_R_reg[7]_i_110_CO_UNCONNECTED [3],\VGA_R_reg[7]_i_110_n_1 ,\VGA_R_reg[7]_i_110_n_2 ,\VGA_R_reg[7]_i_110_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\VGA_R_reg[7]_i_275_n_1 ,\VGA_R_reg[7]_i_275_n_7 ,\VGA_R_reg[7]_i_276_n_4 }),
        .O({\VGA_R_reg[7]_i_110_n_4 ,\NLW_VGA_R_reg[7]_i_110_O_UNCONNECTED [2],\VGA_R_reg[7]_i_110_n_6 ,\VGA_R_reg[7]_i_110_n_7 }),
        .S({\VGA_R[7]_i_277_n_0 ,\VGA_R[7]_i_278_n_0 ,\VGA_R[7]_i_279_n_0 ,\VGA_R[7]_i_280_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_111 
       (.CI(1'b0),
        .CO({\VGA_R_reg[7]_i_111_n_0 ,\VGA_R_reg[7]_i_111_n_1 ,\VGA_R_reg[7]_i_111_n_2 ,\VGA_R_reg[7]_i_111_n_3 }),
        .CYINIT(\VGA_R_reg[7]_i_275_n_1 ),
        .DI({\VGA_R_reg[7]_i_276_n_5 ,\VGA_R_reg[7]_i_276_n_6 ,\VGA_R_reg[7]_i_276_n_7 ,\VGA_R[7]_i_281_n_0 }),
        .O({\VGA_R_reg[7]_i_111_n_4 ,\VGA_R_reg[7]_i_111_n_5 ,\VGA_R_reg[7]_i_111_n_6 ,\VGA_R_reg[7]_i_111_n_7 }),
        .S({\VGA_R[7]_i_282_n_0 ,\VGA_R[7]_i_283_n_0 ,\VGA_R[7]_i_284_n_0 ,\VGA_R[7]_i_285_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_127 
       (.CI(1'b0),
        .CO({\VGA_R_reg[7]_i_127_n_0 ,\VGA_R_reg[7]_i_127_n_1 ,\VGA_R_reg[7]_i_127_n_2 ,\VGA_R_reg[7]_i_127_n_3 }),
        .CYINIT(HWIDTH),
        .DI({\VGA_R[7]_i_310_n_0 ,\VGA_R[7]_i_311_n_0 ,\VGA_R[7]_i_312_n_0 ,\VGA_R[7]_i_313_n_0 }),
        .O({\VGA_R_reg[7]_i_127_n_4 ,\VGA_R_reg[7]_i_127_n_5 ,\VGA_R_reg[7]_i_127_n_6 ,\NLW_VGA_R_reg[7]_i_127_O_UNCONNECTED [0]}),
        .S({1'b0,\VGA_R[7]_i_314_n_0 ,\VGA_R[7]_i_315_n_0 ,\VGA_R[7]_i_316_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_181 
       (.CI(\VGA_R_reg[7]_i_182_n_0 ),
        .CO({\VGA_R_reg[7]_i_181_n_0 ,\VGA_R_reg[7]_i_181_n_1 ,\VGA_R_reg[7]_i_181_n_2 ,\VGA_R_reg[7]_i_181_n_3 }),
        .CYINIT(1'b0),
        .DI({\VGA_R_reg[7]_i_367_n_0 ,\VGA_R_reg[7]_i_367_n_6 ,\VGA_R_reg[7]_i_367_n_7 ,\VGA_R_reg[7]_i_368_n_4 }),
        .O({\NLW_VGA_R_reg[7]_i_181_O_UNCONNECTED [3],\VGA_R_reg[7]_i_181_n_5 ,\VGA_R_reg[7]_i_181_n_6 ,\VGA_R_reg[7]_i_181_n_7 }),
        .S({\VGA_R[7]_i_369_n_0 ,\VGA_R[7]_i_370_n_0 ,\VGA_R[7]_i_371_n_0 ,\VGA_R[7]_i_372_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_182 
       (.CI(1'b0),
        .CO({\VGA_R_reg[7]_i_182_n_0 ,\VGA_R_reg[7]_i_182_n_1 ,\VGA_R_reg[7]_i_182_n_2 ,\VGA_R_reg[7]_i_182_n_3 }),
        .CYINIT(\VGA_R_reg[7]_i_367_n_0 ),
        .DI({\VGA_R_reg[7]_i_368_n_5 ,\VGA_R_reg[7]_i_368_n_6 ,\VGA_R_reg[7]_i_367_n_0 ,\VGA_R[7]_i_373_n_0 }),
        .O({\VGA_R_reg[7]_i_182_n_4 ,\VGA_R_reg[7]_i_182_n_5 ,\VGA_R_reg[7]_i_182_n_6 ,\VGA_R_reg[7]_i_182_n_7 }),
        .S({\VGA_R[7]_i_374_n_0 ,\VGA_R[7]_i_375_n_0 ,\VGA_R[7]_i_376_n_0 ,\VGA_R[7]_i_377_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_203 
       (.CI(1'b0),
        .CO({\VGA_R_reg[7]_i_203_n_0 ,\VGA_R_reg[7]_i_203_n_1 ,\VGA_R_reg[7]_i_203_n_2 ,\VGA_R_reg[7]_i_203_n_3 }),
        .CYINIT(\VGA_R_reg[7]_i_93_n_3 ),
        .DI({\VGA_R[7]_i_379_n_0 ,\VGA_R[7]_i_380_n_0 ,\VGA_R_reg[7]_i_93_n_3 ,\VGA_R[7]_i_381_n_0 }),
        .O({\VGA_R_reg[7]_i_203_n_4 ,\VGA_R_reg[7]_i_203_n_5 ,\VGA_R_reg[7]_i_203_n_6 ,\VGA_R_reg[7]_i_203_n_7 }),
        .S({\VGA_R[7]_i_382_n_0 ,\VGA_R[7]_i_383_n_0 ,\VGA_R[7]_i_384_n_0 ,\VGA_R[7]_i_385_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_204 
       (.CI(1'b0),
        .CO({\VGA_R_reg[7]_i_204_n_0 ,\VGA_R_reg[7]_i_204_n_1 ,\VGA_R_reg[7]_i_204_n_2 ,\VGA_R_reg[7]_i_204_n_3 }),
        .CYINIT(HWIDTH),
        .DI({\VGA_R[7]_i_386_n_0 ,\VGA_R[7]_i_387_n_0 ,\VGA_R[7]_i_388_n_0 ,\VGA_R[7]_i_389_n_0 }),
        .O({\VGA_R_reg[7]_i_204_n_4 ,\VGA_R_reg[7]_i_204_n_5 ,\VGA_R_reg[7]_i_204_n_6 ,\NLW_VGA_R_reg[7]_i_204_O_UNCONNECTED [0]}),
        .S({1'b0,\VGA_R[7]_i_390_n_0 ,\VGA_R[7]_i_391_n_0 ,\VGA_R[7]_i_392_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_241 
       (.CI(1'b0),
        .CO({\VGA_R_reg[7]_i_241_n_0 ,\VGA_R_reg[7]_i_241_n_1 ,\VGA_R_reg[7]_i_241_n_2 ,\VGA_R_reg[7]_i_241_n_3 }),
        .CYINIT(\VGA_R_reg[7]_i_92_n_0 ),
        .DI({\VGA_R_reg[7]_i_203_n_5 ,\VGA_R_reg[7]_i_203_n_6 ,\VGA_R_reg[7]_i_92_n_0 ,\VGA_R[7]_i_423_n_0 }),
        .O({\VGA_R_reg[7]_i_241_n_4 ,\VGA_R_reg[7]_i_241_n_5 ,\VGA_R_reg[7]_i_241_n_6 ,\VGA_R_reg[7]_i_241_n_7 }),
        .S({\VGA_R[7]_i_424_n_0 ,\VGA_R[7]_i_425_n_0 ,\VGA_R[7]_i_426_n_0 ,\VGA_R[7]_i_427_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_275 
       (.CI(\VGA_R_reg[7]_i_276_n_0 ),
        .CO({\NLW_VGA_R_reg[7]_i_275_CO_UNCONNECTED [3],\VGA_R_reg[7]_i_275_n_1 ,\VGA_R_reg[7]_i_275_n_2 ,\VGA_R_reg[7]_i_275_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\VGA_R_reg[7]_i_436_n_1 ,\VGA_R_reg[7]_i_436_n_7 ,\VGA_R_reg[7]_i_437_n_4 }),
        .O({\VGA_R_reg[7]_i_275_n_4 ,\NLW_VGA_R_reg[7]_i_275_O_UNCONNECTED [2],\VGA_R_reg[7]_i_275_n_6 ,\VGA_R_reg[7]_i_275_n_7 }),
        .S({\VGA_R[7]_i_438_n_0 ,\VGA_R[7]_i_439_n_0 ,\VGA_R[7]_i_440_n_0 ,\VGA_R[7]_i_441_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_276 
       (.CI(1'b0),
        .CO({\VGA_R_reg[7]_i_276_n_0 ,\VGA_R_reg[7]_i_276_n_1 ,\VGA_R_reg[7]_i_276_n_2 ,\VGA_R_reg[7]_i_276_n_3 }),
        .CYINIT(\VGA_R_reg[7]_i_436_n_1 ),
        .DI({\VGA_R_reg[7]_i_437_n_5 ,\VGA_R_reg[7]_i_437_n_6 ,\VGA_R_reg[7]_i_437_n_7 ,\VGA_R[7]_i_442_n_0 }),
        .O({\VGA_R_reg[7]_i_276_n_4 ,\VGA_R_reg[7]_i_276_n_5 ,\VGA_R_reg[7]_i_276_n_6 ,\VGA_R_reg[7]_i_276_n_7 }),
        .S({\VGA_R[7]_i_443_n_0 ,\VGA_R[7]_i_444_n_0 ,\VGA_R[7]_i_445_n_0 ,\VGA_R[7]_i_446_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_30 
       (.CI(\VGA_R_reg[7]_i_79_n_0 ),
        .CO({data2[7],\VGA_R_reg[7]_i_30_n_1 ,\VGA_R_reg[7]_i_30_n_2 ,\VGA_R_reg[7]_i_30_n_3 }),
        .CYINIT(1'b0),
        .DI({\VGA_R_reg[7]_i_80_n_0 ,\VGA_R_reg[7]_i_80_n_6 ,\VGA_R_reg[7]_i_80_n_7 ,\VGA_R_reg[7]_i_81_n_4 }),
        .O({\NLW_VGA_R_reg[7]_i_30_O_UNCONNECTED [3],\VGA_R_reg[7]_i_30_n_5 ,\VGA_R_reg[7]_i_30_n_6 ,\VGA_R_reg[7]_i_30_n_7 }),
        .S({\VGA_R[7]_i_82_n_0 ,\VGA_R[7]_i_83_n_0 ,\VGA_R[7]_i_84_n_0 ,\VGA_R[7]_i_85_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_365 
       (.CI(\VGA_R_reg[7]_i_460_n_0 ),
        .CO(\NLW_VGA_R_reg[7]_i_365_CO_UNCONNECTED [3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_VGA_R_reg[7]_i_365_O_UNCONNECTED [3:1],\VGA_R_reg[7]_i_365_n_7 }),
        .S({1'b0,1'b0,1'b0,\VGA_R[7]_i_461_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_367 
       (.CI(\VGA_R_reg[7]_i_368_n_0 ),
        .CO({\VGA_R_reg[7]_i_367_n_0 ,\VGA_R_reg[7]_i_367_n_1 ,\VGA_R_reg[7]_i_367_n_2 ,\VGA_R_reg[7]_i_367_n_3 }),
        .CYINIT(1'b0),
        .DI({\VGA_R_reg[7]_i_462_n_0 ,\VGA_R_reg[7]_i_462_n_6 ,\VGA_R_reg[7]_i_462_n_7 ,\VGA_R_reg[7]_i_463_n_4 }),
        .O({\NLW_VGA_R_reg[7]_i_367_O_UNCONNECTED [3],\VGA_R_reg[7]_i_367_n_5 ,\VGA_R_reg[7]_i_367_n_6 ,\VGA_R_reg[7]_i_367_n_7 }),
        .S({\VGA_R[7]_i_464_n_0 ,\VGA_R[7]_i_465_n_0 ,\VGA_R[7]_i_466_n_0 ,\VGA_R[7]_i_467_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_368 
       (.CI(1'b0),
        .CO({\VGA_R_reg[7]_i_368_n_0 ,\VGA_R_reg[7]_i_368_n_1 ,\VGA_R_reg[7]_i_368_n_2 ,\VGA_R_reg[7]_i_368_n_3 }),
        .CYINIT(\VGA_R_reg[7]_i_462_n_0 ),
        .DI({\VGA_R_reg[7]_i_463_n_5 ,\VGA_R_reg[7]_i_463_n_6 ,\VGA_R_reg[7]_i_462_n_0 ,\VGA_R[7]_i_468_n_0 }),
        .O({\VGA_R_reg[7]_i_368_n_4 ,\VGA_R_reg[7]_i_368_n_5 ,\VGA_R_reg[7]_i_368_n_6 ,\VGA_R_reg[7]_i_368_n_7 }),
        .S({\VGA_R[7]_i_469_n_0 ,\VGA_R[7]_i_470_n_0 ,\VGA_R[7]_i_471_n_0 ,\VGA_R[7]_i_472_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_378 
       (.CI(\VGA_R_reg[7]_i_474_n_0 ),
        .CO(\NLW_VGA_R_reg[7]_i_378_CO_UNCONNECTED [3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_VGA_R_reg[7]_i_378_O_UNCONNECTED [3:1],\VGA_R_reg[7]_i_378_n_7 }),
        .S({1'b0,1'b0,1'b0,\VGA_R[7]_i_475_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_40 
       (.CI(\VGA_R_reg[7]_i_109_n_0 ),
        .CO({\NLW_VGA_R_reg[7]_i_40_CO_UNCONNECTED [3],data6[7],\VGA_R_reg[7]_i_40_n_2 ,\VGA_R_reg[7]_i_40_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\VGA_R_reg[7]_i_110_n_1 ,\VGA_R_reg[7]_i_110_n_7 ,\VGA_R_reg[7]_i_111_n_4 }),
        .O({\VGA_R_reg[7]_i_40_n_4 ,\NLW_VGA_R_reg[7]_i_40_O_UNCONNECTED [2],\VGA_R_reg[7]_i_40_n_6 ,\VGA_R_reg[7]_i_40_n_7 }),
        .S({\VGA_R[7]_i_112_n_0 ,\VGA_R[7]_i_113_n_0 ,\VGA_R[7]_i_114_n_0 ,\VGA_R[7]_i_115_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_435 
       (.CI(\VGA_R_reg[7]_i_477_n_0 ),
        .CO({\NLW_VGA_R_reg[7]_i_435_CO_UNCONNECTED [3],\VGA_R_reg[7]_i_435_n_1 ,\VGA_R_reg[7]_i_435_n_2 ,\VGA_R_reg[7]_i_435_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\VGA_R_reg[7]_i_447_n_1 ,\VGA_R_reg[7]_i_447_n_7 ,\VGA_R_reg[7]_i_478_n_4 }),
        .O({\VGA_R_reg[7]_i_435_n_4 ,\NLW_VGA_R_reg[7]_i_435_O_UNCONNECTED [2],\VGA_R_reg[7]_i_435_n_6 ,\VGA_R_reg[7]_i_435_n_7 }),
        .S({\VGA_R[7]_i_479_n_0 ,\VGA_R[7]_i_480_n_0 ,\VGA_R[7]_i_481_n_0 ,\VGA_R[7]_i_482_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_436 
       (.CI(\VGA_R_reg[7]_i_437_n_0 ),
        .CO({\NLW_VGA_R_reg[7]_i_436_CO_UNCONNECTED [3],\VGA_R_reg[7]_i_436_n_1 ,\VGA_R_reg[7]_i_436_n_2 ,\VGA_R_reg[7]_i_436_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\VGA_R_reg[6]_i_28_n_1 ,\VGA_R_reg[6]_i_28_n_7 ,\VGA_R_reg[7]_i_483_n_4 }),
        .O({\VGA_R_reg[7]_i_436_n_4 ,\NLW_VGA_R_reg[7]_i_436_O_UNCONNECTED [2],\VGA_R_reg[7]_i_436_n_6 ,\VGA_R_reg[7]_i_436_n_7 }),
        .S({\VGA_R[7]_i_484_n_0 ,\VGA_R[7]_i_485_n_0 ,\VGA_R[7]_i_486_n_0 ,\VGA_R[7]_i_487_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_437 
       (.CI(1'b0),
        .CO({\VGA_R_reg[7]_i_437_n_0 ,\VGA_R_reg[7]_i_437_n_1 ,\VGA_R_reg[7]_i_437_n_2 ,\VGA_R_reg[7]_i_437_n_3 }),
        .CYINIT(\VGA_R_reg[6]_i_28_n_1 ),
        .DI({\VGA_R_reg[7]_i_483_n_5 ,\VGA_R_reg[7]_i_483_n_6 ,\VGA_R_reg[7]_i_483_n_7 ,\VGA_R[7]_i_488_n_0 }),
        .O({\VGA_R_reg[7]_i_437_n_4 ,\VGA_R_reg[7]_i_437_n_5 ,\VGA_R_reg[7]_i_437_n_6 ,\VGA_R_reg[7]_i_437_n_7 }),
        .S({\VGA_R[7]_i_489_n_0 ,\VGA_R[7]_i_490_n_0 ,\VGA_R[7]_i_491_n_0 ,\VGA_R[7]_i_492_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_447 
       (.CI(\VGA_R_reg[7]_i_478_n_0 ),
        .CO({\NLW_VGA_R_reg[7]_i_447_CO_UNCONNECTED [3],\VGA_R_reg[7]_i_447_n_1 ,\VGA_R_reg[7]_i_447_n_2 ,\VGA_R_reg[7]_i_447_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\VGA_R_reg[7]_i_494_n_0 ,\VGA_R_reg[7]_i_494_n_6 ,\VGA_R_reg[7]_i_494_n_7 }),
        .O({\VGA_R_reg[7]_i_447_n_4 ,\NLW_VGA_R_reg[7]_i_447_O_UNCONNECTED [2],\VGA_R_reg[7]_i_447_n_6 ,\VGA_R_reg[7]_i_447_n_7 }),
        .S({\VGA_R[7]_i_495_n_0 ,\VGA_R[7]_i_496_n_0 ,\VGA_R[7]_i_497_n_0 ,\VGA_R[7]_i_498_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_460 
       (.CI(\VGA_R_reg[7]_i_512_n_0 ),
        .CO({\VGA_R_reg[7]_i_460_n_0 ,\VGA_R_reg[7]_i_460_n_1 ,\VGA_R_reg[7]_i_460_n_2 ,\VGA_R_reg[7]_i_460_n_3 }),
        .CYINIT(1'b0),
        .DI({\VGA_R_reg[7]_i_474_n_0 ,\VGA_R_reg[7]_i_474_n_6 ,\VGA_R_reg[7]_i_474_n_7 ,\VGA_R_reg[7]_i_513_n_4 }),
        .O({\NLW_VGA_R_reg[7]_i_460_O_UNCONNECTED [3],\VGA_R_reg[7]_i_460_n_5 ,\VGA_R_reg[7]_i_460_n_6 ,\VGA_R_reg[7]_i_460_n_7 }),
        .S({\VGA_R[7]_i_514_n_0 ,\VGA_R[7]_i_515_n_0 ,\VGA_R[7]_i_516_n_0 ,\VGA_R[7]_i_517_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_462 
       (.CI(\VGA_R_reg[7]_i_463_n_0 ),
        .CO({\VGA_R_reg[7]_i_462_n_0 ,\VGA_R_reg[7]_i_462_n_1 ,\VGA_R_reg[7]_i_462_n_2 ,\VGA_R_reg[7]_i_462_n_3 }),
        .CYINIT(1'b0),
        .DI({\VGA_R_reg[7]_i_460_n_0 ,\VGA_R_reg[7]_i_460_n_6 ,\VGA_R_reg[7]_i_460_n_7 ,\VGA_R_reg[7]_i_512_n_4 }),
        .O({\NLW_VGA_R_reg[7]_i_462_O_UNCONNECTED [3],\VGA_R_reg[7]_i_462_n_5 ,\VGA_R_reg[7]_i_462_n_6 ,\VGA_R_reg[7]_i_462_n_7 }),
        .S({\VGA_R[7]_i_518_n_0 ,\VGA_R[7]_i_519_n_0 ,\VGA_R[7]_i_520_n_0 ,\VGA_R[7]_i_521_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_463 
       (.CI(1'b0),
        .CO({\VGA_R_reg[7]_i_463_n_0 ,\VGA_R_reg[7]_i_463_n_1 ,\VGA_R_reg[7]_i_463_n_2 ,\VGA_R_reg[7]_i_463_n_3 }),
        .CYINIT(\VGA_R_reg[7]_i_460_n_0 ),
        .DI({\VGA_R_reg[7]_i_512_n_5 ,\VGA_R_reg[7]_i_512_n_6 ,\VGA_R_reg[7]_i_460_n_0 ,\VGA_R[7]_i_522_n_0 }),
        .O({\VGA_R_reg[7]_i_463_n_4 ,\VGA_R_reg[7]_i_463_n_5 ,\VGA_R_reg[7]_i_463_n_6 ,\VGA_R_reg[7]_i_463_n_7 }),
        .S({\VGA_R[7]_i_523_n_0 ,\VGA_R[7]_i_524_n_0 ,\VGA_R[7]_i_525_n_0 ,\VGA_R[7]_i_526_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_473 
       (.CI(\VGA_R_reg[7]_i_528_n_0 ),
        .CO(\NLW_VGA_R_reg[7]_i_473_CO_UNCONNECTED [3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_VGA_R_reg[7]_i_473_O_UNCONNECTED [3:1],\VGA_R_reg[7]_i_473_n_7 }),
        .S({1'b0,1'b0,1'b0,\VGA_R[7]_i_529_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_474 
       (.CI(\VGA_R_reg[7]_i_513_n_0 ),
        .CO({\VGA_R_reg[7]_i_474_n_0 ,\VGA_R_reg[7]_i_474_n_1 ,\VGA_R_reg[7]_i_474_n_2 ,\VGA_R_reg[7]_i_474_n_3 }),
        .CYINIT(1'b0),
        .DI({\VGA_R_reg[7]_i_528_n_0 ,\VGA_R_reg[7]_i_528_n_6 ,\VGA_R_reg[7]_i_528_n_7 ,\VGA_R_reg[7]_i_530_n_4 }),
        .O({\NLW_VGA_R_reg[7]_i_474_O_UNCONNECTED [3],\VGA_R_reg[7]_i_474_n_5 ,\VGA_R_reg[7]_i_474_n_6 ,\VGA_R_reg[7]_i_474_n_7 }),
        .S({\VGA_R[7]_i_531_n_0 ,\VGA_R[7]_i_532_n_0 ,\VGA_R[7]_i_533_n_0 ,\VGA_R[7]_i_534_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_477 
       (.CI(1'b0),
        .CO({\VGA_R_reg[7]_i_477_n_0 ,\VGA_R_reg[7]_i_477_n_1 ,\VGA_R_reg[7]_i_477_n_2 ,\VGA_R_reg[7]_i_477_n_3 }),
        .CYINIT(\VGA_R_reg[7]_i_447_n_1 ),
        .DI({\VGA_R_reg[7]_i_478_n_5 ,\VGA_R_reg[7]_i_478_n_6 ,\VGA_R_reg[7]_i_478_n_7 ,\VGA_R[7]_i_535_n_0 }),
        .O({\VGA_R_reg[7]_i_477_n_4 ,\VGA_R_reg[7]_i_477_n_5 ,\VGA_R_reg[7]_i_477_n_6 ,\VGA_R_reg[7]_i_477_n_7 }),
        .S({\VGA_R[7]_i_536_n_0 ,\VGA_R[7]_i_537_n_0 ,\VGA_R[7]_i_538_n_0 ,\VGA_R[7]_i_539_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_478 
       (.CI(1'b0),
        .CO({\VGA_R_reg[7]_i_478_n_0 ,\VGA_R_reg[7]_i_478_n_1 ,\VGA_R_reg[7]_i_478_n_2 ,\VGA_R_reg[7]_i_478_n_3 }),
        .CYINIT(\VGA_R_reg[7]_i_494_n_0 ),
        .DI({\VGA_R_reg[7]_i_540_n_4 ,\VGA_R_reg[7]_i_540_n_5 ,\VGA_R_reg[7]_i_540_n_6 ,\VGA_R_reg[7]_i_540_n_7 }),
        .O({\VGA_R_reg[7]_i_478_n_4 ,\VGA_R_reg[7]_i_478_n_5 ,\VGA_R_reg[7]_i_478_n_6 ,\VGA_R_reg[7]_i_478_n_7 }),
        .S({\VGA_R[7]_i_541_n_0 ,\VGA_R[7]_i_542_n_0 ,\VGA_R[7]_i_543_n_0 ,\VGA_R[7]_i_544_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_483 
       (.CI(1'b0),
        .CO({\VGA_R_reg[7]_i_483_n_0 ,\VGA_R_reg[7]_i_483_n_1 ,\VGA_R_reg[7]_i_483_n_2 ,\VGA_R_reg[7]_i_483_n_3 }),
        .CYINIT(\VGA_R_reg[7]_i_435_n_1 ),
        .DI({\VGA_R_reg[7]_i_477_n_5 ,\VGA_R_reg[7]_i_477_n_6 ,\VGA_R_reg[7]_i_477_n_7 ,\VGA_R[7]_i_545_n_0 }),
        .O({\VGA_R_reg[7]_i_483_n_4 ,\VGA_R_reg[7]_i_483_n_5 ,\VGA_R_reg[7]_i_483_n_6 ,\VGA_R_reg[7]_i_483_n_7 }),
        .S({\VGA_R[7]_i_546_n_0 ,\VGA_R[7]_i_547_n_0 ,\VGA_R[7]_i_548_n_0 ,\VGA_R[7]_i_549_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_493 
       (.CI(\VGA_R_reg[7]_i_494_n_0 ),
        .CO(\NLW_VGA_R_reg[7]_i_493_CO_UNCONNECTED [3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_VGA_R_reg[7]_i_493_O_UNCONNECTED [3:1],\VGA_R_reg[7]_i_493_n_7 }),
        .S({1'b0,1'b0,1'b0,\VGA_R[7]_i_550_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_494 
       (.CI(\VGA_R_reg[7]_i_540_n_0 ),
        .CO({\VGA_R_reg[7]_i_494_n_0 ,\VGA_R_reg[7]_i_494_n_1 ,\VGA_R_reg[7]_i_494_n_2 ,\VGA_R_reg[7]_i_494_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\VGA_R[7]_i_551_n_0 ,\VGA_R_reg[7]_i_552_n_7 ,1'b1}),
        .O({\NLW_VGA_R_reg[7]_i_494_O_UNCONNECTED [3],\VGA_R_reg[7]_i_494_n_5 ,\VGA_R_reg[7]_i_494_n_6 ,\VGA_R_reg[7]_i_494_n_7 }),
        .S({\VGA_R_reg[7]_i_552_n_1 ,\VGA_R[7]_i_553_n_0 ,\VGA_R[7]_i_554_n_0 ,\VGA_R[7]_i_555_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_512 
       (.CI(1'b0),
        .CO({\VGA_R_reg[7]_i_512_n_0 ,\VGA_R_reg[7]_i_512_n_1 ,\VGA_R_reg[7]_i_512_n_2 ,\VGA_R_reg[7]_i_512_n_3 }),
        .CYINIT(\VGA_R_reg[7]_i_474_n_0 ),
        .DI({\VGA_R_reg[7]_i_513_n_5 ,\VGA_R_reg[7]_i_513_n_6 ,\VGA_R_reg[7]_i_474_n_0 ,\VGA_R[7]_i_561_n_0 }),
        .O({\VGA_R_reg[7]_i_512_n_4 ,\VGA_R_reg[7]_i_512_n_5 ,\VGA_R_reg[7]_i_512_n_6 ,\VGA_R_reg[7]_i_512_n_7 }),
        .S({\VGA_R[7]_i_562_n_0 ,\VGA_R[7]_i_563_n_0 ,\VGA_R[7]_i_564_n_0 ,\VGA_R[7]_i_565_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_513 
       (.CI(1'b0),
        .CO({\VGA_R_reg[7]_i_513_n_0 ,\VGA_R_reg[7]_i_513_n_1 ,\VGA_R_reg[7]_i_513_n_2 ,\VGA_R_reg[7]_i_513_n_3 }),
        .CYINIT(\VGA_R_reg[7]_i_528_n_0 ),
        .DI({\VGA_R_reg[7]_i_530_n_5 ,\VGA_R_reg[7]_i_530_n_6 ,\VGA_R_reg[7]_i_528_n_0 ,\VGA_R[7]_i_566_n_0 }),
        .O({\VGA_R_reg[7]_i_513_n_4 ,\VGA_R_reg[7]_i_513_n_5 ,\VGA_R_reg[7]_i_513_n_6 ,\VGA_R_reg[7]_i_513_n_7 }),
        .S({\VGA_R[7]_i_567_n_0 ,\VGA_R[7]_i_568_n_0 ,\VGA_R[7]_i_569_n_0 ,\VGA_R[7]_i_570_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_527 
       (.CI(\VGA_R_reg[7]_i_572_n_0 ),
        .CO(\NLW_VGA_R_reg[7]_i_527_CO_UNCONNECTED [3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_VGA_R_reg[7]_i_527_O_UNCONNECTED [3:1],\VGA_R_reg[7]_i_527_n_7 }),
        .S({1'b0,1'b0,1'b0,\VGA_R[7]_i_573_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_528 
       (.CI(\VGA_R_reg[7]_i_530_n_0 ),
        .CO({\VGA_R_reg[7]_i_528_n_0 ,\VGA_R_reg[7]_i_528_n_1 ,\VGA_R_reg[7]_i_528_n_2 ,\VGA_R_reg[7]_i_528_n_3 }),
        .CYINIT(1'b0),
        .DI({\VGA_R_reg[7]_i_572_n_0 ,\VGA_R_reg[7]_i_572_n_6 ,\VGA_R_reg[7]_i_572_n_7 ,\VGA_R_reg[7]_i_574_n_4 }),
        .O({\NLW_VGA_R_reg[7]_i_528_O_UNCONNECTED [3],\VGA_R_reg[7]_i_528_n_5 ,\VGA_R_reg[7]_i_528_n_6 ,\VGA_R_reg[7]_i_528_n_7 }),
        .S({\VGA_R[7]_i_575_n_0 ,\VGA_R[7]_i_576_n_0 ,\VGA_R[7]_i_577_n_0 ,\VGA_R[7]_i_578_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_530 
       (.CI(1'b0),
        .CO({\VGA_R_reg[7]_i_530_n_0 ,\VGA_R_reg[7]_i_530_n_1 ,\VGA_R_reg[7]_i_530_n_2 ,\VGA_R_reg[7]_i_530_n_3 }),
        .CYINIT(\VGA_R_reg[7]_i_572_n_0 ),
        .DI({\VGA_R_reg[7]_i_574_n_5 ,\VGA_R_reg[7]_i_574_n_6 ,\VGA_R_reg[7]_i_572_n_0 ,\VGA_R[7]_i_579_n_0 }),
        .O({\VGA_R_reg[7]_i_530_n_4 ,\VGA_R_reg[7]_i_530_n_5 ,\VGA_R_reg[7]_i_530_n_6 ,\VGA_R_reg[7]_i_530_n_7 }),
        .S({\VGA_R[7]_i_580_n_0 ,\VGA_R[7]_i_581_n_0 ,\VGA_R[7]_i_582_n_0 ,\VGA_R[7]_i_583_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_540 
       (.CI(1'b0),
        .CO({\VGA_R_reg[7]_i_540_n_0 ,\VGA_R_reg[7]_i_540_n_1 ,\VGA_R_reg[7]_i_540_n_2 ,\VGA_R_reg[7]_i_540_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b1,\VGA_R_reg[7]_i_584_n_6 ,\VGA_R[7]_i_585_n_0 ,1'b0}),
        .O({\VGA_R_reg[7]_i_540_n_4 ,\VGA_R_reg[7]_i_540_n_5 ,\VGA_R_reg[7]_i_540_n_6 ,\VGA_R_reg[7]_i_540_n_7 }),
        .S({\VGA_R[7]_i_586_n_0 ,\VGA_R[7]_i_587_n_0 ,\VGA_R[7]_i_588_n_0 ,pattern_b1__0_n_88}));
  CARRY4 \VGA_R_reg[7]_i_552 
       (.CI(\VGA_R_reg[7]_i_584_n_0 ),
        .CO({\NLW_VGA_R_reg[7]_i_552_CO_UNCONNECTED [3],\VGA_R_reg[7]_i_552_n_1 ,\NLW_VGA_R_reg[7]_i_552_CO_UNCONNECTED [1],\VGA_R_reg[7]_i_552_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\VGA_R[7]_i_589_n_0 ,1'b1}),
        .O({\NLW_VGA_R_reg[7]_i_552_O_UNCONNECTED [3:2],\VGA_R_reg[7]_i_552_n_6 ,\VGA_R_reg[7]_i_552_n_7 }),
        .S({1'b0,1'b1,\VGA_R[7]_i_590_n_0 ,\VGA_R[7]_i_591_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_571 
       (.CI(\VGA_R_reg[7]_i_593_n_0 ),
        .CO(\NLW_VGA_R_reg[7]_i_571_CO_UNCONNECTED [3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_VGA_R_reg[7]_i_571_O_UNCONNECTED [3:1],\VGA_R_reg[7]_i_571_n_7 }),
        .S({1'b0,1'b0,1'b0,\VGA_R[7]_i_594_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_572 
       (.CI(\VGA_R_reg[7]_i_574_n_0 ),
        .CO({\VGA_R_reg[7]_i_572_n_0 ,\VGA_R_reg[7]_i_572_n_1 ,\VGA_R_reg[7]_i_572_n_2 ,\VGA_R_reg[7]_i_572_n_3 }),
        .CYINIT(1'b0),
        .DI({\VGA_R_reg[7]_i_593_n_0 ,\VGA_R_reg[7]_i_593_n_6 ,\VGA_R_reg[7]_i_593_n_7 ,\VGA_R_reg[7]_i_595_n_4 }),
        .O({\NLW_VGA_R_reg[7]_i_572_O_UNCONNECTED [3],\VGA_R_reg[7]_i_572_n_5 ,\VGA_R_reg[7]_i_572_n_6 ,\VGA_R_reg[7]_i_572_n_7 }),
        .S({\VGA_R[7]_i_596_n_0 ,\VGA_R[7]_i_597_n_0 ,\VGA_R[7]_i_598_n_0 ,\VGA_R[7]_i_599_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_574 
       (.CI(1'b0),
        .CO({\VGA_R_reg[7]_i_574_n_0 ,\VGA_R_reg[7]_i_574_n_1 ,\VGA_R_reg[7]_i_574_n_2 ,\VGA_R_reg[7]_i_574_n_3 }),
        .CYINIT(\VGA_R_reg[7]_i_593_n_0 ),
        .DI({\VGA_R_reg[7]_i_595_n_5 ,\VGA_R_reg[7]_i_595_n_6 ,\VGA_R_reg[7]_i_593_n_0 ,\VGA_R[7]_i_600_n_0 }),
        .O({\VGA_R_reg[7]_i_574_n_4 ,\VGA_R_reg[7]_i_574_n_5 ,\VGA_R_reg[7]_i_574_n_6 ,\VGA_R_reg[7]_i_574_n_7 }),
        .S({\VGA_R[7]_i_601_n_0 ,\VGA_R[7]_i_602_n_0 ,\VGA_R[7]_i_603_n_0 ,\VGA_R[7]_i_604_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_584 
       (.CI(1'b0),
        .CO({\VGA_R_reg[7]_i_584_n_0 ,\VGA_R_reg[7]_i_584_n_1 ,\VGA_R_reg[7]_i_584_n_2 ,\VGA_R_reg[7]_i_584_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b1,\VGA_R_reg[7]_i_605_n_6 ,\VGA_R[7]_i_606_n_0 ,1'b0}),
        .O({\VGA_R_reg[7]_i_584_n_4 ,\VGA_R_reg[7]_i_584_n_5 ,\VGA_R_reg[7]_i_584_n_6 ,\VGA_R_reg[7]_i_584_n_7 }),
        .S({\VGA_R_reg[7]_i_605_n_1 ,\VGA_R[7]_i_607_n_0 ,\VGA_R[7]_i_608_n_0 ,pattern_b1__0_n_87}));
  CARRY4 \VGA_R_reg[7]_i_592 
       (.CI(\VGA_R_reg[7]_i_609_n_0 ),
        .CO({\NLW_VGA_R_reg[7]_i_592_CO_UNCONNECTED [3:1],\VGA_R_reg[7]_i_592_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_VGA_R_reg[7]_i_592_O_UNCONNECTED [3:2],\VGA_R_reg[7]_i_592_n_6 ,\NLW_VGA_R_reg[7]_i_592_O_UNCONNECTED [0]}),
        .S({1'b0,1'b0,\VGA_R[7]_i_610_n_0 ,\VGA_R[7]_i_611_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_593 
       (.CI(\VGA_R_reg[7]_i_595_n_0 ),
        .CO({\VGA_R_reg[7]_i_593_n_0 ,\VGA_R_reg[7]_i_593_n_1 ,\VGA_R_reg[7]_i_593_n_2 ,\VGA_R_reg[7]_i_593_n_3 }),
        .CYINIT(1'b0),
        .DI({\VGA_R_reg[7]_i_592_n_3 ,\VGA_R_reg[7]_i_609_n_5 ,\VGA_R_reg[7]_i_609_n_6 ,\VGA_R[7]_i_612_n_0 }),
        .O({\NLW_VGA_R_reg[7]_i_593_O_UNCONNECTED [3],\VGA_R_reg[7]_i_593_n_5 ,\VGA_R_reg[7]_i_593_n_6 ,\VGA_R_reg[7]_i_593_n_7 }),
        .S({\VGA_R[7]_i_613_n_0 ,\VGA_R[7]_i_614_n_0 ,\VGA_R[7]_i_615_n_0 ,\VGA_R[7]_i_616_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_595 
       (.CI(1'b0),
        .CO({\VGA_R_reg[7]_i_595_n_0 ,\VGA_R_reg[7]_i_595_n_1 ,\VGA_R_reg[7]_i_595_n_2 ,\VGA_R_reg[7]_i_595_n_3 }),
        .CYINIT(\VGA_R_reg[7]_i_592_n_3 ),
        .DI({\VGA_R[7]_i_617_n_0 ,\VGA_R[7]_i_618_n_0 ,\VGA_R_reg[7]_i_592_n_3 ,\VGA_R[7]_i_619_n_0 }),
        .O({\VGA_R_reg[7]_i_595_n_4 ,\VGA_R_reg[7]_i_595_n_5 ,\VGA_R_reg[7]_i_595_n_6 ,\VGA_R_reg[7]_i_595_n_7 }),
        .S({\VGA_R[7]_i_620_n_0 ,\VGA_R[7]_i_621_n_0 ,\VGA_R[7]_i_622_n_0 ,\VGA_R[7]_i_623_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_605 
       (.CI(1'b0),
        .CO({\NLW_VGA_R_reg[7]_i_605_CO_UNCONNECTED [3],\VGA_R_reg[7]_i_605_n_1 ,\NLW_VGA_R_reg[7]_i_605_CO_UNCONNECTED [1],\VGA_R_reg[7]_i_605_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\VGA_R[7]_i_624_n_0 ,1'b0}),
        .O({\NLW_VGA_R_reg[7]_i_605_O_UNCONNECTED [3:2],\VGA_R_reg[7]_i_605_n_6 ,\NLW_VGA_R_reg[7]_i_605_O_UNCONNECTED [0]}),
        .S({1'b0,1'b1,\VGA_R[7]_i_625_n_0 ,1'b0}));
  CARRY4 \VGA_R_reg[7]_i_609 
       (.CI(1'b0),
        .CO({\VGA_R_reg[7]_i_609_n_0 ,\VGA_R_reg[7]_i_609_n_1 ,\VGA_R_reg[7]_i_609_n_2 ,\VGA_R_reg[7]_i_609_n_3 }),
        .CYINIT(HWIDTH),
        .DI({\VGA_R[7]_i_626_n_0 ,\VGA_R[7]_i_627_n_0 ,\VGA_R[7]_i_628_n_0 ,\VGA_R[7]_i_629_n_0 }),
        .O({\VGA_R_reg[7]_i_609_n_4 ,\VGA_R_reg[7]_i_609_n_5 ,\VGA_R_reg[7]_i_609_n_6 ,\NLW_VGA_R_reg[7]_i_609_O_UNCONNECTED [0]}),
        .S({1'b0,\VGA_R[7]_i_630_n_0 ,\VGA_R[7]_i_631_n_0 ,\VGA_R[7]_i_632_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_79 
       (.CI(1'b0),
        .CO({\VGA_R_reg[7]_i_79_n_0 ,\VGA_R_reg[7]_i_79_n_1 ,\VGA_R_reg[7]_i_79_n_2 ,\VGA_R_reg[7]_i_79_n_3 }),
        .CYINIT(\VGA_R_reg[7]_i_80_n_0 ),
        .DI({\VGA_R_reg[7]_i_81_n_5 ,\VGA_R_reg[7]_i_81_n_6 ,\VGA_R_reg[7]_i_80_n_0 ,\VGA_R[7]_i_176_n_0 }),
        .O({\VGA_R_reg[7]_i_79_n_4 ,\VGA_R_reg[7]_i_79_n_5 ,\VGA_R_reg[7]_i_79_n_6 ,\VGA_R_reg[7]_i_79_n_7 }),
        .S({\VGA_R[7]_i_177_n_0 ,\VGA_R[7]_i_178_n_0 ,\VGA_R[7]_i_179_n_0 ,\VGA_R[7]_i_180_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_80 
       (.CI(\VGA_R_reg[7]_i_81_n_0 ),
        .CO({\VGA_R_reg[7]_i_80_n_0 ,\VGA_R_reg[7]_i_80_n_1 ,\VGA_R_reg[7]_i_80_n_2 ,\VGA_R_reg[7]_i_80_n_3 }),
        .CYINIT(1'b0),
        .DI({\VGA_R_reg[7]_i_181_n_0 ,\VGA_R_reg[7]_i_181_n_6 ,\VGA_R_reg[7]_i_181_n_7 ,\VGA_R_reg[7]_i_182_n_4 }),
        .O({\NLW_VGA_R_reg[7]_i_80_O_UNCONNECTED [3],\VGA_R_reg[7]_i_80_n_5 ,\VGA_R_reg[7]_i_80_n_6 ,\VGA_R_reg[7]_i_80_n_7 }),
        .S({\VGA_R[7]_i_183_n_0 ,\VGA_R[7]_i_184_n_0 ,\VGA_R[7]_i_185_n_0 ,\VGA_R[7]_i_186_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_81 
       (.CI(1'b0),
        .CO({\VGA_R_reg[7]_i_81_n_0 ,\VGA_R_reg[7]_i_81_n_1 ,\VGA_R_reg[7]_i_81_n_2 ,\VGA_R_reg[7]_i_81_n_3 }),
        .CYINIT(\VGA_R_reg[7]_i_181_n_0 ),
        .DI({\VGA_R_reg[7]_i_182_n_5 ,\VGA_R_reg[7]_i_182_n_6 ,\VGA_R_reg[7]_i_181_n_0 ,\VGA_R[7]_i_187_n_0 }),
        .O({\VGA_R_reg[7]_i_81_n_4 ,\VGA_R_reg[7]_i_81_n_5 ,\VGA_R_reg[7]_i_81_n_6 ,\VGA_R_reg[7]_i_81_n_7 }),
        .S({\VGA_R[7]_i_188_n_0 ,\VGA_R[7]_i_189_n_0 ,\VGA_R[7]_i_190_n_0 ,\VGA_R[7]_i_191_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_92 
       (.CI(\VGA_R_reg[7]_i_203_n_0 ),
        .CO({\VGA_R_reg[7]_i_92_n_0 ,\VGA_R_reg[7]_i_92_n_1 ,\VGA_R_reg[7]_i_92_n_2 ,\VGA_R_reg[7]_i_92_n_3 }),
        .CYINIT(1'b0),
        .DI({\VGA_R_reg[7]_i_93_n_3 ,\VGA_R_reg[7]_i_204_n_5 ,\VGA_R_reg[7]_i_204_n_6 ,\VGA_R[7]_i_205_n_0 }),
        .O({\NLW_VGA_R_reg[7]_i_92_O_UNCONNECTED [3],\VGA_R_reg[7]_i_92_n_5 ,\VGA_R_reg[7]_i_92_n_6 ,\VGA_R_reg[7]_i_92_n_7 }),
        .S({\VGA_R[7]_i_206_n_0 ,\VGA_R[7]_i_207_n_0 ,\VGA_R[7]_i_208_n_0 ,\VGA_R[7]_i_209_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_93 
       (.CI(\VGA_R_reg[7]_i_204_n_0 ),
        .CO({\NLW_VGA_R_reg[7]_i_93_CO_UNCONNECTED [3:1],\VGA_R_reg[7]_i_93_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(\NLW_VGA_R_reg[7]_i_93_O_UNCONNECTED [3:0]),
        .S({1'b0,1'b0,1'b0,\VGA_R[7]_i_210_n_0 }));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-13 {cell *THIS*}}" *) 
  DSP48E1 #(
    .ACASCREG(0),
    .ADREG(1),
    .ALUMODEREG(0),
    .AREG(0),
    .AUTORESET_PATDET("NO_RESET"),
    .A_INPUT("DIRECT"),
    .BCASCREG(0),
    .BREG(0),
    .B_INPUT("DIRECT"),
    .CARRYINREG(0),
    .CARRYINSELREG(0),
    .CREG(1),
    .DREG(1),
    .INMODEREG(0),
    .MASK(48'h3FFFFFFFFFFF),
    .MREG(0),
    .OPMODEREG(0),
    .PATTERN(48'h000000000000),
    .PREG(0),
    .SEL_MASK("MASK"),
    .SEL_PATTERN("PATTERN"),
    .USE_DPORT("FALSE"),
    .USE_MULT("MULTIPLY"),
    .USE_PATTERN_DETECT("NO_PATDET"),
    .USE_SIMD("ONE48")) 
    pattern_b1
       (.A({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,p_1_in}),
        .ACIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .ACOUT(NLW_pattern_b1_ACOUT_UNCONNECTED[29:0]),
        .ALUMODE({1'b0,1'b0,1'b0,1'b0}),
        .B({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1}),
        .BCIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .BCOUT(NLW_pattern_b1_BCOUT_UNCONNECTED[17:0]),
        .C({1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1}),
        .CARRYCASCIN(1'b0),
        .CARRYCASCOUT(NLW_pattern_b1_CARRYCASCOUT_UNCONNECTED),
        .CARRYIN(1'b0),
        .CARRYINSEL({1'b0,1'b0,1'b0}),
        .CARRYOUT(NLW_pattern_b1_CARRYOUT_UNCONNECTED[3:0]),
        .CEA1(1'b0),
        .CEA2(1'b0),
        .CEAD(1'b0),
        .CEALUMODE(1'b0),
        .CEB1(1'b0),
        .CEB2(1'b0),
        .CEC(1'b0),
        .CECARRYIN(1'b0),
        .CECTRL(1'b0),
        .CED(1'b0),
        .CEINMODE(1'b0),
        .CEM(1'b0),
        .CEP(1'b0),
        .CLK(1'b0),
        .D({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .INMODE({1'b0,1'b0,1'b0,1'b0,1'b0}),
        .MULTSIGNIN(1'b0),
        .MULTSIGNOUT(NLW_pattern_b1_MULTSIGNOUT_UNCONNECTED),
        .OPMODE({1'b0,1'b0,1'b0,1'b0,1'b1,1'b0,1'b1}),
        .OVERFLOW(NLW_pattern_b1_OVERFLOW_UNCONNECTED),
        .P({NLW_pattern_b1_P_UNCONNECTED[47:19],pattern_b1_n_87,pattern_b1_n_88,pattern_b1_n_89,pattern_b1_n_90,pattern_b1_n_91,pattern_b1_n_92,pattern_b1_n_93,pattern_b1_n_94,pattern_b1_n_95,pattern_b1_n_96,pattern_b1_n_97,pattern_b1_n_98,pattern_b1_n_99,pattern_b1_n_100,pattern_b1_n_101,pattern_b1_n_102,pattern_b1_n_103,pattern_b1_n_104,pattern_b1_n_105}),
        .PATTERNBDETECT(NLW_pattern_b1_PATTERNBDETECT_UNCONNECTED),
        .PATTERNDETECT(NLW_pattern_b1_PATTERNDETECT_UNCONNECTED),
        .PCIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .PCOUT(NLW_pattern_b1_PCOUT_UNCONNECTED[47:0]),
        .RSTA(1'b0),
        .RSTALLCARRYIN(1'b0),
        .RSTALUMODE(1'b0),
        .RSTB(1'b0),
        .RSTC(1'b0),
        .RSTCTRL(1'b0),
        .RSTD(1'b0),
        .RSTINMODE(1'b0),
        .RSTM(1'b0),
        .RSTP(1'b0),
        .UNDERFLOW(NLW_pattern_b1_UNDERFLOW_UNCONNECTED));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-13 {cell *THIS*}}" *) 
  DSP48E1 #(
    .ACASCREG(0),
    .ADREG(1),
    .ALUMODEREG(0),
    .AREG(0),
    .AUTORESET_PATDET("NO_RESET"),
    .A_INPUT("DIRECT"),
    .BCASCREG(0),
    .BREG(0),
    .B_INPUT("DIRECT"),
    .CARRYINREG(0),
    .CARRYINSELREG(0),
    .CREG(1),
    .DREG(1),
    .INMODEREG(0),
    .MASK(48'h3FFFFFFFFFFF),
    .MREG(0),
    .OPMODEREG(0),
    .PATTERN(48'h000000000000),
    .PREG(0),
    .SEL_MASK("MASK"),
    .SEL_PATTERN("PATTERN"),
    .USE_DPORT("FALSE"),
    .USE_MULT("MULTIPLY"),
    .USE_PATTERN_DETECT("NO_PATDET"),
    .USE_SIMD("ONE48")) 
    pattern_b1__0
       (.A({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,A,disp_y}),
        .ACIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .ACOUT(NLW_pattern_b1__0_ACOUT_UNCONNECTED[29:0]),
        .ALUMODE({1'b0,1'b0,1'b0,1'b0}),
        .B({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1}),
        .BCIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .BCOUT(NLW_pattern_b1__0_BCOUT_UNCONNECTED[17:0]),
        .C({1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1}),
        .CARRYCASCIN(1'b0),
        .CARRYCASCOUT(NLW_pattern_b1__0_CARRYCASCOUT_UNCONNECTED),
        .CARRYIN(1'b0),
        .CARRYINSEL({1'b0,1'b0,1'b0}),
        .CARRYOUT(NLW_pattern_b1__0_CARRYOUT_UNCONNECTED[3:0]),
        .CEA1(1'b0),
        .CEA2(1'b0),
        .CEAD(1'b0),
        .CEALUMODE(1'b0),
        .CEB1(1'b0),
        .CEB2(1'b0),
        .CEC(1'b0),
        .CECARRYIN(1'b0),
        .CECTRL(1'b0),
        .CED(1'b0),
        .CEINMODE(1'b0),
        .CEM(1'b0),
        .CEP(1'b0),
        .CLK(1'b0),
        .D({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .INMODE({1'b0,1'b0,1'b0,1'b0,1'b0}),
        .MULTSIGNIN(1'b0),
        .MULTSIGNOUT(NLW_pattern_b1__0_MULTSIGNOUT_UNCONNECTED),
        .OPMODE({1'b0,1'b0,1'b0,1'b0,1'b1,1'b0,1'b1}),
        .OVERFLOW(NLW_pattern_b1__0_OVERFLOW_UNCONNECTED),
        .P({NLW_pattern_b1__0_P_UNCONNECTED[47:19],pattern_b1__0_n_87,pattern_b1__0_n_88,pattern_b1__0_n_89,pattern_b1__0_n_90,pattern_b1__0_n_91,pattern_b1__0_n_92,pattern_b1__0_n_93,pattern_b1__0_n_94,pattern_b1__0_n_95,pattern_b1__0_n_96,pattern_b1__0_n_97,pattern_b1__0_n_98,pattern_b1__0_n_99,pattern_b1__0_n_100,pattern_b1__0_n_101,pattern_b1__0_n_102,pattern_b1__0_n_103,pattern_b1__0_n_104,pattern_b1__0_n_105}),
        .PATTERNBDETECT(NLW_pattern_b1__0_PATTERNBDETECT_UNCONNECTED),
        .PATTERNDETECT(NLW_pattern_b1__0_PATTERNDETECT_UNCONNECTED),
        .PCIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .PCOUT(NLW_pattern_b1__0_PCOUT_UNCONNECTED[47:0]),
        .RSTA(1'b0),
        .RSTALLCARRYIN(1'b0),
        .RSTALUMODE(1'b0),
        .RSTB(1'b0),
        .RSTC(1'b0),
        .RSTCTRL(1'b0),
        .RSTD(1'b0),
        .RSTINMODE(1'b0),
        .RSTM(1'b0),
        .RSTP(1'b0),
        .UNDERFLOW(NLW_pattern_b1__0_UNDERFLOW_UNCONNECTED));
  LUT2 #(
    .INIT(4'h2)) 
    pattern_b1__0_i_13
       (.I0(timing_sel[1]),
        .I1(timing_sel[0]),
        .O(pattern_b1__0_i_13_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    pattern_b1_i_17
       (.I0(pattern_b1_i_18_n_6),
        .O(disp_enable2));
  CARRY4 pattern_b1_i_18
       (.CI(1'b0),
        .CO({pattern_b1_i_18_n_0,pattern_b1_i_18_n_1,pattern_b1_i_18_n_2,pattern_b1_i_18_n_3}),
        .CYINIT(1'b0),
        .DI({pattern_b1_i_25_n_0,pattern_b1_i_26_n_0,pattern_b1_i_27_n_0,1'b0}),
        .O({pattern_b1_i_18_n_4,pattern_b1_i_18_n_5,pattern_b1_i_18_n_6,NLW_pattern_b1_i_18_O_UNCONNECTED[0]}),
        .S({pattern_b1_i_28_n_0,pattern_b1_i_29_n_0,pattern_b1_i_30_n_0,1'b0}));
  CARRY4 pattern_b1_i_23
       (.CI(1'b0),
        .CO({pattern_b1_i_23_n_0,NLW_pattern_b1_i_23_CO_UNCONNECTED[2],pattern_b1_i_23_n_2,pattern_b1_i_23_n_3}),
        .CYINIT(HBACK),
        .DI({1'b0,pattern_b1_i_32_n_0,1'b1,pattern_b1_i_33_n_0}),
        .O({NLW_pattern_b1_i_23_O_UNCONNECTED[3],pattern_b1_i_23_n_5,pattern_b1_i_23_n_6,pattern_b1_i_23_n_7}),
        .S({1'b1,1'b0,pattern_b1_i_34_n_0,pattern_b1_i_35_n_0}));
  CARRY4 pattern_b1_i_24
       (.CI(pattern_b1_i_18_n_0),
        .CO({NLW_pattern_b1_i_24_CO_UNCONNECTED[3:1],pattern_b1_i_24_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(NLW_pattern_b1_i_24_O_UNCONNECTED[3:0]),
        .S({1'b0,1'b0,1'b0,1'b1}));
  LUT2 #(
    .INIT(4'h2)) 
    pattern_b1_i_25
       (.I0(timing_sel[1]),
        .I1(timing_sel[0]),
        .O(pattern_b1_i_25_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    pattern_b1_i_26
       (.I0(timing_sel[1]),
        .I1(timing_sel[0]),
        .O(pattern_b1_i_26_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    pattern_b1_i_27
       (.I0(timing_sel[1]),
        .I1(timing_sel[0]),
        .O(pattern_b1_i_27_n_0));
  LUT3 #(
    .INIT(8'h9A)) 
    pattern_b1_i_28
       (.I0(pattern_b1__0_i_13_n_0),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .O(pattern_b1_i_28_n_0));
  LUT3 #(
    .INIT(8'h40)) 
    pattern_b1_i_29
       (.I0(timing_sel[1]),
        .I1(timing_sel[0]),
        .I2(pattern_b1__0_i_13_n_0),
        .O(pattern_b1_i_29_n_0));
  LUT3 #(
    .INIT(8'h9A)) 
    pattern_b1_i_30
       (.I0(pattern_b1__0_i_13_n_0),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .O(pattern_b1_i_30_n_0));
  LUT3 #(
    .INIT(8'hBA)) 
    pattern_b1_i_31
       (.I0(pattern_b1__0_i_13_n_0),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .O(HBACK));
  LUT2 #(
    .INIT(4'h2)) 
    pattern_b1_i_32
       (.I0(timing_sel[1]),
        .I1(timing_sel[0]),
        .O(pattern_b1_i_32_n_0));
  LUT2 #(
    .INIT(4'hB)) 
    pattern_b1_i_33
       (.I0(timing_sel[0]),
        .I1(timing_sel[1]),
        .O(pattern_b1_i_33_n_0));
  LUT3 #(
    .INIT(8'hBA)) 
    pattern_b1_i_34
       (.I0(pattern_b1__0_i_13_n_0),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .O(pattern_b1_i_34_n_0));
  LUT2 #(
    .INIT(4'hB)) 
    pattern_b1_i_35
       (.I0(timing_sel[0]),
        .I1(timing_sel[1]),
        .O(pattern_b1_i_35_n_0));
  system_pattern_multi_0_0_syncgen_multi syncgen_multi
       (.A({A,disp_y}),
        .CLK(CLK),
        .CO(pattern_b1_i_23_n_0),
        .D(pattern_b),
        .DI(disp_enable2),
        .O({pattern_b1_i_18_n_4,pattern_b1_i_18_n_5,pattern_b1_i_18_n_6}),
        .P(data9[7:3]),
        .PCK(PCK),
        .RST(RST),
        .RST_0(syncgen_multi_n_23),
        .S({\VGA_R[7]_i_419_n_0 ,\VGA_R[7]_i_420_n_0 ,\VGA_R[7]_i_421_n_0 }),
        .SR(syncgen_multi_n_22),
        .SerialClk(SerialClk),
        .\VGA_B_reg[0] (\VGA_R[0]_i_2_n_0 ),
        .\VGA_B_reg[1] (\VGA_R[1]_i_2_n_0 ),
        .\VGA_B_reg[2] (\VGA_R[2]_i_2_n_0 ),
        .\VGA_B_reg[7] (\VGA_R[7]_i_34_n_0 ),
        .VGA_HS(VGA_HS),
        .\VGA_R[7]_i_330_0 (\VGA_R_reg[7]_i_127_n_0 ),
        .\VGA_R[7]_i_330_1 (\VGA_R[7]_i_129_n_0 ),
        .\VGA_R[7]_i_343_0 (\VGA_R[7]_i_319_n_0 ),
        .\VGA_R_reg[4]_i_5_0 (\VGA_R[7]_i_286_n_0 ),
        .\VGA_R_reg[5] (\VGA_R[5]_i_5_n_0 ),
        .\VGA_R_reg[5]_i_11_0 (\VGA_R_reg[5]_i_79_n_0 ),
        .\VGA_R_reg[5]_i_14_0 (\VGA_R_reg[5]_i_98_n_2 ),
        .\VGA_R_reg[5]_i_14_1 (\VGA_R_reg[5]_i_99_n_1 ),
        .\VGA_R_reg[5]_i_14_2 (\VGA_R_reg[5]_i_97_n_6 ),
        .\VGA_R_reg[5]_i_14_3 (\VGA_R_reg[5]_i_97_n_1 ),
        .\VGA_R_reg[5]_i_14_4 (\VGA_R[5]_i_96_n_0 ),
        .\VGA_R_reg[5]_i_31_0 (\VGA_R_reg[5]_i_78_n_6 ),
        .\VGA_R_reg[5]_i_31_1 (\VGA_R[5]_i_102_n_0 ),
        .\VGA_R_reg[5]_i_31_2 (\VGA_R[5]_i_101_n_0 ),
        .\VGA_R_reg[5]_i_31_3 ({\VGA_R_reg[5]_i_79_n_5 ,\VGA_R_reg[5]_i_79_n_6 ,\VGA_R_reg[5]_i_79_n_7 }),
        .\VGA_R_reg[5]_i_35_0 (\VGA_R_reg[5]_i_108_n_1 ),
        .\VGA_R_reg[5]_i_35_1 ({\VGA_R_reg[5]_i_108_n_6 ,\VGA_R_reg[5]_i_108_n_7 }),
        .\VGA_R_reg[6] (\VGA_R[7]_i_29_n_0 ),
        .\VGA_R_reg[6]_0 (\VGA_R[7]_i_25_n_0 ),
        .\VGA_R_reg[7]_i_16_0 (\VGA_R[7]_i_120_n_0 ),
        .\VGA_R_reg[7]_i_16_1 (\VGA_R[7]_i_119_n_0 ),
        .\VGA_R_reg[7]_i_231_0 (\VGA_R[7]_i_366_n_0 ),
        .\VGA_R_reg[7]_i_236_0 (\VGA_R_reg[7]_i_101_n_0 ),
        .\VGA_R_reg[7]_i_4_0 (\VGA_R[7]_i_60_n_0 ),
        .\VGA_R_reg[7]_i_70_0 ({\VGA_R_reg[7]_i_127_n_4 ,\VGA_R_reg[7]_i_127_n_5 ,\VGA_R_reg[7]_i_127_n_6 }),
        .\VGA_R_reg[7]_i_74_0 (\VGA_R[7]_i_131_n_0 ),
        .\VGA_R_reg[7]_i_99_0 ({\VGA_R_reg[7]_i_241_n_4 ,\VGA_R_reg[7]_i_241_n_5 ,\VGA_R_reg[7]_i_241_n_6 }),
        .\VGA_R_reg[7]_i_99_1 ({\VGA_R_reg[7]_i_101_n_6 ,\VGA_R_reg[7]_i_101_n_7 }),
        .\VGA_R_reg[7]_i_99_2 ({\VGA_R[7]_i_242_n_0 ,\VGA_R[7]_i_243_n_0 ,\VGA_R[7]_i_244_n_0 ,\VGA_R[7]_i_245_n_0 }),
        .VGA_VS(VGA_VS),
        .data2(data2),
        .data6(data6),
        .locked(locked),
        .p_1_in(p_1_in),
        .pattern_sel(pattern_sel),
        .\pattern_sel[3] (pattern_g),
        .\pattern_sel[3]_0 (pattern_r),
        .reconfig_done(reconfig_done),
        .reconfig_req(reconfig_req),
        .timing_sel(timing_sel),
        .timing_sel_imm(timing_sel_imm),
        .zp_sum(pattern_b1__0_i_13_n_0),
        .zp_sum0({pattern_b1_i_23_n_5,pattern_b1_i_23_n_6,pattern_b1_i_23_n_7}),
        .zp_sum0_0(pattern_b1_i_24_n_3));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-13 {cell *THIS*}}" *) 
  DSP48E1 #(
    .ACASCREG(0),
    .ADREG(1),
    .ALUMODEREG(0),
    .AREG(0),
    .AUTORESET_PATDET("NO_RESET"),
    .A_INPUT("DIRECT"),
    .BCASCREG(0),
    .BREG(0),
    .B_INPUT("DIRECT"),
    .CARRYINREG(0),
    .CARRYINSELREG(0),
    .CREG(0),
    .DREG(1),
    .INMODEREG(0),
    .MASK(48'h3FFFFFFFFFFF),
    .MREG(0),
    .OPMODEREG(0),
    .PATTERN(48'h000000000000),
    .PREG(0),
    .SEL_MASK("MASK"),
    .SEL_PATTERN("PATTERN"),
    .USE_DPORT("FALSE"),
    .USE_MULT("MULTIPLY"),
    .USE_PATTERN_DETECT("NO_PATDET"),
    .USE_SIMD("ONE48")) 
    zp_sum
       (.A({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,A,disp_y}),
        .ACIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .ACOUT(NLW_zp_sum_ACOUT_UNCONNECTED[29:0]),
        .ALUMODE({1'b0,1'b0,1'b0,1'b0}),
        .B({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,A,disp_y}),
        .BCIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .BCOUT(NLW_zp_sum_BCOUT_UNCONNECTED[17:0]),
        .C({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,zp_sum0_n_93,zp_sum0_n_94,zp_sum0_n_95,zp_sum0_n_96,zp_sum0_n_97,zp_sum0_n_98,zp_sum0_n_99,zp_sum0_n_100,zp_sum0_n_101,zp_sum0_n_102,zp_sum0_n_103,zp_sum0_n_104,zp_sum0_n_105}),
        .CARRYCASCIN(1'b0),
        .CARRYCASCOUT(NLW_zp_sum_CARRYCASCOUT_UNCONNECTED),
        .CARRYIN(1'b0),
        .CARRYINSEL({1'b0,1'b0,1'b0}),
        .CARRYOUT(NLW_zp_sum_CARRYOUT_UNCONNECTED[3:0]),
        .CEA1(1'b0),
        .CEA2(1'b0),
        .CEAD(1'b0),
        .CEALUMODE(1'b0),
        .CEB1(1'b0),
        .CEB2(1'b0),
        .CEC(1'b0),
        .CECARRYIN(1'b0),
        .CECTRL(1'b0),
        .CED(1'b0),
        .CEINMODE(1'b0),
        .CEM(1'b0),
        .CEP(1'b0),
        .CLK(1'b0),
        .D({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .INMODE({1'b0,1'b0,1'b0,1'b0,1'b0}),
        .MULTSIGNIN(1'b0),
        .MULTSIGNOUT(NLW_zp_sum_MULTSIGNOUT_UNCONNECTED),
        .OPMODE({1'b0,1'b1,1'b1,1'b0,1'b1,1'b0,1'b1}),
        .OVERFLOW(NLW_zp_sum_OVERFLOW_UNCONNECTED),
        .P({NLW_zp_sum_P_UNCONNECTED[47:13],data9,zp_sum_n_101,zp_sum_n_102,zp_sum_n_103,zp_sum_n_104,zp_sum_n_105}),
        .PATTERNBDETECT(NLW_zp_sum_PATTERNBDETECT_UNCONNECTED),
        .PATTERNDETECT(NLW_zp_sum_PATTERNDETECT_UNCONNECTED),
        .PCIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .PCOUT(NLW_zp_sum_PCOUT_UNCONNECTED[47:0]),
        .RSTA(1'b0),
        .RSTALLCARRYIN(1'b0),
        .RSTALUMODE(1'b0),
        .RSTB(1'b0),
        .RSTC(1'b0),
        .RSTCTRL(1'b0),
        .RSTD(1'b0),
        .RSTINMODE(1'b0),
        .RSTM(1'b0),
        .RSTP(1'b0),
        .UNDERFLOW(NLW_zp_sum_UNDERFLOW_UNCONNECTED));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-13 {cell *THIS*}}" *) 
  DSP48E1 #(
    .ACASCREG(0),
    .ADREG(1),
    .ALUMODEREG(0),
    .AREG(0),
    .AUTORESET_PATDET("NO_RESET"),
    .A_INPUT("DIRECT"),
    .BCASCREG(0),
    .BREG(0),
    .B_INPUT("DIRECT"),
    .CARRYINREG(0),
    .CARRYINSELREG(0),
    .CREG(1),
    .DREG(1),
    .INMODEREG(0),
    .MASK(48'h3FFFFFFFFFFF),
    .MREG(0),
    .OPMODEREG(0),
    .PATTERN(48'h000000000000),
    .PREG(0),
    .SEL_MASK("MASK"),
    .SEL_PATTERN("PATTERN"),
    .USE_DPORT("FALSE"),
    .USE_MULT("MULTIPLY"),
    .USE_PATTERN_DETECT("NO_PATDET"),
    .USE_SIMD("ONE48")) 
    zp_sum0
       (.A({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,p_1_in}),
        .ACIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .ACOUT(NLW_zp_sum0_ACOUT_UNCONNECTED[29:0]),
        .ALUMODE({1'b0,1'b0,1'b0,1'b0}),
        .B({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,p_1_in}),
        .BCIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .BCOUT(NLW_zp_sum0_BCOUT_UNCONNECTED[17:0]),
        .C({1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1}),
        .CARRYCASCIN(1'b0),
        .CARRYCASCOUT(NLW_zp_sum0_CARRYCASCOUT_UNCONNECTED),
        .CARRYIN(1'b0),
        .CARRYINSEL({1'b0,1'b0,1'b0}),
        .CARRYOUT(NLW_zp_sum0_CARRYOUT_UNCONNECTED[3:0]),
        .CEA1(1'b0),
        .CEA2(1'b0),
        .CEAD(1'b0),
        .CEALUMODE(1'b0),
        .CEB1(1'b0),
        .CEB2(1'b0),
        .CEC(1'b0),
        .CECARRYIN(1'b0),
        .CECTRL(1'b0),
        .CED(1'b0),
        .CEINMODE(1'b0),
        .CEM(1'b0),
        .CEP(1'b0),
        .CLK(1'b0),
        .D({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .INMODE({1'b0,1'b0,1'b0,1'b0,1'b0}),
        .MULTSIGNIN(1'b0),
        .MULTSIGNOUT(NLW_zp_sum0_MULTSIGNOUT_UNCONNECTED),
        .OPMODE({1'b0,1'b0,1'b0,1'b0,1'b1,1'b0,1'b1}),
        .OVERFLOW(NLW_zp_sum0_OVERFLOW_UNCONNECTED),
        .P({NLW_zp_sum0_P_UNCONNECTED[47:22],zp_sum0_n_84,zp_sum0_n_85,zp_sum0_n_86,zp_sum0_n_87,zp_sum0_n_88,zp_sum0_n_89,zp_sum0_n_90,zp_sum0_n_91,zp_sum0_n_92,zp_sum0_n_93,zp_sum0_n_94,zp_sum0_n_95,zp_sum0_n_96,zp_sum0_n_97,zp_sum0_n_98,zp_sum0_n_99,zp_sum0_n_100,zp_sum0_n_101,zp_sum0_n_102,zp_sum0_n_103,zp_sum0_n_104,zp_sum0_n_105}),
        .PATTERNBDETECT(NLW_zp_sum0_PATTERNBDETECT_UNCONNECTED),
        .PATTERNDETECT(NLW_zp_sum0_PATTERNDETECT_UNCONNECTED),
        .PCIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .PCOUT(NLW_zp_sum0_PCOUT_UNCONNECTED[47:0]),
        .RSTA(1'b0),
        .RSTALLCARRYIN(1'b0),
        .RSTALUMODE(1'b0),
        .RSTB(1'b0),
        .RSTC(1'b0),
        .RSTCTRL(1'b0),
        .RSTD(1'b0),
        .RSTINMODE(1'b0),
        .RSTM(1'b0),
        .RSTP(1'b0),
        .UNDERFLOW(NLW_zp_sum0_UNDERFLOW_UNCONNECTED));
endmodule

(* ORIG_REF_NAME = "pckgen_triple" *) 
module system_pattern_multi_0_0_pckgen_triple
   (locked,
    PCK,
    SerialClk,
    reconfig_done,
    timing_sel_imm,
    CLK,
    reconfig_req);
  output locked;
  output PCK;
  output SerialClk;
  output reconfig_done;
  input [1:0]timing_sel_imm;
  input CLK;
  input reconfig_req;

  wire CLK;
  wire CLKFBIN;
  wire CLKFBOUT;
  wire \FSM_sequential_state[1]_i_1_n_0 ;
  wire \FSM_sequential_state[2]_i_1_n_0 ;
  wire MMCM_RECONFIG_n_25;
  wire PCK;
  wire SerialClk;
  wire [6:0]drp_daddr;
  wire drp_den;
  wire [15:0]drp_di;
  wire [15:0]drp_do;
  wire drp_drdy;
  wire drp_dwe;
  wire iPCK;
  wire iSerialClk;
  wire load_pulse;
  wire load_pulse_reg_n_0;
  wire locked;
  wire mmcm_drp_inst_n_16;
  wire mmcm_rst;
  wire reconfig_done;
  wire reconfig_done_i_1_n_0;
  wire reconfig_req;
  wire sen_pulse;
  wire sen_pulse_reg_n_0;
  wire [2:0]state;
  wire [1:0]timing_sel_imm;
  wire NLW_MMCM_RECONFIG_CLKFBOUTB_UNCONNECTED;
  wire NLW_MMCM_RECONFIG_CLKFBSTOPPED_UNCONNECTED;
  wire NLW_MMCM_RECONFIG_CLKINSTOPPED_UNCONNECTED;
  wire NLW_MMCM_RECONFIG_CLKOUT0B_UNCONNECTED;
  wire NLW_MMCM_RECONFIG_CLKOUT1B_UNCONNECTED;
  wire NLW_MMCM_RECONFIG_CLKOUT2_UNCONNECTED;
  wire NLW_MMCM_RECONFIG_CLKOUT2B_UNCONNECTED;
  wire NLW_MMCM_RECONFIG_CLKOUT3_UNCONNECTED;
  wire NLW_MMCM_RECONFIG_CLKOUT3B_UNCONNECTED;
  wire NLW_MMCM_RECONFIG_CLKOUT4_UNCONNECTED;
  wire NLW_MMCM_RECONFIG_CLKOUT5_UNCONNECTED;
  wire NLW_MMCM_RECONFIG_CLKOUT6_UNCONNECTED;
  wire NLW_MMCM_RECONFIG_PSDONE_UNCONNECTED;

  (* BOX_TYPE = "PRIMITIVE" *) 
  BUFG BUFG_5X
       (.I(iSerialClk),
        .O(SerialClk));
  (* BOX_TYPE = "PRIMITIVE" *) 
  BUFG BUFG_FB
       (.I(CLKFBOUT),
        .O(CLKFBIN));
  (* BOX_TYPE = "PRIMITIVE" *) 
  BUFG BUFG_PCK
       (.I(iPCK),
        .O(PCK));
  (* SOFT_HLUTNM = "soft_lutpair20" *) 
  LUT4 #(
    .INIT(16'h98AA)) 
    \FSM_sequential_state[1]_i_1 
       (.I0(state[1]),
        .I1(state[2]),
        .I2(reconfig_req),
        .I3(state[0]),
        .O(\FSM_sequential_state[1]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair20" *) 
  LUT3 #(
    .INIT(8'hAC)) 
    \FSM_sequential_state[2]_i_1 
       (.I0(state[1]),
        .I1(state[2]),
        .I2(state[0]),
        .O(\FSM_sequential_state[2]_i_1_n_0 ));
  (* FSM_ENCODED_STATES = "S_BOOT_WAIT:000,S_IDLE:001,S_LOAD:010,S_SEN:011,S_WAIT_SRDY:100,S_DONE:101," *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_sequential_state_reg[0] 
       (.C(CLK),
        .CE(1'b1),
        .D(mmcm_drp_inst_n_16),
        .Q(state[0]),
        .R(1'b0));
  (* FSM_ENCODED_STATES = "S_BOOT_WAIT:000,S_IDLE:001,S_LOAD:010,S_SEN:011,S_WAIT_SRDY:100,S_DONE:101," *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_sequential_state_reg[1] 
       (.C(CLK),
        .CE(1'b1),
        .D(\FSM_sequential_state[1]_i_1_n_0 ),
        .Q(state[1]),
        .R(1'b0));
  (* FSM_ENCODED_STATES = "S_BOOT_WAIT:000,S_IDLE:001,S_LOAD:010,S_SEN:011,S_WAIT_SRDY:100,S_DONE:101," *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_sequential_state_reg[2] 
       (.C(CLK),
        .CE(1'b1),
        .D(\FSM_sequential_state[2]_i_1_n_0 ),
        .Q(state[2]),
        .R(1'b0));
  (* BOX_TYPE = "PRIMITIVE" *) 
  MMCME2_ADV #(
    .BANDWIDTH("OPTIMIZED"),
    .CLKFBOUT_MULT_F(17.625000),
    .CLKFBOUT_PHASE(0.000000),
    .CLKFBOUT_USE_FINE_PS("FALSE"),
    .CLKIN1_PERIOD(10.000000),
    .CLKIN2_PERIOD(0.000000),
    .CLKOUT0_DIVIDE_F(35.000000),
    .CLKOUT0_DUTY_CYCLE(0.500000),
    .CLKOUT0_PHASE(0.000000),
    .CLKOUT0_USE_FINE_PS("FALSE"),
    .CLKOUT1_DIVIDE(7),
    .CLKOUT1_DUTY_CYCLE(0.500000),
    .CLKOUT1_PHASE(0.000000),
    .CLKOUT1_USE_FINE_PS("FALSE"),
    .CLKOUT2_DIVIDE(1),
    .CLKOUT2_DUTY_CYCLE(0.500000),
    .CLKOUT2_PHASE(0.000000),
    .CLKOUT2_USE_FINE_PS("FALSE"),
    .CLKOUT3_DIVIDE(1),
    .CLKOUT3_DUTY_CYCLE(0.500000),
    .CLKOUT3_PHASE(0.000000),
    .CLKOUT3_USE_FINE_PS("FALSE"),
    .CLKOUT4_CASCADE("FALSE"),
    .CLKOUT4_DIVIDE(1),
    .CLKOUT4_DUTY_CYCLE(0.500000),
    .CLKOUT4_PHASE(0.000000),
    .CLKOUT4_USE_FINE_PS("FALSE"),
    .CLKOUT5_DIVIDE(1),
    .CLKOUT5_DUTY_CYCLE(0.500000),
    .CLKOUT5_PHASE(0.000000),
    .CLKOUT5_USE_FINE_PS("FALSE"),
    .CLKOUT6_DIVIDE(1),
    .CLKOUT6_DUTY_CYCLE(0.500000),
    .CLKOUT6_PHASE(0.000000),
    .CLKOUT6_USE_FINE_PS("FALSE"),
    .COMPENSATION("ZHOLD"),
    .DIVCLK_DIVIDE(2),
    .IS_CLKINSEL_INVERTED(1'b0),
    .IS_PSEN_INVERTED(1'b0),
    .IS_PSINCDEC_INVERTED(1'b0),
    .IS_PWRDWN_INVERTED(1'b0),
    .IS_RST_INVERTED(1'b0),
    .REF_JITTER1(0.010000),
    .REF_JITTER2(0.010000),
    .SS_EN("FALSE"),
    .SS_MODE("CENTER_HIGH"),
    .SS_MOD_PERIOD(10000),
    .STARTUP_WAIT("FALSE")) 
    MMCM_RECONFIG
       (.CLKFBIN(CLKFBIN),
        .CLKFBOUT(CLKFBOUT),
        .CLKFBOUTB(NLW_MMCM_RECONFIG_CLKFBOUTB_UNCONNECTED),
        .CLKFBSTOPPED(NLW_MMCM_RECONFIG_CLKFBSTOPPED_UNCONNECTED),
        .CLKIN1(CLK),
        .CLKIN2(1'b0),
        .CLKINSEL(1'b1),
        .CLKINSTOPPED(NLW_MMCM_RECONFIG_CLKINSTOPPED_UNCONNECTED),
        .CLKOUT0(iPCK),
        .CLKOUT0B(NLW_MMCM_RECONFIG_CLKOUT0B_UNCONNECTED),
        .CLKOUT1(iSerialClk),
        .CLKOUT1B(NLW_MMCM_RECONFIG_CLKOUT1B_UNCONNECTED),
        .CLKOUT2(NLW_MMCM_RECONFIG_CLKOUT2_UNCONNECTED),
        .CLKOUT2B(NLW_MMCM_RECONFIG_CLKOUT2B_UNCONNECTED),
        .CLKOUT3(NLW_MMCM_RECONFIG_CLKOUT3_UNCONNECTED),
        .CLKOUT3B(NLW_MMCM_RECONFIG_CLKOUT3B_UNCONNECTED),
        .CLKOUT4(NLW_MMCM_RECONFIG_CLKOUT4_UNCONNECTED),
        .CLKOUT5(NLW_MMCM_RECONFIG_CLKOUT5_UNCONNECTED),
        .CLKOUT6(NLW_MMCM_RECONFIG_CLKOUT6_UNCONNECTED),
        .DADDR(drp_daddr),
        .DCLK(CLK),
        .DEN(drp_den),
        .DI(drp_di),
        .DO({drp_do[15:9],MMCM_RECONFIG_n_25,drp_do[7:0]}),
        .DRDY(drp_drdy),
        .DWE(drp_dwe),
        .LOCKED(locked),
        .PSCLK(1'b0),
        .PSDONE(NLW_MMCM_RECONFIG_PSDONE_UNCONNECTED),
        .PSEN(1'b0),
        .PSINCDEC(1'b0),
        .PWRDWN(1'b0),
        .RST(mmcm_rst));
  LUT3 #(
    .INIT(8'h02)) 
    load_pulse_i_1
       (.I0(state[1]),
        .I1(state[2]),
        .I2(state[0]),
        .O(load_pulse));
  FDRE #(
    .INIT(1'b0)) 
    load_pulse_reg
       (.C(CLK),
        .CE(1'b1),
        .D(load_pulse),
        .Q(load_pulse_reg_n_0),
        .R(1'b0));
  system_pattern_multi_0_0_mmcm_drp mmcm_drp_inst
       (.CLK(CLK),
        .DADDR(drp_daddr),
        .DEN(drp_den),
        .DI(drp_di),
        .DO({drp_do[15:9],drp_do[7:0]}),
        .DWE(drp_dwe),
        .\FSM_sequential_state_reg[1] (mmcm_drp_inst_n_16),
        .drp_drdy(drp_drdy),
        .locked(locked),
        .mmcm_rst(mmcm_rst),
        .\ram_addr_reg[0]_0 (sen_pulse_reg_n_0),
        .\ram_reg[26][0]_0 (load_pulse_reg_n_0),
        .reconfig_req(reconfig_req),
        .state(state),
        .timing_sel_imm(timing_sel_imm));
  (* SOFT_HLUTNM = "soft_lutpair21" *) 
  LUT3 #(
    .INIT(8'h40)) 
    reconfig_done_i_1
       (.I0(state[1]),
        .I1(state[0]),
        .I2(state[2]),
        .O(reconfig_done_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    reconfig_done_reg
       (.C(CLK),
        .CE(1'b1),
        .D(reconfig_done_i_1_n_0),
        .Q(reconfig_done),
        .R(1'b0));
  (* SOFT_HLUTNM = "soft_lutpair21" *) 
  LUT3 #(
    .INIT(8'h40)) 
    sen_pulse_i_1
       (.I0(state[2]),
        .I1(state[0]),
        .I2(state[1]),
        .O(sen_pulse));
  FDRE #(
    .INIT(1'b0)) 
    sen_pulse_reg
       (.C(CLK),
        .CE(1'b1),
        .D(sen_pulse),
        .Q(sen_pulse_reg_n_0),
        .R(1'b0));
endmodule

(* ORIG_REF_NAME = "syncgen_multi" *) 
module system_pattern_multi_0_0_syncgen_multi
   (p_1_in,
    A,
    SR,
    RST_0,
    D,
    \pattern_sel[3] ,
    \pattern_sel[3]_0 ,
    locked,
    PCK,
    SerialClk,
    reconfig_done,
    VGA_HS,
    VGA_VS,
    timing_sel_imm,
    zp_sum,
    timing_sel,
    \VGA_R_reg[4]_i_5_0 ,
    O,
    CO,
    \VGA_R_reg[5]_i_35_0 ,
    \VGA_R_reg[5]_i_35_1 ,
    pattern_sel,
    \VGA_B_reg[7] ,
    zp_sum0,
    \VGA_R_reg[7]_i_4_0 ,
    RST,
    \VGA_R_reg[7]_i_231_0 ,
    zp_sum0_0,
    \VGA_R_reg[7]_i_16_0 ,
    \VGA_R_reg[7]_i_16_1 ,
    \VGA_B_reg[0] ,
    data2,
    \VGA_B_reg[1] ,
    \VGA_B_reg[2] ,
    \VGA_R_reg[5]_i_31_0 ,
    \VGA_R_reg[5]_i_11_0 ,
    \VGA_R_reg[5]_i_31_1 ,
    \VGA_R_reg[5]_i_31_2 ,
    \VGA_R_reg[5]_i_31_3 ,
    \VGA_R_reg[5]_i_14_0 ,
    \VGA_R_reg[5]_i_14_1 ,
    \VGA_R_reg[5]_i_14_2 ,
    \VGA_R_reg[5]_i_14_3 ,
    \VGA_R_reg[5]_i_14_4 ,
    data6,
    \VGA_R_reg[6] ,
    \VGA_R_reg[6]_0 ,
    P,
    \VGA_R_reg[5] ,
    \VGA_R_reg[7]_i_236_0 ,
    DI,
    \VGA_R_reg[7]_i_99_0 ,
    S,
    \VGA_R_reg[7]_i_99_1 ,
    \VGA_R_reg[7]_i_99_2 ,
    \VGA_R[7]_i_330_0 ,
    \VGA_R[7]_i_330_1 ,
    \VGA_R[7]_i_343_0 ,
    \VGA_R_reg[7]_i_70_0 ,
    \VGA_R_reg[7]_i_74_0 ,
    CLK,
    reconfig_req);
  output [10:0]p_1_in;
  output [10:0]A;
  output [0:0]SR;
  output RST_0;
  output [7:0]D;
  output [7:0]\pattern_sel[3] ;
  output [7:0]\pattern_sel[3]_0 ;
  output locked;
  output PCK;
  output SerialClk;
  output reconfig_done;
  output VGA_HS;
  output VGA_VS;
  input [1:0]timing_sel_imm;
  input zp_sum;
  input [1:0]timing_sel;
  input \VGA_R_reg[4]_i_5_0 ;
  input [2:0]O;
  input [0:0]CO;
  input [0:0]\VGA_R_reg[5]_i_35_0 ;
  input [1:0]\VGA_R_reg[5]_i_35_1 ;
  input [3:0]pattern_sel;
  input \VGA_B_reg[7] ;
  input [2:0]zp_sum0;
  input \VGA_R_reg[7]_i_4_0 ;
  input RST;
  input \VGA_R_reg[7]_i_231_0 ;
  input [0:0]zp_sum0_0;
  input \VGA_R_reg[7]_i_16_0 ;
  input \VGA_R_reg[7]_i_16_1 ;
  input \VGA_B_reg[0] ;
  input [7:0]data2;
  input \VGA_B_reg[1] ;
  input \VGA_B_reg[2] ;
  input [0:0]\VGA_R_reg[5]_i_31_0 ;
  input [0:0]\VGA_R_reg[5]_i_11_0 ;
  input \VGA_R_reg[5]_i_31_1 ;
  input \VGA_R_reg[5]_i_31_2 ;
  input [2:0]\VGA_R_reg[5]_i_31_3 ;
  input [0:0]\VGA_R_reg[5]_i_14_0 ;
  input [0:0]\VGA_R_reg[5]_i_14_1 ;
  input [0:0]\VGA_R_reg[5]_i_14_2 ;
  input [0:0]\VGA_R_reg[5]_i_14_3 ;
  input \VGA_R_reg[5]_i_14_4 ;
  input [7:0]data6;
  input \VGA_R_reg[6] ;
  input \VGA_R_reg[6]_0 ;
  input [4:0]P;
  input \VGA_R_reg[5] ;
  input [0:0]\VGA_R_reg[7]_i_236_0 ;
  input [0:0]DI;
  input [2:0]\VGA_R_reg[7]_i_99_0 ;
  input [2:0]S;
  input [1:0]\VGA_R_reg[7]_i_99_1 ;
  input [3:0]\VGA_R_reg[7]_i_99_2 ;
  input [0:0]\VGA_R[7]_i_330_0 ;
  input [0:0]\VGA_R[7]_i_330_1 ;
  input [0:0]\VGA_R[7]_i_343_0 ;
  input [2:0]\VGA_R_reg[7]_i_70_0 ;
  input [0:0]\VGA_R_reg[7]_i_74_0 ;
  input CLK;
  input reconfig_req;

  wire [10:0]A;
  wire CLK;
  wire [0:0]CO;
  wire [7:0]D;
  wire [0:0]DI;
  wire [7:0]FCNT;
  wire \FCNT[7]_i_1_n_0 ;
  wire \FCNT[7]_i_3_n_0 ;
  wire [10:0]HCNT;
  wire \HCNT[10]_i_1_n_0 ;
  wire \HCNT[10]_i_3_n_0 ;
  wire [2:0]O;
  wire [4:0]P;
  wire PCK;
  wire RST;
  wire RST_0;
  wire [2:0]S;
  wire [0:0]SR;
  wire SerialClk;
  wire [10:0]VCNT;
  wire VCNT0;
  wire \VCNT[10]_i_10_n_0 ;
  wire \VCNT[10]_i_11_n_0 ;
  wire \VCNT[10]_i_12_n_0 ;
  wire \VCNT[10]_i_13_n_0 ;
  wire \VCNT[10]_i_1_n_0 ;
  wire \VCNT[10]_i_5_n_0 ;
  wire \VCNT[10]_i_6_n_0 ;
  wire \VCNT[10]_i_7_n_0 ;
  wire \VCNT[10]_i_8_n_0 ;
  wire \VCNT[10]_i_9_n_0 ;
  wire \VCNT_reg[10]_i_2_n_1 ;
  wire \VCNT_reg[10]_i_2_n_2 ;
  wire \VCNT_reg[10]_i_2_n_3 ;
  wire \VCNT_reg[10]_i_4_n_1 ;
  wire \VCNT_reg[10]_i_4_n_2 ;
  wire \VCNT_reg[10]_i_4_n_3 ;
  wire \VGA_B[4]_i_2_n_0 ;
  wire \VGA_B[5]_i_2_n_0 ;
  wire \VGA_B[6]_i_2_n_0 ;
  wire \VGA_B[7]_i_10_n_0 ;
  wire \VGA_B[7]_i_11_n_0 ;
  wire \VGA_B[7]_i_12_n_0 ;
  wire \VGA_B[7]_i_14_n_0 ;
  wire \VGA_B[7]_i_15_n_0 ;
  wire \VGA_B[7]_i_16_n_0 ;
  wire \VGA_B[7]_i_17_n_0 ;
  wire \VGA_B[7]_i_18_n_0 ;
  wire \VGA_B[7]_i_19_n_0 ;
  wire \VGA_B[7]_i_20_n_0 ;
  wire \VGA_B[7]_i_21_n_0 ;
  wire \VGA_B[7]_i_22_n_0 ;
  wire \VGA_B[7]_i_23_n_0 ;
  wire \VGA_B[7]_i_24_n_0 ;
  wire \VGA_B[7]_i_25_n_0 ;
  wire \VGA_B[7]_i_26_n_0 ;
  wire \VGA_B[7]_i_27_n_0 ;
  wire \VGA_B[7]_i_29_n_0 ;
  wire \VGA_B[7]_i_2_n_0 ;
  wire \VGA_B[7]_i_31_n_0 ;
  wire \VGA_B[7]_i_33_n_0 ;
  wire \VGA_B[7]_i_3_n_0 ;
  wire \VGA_B[7]_i_4_n_0 ;
  wire \VGA_B[7]_i_5_n_0 ;
  wire \VGA_B[7]_i_9_n_0 ;
  wire \VGA_B_reg[0] ;
  wire \VGA_B_reg[1] ;
  wire \VGA_B_reg[2] ;
  wire \VGA_B_reg[7] ;
  wire \VGA_B_reg[7]_i_13_n_0 ;
  wire \VGA_B_reg[7]_i_13_n_1 ;
  wire \VGA_B_reg[7]_i_13_n_2 ;
  wire \VGA_B_reg[7]_i_13_n_3 ;
  wire \VGA_B_reg[7]_i_28_n_7 ;
  wire \VGA_B_reg[7]_i_30_n_7 ;
  wire \VGA_B_reg[7]_i_32_n_7 ;
  wire \VGA_B_reg[7]_i_6_n_0 ;
  wire \VGA_B_reg[7]_i_6_n_1 ;
  wire \VGA_B_reg[7]_i_6_n_2 ;
  wire \VGA_B_reg[7]_i_6_n_3 ;
  wire \VGA_B_reg[7]_i_7_n_1 ;
  wire \VGA_B_reg[7]_i_7_n_2 ;
  wire \VGA_B_reg[7]_i_7_n_3 ;
  wire \VGA_B_reg[7]_i_8_n_0 ;
  wire \VGA_B_reg[7]_i_8_n_1 ;
  wire \VGA_B_reg[7]_i_8_n_2 ;
  wire \VGA_B_reg[7]_i_8_n_3 ;
  wire \VGA_G[6]_i_2_n_0 ;
  wire \VGA_G[7]_i_10_n_0 ;
  wire \VGA_G[7]_i_11_n_0 ;
  wire \VGA_G[7]_i_12_n_0 ;
  wire \VGA_G[7]_i_13_n_0 ;
  wire \VGA_G[7]_i_14_n_0 ;
  wire \VGA_G[7]_i_15_n_0 ;
  wire \VGA_G[7]_i_16_n_0 ;
  wire \VGA_G[7]_i_17_n_0 ;
  wire \VGA_G[7]_i_18_n_0 ;
  wire \VGA_G[7]_i_19_n_0 ;
  wire \VGA_G[7]_i_20_n_0 ;
  wire \VGA_G[7]_i_21_n_0 ;
  wire \VGA_G[7]_i_2_n_0 ;
  wire \VGA_G[7]_i_3_n_0 ;
  wire \VGA_G[7]_i_4_n_0 ;
  wire \VGA_G[7]_i_5_n_0 ;
  wire \VGA_G[7]_i_9_n_0 ;
  wire \VGA_G_reg[7]_i_6_n_0 ;
  wire \VGA_G_reg[7]_i_6_n_1 ;
  wire \VGA_G_reg[7]_i_6_n_2 ;
  wire \VGA_G_reg[7]_i_6_n_3 ;
  wire \VGA_G_reg[7]_i_6_n_5 ;
  wire \VGA_G_reg[7]_i_6_n_6 ;
  wire \VGA_G_reg[7]_i_6_n_7 ;
  wire \VGA_G_reg[7]_i_7_n_1 ;
  wire \VGA_G_reg[7]_i_7_n_2 ;
  wire \VGA_G_reg[7]_i_7_n_3 ;
  wire \VGA_G_reg[7]_i_7_n_5 ;
  wire \VGA_G_reg[7]_i_7_n_6 ;
  wire \VGA_G_reg[7]_i_7_n_7 ;
  wire \VGA_G_reg[7]_i_8_n_0 ;
  wire \VGA_G_reg[7]_i_8_n_1 ;
  wire \VGA_G_reg[7]_i_8_n_2 ;
  wire \VGA_G_reg[7]_i_8_n_3 ;
  wire \VGA_G_reg[7]_i_8_n_4 ;
  wire \VGA_G_reg[7]_i_8_n_5 ;
  wire \VGA_G_reg[7]_i_8_n_6 ;
  wire \VGA_G_reg[7]_i_8_n_7 ;
  wire VGA_HS;
  wire VGA_HS0;
  wire VGA_HS1;
  wire VGA_HS_i_10_n_0;
  wire VGA_HS_i_11_n_0;
  wire VGA_HS_i_12_n_0;
  wire VGA_HS_i_1_n_0;
  wire VGA_HS_i_2_n_0;
  wire VGA_HS_i_5_n_0;
  wire VGA_HS_i_6_n_0;
  wire VGA_HS_i_7_n_0;
  wire VGA_HS_i_8_n_0;
  wire VGA_HS_i_9_n_0;
  wire VGA_HS_reg_i_3_n_1;
  wire VGA_HS_reg_i_3_n_2;
  wire VGA_HS_reg_i_3_n_3;
  wire VGA_HS_reg_i_4_n_1;
  wire VGA_HS_reg_i_4_n_2;
  wire VGA_HS_reg_i_4_n_3;
  wire \VGA_R[0]_i_3_n_0 ;
  wire \VGA_R[0]_i_4_n_0 ;
  wire \VGA_R[1]_i_3_n_0 ;
  wire \VGA_R[1]_i_4_n_0 ;
  wire \VGA_R[2]_i_3_n_0 ;
  wire \VGA_R[2]_i_4_n_0 ;
  wire \VGA_R[3]_i_2_n_0 ;
  wire \VGA_R[3]_i_3_n_0 ;
  wire \VGA_R[3]_i_4_n_0 ;
  wire \VGA_R[3]_i_5_n_0 ;
  wire \VGA_R[4]_i_10_n_0 ;
  wire \VGA_R[4]_i_11_n_0 ;
  wire \VGA_R[4]_i_22_n_0 ;
  wire \VGA_R[4]_i_23_n_0 ;
  wire \VGA_R[4]_i_24_n_0 ;
  wire \VGA_R[4]_i_25_n_0 ;
  wire \VGA_R[4]_i_26_n_0 ;
  wire \VGA_R[4]_i_27_n_0 ;
  wire \VGA_R[4]_i_28_n_0 ;
  wire \VGA_R[4]_i_29_n_0 ;
  wire \VGA_R[4]_i_2_n_0 ;
  wire \VGA_R[4]_i_3_n_0 ;
  wire \VGA_R[4]_i_4_n_0 ;
  wire \VGA_R[4]_i_9_n_0 ;
  wire \VGA_R[5]_i_15_n_0 ;
  wire \VGA_R[5]_i_16_n_0 ;
  wire \VGA_R[5]_i_17_n_0 ;
  wire \VGA_R[5]_i_19_n_0 ;
  wire \VGA_R[5]_i_20_n_0 ;
  wire \VGA_R[5]_i_2_n_0 ;
  wire \VGA_R[5]_i_32_n_0 ;
  wire \VGA_R[5]_i_33_n_0 ;
  wire \VGA_R[5]_i_34_n_0 ;
  wire \VGA_R[5]_i_36_n_0 ;
  wire \VGA_R[5]_i_37_n_0 ;
  wire \VGA_R[5]_i_38_n_0 ;
  wire \VGA_R[5]_i_39_n_0 ;
  wire \VGA_R[5]_i_3_n_0 ;
  wire \VGA_R[5]_i_41_n_0 ;
  wire \VGA_R[5]_i_42_n_0 ;
  wire \VGA_R[5]_i_43_n_0 ;
  wire \VGA_R[5]_i_44_n_0 ;
  wire \VGA_R[5]_i_45_n_0 ;
  wire \VGA_R[5]_i_46_n_0 ;
  wire \VGA_R[5]_i_47_n_0 ;
  wire \VGA_R[5]_i_48_n_0 ;
  wire \VGA_R[5]_i_49_n_0 ;
  wire \VGA_R[5]_i_4_n_0 ;
  wire \VGA_R[5]_i_50_n_0 ;
  wire \VGA_R[5]_i_51_n_0 ;
  wire \VGA_R[5]_i_52_n_0 ;
  wire \VGA_R[5]_i_53_n_0 ;
  wire \VGA_R[5]_i_54_n_0 ;
  wire \VGA_R[5]_i_55_n_0 ;
  wire \VGA_R[5]_i_56_n_0 ;
  wire \VGA_R[5]_i_57_n_0 ;
  wire \VGA_R[5]_i_58_n_0 ;
  wire \VGA_R[5]_i_59_n_0 ;
  wire \VGA_R[5]_i_6_n_0 ;
  wire \VGA_R[5]_i_70_n_0 ;
  wire \VGA_R[5]_i_71_n_0 ;
  wire \VGA_R[5]_i_72_n_0 ;
  wire \VGA_R[5]_i_73_n_0 ;
  wire \VGA_R[5]_i_74_n_0 ;
  wire \VGA_R[5]_i_75_n_0 ;
  wire \VGA_R[5]_i_76_n_0 ;
  wire \VGA_R[5]_i_77_n_0 ;
  wire \VGA_R[5]_i_80_n_0 ;
  wire \VGA_R[5]_i_81_n_0 ;
  wire \VGA_R[5]_i_82_n_0 ;
  wire \VGA_R[5]_i_83_n_0 ;
  wire \VGA_R[5]_i_84_n_0 ;
  wire \VGA_R[5]_i_85_n_0 ;
  wire \VGA_R[5]_i_86_n_0 ;
  wire \VGA_R[5]_i_87_n_0 ;
  wire \VGA_R[5]_i_88_n_0 ;
  wire \VGA_R[5]_i_89_n_0 ;
  wire \VGA_R[5]_i_90_n_0 ;
  wire \VGA_R[5]_i_91_n_0 ;
  wire \VGA_R[5]_i_92_n_0 ;
  wire \VGA_R[5]_i_93_n_0 ;
  wire \VGA_R[5]_i_94_n_0 ;
  wire \VGA_R[5]_i_95_n_0 ;
  wire \VGA_R[6]_i_2_n_0 ;
  wire \VGA_R[6]_i_3_n_0 ;
  wire \VGA_R[6]_i_4_n_0 ;
  wire \VGA_R[7]_i_103_n_0 ;
  wire \VGA_R[7]_i_104_n_0 ;
  wire \VGA_R[7]_i_106_n_0 ;
  wire \VGA_R[7]_i_107_n_0 ;
  wire \VGA_R[7]_i_108_n_0 ;
  wire \VGA_R[7]_i_10_n_0 ;
  wire \VGA_R[7]_i_123_n_0 ;
  wire \VGA_R[7]_i_124_n_0 ;
  wire \VGA_R[7]_i_125_n_0 ;
  wire \VGA_R[7]_i_126_n_0 ;
  wire \VGA_R[7]_i_128_n_0 ;
  wire \VGA_R[7]_i_12_n_0 ;
  wire \VGA_R[7]_i_132_n_0 ;
  wire \VGA_R[7]_i_133_n_0 ;
  wire \VGA_R[7]_i_134_n_0 ;
  wire \VGA_R[7]_i_135_n_0 ;
  wire \VGA_R[7]_i_138_n_0 ;
  wire \VGA_R[7]_i_139_n_0 ;
  wire \VGA_R[7]_i_13_n_0 ;
  wire \VGA_R[7]_i_140_n_0 ;
  wire \VGA_R[7]_i_141_n_0 ;
  wire \VGA_R[7]_i_144_n_0 ;
  wire \VGA_R[7]_i_145_n_0 ;
  wire \VGA_R[7]_i_146_n_0 ;
  wire \VGA_R[7]_i_147_n_0 ;
  wire \VGA_R[7]_i_149_n_0 ;
  wire \VGA_R[7]_i_14_n_0 ;
  wire \VGA_R[7]_i_150_n_0 ;
  wire \VGA_R[7]_i_151_n_0 ;
  wire \VGA_R[7]_i_152_n_0 ;
  wire \VGA_R[7]_i_153_n_0 ;
  wire \VGA_R[7]_i_154_n_0 ;
  wire \VGA_R[7]_i_155_n_0 ;
  wire \VGA_R[7]_i_156_n_0 ;
  wire \VGA_R[7]_i_159_n_0 ;
  wire \VGA_R[7]_i_15_n_0 ;
  wire \VGA_R[7]_i_160_n_0 ;
  wire \VGA_R[7]_i_161_n_0 ;
  wire \VGA_R[7]_i_162_n_0 ;
  wire \VGA_R[7]_i_164_n_0 ;
  wire \VGA_R[7]_i_165_n_0 ;
  wire \VGA_R[7]_i_166_n_0 ;
  wire \VGA_R[7]_i_167_n_0 ;
  wire \VGA_R[7]_i_168_n_0 ;
  wire \VGA_R[7]_i_169_n_0 ;
  wire \VGA_R[7]_i_170_n_0 ;
  wire \VGA_R[7]_i_171_n_0 ;
  wire \VGA_R[7]_i_172_n_0 ;
  wire \VGA_R[7]_i_173_n_0 ;
  wire \VGA_R[7]_i_174_n_0 ;
  wire \VGA_R[7]_i_175_n_0 ;
  wire \VGA_R[7]_i_17_n_0 ;
  wire \VGA_R[7]_i_18_n_0 ;
  wire \VGA_R[7]_i_193_n_0 ;
  wire \VGA_R[7]_i_194_n_0 ;
  wire \VGA_R[7]_i_195_n_0 ;
  wire \VGA_R[7]_i_196_n_0 ;
  wire \VGA_R[7]_i_197_n_0 ;
  wire \VGA_R[7]_i_198_n_0 ;
  wire \VGA_R[7]_i_199_n_0 ;
  wire \VGA_R[7]_i_19_n_0 ;
  wire \VGA_R[7]_i_200_n_0 ;
  wire \VGA_R[7]_i_201_n_0 ;
  wire \VGA_R[7]_i_202_n_0 ;
  wire \VGA_R[7]_i_20_n_0 ;
  wire \VGA_R[7]_i_212_n_0 ;
  wire \VGA_R[7]_i_213_n_0 ;
  wire \VGA_R[7]_i_214_n_0 ;
  wire \VGA_R[7]_i_215_n_0 ;
  wire \VGA_R[7]_i_217_n_0 ;
  wire \VGA_R[7]_i_218_n_0 ;
  wire \VGA_R[7]_i_219_n_0 ;
  wire \VGA_R[7]_i_220_n_0 ;
  wire \VGA_R[7]_i_222_n_0 ;
  wire \VGA_R[7]_i_223_n_0 ;
  wire \VGA_R[7]_i_224_n_0 ;
  wire \VGA_R[7]_i_225_n_0 ;
  wire \VGA_R[7]_i_227_n_0 ;
  wire \VGA_R[7]_i_228_n_0 ;
  wire \VGA_R[7]_i_229_n_0 ;
  wire \VGA_R[7]_i_22_n_0 ;
  wire \VGA_R[7]_i_230_n_0 ;
  wire \VGA_R[7]_i_232_n_0 ;
  wire \VGA_R[7]_i_233_n_0 ;
  wire \VGA_R[7]_i_234_n_0 ;
  wire \VGA_R[7]_i_235_n_0 ;
  wire \VGA_R[7]_i_237_n_0 ;
  wire \VGA_R[7]_i_238_n_0 ;
  wire \VGA_R[7]_i_239_n_0 ;
  wire \VGA_R[7]_i_23_n_0 ;
  wire \VGA_R[7]_i_240_n_0 ;
  wire \VGA_R[7]_i_24_n_0 ;
  wire \VGA_R[7]_i_250_n_0 ;
  wire \VGA_R[7]_i_251_n_0 ;
  wire \VGA_R[7]_i_252_n_0 ;
  wire \VGA_R[7]_i_253_n_0 ;
  wire \VGA_R[7]_i_254_n_0 ;
  wire \VGA_R[7]_i_255_n_0 ;
  wire \VGA_R[7]_i_256_n_0 ;
  wire \VGA_R[7]_i_257_n_0 ;
  wire \VGA_R[7]_i_258_n_0 ;
  wire \VGA_R[7]_i_259_n_0 ;
  wire \VGA_R[7]_i_260_n_0 ;
  wire \VGA_R[7]_i_261_n_0 ;
  wire \VGA_R[7]_i_262_n_0 ;
  wire \VGA_R[7]_i_263_n_0 ;
  wire \VGA_R[7]_i_264_n_0 ;
  wire \VGA_R[7]_i_265_n_0 ;
  wire \VGA_R[7]_i_266_n_0 ;
  wire \VGA_R[7]_i_267_n_0 ;
  wire \VGA_R[7]_i_268_n_0 ;
  wire \VGA_R[7]_i_269_n_0 ;
  wire \VGA_R[7]_i_26_n_0 ;
  wire \VGA_R[7]_i_27_n_0 ;
  wire \VGA_R[7]_i_287_n_0 ;
  wire \VGA_R[7]_i_288_n_0 ;
  wire \VGA_R[7]_i_289_n_0 ;
  wire \VGA_R[7]_i_28_n_0 ;
  wire \VGA_R[7]_i_290_n_0 ;
  wire \VGA_R[7]_i_291_n_0 ;
  wire \VGA_R[7]_i_292_n_0 ;
  wire \VGA_R[7]_i_293_n_0 ;
  wire \VGA_R[7]_i_294_n_0 ;
  wire \VGA_R[7]_i_295_n_0 ;
  wire \VGA_R[7]_i_296_n_0 ;
  wire \VGA_R[7]_i_297_n_0 ;
  wire \VGA_R[7]_i_298_n_0 ;
  wire \VGA_R[7]_i_299_n_0 ;
  wire \VGA_R[7]_i_300_n_0 ;
  wire \VGA_R[7]_i_301_n_0 ;
  wire \VGA_R[7]_i_302_n_0 ;
  wire \VGA_R[7]_i_303_n_0 ;
  wire \VGA_R[7]_i_304_n_0 ;
  wire \VGA_R[7]_i_305_n_0 ;
  wire \VGA_R[7]_i_306_n_0 ;
  wire \VGA_R[7]_i_307_n_0 ;
  wire \VGA_R[7]_i_308_n_0 ;
  wire \VGA_R[7]_i_318_n_0 ;
  wire \VGA_R[7]_i_31_n_0 ;
  wire \VGA_R[7]_i_320_n_0 ;
  wire \VGA_R[7]_i_321_n_0 ;
  wire \VGA_R[7]_i_322_n_0 ;
  wire \VGA_R[7]_i_323_n_0 ;
  wire \VGA_R[7]_i_324_n_0 ;
  wire \VGA_R[7]_i_325_n_0 ;
  wire \VGA_R[7]_i_326_n_0 ;
  wire \VGA_R[7]_i_327_n_0 ;
  wire \VGA_R[7]_i_328_n_0 ;
  wire \VGA_R[7]_i_329_n_0 ;
  wire \VGA_R[7]_i_32_n_0 ;
  wire [0:0]\VGA_R[7]_i_330_0 ;
  wire [0:0]\VGA_R[7]_i_330_1 ;
  wire \VGA_R[7]_i_330_n_0 ;
  wire \VGA_R[7]_i_331_n_0 ;
  wire \VGA_R[7]_i_332_n_0 ;
  wire \VGA_R[7]_i_333_n_0 ;
  wire \VGA_R[7]_i_334_n_0 ;
  wire \VGA_R[7]_i_335_n_0 ;
  wire \VGA_R[7]_i_336_n_0 ;
  wire \VGA_R[7]_i_337_n_0 ;
  wire \VGA_R[7]_i_338_n_0 ;
  wire \VGA_R[7]_i_339_n_0 ;
  wire \VGA_R[7]_i_340_n_0 ;
  wire \VGA_R[7]_i_341_n_0 ;
  wire \VGA_R[7]_i_342_n_0 ;
  wire [0:0]\VGA_R[7]_i_343_0 ;
  wire \VGA_R[7]_i_343_n_0 ;
  wire \VGA_R[7]_i_344_n_0 ;
  wire \VGA_R[7]_i_345_n_0 ;
  wire \VGA_R[7]_i_346_n_0 ;
  wire \VGA_R[7]_i_347_n_0 ;
  wire \VGA_R[7]_i_348_n_0 ;
  wire \VGA_R[7]_i_349_n_0 ;
  wire \VGA_R[7]_i_350_n_0 ;
  wire \VGA_R[7]_i_351_n_0 ;
  wire \VGA_R[7]_i_352_n_0 ;
  wire \VGA_R[7]_i_353_n_0 ;
  wire \VGA_R[7]_i_354_n_0 ;
  wire \VGA_R[7]_i_355_n_0 ;
  wire \VGA_R[7]_i_356_n_0 ;
  wire \VGA_R[7]_i_357_n_0 ;
  wire \VGA_R[7]_i_358_n_0 ;
  wire \VGA_R[7]_i_359_n_0 ;
  wire \VGA_R[7]_i_35_n_0 ;
  wire \VGA_R[7]_i_360_n_0 ;
  wire \VGA_R[7]_i_361_n_0 ;
  wire \VGA_R[7]_i_362_n_0 ;
  wire \VGA_R[7]_i_363_n_0 ;
  wire \VGA_R[7]_i_364_n_0 ;
  wire \VGA_R[7]_i_36_n_0 ;
  wire \VGA_R[7]_i_37_n_0 ;
  wire \VGA_R[7]_i_393_n_0 ;
  wire \VGA_R[7]_i_394_n_0 ;
  wire \VGA_R[7]_i_395_n_0 ;
  wire \VGA_R[7]_i_396_n_0 ;
  wire \VGA_R[7]_i_397_n_0 ;
  wire \VGA_R[7]_i_398_n_0 ;
  wire \VGA_R[7]_i_399_n_0 ;
  wire \VGA_R[7]_i_400_n_0 ;
  wire \VGA_R[7]_i_401_n_0 ;
  wire \VGA_R[7]_i_402_n_0 ;
  wire \VGA_R[7]_i_403_n_0 ;
  wire \VGA_R[7]_i_404_n_0 ;
  wire \VGA_R[7]_i_405_n_0 ;
  wire \VGA_R[7]_i_406_n_0 ;
  wire \VGA_R[7]_i_407_n_0 ;
  wire \VGA_R[7]_i_408_n_0 ;
  wire \VGA_R[7]_i_409_n_0 ;
  wire \VGA_R[7]_i_410_n_0 ;
  wire \VGA_R[7]_i_411_n_0 ;
  wire \VGA_R[7]_i_412_n_0 ;
  wire \VGA_R[7]_i_413_n_0 ;
  wire \VGA_R[7]_i_414_n_0 ;
  wire \VGA_R[7]_i_415_n_0 ;
  wire \VGA_R[7]_i_416_n_0 ;
  wire \VGA_R[7]_i_417_n_0 ;
  wire \VGA_R[7]_i_418_n_0 ;
  wire \VGA_R[7]_i_41_n_0 ;
  wire \VGA_R[7]_i_422_n_0 ;
  wire \VGA_R[7]_i_428_n_0 ;
  wire \VGA_R[7]_i_429_n_0 ;
  wire \VGA_R[7]_i_42_n_0 ;
  wire \VGA_R[7]_i_430_n_0 ;
  wire \VGA_R[7]_i_431_n_0 ;
  wire \VGA_R[7]_i_432_n_0 ;
  wire \VGA_R[7]_i_433_n_0 ;
  wire \VGA_R[7]_i_434_n_0 ;
  wire \VGA_R[7]_i_43_n_0 ;
  wire \VGA_R[7]_i_44_n_0 ;
  wire \VGA_R[7]_i_451_n_0 ;
  wire \VGA_R[7]_i_452_n_0 ;
  wire \VGA_R[7]_i_453_n_0 ;
  wire \VGA_R[7]_i_454_n_0 ;
  wire \VGA_R[7]_i_45_n_0 ;
  wire \VGA_R[7]_i_46_n_0 ;
  wire \VGA_R[7]_i_476_n_0 ;
  wire \VGA_R[7]_i_47_n_0 ;
  wire \VGA_R[7]_i_48_n_0 ;
  wire \VGA_R[7]_i_499_n_0 ;
  wire \VGA_R[7]_i_49_n_0 ;
  wire \VGA_R[7]_i_500_n_0 ;
  wire \VGA_R[7]_i_502_n_0 ;
  wire \VGA_R[7]_i_503_n_0 ;
  wire \VGA_R[7]_i_504_n_0 ;
  wire \VGA_R[7]_i_505_n_0 ;
  wire \VGA_R[7]_i_506_n_0 ;
  wire \VGA_R[7]_i_507_n_0 ;
  wire \VGA_R[7]_i_508_n_0 ;
  wire \VGA_R[7]_i_509_n_0 ;
  wire \VGA_R[7]_i_50_n_0 ;
  wire \VGA_R[7]_i_510_n_0 ;
  wire \VGA_R[7]_i_511_n_0 ;
  wire \VGA_R[7]_i_51_n_0 ;
  wire \VGA_R[7]_i_52_n_0 ;
  wire \VGA_R[7]_i_53_n_0 ;
  wire \VGA_R[7]_i_54_n_0 ;
  wire \VGA_R[7]_i_556_n_0 ;
  wire \VGA_R[7]_i_557_n_0 ;
  wire \VGA_R[7]_i_558_n_0 ;
  wire \VGA_R[7]_i_559_n_0 ;
  wire \VGA_R[7]_i_55_n_0 ;
  wire \VGA_R[7]_i_560_n_0 ;
  wire \VGA_R[7]_i_56_n_0 ;
  wire \VGA_R[7]_i_57_n_0 ;
  wire \VGA_R[7]_i_58_n_0 ;
  wire \VGA_R[7]_i_59_n_0 ;
  wire \VGA_R[7]_i_61_n_0 ;
  wire \VGA_R[7]_i_62_n_0 ;
  wire \VGA_R[7]_i_63_n_0 ;
  wire \VGA_R[7]_i_64_n_0 ;
  wire \VGA_R[7]_i_65_n_0 ;
  wire \VGA_R[7]_i_66_n_0 ;
  wire \VGA_R[7]_i_67_n_0 ;
  wire \VGA_R[7]_i_6_n_0 ;
  wire \VGA_R[7]_i_7_n_0 ;
  wire \VGA_R[7]_i_88_n_0 ;
  wire \VGA_R[7]_i_89_n_0 ;
  wire \VGA_R[7]_i_8_n_0 ;
  wire \VGA_R[7]_i_90_n_0 ;
  wire \VGA_R[7]_i_91_n_0 ;
  wire \VGA_R[7]_i_9_n_0 ;
  wire \VGA_R_reg[4]_i_5_0 ;
  wire \VGA_R_reg[4]_i_5_n_2 ;
  wire \VGA_R_reg[4]_i_5_n_3 ;
  wire \VGA_R_reg[4]_i_8_n_0 ;
  wire \VGA_R_reg[4]_i_8_n_1 ;
  wire \VGA_R_reg[4]_i_8_n_2 ;
  wire \VGA_R_reg[4]_i_8_n_3 ;
  wire \VGA_R_reg[5] ;
  wire [0:0]\VGA_R_reg[5]_i_11_0 ;
  wire \VGA_R_reg[5]_i_11_n_2 ;
  wire \VGA_R_reg[5]_i_11_n_3 ;
  wire \VGA_R_reg[5]_i_12_n_2 ;
  wire \VGA_R_reg[5]_i_12_n_3 ;
  wire \VGA_R_reg[5]_i_13_n_2 ;
  wire \VGA_R_reg[5]_i_13_n_3 ;
  wire [0:0]\VGA_R_reg[5]_i_14_0 ;
  wire [0:0]\VGA_R_reg[5]_i_14_1 ;
  wire [0:0]\VGA_R_reg[5]_i_14_2 ;
  wire [0:0]\VGA_R_reg[5]_i_14_3 ;
  wire \VGA_R_reg[5]_i_14_4 ;
  wire \VGA_R_reg[5]_i_14_n_0 ;
  wire \VGA_R_reg[5]_i_14_n_1 ;
  wire \VGA_R_reg[5]_i_14_n_2 ;
  wire \VGA_R_reg[5]_i_14_n_3 ;
  wire \VGA_R_reg[5]_i_18_n_0 ;
  wire \VGA_R_reg[5]_i_18_n_1 ;
  wire \VGA_R_reg[5]_i_18_n_2 ;
  wire \VGA_R_reg[5]_i_18_n_3 ;
  wire [0:0]\VGA_R_reg[5]_i_31_0 ;
  wire \VGA_R_reg[5]_i_31_1 ;
  wire \VGA_R_reg[5]_i_31_2 ;
  wire [2:0]\VGA_R_reg[5]_i_31_3 ;
  wire \VGA_R_reg[5]_i_31_n_0 ;
  wire \VGA_R_reg[5]_i_31_n_1 ;
  wire \VGA_R_reg[5]_i_31_n_2 ;
  wire \VGA_R_reg[5]_i_31_n_3 ;
  wire [0:0]\VGA_R_reg[5]_i_35_0 ;
  wire [1:0]\VGA_R_reg[5]_i_35_1 ;
  wire \VGA_R_reg[5]_i_35_n_0 ;
  wire \VGA_R_reg[5]_i_35_n_1 ;
  wire \VGA_R_reg[5]_i_35_n_2 ;
  wire \VGA_R_reg[5]_i_35_n_3 ;
  wire \VGA_R_reg[5]_i_40_n_0 ;
  wire \VGA_R_reg[5]_i_40_n_1 ;
  wire \VGA_R_reg[5]_i_40_n_2 ;
  wire \VGA_R_reg[5]_i_40_n_3 ;
  wire \VGA_R_reg[5]_i_7_n_3 ;
  wire \VGA_R_reg[5]_i_8_n_2 ;
  wire \VGA_R_reg[5]_i_8_n_3 ;
  wire \VGA_R_reg[6] ;
  wire \VGA_R_reg[6]_0 ;
  wire \VGA_R_reg[7]_i_100_n_0 ;
  wire \VGA_R_reg[7]_i_100_n_1 ;
  wire \VGA_R_reg[7]_i_100_n_2 ;
  wire \VGA_R_reg[7]_i_100_n_3 ;
  wire \VGA_R_reg[7]_i_100_n_5 ;
  wire \VGA_R_reg[7]_i_100_n_6 ;
  wire \VGA_R_reg[7]_i_100_n_7 ;
  wire \VGA_R_reg[7]_i_102_n_0 ;
  wire \VGA_R_reg[7]_i_102_n_1 ;
  wire \VGA_R_reg[7]_i_102_n_2 ;
  wire \VGA_R_reg[7]_i_102_n_3 ;
  wire \VGA_R_reg[7]_i_105_n_0 ;
  wire \VGA_R_reg[7]_i_105_n_1 ;
  wire \VGA_R_reg[7]_i_105_n_2 ;
  wire \VGA_R_reg[7]_i_105_n_3 ;
  wire \VGA_R_reg[7]_i_116_n_1 ;
  wire \VGA_R_reg[7]_i_116_n_2 ;
  wire \VGA_R_reg[7]_i_116_n_3 ;
  wire \VGA_R_reg[7]_i_117_n_1 ;
  wire \VGA_R_reg[7]_i_117_n_2 ;
  wire \VGA_R_reg[7]_i_117_n_3 ;
  wire \VGA_R_reg[7]_i_118_n_1 ;
  wire \VGA_R_reg[7]_i_118_n_2 ;
  wire \VGA_R_reg[7]_i_118_n_3 ;
  wire \VGA_R_reg[7]_i_11_n_0 ;
  wire \VGA_R_reg[7]_i_11_n_1 ;
  wire \VGA_R_reg[7]_i_11_n_2 ;
  wire \VGA_R_reg[7]_i_11_n_3 ;
  wire \VGA_R_reg[7]_i_121_n_0 ;
  wire \VGA_R_reg[7]_i_121_n_1 ;
  wire \VGA_R_reg[7]_i_121_n_2 ;
  wire \VGA_R_reg[7]_i_121_n_3 ;
  wire \VGA_R_reg[7]_i_121_n_4 ;
  wire \VGA_R_reg[7]_i_121_n_5 ;
  wire \VGA_R_reg[7]_i_121_n_6 ;
  wire \VGA_R_reg[7]_i_121_n_7 ;
  wire \VGA_R_reg[7]_i_122_n_0 ;
  wire \VGA_R_reg[7]_i_122_n_1 ;
  wire \VGA_R_reg[7]_i_122_n_2 ;
  wire \VGA_R_reg[7]_i_122_n_3 ;
  wire \VGA_R_reg[7]_i_122_n_4 ;
  wire \VGA_R_reg[7]_i_122_n_5 ;
  wire \VGA_R_reg[7]_i_122_n_6 ;
  wire \VGA_R_reg[7]_i_122_n_7 ;
  wire \VGA_R_reg[7]_i_130_n_0 ;
  wire \VGA_R_reg[7]_i_130_n_1 ;
  wire \VGA_R_reg[7]_i_130_n_2 ;
  wire \VGA_R_reg[7]_i_130_n_3 ;
  wire \VGA_R_reg[7]_i_130_n_4 ;
  wire \VGA_R_reg[7]_i_130_n_5 ;
  wire \VGA_R_reg[7]_i_130_n_6 ;
  wire \VGA_R_reg[7]_i_130_n_7 ;
  wire \VGA_R_reg[7]_i_136_n_0 ;
  wire \VGA_R_reg[7]_i_136_n_1 ;
  wire \VGA_R_reg[7]_i_136_n_2 ;
  wire \VGA_R_reg[7]_i_136_n_3 ;
  wire \VGA_R_reg[7]_i_136_n_4 ;
  wire \VGA_R_reg[7]_i_136_n_5 ;
  wire \VGA_R_reg[7]_i_136_n_6 ;
  wire \VGA_R_reg[7]_i_136_n_7 ;
  wire \VGA_R_reg[7]_i_137_n_0 ;
  wire \VGA_R_reg[7]_i_137_n_1 ;
  wire \VGA_R_reg[7]_i_137_n_2 ;
  wire \VGA_R_reg[7]_i_137_n_3 ;
  wire \VGA_R_reg[7]_i_137_n_4 ;
  wire \VGA_R_reg[7]_i_137_n_5 ;
  wire \VGA_R_reg[7]_i_137_n_6 ;
  wire \VGA_R_reg[7]_i_137_n_7 ;
  wire \VGA_R_reg[7]_i_142_n_0 ;
  wire \VGA_R_reg[7]_i_142_n_1 ;
  wire \VGA_R_reg[7]_i_142_n_2 ;
  wire \VGA_R_reg[7]_i_142_n_3 ;
  wire \VGA_R_reg[7]_i_142_n_4 ;
  wire \VGA_R_reg[7]_i_142_n_5 ;
  wire \VGA_R_reg[7]_i_142_n_6 ;
  wire \VGA_R_reg[7]_i_142_n_7 ;
  wire \VGA_R_reg[7]_i_143_n_0 ;
  wire \VGA_R_reg[7]_i_143_n_1 ;
  wire \VGA_R_reg[7]_i_143_n_2 ;
  wire \VGA_R_reg[7]_i_143_n_3 ;
  wire \VGA_R_reg[7]_i_143_n_4 ;
  wire \VGA_R_reg[7]_i_143_n_5 ;
  wire \VGA_R_reg[7]_i_143_n_6 ;
  wire \VGA_R_reg[7]_i_143_n_7 ;
  wire \VGA_R_reg[7]_i_148_n_0 ;
  wire \VGA_R_reg[7]_i_148_n_1 ;
  wire \VGA_R_reg[7]_i_148_n_2 ;
  wire \VGA_R_reg[7]_i_148_n_3 ;
  wire \VGA_R_reg[7]_i_148_n_4 ;
  wire \VGA_R_reg[7]_i_148_n_5 ;
  wire \VGA_R_reg[7]_i_148_n_6 ;
  wire \VGA_R_reg[7]_i_148_n_7 ;
  wire \VGA_R_reg[7]_i_157_n_0 ;
  wire \VGA_R_reg[7]_i_157_n_1 ;
  wire \VGA_R_reg[7]_i_157_n_2 ;
  wire \VGA_R_reg[7]_i_157_n_3 ;
  wire \VGA_R_reg[7]_i_157_n_4 ;
  wire \VGA_R_reg[7]_i_157_n_5 ;
  wire \VGA_R_reg[7]_i_157_n_6 ;
  wire \VGA_R_reg[7]_i_157_n_7 ;
  wire \VGA_R_reg[7]_i_158_n_0 ;
  wire \VGA_R_reg[7]_i_158_n_1 ;
  wire \VGA_R_reg[7]_i_158_n_2 ;
  wire \VGA_R_reg[7]_i_158_n_3 ;
  wire \VGA_R_reg[7]_i_158_n_4 ;
  wire \VGA_R_reg[7]_i_158_n_5 ;
  wire \VGA_R_reg[7]_i_158_n_6 ;
  wire \VGA_R_reg[7]_i_158_n_7 ;
  wire \VGA_R_reg[7]_i_163_n_0 ;
  wire \VGA_R_reg[7]_i_163_n_1 ;
  wire \VGA_R_reg[7]_i_163_n_2 ;
  wire \VGA_R_reg[7]_i_163_n_3 ;
  wire \VGA_R_reg[7]_i_163_n_4 ;
  wire \VGA_R_reg[7]_i_163_n_5 ;
  wire \VGA_R_reg[7]_i_163_n_6 ;
  wire \VGA_R_reg[7]_i_163_n_7 ;
  wire \VGA_R_reg[7]_i_16_0 ;
  wire \VGA_R_reg[7]_i_16_1 ;
  wire \VGA_R_reg[7]_i_16_n_0 ;
  wire \VGA_R_reg[7]_i_16_n_1 ;
  wire \VGA_R_reg[7]_i_16_n_2 ;
  wire \VGA_R_reg[7]_i_16_n_3 ;
  wire \VGA_R_reg[7]_i_211_n_0 ;
  wire \VGA_R_reg[7]_i_211_n_1 ;
  wire \VGA_R_reg[7]_i_211_n_2 ;
  wire \VGA_R_reg[7]_i_211_n_3 ;
  wire \VGA_R_reg[7]_i_211_n_4 ;
  wire \VGA_R_reg[7]_i_211_n_5 ;
  wire \VGA_R_reg[7]_i_211_n_6 ;
  wire \VGA_R_reg[7]_i_211_n_7 ;
  wire \VGA_R_reg[7]_i_216_n_0 ;
  wire \VGA_R_reg[7]_i_216_n_1 ;
  wire \VGA_R_reg[7]_i_216_n_2 ;
  wire \VGA_R_reg[7]_i_216_n_3 ;
  wire \VGA_R_reg[7]_i_216_n_4 ;
  wire \VGA_R_reg[7]_i_216_n_5 ;
  wire \VGA_R_reg[7]_i_216_n_6 ;
  wire \VGA_R_reg[7]_i_216_n_7 ;
  wire \VGA_R_reg[7]_i_21_n_0 ;
  wire \VGA_R_reg[7]_i_21_n_1 ;
  wire \VGA_R_reg[7]_i_21_n_2 ;
  wire \VGA_R_reg[7]_i_21_n_3 ;
  wire \VGA_R_reg[7]_i_221_n_0 ;
  wire \VGA_R_reg[7]_i_221_n_1 ;
  wire \VGA_R_reg[7]_i_221_n_2 ;
  wire \VGA_R_reg[7]_i_221_n_3 ;
  wire \VGA_R_reg[7]_i_221_n_4 ;
  wire \VGA_R_reg[7]_i_221_n_5 ;
  wire \VGA_R_reg[7]_i_221_n_6 ;
  wire \VGA_R_reg[7]_i_221_n_7 ;
  wire \VGA_R_reg[7]_i_226_n_0 ;
  wire \VGA_R_reg[7]_i_226_n_1 ;
  wire \VGA_R_reg[7]_i_226_n_2 ;
  wire \VGA_R_reg[7]_i_226_n_3 ;
  wire \VGA_R_reg[7]_i_226_n_4 ;
  wire \VGA_R_reg[7]_i_226_n_5 ;
  wire \VGA_R_reg[7]_i_226_n_6 ;
  wire \VGA_R_reg[7]_i_226_n_7 ;
  wire \VGA_R_reg[7]_i_231_0 ;
  wire \VGA_R_reg[7]_i_231_n_0 ;
  wire \VGA_R_reg[7]_i_231_n_1 ;
  wire \VGA_R_reg[7]_i_231_n_2 ;
  wire \VGA_R_reg[7]_i_231_n_3 ;
  wire \VGA_R_reg[7]_i_231_n_4 ;
  wire \VGA_R_reg[7]_i_231_n_5 ;
  wire \VGA_R_reg[7]_i_231_n_6 ;
  wire \VGA_R_reg[7]_i_231_n_7 ;
  wire [0:0]\VGA_R_reg[7]_i_236_0 ;
  wire \VGA_R_reg[7]_i_236_n_0 ;
  wire \VGA_R_reg[7]_i_236_n_1 ;
  wire \VGA_R_reg[7]_i_236_n_2 ;
  wire \VGA_R_reg[7]_i_236_n_3 ;
  wire \VGA_R_reg[7]_i_236_n_4 ;
  wire \VGA_R_reg[7]_i_236_n_5 ;
  wire \VGA_R_reg[7]_i_236_n_6 ;
  wire \VGA_R_reg[7]_i_236_n_7 ;
  wire \VGA_R_reg[7]_i_317_n_0 ;
  wire \VGA_R_reg[7]_i_317_n_1 ;
  wire \VGA_R_reg[7]_i_317_n_2 ;
  wire \VGA_R_reg[7]_i_317_n_3 ;
  wire \VGA_R_reg[7]_i_317_n_4 ;
  wire \VGA_R_reg[7]_i_317_n_5 ;
  wire \VGA_R_reg[7]_i_317_n_6 ;
  wire \VGA_R_reg[7]_i_317_n_7 ;
  wire \VGA_R_reg[7]_i_33_n_0 ;
  wire \VGA_R_reg[7]_i_33_n_1 ;
  wire \VGA_R_reg[7]_i_33_n_2 ;
  wire \VGA_R_reg[7]_i_33_n_3 ;
  wire \VGA_R_reg[7]_i_33_n_5 ;
  wire \VGA_R_reg[7]_i_33_n_6 ;
  wire \VGA_R_reg[7]_i_33_n_7 ;
  wire \VGA_R_reg[7]_i_38_n_3 ;
  wire \VGA_R_reg[7]_i_39_n_3 ;
  wire \VGA_R_reg[7]_i_3_n_3 ;
  wire \VGA_R_reg[7]_i_448_n_7 ;
  wire \VGA_R_reg[7]_i_449_n_7 ;
  wire \VGA_R_reg[7]_i_450_n_0 ;
  wire \VGA_R_reg[7]_i_450_n_1 ;
  wire \VGA_R_reg[7]_i_450_n_2 ;
  wire \VGA_R_reg[7]_i_450_n_3 ;
  wire \VGA_R_reg[7]_i_450_n_4 ;
  wire \VGA_R_reg[7]_i_450_n_5 ;
  wire \VGA_R_reg[7]_i_450_n_6 ;
  wire \VGA_R_reg[7]_i_450_n_7 ;
  wire \VGA_R_reg[7]_i_455_n_7 ;
  wire \VGA_R_reg[7]_i_456_n_3 ;
  wire \VGA_R_reg[7]_i_456_n_6 ;
  wire \VGA_R_reg[7]_i_456_n_7 ;
  wire \VGA_R_reg[7]_i_457_n_7 ;
  wire \VGA_R_reg[7]_i_458_n_7 ;
  wire \VGA_R_reg[7]_i_459_n_7 ;
  wire \VGA_R_reg[7]_i_4_0 ;
  wire \VGA_R_reg[7]_i_4_n_3 ;
  wire \VGA_R_reg[7]_i_501_n_0 ;
  wire \VGA_R_reg[7]_i_501_n_1 ;
  wire \VGA_R_reg[7]_i_501_n_2 ;
  wire \VGA_R_reg[7]_i_501_n_3 ;
  wire \VGA_R_reg[7]_i_5_n_3 ;
  wire \VGA_R_reg[7]_i_68_n_1 ;
  wire \VGA_R_reg[7]_i_68_n_2 ;
  wire \VGA_R_reg[7]_i_68_n_3 ;
  wire \VGA_R_reg[7]_i_68_n_5 ;
  wire \VGA_R_reg[7]_i_68_n_6 ;
  wire \VGA_R_reg[7]_i_68_n_7 ;
  wire \VGA_R_reg[7]_i_69_n_6 ;
  wire [2:0]\VGA_R_reg[7]_i_70_0 ;
  wire \VGA_R_reg[7]_i_70_n_1 ;
  wire \VGA_R_reg[7]_i_70_n_2 ;
  wire \VGA_R_reg[7]_i_70_n_3 ;
  wire \VGA_R_reg[7]_i_70_n_5 ;
  wire \VGA_R_reg[7]_i_70_n_6 ;
  wire \VGA_R_reg[7]_i_70_n_7 ;
  wire \VGA_R_reg[7]_i_71_n_1 ;
  wire \VGA_R_reg[7]_i_71_n_2 ;
  wire \VGA_R_reg[7]_i_71_n_3 ;
  wire \VGA_R_reg[7]_i_71_n_5 ;
  wire \VGA_R_reg[7]_i_71_n_6 ;
  wire \VGA_R_reg[7]_i_71_n_7 ;
  wire \VGA_R_reg[7]_i_72_n_1 ;
  wire \VGA_R_reg[7]_i_72_n_2 ;
  wire \VGA_R_reg[7]_i_72_n_3 ;
  wire \VGA_R_reg[7]_i_72_n_5 ;
  wire \VGA_R_reg[7]_i_72_n_6 ;
  wire \VGA_R_reg[7]_i_72_n_7 ;
  wire \VGA_R_reg[7]_i_73_n_1 ;
  wire \VGA_R_reg[7]_i_73_n_2 ;
  wire \VGA_R_reg[7]_i_73_n_3 ;
  wire \VGA_R_reg[7]_i_73_n_5 ;
  wire \VGA_R_reg[7]_i_73_n_6 ;
  wire \VGA_R_reg[7]_i_73_n_7 ;
  wire [0:0]\VGA_R_reg[7]_i_74_0 ;
  wire \VGA_R_reg[7]_i_74_n_1 ;
  wire \VGA_R_reg[7]_i_74_n_2 ;
  wire \VGA_R_reg[7]_i_74_n_3 ;
  wire \VGA_R_reg[7]_i_74_n_5 ;
  wire \VGA_R_reg[7]_i_74_n_6 ;
  wire \VGA_R_reg[7]_i_74_n_7 ;
  wire \VGA_R_reg[7]_i_75_n_1 ;
  wire \VGA_R_reg[7]_i_75_n_2 ;
  wire \VGA_R_reg[7]_i_75_n_3 ;
  wire \VGA_R_reg[7]_i_75_n_5 ;
  wire \VGA_R_reg[7]_i_75_n_6 ;
  wire \VGA_R_reg[7]_i_75_n_7 ;
  wire \VGA_R_reg[7]_i_76_n_1 ;
  wire \VGA_R_reg[7]_i_76_n_2 ;
  wire \VGA_R_reg[7]_i_76_n_3 ;
  wire \VGA_R_reg[7]_i_76_n_5 ;
  wire \VGA_R_reg[7]_i_76_n_6 ;
  wire \VGA_R_reg[7]_i_76_n_7 ;
  wire \VGA_R_reg[7]_i_77_n_1 ;
  wire \VGA_R_reg[7]_i_77_n_2 ;
  wire \VGA_R_reg[7]_i_77_n_3 ;
  wire \VGA_R_reg[7]_i_77_n_5 ;
  wire \VGA_R_reg[7]_i_77_n_6 ;
  wire \VGA_R_reg[7]_i_77_n_7 ;
  wire \VGA_R_reg[7]_i_78_n_1 ;
  wire \VGA_R_reg[7]_i_78_n_2 ;
  wire \VGA_R_reg[7]_i_78_n_3 ;
  wire \VGA_R_reg[7]_i_78_n_5 ;
  wire \VGA_R_reg[7]_i_78_n_6 ;
  wire \VGA_R_reg[7]_i_78_n_7 ;
  wire \VGA_R_reg[7]_i_86_n_0 ;
  wire \VGA_R_reg[7]_i_86_n_1 ;
  wire \VGA_R_reg[7]_i_86_n_2 ;
  wire \VGA_R_reg[7]_i_86_n_3 ;
  wire \VGA_R_reg[7]_i_86_n_4 ;
  wire \VGA_R_reg[7]_i_86_n_5 ;
  wire \VGA_R_reg[7]_i_86_n_6 ;
  wire \VGA_R_reg[7]_i_86_n_7 ;
  wire \VGA_R_reg[7]_i_87_n_0 ;
  wire \VGA_R_reg[7]_i_87_n_1 ;
  wire \VGA_R_reg[7]_i_87_n_2 ;
  wire \VGA_R_reg[7]_i_87_n_3 ;
  wire \VGA_R_reg[7]_i_87_n_4 ;
  wire \VGA_R_reg[7]_i_87_n_5 ;
  wire \VGA_R_reg[7]_i_87_n_6 ;
  wire \VGA_R_reg[7]_i_87_n_7 ;
  wire \VGA_R_reg[7]_i_94_n_0 ;
  wire \VGA_R_reg[7]_i_94_n_1 ;
  wire \VGA_R_reg[7]_i_94_n_2 ;
  wire \VGA_R_reg[7]_i_94_n_3 ;
  wire \VGA_R_reg[7]_i_94_n_5 ;
  wire \VGA_R_reg[7]_i_94_n_6 ;
  wire \VGA_R_reg[7]_i_94_n_7 ;
  wire \VGA_R_reg[7]_i_95_n_0 ;
  wire \VGA_R_reg[7]_i_95_n_1 ;
  wire \VGA_R_reg[7]_i_95_n_2 ;
  wire \VGA_R_reg[7]_i_95_n_3 ;
  wire \VGA_R_reg[7]_i_95_n_5 ;
  wire \VGA_R_reg[7]_i_95_n_6 ;
  wire \VGA_R_reg[7]_i_95_n_7 ;
  wire \VGA_R_reg[7]_i_96_n_0 ;
  wire \VGA_R_reg[7]_i_96_n_1 ;
  wire \VGA_R_reg[7]_i_96_n_2 ;
  wire \VGA_R_reg[7]_i_96_n_3 ;
  wire \VGA_R_reg[7]_i_96_n_5 ;
  wire \VGA_R_reg[7]_i_96_n_6 ;
  wire \VGA_R_reg[7]_i_96_n_7 ;
  wire \VGA_R_reg[7]_i_97_n_0 ;
  wire \VGA_R_reg[7]_i_97_n_1 ;
  wire \VGA_R_reg[7]_i_97_n_2 ;
  wire \VGA_R_reg[7]_i_97_n_3 ;
  wire \VGA_R_reg[7]_i_97_n_5 ;
  wire \VGA_R_reg[7]_i_97_n_6 ;
  wire \VGA_R_reg[7]_i_97_n_7 ;
  wire \VGA_R_reg[7]_i_98_n_0 ;
  wire \VGA_R_reg[7]_i_98_n_1 ;
  wire \VGA_R_reg[7]_i_98_n_2 ;
  wire \VGA_R_reg[7]_i_98_n_3 ;
  wire \VGA_R_reg[7]_i_98_n_5 ;
  wire \VGA_R_reg[7]_i_98_n_6 ;
  wire \VGA_R_reg[7]_i_98_n_7 ;
  wire [2:0]\VGA_R_reg[7]_i_99_0 ;
  wire [1:0]\VGA_R_reg[7]_i_99_1 ;
  wire [3:0]\VGA_R_reg[7]_i_99_2 ;
  wire \VGA_R_reg[7]_i_99_n_0 ;
  wire \VGA_R_reg[7]_i_99_n_1 ;
  wire \VGA_R_reg[7]_i_99_n_2 ;
  wire \VGA_R_reg[7]_i_99_n_3 ;
  wire \VGA_R_reg[7]_i_99_n_5 ;
  wire \VGA_R_reg[7]_i_99_n_6 ;
  wire \VGA_R_reg[7]_i_99_n_7 ;
  wire VGA_VS;
  wire VGA_VS0;
  wire VGA_VS1;
  wire VGA_VS_i_10_n_0;
  wire VGA_VS_i_11_n_0;
  wire VGA_VS_i_1_n_0;
  wire VGA_VS_i_4_n_0;
  wire VGA_VS_i_5_n_0;
  wire VGA_VS_i_6_n_0;
  wire VGA_VS_i_7_n_0;
  wire VGA_VS_i_8_n_0;
  wire VGA_VS_i_9_n_0;
  wire VGA_VS_reg_i_2_n_1;
  wire VGA_VS_reg_i_2_n_2;
  wire VGA_VS_reg_i_2_n_3;
  wire VGA_VS_reg_i_3_n_1;
  wire VGA_VS_reg_i_3_n_2;
  wire VGA_VS_reg_i_3_n_3;
  wire [7:0]data2;
  wire [7:0]data6;
  wire disp_enable0;
  wire disp_enable1;
  wire disp_enable10_in;
  wire hcntend;
  wire locked;
  wire [10:1]p_0_in;
  wire [10:0]p_0_in__0;
  wire [7:0]p_0_in__1;
  wire [10:0]p_1_in;
  wire pattern_b11_in;
  wire pattern_b1__0_i_10_n_0;
  wire pattern_b1__0_i_11_n_0;
  wire pattern_b1__0_i_12_n_0;
  wire pattern_b1__0_i_1_n_2;
  wire pattern_b1__0_i_1_n_3;
  wire pattern_b1__0_i_2_n_0;
  wire pattern_b1__0_i_2_n_1;
  wire pattern_b1__0_i_2_n_2;
  wire pattern_b1__0_i_2_n_3;
  wire pattern_b1__0_i_3_n_0;
  wire pattern_b1__0_i_3_n_1;
  wire pattern_b1__0_i_3_n_2;
  wire pattern_b1__0_i_3_n_3;
  wire pattern_b1__0_i_4_n_0;
  wire pattern_b1__0_i_5_n_0;
  wire pattern_b1__0_i_6_n_0;
  wire pattern_b1__0_i_7_n_0;
  wire pattern_b1__0_i_8_n_0;
  wire pattern_b1__0_i_9_n_0;
  wire pattern_b1__1;
  wire pattern_b1_i_10_n_0;
  wire pattern_b1_i_11_n_0;
  wire pattern_b1_i_12_n_0;
  wire pattern_b1_i_13_n_0;
  wire pattern_b1_i_14_n_0;
  wire pattern_b1_i_15_n_0;
  wire pattern_b1_i_16_n_0;
  wire pattern_b1_i_19_n_0;
  wire pattern_b1_i_1_n_3;
  wire pattern_b1_i_20_n_0;
  wire pattern_b1_i_21_n_0;
  wire pattern_b1_i_22_n_0;
  wire pattern_b1_i_2_n_0;
  wire pattern_b1_i_2_n_1;
  wire pattern_b1_i_2_n_2;
  wire pattern_b1_i_2_n_3;
  wire pattern_b1_i_3_n_0;
  wire pattern_b1_i_3_n_1;
  wire pattern_b1_i_3_n_2;
  wire pattern_b1_i_3_n_3;
  wire pattern_b1_i_4_n_0;
  wire pattern_b1_i_5_n_0;
  wire pattern_b1_i_6_n_0;
  wire pattern_b1_i_7_n_0;
  wire pattern_b1_i_8_n_0;
  wire pattern_b1_i_9_n_0;
  wire pattern_b20_out;
  wire pattern_b3__4;
  wire [3:0]pattern_sel;
  wire [7:0]\pattern_sel[3] ;
  wire [7:0]\pattern_sel[3]_0 ;
  wire reconfig_done;
  wire reconfig_req;
  wire [32:0]sel0;
  wire [1:0]timing_sel;
  wire [1:0]timing_sel_imm;
  wire zp_sum;
  wire [2:0]zp_sum0;
  wire [0:0]zp_sum0_0;
  wire [3:0]\NLW_VCNT_reg[10]_i_2_O_UNCONNECTED ;
  wire [3:0]\NLW_VCNT_reg[10]_i_4_O_UNCONNECTED ;
  wire [3:0]\NLW_VGA_B_reg[7]_i_13_O_UNCONNECTED ;
  wire [3:0]\NLW_VGA_B_reg[7]_i_28_CO_UNCONNECTED ;
  wire [3:1]\NLW_VGA_B_reg[7]_i_28_O_UNCONNECTED ;
  wire [3:0]\NLW_VGA_B_reg[7]_i_30_CO_UNCONNECTED ;
  wire [3:1]\NLW_VGA_B_reg[7]_i_30_O_UNCONNECTED ;
  wire [3:0]\NLW_VGA_B_reg[7]_i_32_CO_UNCONNECTED ;
  wire [3:1]\NLW_VGA_B_reg[7]_i_32_O_UNCONNECTED ;
  wire [3:0]\NLW_VGA_B_reg[7]_i_6_O_UNCONNECTED ;
  wire [3:0]\NLW_VGA_B_reg[7]_i_7_O_UNCONNECTED ;
  wire [3:0]\NLW_VGA_B_reg[7]_i_8_O_UNCONNECTED ;
  wire [3:3]\NLW_VGA_G_reg[7]_i_6_O_UNCONNECTED ;
  wire [3:3]\NLW_VGA_G_reg[7]_i_7_O_UNCONNECTED ;
  wire [3:0]NLW_VGA_HS_reg_i_3_O_UNCONNECTED;
  wire [3:0]NLW_VGA_HS_reg_i_4_O_UNCONNECTED;
  wire [3:2]\NLW_VGA_R_reg[4]_i_5_CO_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[4]_i_5_O_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[4]_i_8_O_UNCONNECTED ;
  wire [3:2]\NLW_VGA_R_reg[5]_i_11_CO_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[5]_i_11_O_UNCONNECTED ;
  wire [3:2]\NLW_VGA_R_reg[5]_i_12_CO_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[5]_i_12_O_UNCONNECTED ;
  wire [3:2]\NLW_VGA_R_reg[5]_i_13_CO_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[5]_i_13_O_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[5]_i_14_O_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[5]_i_18_O_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[5]_i_31_O_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[5]_i_35_O_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[5]_i_40_O_UNCONNECTED ;
  wire [3:2]\NLW_VGA_R_reg[5]_i_7_CO_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[5]_i_7_O_UNCONNECTED ;
  wire [3:2]\NLW_VGA_R_reg[5]_i_8_CO_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[5]_i_8_O_UNCONNECTED ;
  wire [3:3]\NLW_VGA_R_reg[7]_i_100_O_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[7]_i_102_O_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[7]_i_105_O_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[7]_i_11_O_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[7]_i_116_O_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[7]_i_117_O_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[7]_i_118_O_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[7]_i_16_O_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[7]_i_21_O_UNCONNECTED ;
  wire [3:2]\NLW_VGA_R_reg[7]_i_3_CO_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[7]_i_3_O_UNCONNECTED ;
  wire [3:3]\NLW_VGA_R_reg[7]_i_33_O_UNCONNECTED ;
  wire [3:1]\NLW_VGA_R_reg[7]_i_38_CO_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[7]_i_38_O_UNCONNECTED ;
  wire [3:2]\NLW_VGA_R_reg[7]_i_39_CO_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[7]_i_39_O_UNCONNECTED ;
  wire [3:2]\NLW_VGA_R_reg[7]_i_4_CO_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[7]_i_4_O_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[7]_i_448_CO_UNCONNECTED ;
  wire [3:1]\NLW_VGA_R_reg[7]_i_448_O_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[7]_i_449_CO_UNCONNECTED ;
  wire [3:1]\NLW_VGA_R_reg[7]_i_449_O_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[7]_i_455_CO_UNCONNECTED ;
  wire [3:1]\NLW_VGA_R_reg[7]_i_455_O_UNCONNECTED ;
  wire [3:1]\NLW_VGA_R_reg[7]_i_456_CO_UNCONNECTED ;
  wire [3:2]\NLW_VGA_R_reg[7]_i_456_O_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[7]_i_457_CO_UNCONNECTED ;
  wire [3:1]\NLW_VGA_R_reg[7]_i_457_O_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[7]_i_458_CO_UNCONNECTED ;
  wire [3:1]\NLW_VGA_R_reg[7]_i_458_O_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[7]_i_459_CO_UNCONNECTED ;
  wire [3:1]\NLW_VGA_R_reg[7]_i_459_O_UNCONNECTED ;
  wire [3:2]\NLW_VGA_R_reg[7]_i_5_CO_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[7]_i_5_O_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[7]_i_501_O_UNCONNECTED ;
  wire [3:3]\NLW_VGA_R_reg[7]_i_68_O_UNCONNECTED ;
  wire [3:1]\NLW_VGA_R_reg[7]_i_69_CO_UNCONNECTED ;
  wire [3:0]\NLW_VGA_R_reg[7]_i_69_O_UNCONNECTED ;
  wire [3:3]\NLW_VGA_R_reg[7]_i_70_O_UNCONNECTED ;
  wire [3:3]\NLW_VGA_R_reg[7]_i_71_O_UNCONNECTED ;
  wire [3:3]\NLW_VGA_R_reg[7]_i_72_O_UNCONNECTED ;
  wire [3:3]\NLW_VGA_R_reg[7]_i_73_O_UNCONNECTED ;
  wire [3:3]\NLW_VGA_R_reg[7]_i_74_O_UNCONNECTED ;
  wire [3:3]\NLW_VGA_R_reg[7]_i_75_O_UNCONNECTED ;
  wire [3:3]\NLW_VGA_R_reg[7]_i_76_O_UNCONNECTED ;
  wire [3:3]\NLW_VGA_R_reg[7]_i_77_O_UNCONNECTED ;
  wire [3:3]\NLW_VGA_R_reg[7]_i_78_O_UNCONNECTED ;
  wire [3:3]\NLW_VGA_R_reg[7]_i_94_O_UNCONNECTED ;
  wire [3:3]\NLW_VGA_R_reg[7]_i_95_O_UNCONNECTED ;
  wire [3:3]\NLW_VGA_R_reg[7]_i_96_O_UNCONNECTED ;
  wire [3:3]\NLW_VGA_R_reg[7]_i_97_O_UNCONNECTED ;
  wire [3:3]\NLW_VGA_R_reg[7]_i_98_O_UNCONNECTED ;
  wire [3:3]\NLW_VGA_R_reg[7]_i_99_O_UNCONNECTED ;
  wire [3:0]NLW_VGA_VS_reg_i_2_O_UNCONNECTED;
  wire [3:0]NLW_VGA_VS_reg_i_3_O_UNCONNECTED;
  wire [3:2]NLW_pattern_b1__0_i_1_CO_UNCONNECTED;
  wire [3:3]NLW_pattern_b1__0_i_1_O_UNCONNECTED;
  wire [3:1]NLW_pattern_b1_i_1_CO_UNCONNECTED;
  wire [3:2]NLW_pattern_b1_i_1_O_UNCONNECTED;

  (* SOFT_HLUTNM = "soft_lutpair39" *) 
  LUT1 #(
    .INIT(2'h1)) 
    \FCNT[0]_i_1 
       (.I0(FCNT[0]),
        .O(p_0_in__1[0]));
  (* SOFT_HLUTNM = "soft_lutpair39" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \FCNT[1]_i_1 
       (.I0(FCNT[0]),
        .I1(FCNT[1]),
        .O(p_0_in__1[1]));
  (* SOFT_HLUTNM = "soft_lutpair28" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \FCNT[2]_i_1 
       (.I0(FCNT[0]),
        .I1(FCNT[1]),
        .I2(FCNT[2]),
        .O(p_0_in__1[2]));
  (* SOFT_HLUTNM = "soft_lutpair22" *) 
  LUT4 #(
    .INIT(16'h7F80)) 
    \FCNT[3]_i_1 
       (.I0(FCNT[1]),
        .I1(FCNT[0]),
        .I2(FCNT[2]),
        .I3(FCNT[3]),
        .O(p_0_in__1[3]));
  (* SOFT_HLUTNM = "soft_lutpair28" *) 
  LUT5 #(
    .INIT(32'h7FFF8000)) 
    \FCNT[4]_i_1 
       (.I0(FCNT[2]),
        .I1(FCNT[0]),
        .I2(FCNT[1]),
        .I3(FCNT[3]),
        .I4(FCNT[4]),
        .O(p_0_in__1[4]));
  LUT6 #(
    .INIT(64'h7FFFFFFF80000000)) 
    \FCNT[5]_i_1 
       (.I0(FCNT[3]),
        .I1(FCNT[1]),
        .I2(FCNT[0]),
        .I3(FCNT[2]),
        .I4(FCNT[4]),
        .I5(FCNT[5]),
        .O(p_0_in__1[5]));
  (* SOFT_HLUTNM = "soft_lutpair32" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \FCNT[6]_i_1 
       (.I0(\FCNT[7]_i_3_n_0 ),
        .I1(FCNT[6]),
        .O(p_0_in__1[6]));
  LUT2 #(
    .INIT(4'h8)) 
    \FCNT[7]_i_1 
       (.I0(hcntend),
        .I1(VCNT0),
        .O(\FCNT[7]_i_1_n_0 ));
  LUT3 #(
    .INIT(8'h78)) 
    \FCNT[7]_i_2 
       (.I0(\FCNT[7]_i_3_n_0 ),
        .I1(FCNT[6]),
        .I2(FCNT[7]),
        .O(p_0_in__1[7]));
  LUT6 #(
    .INIT(64'h8000000000000000)) 
    \FCNT[7]_i_3 
       (.I0(FCNT[5]),
        .I1(FCNT[3]),
        .I2(FCNT[1]),
        .I3(FCNT[0]),
        .I4(FCNT[2]),
        .I5(FCNT[4]),
        .O(\FCNT[7]_i_3_n_0 ));
  FDRE \FCNT_reg[0] 
       (.C(PCK),
        .CE(\FCNT[7]_i_1_n_0 ),
        .D(p_0_in__1[0]),
        .Q(FCNT[0]),
        .R(RST));
  FDRE \FCNT_reg[1] 
       (.C(PCK),
        .CE(\FCNT[7]_i_1_n_0 ),
        .D(p_0_in__1[1]),
        .Q(FCNT[1]),
        .R(RST));
  FDRE \FCNT_reg[2] 
       (.C(PCK),
        .CE(\FCNT[7]_i_1_n_0 ),
        .D(p_0_in__1[2]),
        .Q(FCNT[2]),
        .R(RST));
  FDRE \FCNT_reg[3] 
       (.C(PCK),
        .CE(\FCNT[7]_i_1_n_0 ),
        .D(p_0_in__1[3]),
        .Q(FCNT[3]),
        .R(RST));
  FDRE \FCNT_reg[4] 
       (.C(PCK),
        .CE(\FCNT[7]_i_1_n_0 ),
        .D(p_0_in__1[4]),
        .Q(FCNT[4]),
        .R(RST));
  FDRE \FCNT_reg[5] 
       (.C(PCK),
        .CE(\FCNT[7]_i_1_n_0 ),
        .D(p_0_in__1[5]),
        .Q(FCNT[5]),
        .R(RST));
  FDRE \FCNT_reg[6] 
       (.C(PCK),
        .CE(\FCNT[7]_i_1_n_0 ),
        .D(p_0_in__1[6]),
        .Q(FCNT[6]),
        .R(RST));
  FDRE \FCNT_reg[7] 
       (.C(PCK),
        .CE(\FCNT[7]_i_1_n_0 ),
        .D(p_0_in__1[7]),
        .Q(FCNT[7]),
        .R(RST));
  LUT1 #(
    .INIT(2'h1)) 
    \HCNT[0]_i_1 
       (.I0(HCNT[0]),
        .O(p_1_in[0]));
  LUT2 #(
    .INIT(4'hE)) 
    \HCNT[10]_i_1 
       (.I0(RST),
        .I1(hcntend),
        .O(\HCNT[10]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h7FFFFFFF80000000)) 
    \HCNT[10]_i_2 
       (.I0(HCNT[8]),
        .I1(HCNT[6]),
        .I2(\HCNT[10]_i_3_n_0 ),
        .I3(HCNT[7]),
        .I4(HCNT[9]),
        .I5(HCNT[10]),
        .O(p_0_in[10]));
  LUT6 #(
    .INIT(64'h8000000000000000)) 
    \HCNT[10]_i_3 
       (.I0(HCNT[5]),
        .I1(HCNT[3]),
        .I2(HCNT[1]),
        .I3(HCNT[0]),
        .I4(HCNT[2]),
        .I5(HCNT[4]),
        .O(\HCNT[10]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair36" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \HCNT[1]_i_1 
       (.I0(HCNT[0]),
        .I1(HCNT[1]),
        .O(p_0_in[1]));
  (* SOFT_HLUTNM = "soft_lutpair36" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \HCNT[2]_i_1 
       (.I0(HCNT[0]),
        .I1(HCNT[1]),
        .I2(HCNT[2]),
        .O(p_0_in[2]));
  (* SOFT_HLUTNM = "soft_lutpair25" *) 
  LUT4 #(
    .INIT(16'h7F80)) 
    \HCNT[3]_i_1 
       (.I0(HCNT[1]),
        .I1(HCNT[0]),
        .I2(HCNT[2]),
        .I3(HCNT[3]),
        .O(p_0_in[3]));
  (* SOFT_HLUTNM = "soft_lutpair25" *) 
  LUT5 #(
    .INIT(32'h7FFF8000)) 
    \HCNT[4]_i_1 
       (.I0(HCNT[2]),
        .I1(HCNT[0]),
        .I2(HCNT[1]),
        .I3(HCNT[3]),
        .I4(HCNT[4]),
        .O(p_0_in[4]));
  LUT6 #(
    .INIT(64'h7FFFFFFF80000000)) 
    \HCNT[5]_i_1 
       (.I0(HCNT[3]),
        .I1(HCNT[1]),
        .I2(HCNT[0]),
        .I3(HCNT[2]),
        .I4(HCNT[4]),
        .I5(HCNT[5]),
        .O(p_0_in[5]));
  (* SOFT_HLUTNM = "soft_lutpair35" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \HCNT[6]_i_1 
       (.I0(\HCNT[10]_i_3_n_0 ),
        .I1(HCNT[6]),
        .O(p_0_in[6]));
  (* SOFT_HLUTNM = "soft_lutpair35" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \HCNT[7]_i_1 
       (.I0(\HCNT[10]_i_3_n_0 ),
        .I1(HCNT[6]),
        .I2(HCNT[7]),
        .O(p_0_in[7]));
  (* SOFT_HLUTNM = "soft_lutpair24" *) 
  LUT4 #(
    .INIT(16'h7F80)) 
    \HCNT[8]_i_1 
       (.I0(HCNT[6]),
        .I1(\HCNT[10]_i_3_n_0 ),
        .I2(HCNT[7]),
        .I3(HCNT[8]),
        .O(p_0_in[8]));
  (* SOFT_HLUTNM = "soft_lutpair24" *) 
  LUT5 #(
    .INIT(32'h7FFF8000)) 
    \HCNT[9]_i_1 
       (.I0(HCNT[7]),
        .I1(\HCNT[10]_i_3_n_0 ),
        .I2(HCNT[6]),
        .I3(HCNT[8]),
        .I4(HCNT[9]),
        .O(p_0_in[9]));
  FDRE \HCNT_reg[0] 
       (.C(PCK),
        .CE(1'b1),
        .D(p_1_in[0]),
        .Q(HCNT[0]),
        .R(\HCNT[10]_i_1_n_0 ));
  FDRE \HCNT_reg[10] 
       (.C(PCK),
        .CE(1'b1),
        .D(p_0_in[10]),
        .Q(HCNT[10]),
        .R(\HCNT[10]_i_1_n_0 ));
  FDRE \HCNT_reg[1] 
       (.C(PCK),
        .CE(1'b1),
        .D(p_0_in[1]),
        .Q(HCNT[1]),
        .R(\HCNT[10]_i_1_n_0 ));
  FDRE \HCNT_reg[2] 
       (.C(PCK),
        .CE(1'b1),
        .D(p_0_in[2]),
        .Q(HCNT[2]),
        .R(\HCNT[10]_i_1_n_0 ));
  FDRE \HCNT_reg[3] 
       (.C(PCK),
        .CE(1'b1),
        .D(p_0_in[3]),
        .Q(HCNT[3]),
        .R(\HCNT[10]_i_1_n_0 ));
  FDRE \HCNT_reg[4] 
       (.C(PCK),
        .CE(1'b1),
        .D(p_0_in[4]),
        .Q(HCNT[4]),
        .R(\HCNT[10]_i_1_n_0 ));
  FDRE \HCNT_reg[5] 
       (.C(PCK),
        .CE(1'b1),
        .D(p_0_in[5]),
        .Q(HCNT[5]),
        .R(\HCNT[10]_i_1_n_0 ));
  FDRE \HCNT_reg[6] 
       (.C(PCK),
        .CE(1'b1),
        .D(p_0_in[6]),
        .Q(HCNT[6]),
        .R(\HCNT[10]_i_1_n_0 ));
  FDRE \HCNT_reg[7] 
       (.C(PCK),
        .CE(1'b1),
        .D(p_0_in[7]),
        .Q(HCNT[7]),
        .R(\HCNT[10]_i_1_n_0 ));
  FDRE \HCNT_reg[8] 
       (.C(PCK),
        .CE(1'b1),
        .D(p_0_in[8]),
        .Q(HCNT[8]),
        .R(\HCNT[10]_i_1_n_0 ));
  FDRE \HCNT_reg[9] 
       (.C(PCK),
        .CE(1'b1),
        .D(p_0_in[9]),
        .Q(HCNT[9]),
        .R(\HCNT[10]_i_1_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \VCNT[0]_i_1 
       (.I0(VCNT[0]),
        .O(p_0_in__0[0]));
  LUT3 #(
    .INIT(8'hEA)) 
    \VCNT[10]_i_1 
       (.I0(RST),
        .I1(VCNT0),
        .I2(hcntend),
        .O(\VCNT[10]_i_1_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \VCNT[10]_i_10 
       (.I0(VCNT[9]),
        .I1(VCNT[10]),
        .O(\VCNT[10]_i_10_n_0 ));
  LUT5 #(
    .INIT(32'h00201101)) 
    \VCNT[10]_i_11 
       (.I0(VCNT[6]),
        .I1(VCNT[8]),
        .I2(timing_sel[1]),
        .I3(timing_sel[0]),
        .I4(VCNT[7]),
        .O(\VCNT[10]_i_11_n_0 ));
  LUT5 #(
    .INIT(32'h00202202)) 
    \VCNT[10]_i_12 
       (.I0(VCNT[3]),
        .I1(VCNT[4]),
        .I2(timing_sel[1]),
        .I3(timing_sel[0]),
        .I4(VCNT[5]),
        .O(\VCNT[10]_i_12_n_0 ));
  LUT5 #(
    .INIT(32'h00650000)) 
    \VCNT[10]_i_13 
       (.I0(VCNT[0]),
        .I1(timing_sel[0]),
        .I2(timing_sel[1]),
        .I3(VCNT[1]),
        .I4(VCNT[2]),
        .O(\VCNT[10]_i_13_n_0 ));
  LUT6 #(
    .INIT(64'h7FFFFFFF80000000)) 
    \VCNT[10]_i_3 
       (.I0(VCNT[8]),
        .I1(VCNT[6]),
        .I2(\VCNT[10]_i_9_n_0 ),
        .I3(VCNT[7]),
        .I4(VCNT[9]),
        .I5(VCNT[10]),
        .O(p_0_in__0[10]));
  LUT4 #(
    .INIT(16'h2822)) 
    \VCNT[10]_i_5 
       (.I0(HCNT[9]),
        .I1(HCNT[10]),
        .I2(timing_sel[0]),
        .I3(timing_sel[1]),
        .O(\VCNT[10]_i_5_n_0 ));
  LUT5 #(
    .INIT(32'h00004920)) 
    \VCNT[10]_i_6 
       (.I0(HCNT[6]),
        .I1(timing_sel[0]),
        .I2(timing_sel[1]),
        .I3(HCNT[8]),
        .I4(HCNT[7]),
        .O(\VCNT[10]_i_6_n_0 ));
  LUT5 #(
    .INIT(32'h04A20000)) 
    \VCNT[10]_i_7 
       (.I0(HCNT[3]),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .I3(HCNT[5]),
        .I4(HCNT[4]),
        .O(\VCNT[10]_i_7_n_0 ));
  LUT5 #(
    .INIT(32'h82000028)) 
    \VCNT[10]_i_8 
       (.I0(HCNT[0]),
        .I1(timing_sel[0]),
        .I2(timing_sel[1]),
        .I3(HCNT[2]),
        .I4(HCNT[1]),
        .O(\VCNT[10]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'h8000000000000000)) 
    \VCNT[10]_i_9 
       (.I0(VCNT[5]),
        .I1(VCNT[3]),
        .I2(VCNT[1]),
        .I3(VCNT[0]),
        .I4(VCNT[2]),
        .I5(VCNT[4]),
        .O(\VCNT[10]_i_9_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair38" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \VCNT[1]_i_1 
       (.I0(VCNT[0]),
        .I1(VCNT[1]),
        .O(p_0_in__0[1]));
  (* SOFT_HLUTNM = "soft_lutpair38" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \VCNT[2]_i_1 
       (.I0(VCNT[0]),
        .I1(VCNT[1]),
        .I2(VCNT[2]),
        .O(p_0_in__0[2]));
  (* SOFT_HLUTNM = "soft_lutpair27" *) 
  LUT4 #(
    .INIT(16'h7F80)) 
    \VCNT[3]_i_1 
       (.I0(VCNT[1]),
        .I1(VCNT[0]),
        .I2(VCNT[2]),
        .I3(VCNT[3]),
        .O(p_0_in__0[3]));
  (* SOFT_HLUTNM = "soft_lutpair27" *) 
  LUT5 #(
    .INIT(32'h7FFF8000)) 
    \VCNT[4]_i_1 
       (.I0(VCNT[2]),
        .I1(VCNT[0]),
        .I2(VCNT[1]),
        .I3(VCNT[3]),
        .I4(VCNT[4]),
        .O(p_0_in__0[4]));
  LUT6 #(
    .INIT(64'h7FFFFFFF80000000)) 
    \VCNT[5]_i_1 
       (.I0(VCNT[3]),
        .I1(VCNT[1]),
        .I2(VCNT[0]),
        .I3(VCNT[2]),
        .I4(VCNT[4]),
        .I5(VCNT[5]),
        .O(p_0_in__0[5]));
  (* SOFT_HLUTNM = "soft_lutpair37" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \VCNT[6]_i_1 
       (.I0(\VCNT[10]_i_9_n_0 ),
        .I1(VCNT[6]),
        .O(p_0_in__0[6]));
  (* SOFT_HLUTNM = "soft_lutpair37" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \VCNT[7]_i_1 
       (.I0(\VCNT[10]_i_9_n_0 ),
        .I1(VCNT[6]),
        .I2(VCNT[7]),
        .O(p_0_in__0[7]));
  (* SOFT_HLUTNM = "soft_lutpair26" *) 
  LUT4 #(
    .INIT(16'h7F80)) 
    \VCNT[8]_i_1 
       (.I0(VCNT[6]),
        .I1(\VCNT[10]_i_9_n_0 ),
        .I2(VCNT[7]),
        .I3(VCNT[8]),
        .O(p_0_in__0[8]));
  (* SOFT_HLUTNM = "soft_lutpair26" *) 
  LUT5 #(
    .INIT(32'h7FFF8000)) 
    \VCNT[9]_i_1 
       (.I0(VCNT[7]),
        .I1(\VCNT[10]_i_9_n_0 ),
        .I2(VCNT[6]),
        .I3(VCNT[8]),
        .I4(VCNT[9]),
        .O(p_0_in__0[9]));
  FDRE \VCNT_reg[0] 
       (.C(PCK),
        .CE(hcntend),
        .D(p_0_in__0[0]),
        .Q(VCNT[0]),
        .R(\VCNT[10]_i_1_n_0 ));
  FDRE \VCNT_reg[10] 
       (.C(PCK),
        .CE(hcntend),
        .D(p_0_in__0[10]),
        .Q(VCNT[10]),
        .R(\VCNT[10]_i_1_n_0 ));
  CARRY4 \VCNT_reg[10]_i_2 
       (.CI(1'b0),
        .CO({hcntend,\VCNT_reg[10]_i_2_n_1 ,\VCNT_reg[10]_i_2_n_2 ,\VCNT_reg[10]_i_2_n_3 }),
        .CYINIT(1'b1),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(\NLW_VCNT_reg[10]_i_2_O_UNCONNECTED [3:0]),
        .S({\VCNT[10]_i_5_n_0 ,\VCNT[10]_i_6_n_0 ,\VCNT[10]_i_7_n_0 ,\VCNT[10]_i_8_n_0 }));
  CARRY4 \VCNT_reg[10]_i_4 
       (.CI(1'b0),
        .CO({VCNT0,\VCNT_reg[10]_i_4_n_1 ,\VCNT_reg[10]_i_4_n_2 ,\VCNT_reg[10]_i_4_n_3 }),
        .CYINIT(1'b1),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(\NLW_VCNT_reg[10]_i_4_O_UNCONNECTED [3:0]),
        .S({\VCNT[10]_i_10_n_0 ,\VCNT[10]_i_11_n_0 ,\VCNT[10]_i_12_n_0 ,\VCNT[10]_i_13_n_0 }));
  FDRE \VCNT_reg[1] 
       (.C(PCK),
        .CE(hcntend),
        .D(p_0_in__0[1]),
        .Q(VCNT[1]),
        .R(\VCNT[10]_i_1_n_0 ));
  FDRE \VCNT_reg[2] 
       (.C(PCK),
        .CE(hcntend),
        .D(p_0_in__0[2]),
        .Q(VCNT[2]),
        .R(\VCNT[10]_i_1_n_0 ));
  FDRE \VCNT_reg[3] 
       (.C(PCK),
        .CE(hcntend),
        .D(p_0_in__0[3]),
        .Q(VCNT[3]),
        .R(\VCNT[10]_i_1_n_0 ));
  FDRE \VCNT_reg[4] 
       (.C(PCK),
        .CE(hcntend),
        .D(p_0_in__0[4]),
        .Q(VCNT[4]),
        .R(\VCNT[10]_i_1_n_0 ));
  FDRE \VCNT_reg[5] 
       (.C(PCK),
        .CE(hcntend),
        .D(p_0_in__0[5]),
        .Q(VCNT[5]),
        .R(\VCNT[10]_i_1_n_0 ));
  FDRE \VCNT_reg[6] 
       (.C(PCK),
        .CE(hcntend),
        .D(p_0_in__0[6]),
        .Q(VCNT[6]),
        .R(\VCNT[10]_i_1_n_0 ));
  FDRE \VCNT_reg[7] 
       (.C(PCK),
        .CE(hcntend),
        .D(p_0_in__0[7]),
        .Q(VCNT[7]),
        .R(\VCNT[10]_i_1_n_0 ));
  FDRE \VCNT_reg[8] 
       (.C(PCK),
        .CE(hcntend),
        .D(p_0_in__0[8]),
        .Q(VCNT[8]),
        .R(\VCNT[10]_i_1_n_0 ));
  FDRE \VCNT_reg[9] 
       (.C(PCK),
        .CE(hcntend),
        .D(p_0_in__0[9]),
        .Q(VCNT[9]),
        .R(\VCNT[10]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hBABBBABBBABBAAAA)) 
    \VGA_B[0]_i_1 
       (.I0(\VGA_B_reg[0] ),
        .I1(pattern_sel[3]),
        .I2(\VGA_B[7]_i_4_n_0 ),
        .I3(\VGA_R[0]_i_3_n_0 ),
        .I4(\VGA_R[0]_i_4_n_0 ),
        .I5(\VGA_B[7]_i_3_n_0 ),
        .O(D[0]));
  LUT6 #(
    .INIT(64'hBABBBABBBABBAAAA)) 
    \VGA_B[1]_i_1 
       (.I0(\VGA_B_reg[1] ),
        .I1(pattern_sel[3]),
        .I2(\VGA_B[7]_i_4_n_0 ),
        .I3(\VGA_R[1]_i_3_n_0 ),
        .I4(\VGA_R[1]_i_4_n_0 ),
        .I5(\VGA_B[7]_i_3_n_0 ),
        .O(D[1]));
  LUT6 #(
    .INIT(64'hBABBBABBBABBAAAA)) 
    \VGA_B[2]_i_1 
       (.I0(\VGA_B_reg[2] ),
        .I1(pattern_sel[3]),
        .I2(\VGA_B[7]_i_4_n_0 ),
        .I3(\VGA_R[2]_i_3_n_0 ),
        .I4(\VGA_R[2]_i_4_n_0 ),
        .I5(\VGA_B[7]_i_3_n_0 ),
        .O(D[2]));
  LUT6 #(
    .INIT(64'hBABBBABBBABBAAAA)) 
    \VGA_B[3]_i_1 
       (.I0(\VGA_R[3]_i_2_n_0 ),
        .I1(pattern_sel[3]),
        .I2(\VGA_B[7]_i_4_n_0 ),
        .I3(\VGA_R[3]_i_3_n_0 ),
        .I4(\VGA_R[3]_i_4_n_0 ),
        .I5(\VGA_B[7]_i_3_n_0 ),
        .O(D[3]));
  LUT6 #(
    .INIT(64'hBBB88888BBB8BBB8)) 
    \VGA_B[4]_i_1 
       (.I0(\VGA_B[4]_i_2_n_0 ),
        .I1(pattern_sel[3]),
        .I2(\VGA_B[7]_i_3_n_0 ),
        .I3(\VGA_R[4]_i_4_n_0 ),
        .I4(\VGA_B[7]_i_4_n_0 ),
        .I5(\VGA_R[4]_i_3_n_0 ),
        .O(D[4]));
  LUT6 #(
    .INIT(64'h08080808A8A8A808)) 
    \VGA_B[4]_i_2 
       (.I0(\VGA_R_reg[6] ),
        .I1(P[1]),
        .I2(\VGA_R_reg[6]_0 ),
        .I3(\VGA_R_reg[4]_i_5_n_2 ),
        .I4(\VGA_R_reg[5]_i_8_n_2 ),
        .I5(sel0[32]),
        .O(\VGA_B[4]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hBBB88888BBB8BBB8)) 
    \VGA_B[5]_i_1 
       (.I0(\VGA_B[5]_i_2_n_0 ),
        .I1(pattern_sel[3]),
        .I2(\VGA_B[7]_i_3_n_0 ),
        .I3(\VGA_R[5]_i_4_n_0 ),
        .I4(\VGA_B[7]_i_4_n_0 ),
        .I5(\VGA_R[5]_i_3_n_0 ),
        .O(D[5]));
  LUT6 #(
    .INIT(64'h08080808A8A8A808)) 
    \VGA_B[5]_i_2 
       (.I0(\VGA_R_reg[6] ),
        .I1(P[2]),
        .I2(\VGA_R_reg[6]_0 ),
        .I3(\VGA_R_reg[5]_i_8_n_2 ),
        .I4(\VGA_R[5]_i_6_n_0 ),
        .I5(sel0[32]),
        .O(\VGA_B[5]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hBBB88888BBB8BBB8)) 
    \VGA_B[6]_i_1 
       (.I0(\VGA_B[6]_i_2_n_0 ),
        .I1(pattern_sel[3]),
        .I2(\VGA_B[7]_i_3_n_0 ),
        .I3(\VGA_R[6]_i_3_n_0 ),
        .I4(\VGA_B[7]_i_4_n_0 ),
        .I5(\VGA_R[6]_i_4_n_0 ),
        .O(D[6]));
  LUT6 #(
    .INIT(64'h222222A200000080)) 
    \VGA_B[6]_i_2 
       (.I0(\VGA_R_reg[6] ),
        .I1(\VGA_R_reg[6]_0 ),
        .I2(\VGA_R[7]_i_27_n_0 ),
        .I3(\VGA_R[7]_i_28_n_0 ),
        .I4(\VGA_B[7]_i_5_n_0 ),
        .I5(P[3]),
        .O(\VGA_B[6]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hBBB88888BBB8BBB8)) 
    \VGA_B[7]_i_1 
       (.I0(\VGA_B[7]_i_2_n_0 ),
        .I1(pattern_sel[3]),
        .I2(\VGA_B[7]_i_3_n_0 ),
        .I3(\VGA_R[7]_i_7_n_0 ),
        .I4(\VGA_B[7]_i_4_n_0 ),
        .I5(\VGA_R[7]_i_9_n_0 ),
        .O(D[7]));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_B[7]_i_10 
       (.I0(\VGA_R_reg[7]_i_33_n_0 ),
        .I1(zp_sum),
        .I2(\VGA_R_reg[7]_i_33_n_6 ),
        .O(\VGA_B[7]_i_10_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_B[7]_i_11 
       (.I0(zp_sum),
        .I1(\VGA_R_reg[7]_i_33_n_0 ),
        .I2(\VGA_R_reg[7]_i_33_n_7 ),
        .O(\VGA_B[7]_i_11_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_B[7]_i_12 
       (.I0(\VGA_R_reg[7]_i_33_n_0 ),
        .I1(zp_sum),
        .I2(\VGA_R_reg[7]_i_86_n_4 ),
        .O(\VGA_B[7]_i_12_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_B[7]_i_14 
       (.I0(sel0[1]),
        .I1(\VGA_R_reg[7]_i_68_n_5 ),
        .O(\VGA_B[7]_i_14_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_B[7]_i_15 
       (.I0(sel0[1]),
        .I1(zp_sum),
        .I2(\VGA_R_reg[7]_i_68_n_6 ),
        .O(\VGA_B[7]_i_15_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_B[7]_i_16 
       (.I0(zp_sum),
        .I1(sel0[1]),
        .I2(\VGA_R_reg[7]_i_68_n_7 ),
        .O(\VGA_B[7]_i_16_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_B[7]_i_17 
       (.I0(sel0[1]),
        .I1(zp_sum),
        .I2(\VGA_R_reg[7]_i_121_n_4 ),
        .O(\VGA_B[7]_i_17_n_0 ));
  LUT1 #(
    .INIT(2'h2)) 
    \VGA_B[7]_i_18 
       (.I0(p_1_in[1]),
        .O(\VGA_B[7]_i_18_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_B[7]_i_19 
       (.I0(zp_sum),
        .I1(\VGA_R_reg[7]_i_33_n_0 ),
        .I2(\VGA_R_reg[7]_i_86_n_5 ),
        .O(\VGA_B[7]_i_19_n_0 ));
  LUT6 #(
    .INIT(64'h222222A200000080)) 
    \VGA_B[7]_i_2 
       (.I0(\VGA_R_reg[6] ),
        .I1(\VGA_R_reg[6]_0 ),
        .I2(\VGA_R[7]_i_27_n_0 ),
        .I3(\VGA_R[7]_i_28_n_0 ),
        .I4(\VGA_B[7]_i_5_n_0 ),
        .I5(P[4]),
        .O(\VGA_B[7]_i_2_n_0 ));
  LUT4 #(
    .INIT(16'h659A)) 
    \VGA_B[7]_i_20 
       (.I0(\VGA_R_reg[7]_i_33_n_0 ),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .I3(\VGA_R_reg[7]_i_86_n_6 ),
        .O(\VGA_B[7]_i_20_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_B[7]_i_21 
       (.I0(\VGA_R_reg[7]_i_33_n_0 ),
        .I1(\VGA_R_reg[7]_i_86_n_7 ),
        .O(\VGA_B[7]_i_21_n_0 ));
  LUT4 #(
    .INIT(16'h6966)) 
    \VGA_B[7]_i_22 
       (.I0(p_1_in[1]),
        .I1(\VGA_R_reg[7]_i_33_n_0 ),
        .I2(timing_sel[1]),
        .I3(timing_sel[0]),
        .O(\VGA_B[7]_i_22_n_0 ));
  LUT1 #(
    .INIT(2'h2)) 
    \VGA_B[7]_i_23 
       (.I0(\VGA_B_reg[7]_i_28_n_7 ),
        .O(\VGA_B[7]_i_23_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_B[7]_i_24 
       (.I0(zp_sum),
        .I1(sel0[1]),
        .I2(\VGA_R_reg[7]_i_121_n_5 ),
        .O(\VGA_B[7]_i_24_n_0 ));
  LUT4 #(
    .INIT(16'h659A)) 
    \VGA_B[7]_i_25 
       (.I0(sel0[1]),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .I3(\VGA_R_reg[7]_i_121_n_6 ),
        .O(\VGA_B[7]_i_25_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_B[7]_i_26 
       (.I0(sel0[1]),
        .I1(\VGA_R_reg[7]_i_121_n_7 ),
        .O(\VGA_B[7]_i_26_n_0 ));
  LUT4 #(
    .INIT(16'h659A)) 
    \VGA_B[7]_i_27 
       (.I0(sel0[1]),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .I3(\VGA_B_reg[7]_i_28_n_7 ),
        .O(\VGA_B[7]_i_27_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_B[7]_i_29 
       (.I0(\VGA_B_reg[7]_i_30_n_7 ),
        .I1(sel0[3]),
        .O(\VGA_B[7]_i_29_n_0 ));
  LUT6 #(
    .INIT(64'h0000000155555555)) 
    \VGA_B[7]_i_3 
       (.I0(pattern_sel[1]),
        .I1(\VGA_B_reg[7]_i_6_n_0 ),
        .I2(\VGA_B_reg[7] ),
        .I3(\VGA_R[7]_i_35_n_0 ),
        .I4(\VGA_R[7]_i_36_n_0 ),
        .I5(\VGA_R[7]_i_37_n_0 ),
        .O(\VGA_B[7]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_B[7]_i_31 
       (.I0(\VGA_B_reg[7]_i_32_n_7 ),
        .I1(sel0[4]),
        .O(\VGA_B[7]_i_31_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_B[7]_i_33 
       (.I0(\VGA_R_reg[7]_i_450_n_7 ),
        .I1(sel0[5]),
        .O(\VGA_B[7]_i_33_n_0 ));
  LUT6 #(
    .INIT(64'h0000FFAB000000AB)) 
    \VGA_B[7]_i_4 
       (.I0(\VGA_R[7]_i_41_n_0 ),
        .I1(\VGA_R[7]_i_42_n_0 ),
        .I2(\VGA_R[7]_i_31_n_0 ),
        .I3(pattern_sel[0]),
        .I4(pattern_sel[1]),
        .I5(FCNT[6]),
        .O(\VGA_B[7]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair33" *) 
  LUT4 #(
    .INIT(16'hFEFF)) 
    \VGA_B[7]_i_5 
       (.I0(sel0[0]),
        .I1(sel0[12]),
        .I2(sel0[11]),
        .I3(sel0[32]),
        .O(\VGA_B[7]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_B[7]_i_9 
       (.I0(\VGA_R_reg[7]_i_33_n_0 ),
        .I1(\VGA_R_reg[7]_i_33_n_5 ),
        .O(\VGA_B[7]_i_9_n_0 ));
  CARRY4 \VGA_B_reg[7]_i_13 
       (.CI(1'b0),
        .CO({\VGA_B_reg[7]_i_13_n_0 ,\VGA_B_reg[7]_i_13_n_1 ,\VGA_B_reg[7]_i_13_n_2 ,\VGA_B_reg[7]_i_13_n_3 }),
        .CYINIT(sel0[1]),
        .DI({\VGA_R_reg[7]_i_121_n_5 ,\VGA_R_reg[7]_i_121_n_6 ,sel0[1],\VGA_B[7]_i_23_n_0 }),
        .O(\NLW_VGA_B_reg[7]_i_13_O_UNCONNECTED [3:0]),
        .S({\VGA_B[7]_i_24_n_0 ,\VGA_B[7]_i_25_n_0 ,\VGA_B[7]_i_26_n_0 ,\VGA_B[7]_i_27_n_0 }));
  CARRY4 \VGA_B_reg[7]_i_28 
       (.CI(sel0[3]),
        .CO(\NLW_VGA_B_reg[7]_i_28_CO_UNCONNECTED [3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_VGA_B_reg[7]_i_28_O_UNCONNECTED [3:1],\VGA_B_reg[7]_i_28_n_7 }),
        .S({1'b0,1'b0,1'b0,\VGA_B[7]_i_29_n_0 }));
  CARRY4 \VGA_B_reg[7]_i_30 
       (.CI(sel0[4]),
        .CO(\NLW_VGA_B_reg[7]_i_30_CO_UNCONNECTED [3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_VGA_B_reg[7]_i_30_O_UNCONNECTED [3:1],\VGA_B_reg[7]_i_30_n_7 }),
        .S({1'b0,1'b0,1'b0,\VGA_B[7]_i_31_n_0 }));
  CARRY4 \VGA_B_reg[7]_i_32 
       (.CI(sel0[5]),
        .CO(\NLW_VGA_B_reg[7]_i_32_CO_UNCONNECTED [3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_VGA_B_reg[7]_i_32_O_UNCONNECTED [3:1],\VGA_B_reg[7]_i_32_n_7 }),
        .S({1'b0,1'b0,1'b0,\VGA_B[7]_i_33_n_0 }));
  CARRY4 \VGA_B_reg[7]_i_6 
       (.CI(\VGA_B_reg[7]_i_8_n_0 ),
        .CO({\VGA_B_reg[7]_i_6_n_0 ,\VGA_B_reg[7]_i_6_n_1 ,\VGA_B_reg[7]_i_6_n_2 ,\VGA_B_reg[7]_i_6_n_3 }),
        .CYINIT(1'b0),
        .DI({\VGA_R_reg[7]_i_33_n_0 ,\VGA_R_reg[7]_i_33_n_6 ,\VGA_R_reg[7]_i_33_n_7 ,\VGA_R_reg[7]_i_86_n_4 }),
        .O(\NLW_VGA_B_reg[7]_i_6_O_UNCONNECTED [3:0]),
        .S({\VGA_B[7]_i_9_n_0 ,\VGA_B[7]_i_10_n_0 ,\VGA_B[7]_i_11_n_0 ,\VGA_B[7]_i_12_n_0 }));
  CARRY4 \VGA_B_reg[7]_i_7 
       (.CI(\VGA_B_reg[7]_i_13_n_0 ),
        .CO({sel0[0],\VGA_B_reg[7]_i_7_n_1 ,\VGA_B_reg[7]_i_7_n_2 ,\VGA_B_reg[7]_i_7_n_3 }),
        .CYINIT(1'b0),
        .DI({sel0[1],\VGA_R_reg[7]_i_68_n_6 ,\VGA_R_reg[7]_i_68_n_7 ,\VGA_R_reg[7]_i_121_n_4 }),
        .O(\NLW_VGA_B_reg[7]_i_7_O_UNCONNECTED [3:0]),
        .S({\VGA_B[7]_i_14_n_0 ,\VGA_B[7]_i_15_n_0 ,\VGA_B[7]_i_16_n_0 ,\VGA_B[7]_i_17_n_0 }));
  CARRY4 \VGA_B_reg[7]_i_8 
       (.CI(1'b0),
        .CO({\VGA_B_reg[7]_i_8_n_0 ,\VGA_B_reg[7]_i_8_n_1 ,\VGA_B_reg[7]_i_8_n_2 ,\VGA_B_reg[7]_i_8_n_3 }),
        .CYINIT(\VGA_R_reg[7]_i_33_n_0 ),
        .DI({\VGA_R_reg[7]_i_86_n_5 ,\VGA_R_reg[7]_i_86_n_6 ,\VGA_R_reg[7]_i_33_n_0 ,\VGA_B[7]_i_18_n_0 }),
        .O(\NLW_VGA_B_reg[7]_i_8_O_UNCONNECTED [3:0]),
        .S({\VGA_B[7]_i_19_n_0 ,\VGA_B[7]_i_20_n_0 ,\VGA_B[7]_i_21_n_0 ,\VGA_B[7]_i_22_n_0 }));
  (* SOFT_HLUTNM = "soft_lutpair30" *) 
  LUT4 #(
    .INIT(16'h0080)) 
    VGA_DE_i_1
       (.I0(disp_enable10_in),
        .I1(disp_enable1),
        .I2(disp_enable0),
        .I3(RST),
        .O(RST_0));
  LUT6 #(
    .INIT(64'hBABBBABBBABBAAAA)) 
    \VGA_G[0]_i_1 
       (.I0(\VGA_B_reg[0] ),
        .I1(pattern_sel[3]),
        .I2(\VGA_G[7]_i_4_n_0 ),
        .I3(\VGA_R[0]_i_3_n_0 ),
        .I4(\VGA_R[0]_i_4_n_0 ),
        .I5(\VGA_G[7]_i_3_n_0 ),
        .O(\pattern_sel[3] [0]));
  LUT6 #(
    .INIT(64'hBABBBABBBABBAAAA)) 
    \VGA_G[1]_i_1 
       (.I0(\VGA_B_reg[1] ),
        .I1(pattern_sel[3]),
        .I2(\VGA_G[7]_i_4_n_0 ),
        .I3(\VGA_R[1]_i_3_n_0 ),
        .I4(\VGA_R[1]_i_4_n_0 ),
        .I5(\VGA_G[7]_i_3_n_0 ),
        .O(\pattern_sel[3] [1]));
  LUT6 #(
    .INIT(64'hBABBBABBBABBAAAA)) 
    \VGA_G[2]_i_1 
       (.I0(\VGA_B_reg[2] ),
        .I1(pattern_sel[3]),
        .I2(\VGA_G[7]_i_4_n_0 ),
        .I3(\VGA_R[2]_i_3_n_0 ),
        .I4(\VGA_R[2]_i_4_n_0 ),
        .I5(\VGA_G[7]_i_3_n_0 ),
        .O(\pattern_sel[3] [2]));
  LUT6 #(
    .INIT(64'hBABBBABBBABBAAAA)) 
    \VGA_G[3]_i_1 
       (.I0(\VGA_R[3]_i_2_n_0 ),
        .I1(pattern_sel[3]),
        .I2(\VGA_G[7]_i_4_n_0 ),
        .I3(\VGA_R[3]_i_3_n_0 ),
        .I4(\VGA_R[3]_i_4_n_0 ),
        .I5(\VGA_G[7]_i_3_n_0 ),
        .O(\pattern_sel[3] [3]));
  LUT6 #(
    .INIT(64'hBABBBABBBABBAAAA)) 
    \VGA_G[4]_i_1 
       (.I0(\VGA_R[4]_i_2_n_0 ),
        .I1(pattern_sel[3]),
        .I2(\VGA_G[7]_i_4_n_0 ),
        .I3(\VGA_R[4]_i_3_n_0 ),
        .I4(\VGA_R[4]_i_4_n_0 ),
        .I5(\VGA_G[7]_i_3_n_0 ),
        .O(\pattern_sel[3] [4]));
  LUT6 #(
    .INIT(64'hBABBBABBBABBAAAA)) 
    \VGA_G[5]_i_1 
       (.I0(\VGA_R[5]_i_2_n_0 ),
        .I1(pattern_sel[3]),
        .I2(\VGA_G[7]_i_4_n_0 ),
        .I3(\VGA_R[5]_i_3_n_0 ),
        .I4(\VGA_R[5]_i_4_n_0 ),
        .I5(\VGA_G[7]_i_3_n_0 ),
        .O(\pattern_sel[3] [5]));
  LUT6 #(
    .INIT(64'hBBB88888BBB8BBB8)) 
    \VGA_G[6]_i_1 
       (.I0(\VGA_G[6]_i_2_n_0 ),
        .I1(pattern_sel[3]),
        .I2(\VGA_G[7]_i_3_n_0 ),
        .I3(\VGA_R[6]_i_3_n_0 ),
        .I4(\VGA_G[7]_i_4_n_0 ),
        .I5(\VGA_R[6]_i_4_n_0 ),
        .O(\pattern_sel[3] [6]));
  LUT6 #(
    .INIT(64'h222222A200000080)) 
    \VGA_G[6]_i_2 
       (.I0(\VGA_R_reg[6] ),
        .I1(\VGA_R_reg[6]_0 ),
        .I2(\VGA_R[7]_i_27_n_0 ),
        .I3(\VGA_R[7]_i_28_n_0 ),
        .I4(\VGA_G[7]_i_5_n_0 ),
        .I5(P[3]),
        .O(\VGA_G[6]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hBBB88888BBB8BBB8)) 
    \VGA_G[7]_i_1 
       (.I0(\VGA_G[7]_i_2_n_0 ),
        .I1(pattern_sel[3]),
        .I2(\VGA_G[7]_i_3_n_0 ),
        .I3(\VGA_R[7]_i_7_n_0 ),
        .I4(\VGA_G[7]_i_4_n_0 ),
        .I5(\VGA_R[7]_i_9_n_0 ),
        .O(\pattern_sel[3] [7]));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_G[7]_i_10 
       (.I0(\VGA_R_reg[7]_i_94_n_0 ),
        .I1(zp_sum),
        .I2(\VGA_R_reg[7]_i_94_n_6 ),
        .O(\VGA_G[7]_i_10_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_G[7]_i_11 
       (.I0(zp_sum),
        .I1(\VGA_R_reg[7]_i_94_n_0 ),
        .I2(\VGA_R_reg[7]_i_94_n_7 ),
        .O(\VGA_G[7]_i_11_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_G[7]_i_12 
       (.I0(\VGA_R_reg[7]_i_94_n_0 ),
        .I1(zp_sum),
        .I2(\VGA_G_reg[7]_i_8_n_4 ),
        .O(\VGA_G[7]_i_12_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_G[7]_i_13 
       (.I0(sel0[3]),
        .I1(\VGA_R_reg[7]_i_75_n_5 ),
        .O(\VGA_G[7]_i_13_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_G[7]_i_14 
       (.I0(sel0[3]),
        .I1(zp_sum),
        .I2(\VGA_R_reg[7]_i_75_n_6 ),
        .O(\VGA_G[7]_i_14_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_G[7]_i_15 
       (.I0(zp_sum),
        .I1(sel0[3]),
        .I2(\VGA_R_reg[7]_i_75_n_7 ),
        .O(\VGA_G[7]_i_15_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_G[7]_i_16 
       (.I0(sel0[3]),
        .I1(zp_sum),
        .I2(\VGA_R_reg[7]_i_157_n_4 ),
        .O(\VGA_G[7]_i_16_n_0 ));
  LUT1 #(
    .INIT(2'h2)) 
    \VGA_G[7]_i_17 
       (.I0(p_1_in[4]),
        .O(\VGA_G[7]_i_17_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_G[7]_i_18 
       (.I0(zp_sum),
        .I1(\VGA_R_reg[7]_i_95_n_0 ),
        .I2(\VGA_R_reg[7]_i_211_n_5 ),
        .O(\VGA_G[7]_i_18_n_0 ));
  LUT4 #(
    .INIT(16'h659A)) 
    \VGA_G[7]_i_19 
       (.I0(\VGA_R_reg[7]_i_95_n_0 ),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .I3(\VGA_R_reg[7]_i_211_n_6 ),
        .O(\VGA_G[7]_i_19_n_0 ));
  LUT6 #(
    .INIT(64'h222222A200000080)) 
    \VGA_G[7]_i_2 
       (.I0(\VGA_R_reg[6] ),
        .I1(\VGA_R_reg[6]_0 ),
        .I2(\VGA_R[7]_i_27_n_0 ),
        .I3(\VGA_R[7]_i_28_n_0 ),
        .I4(\VGA_G[7]_i_5_n_0 ),
        .I5(P[4]),
        .O(\VGA_G[7]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_G[7]_i_20 
       (.I0(\VGA_R_reg[7]_i_95_n_0 ),
        .I1(\VGA_R_reg[7]_i_211_n_7 ),
        .O(\VGA_G[7]_i_20_n_0 ));
  LUT4 #(
    .INIT(16'h6966)) 
    \VGA_G[7]_i_21 
       (.I0(p_1_in[4]),
        .I1(\VGA_R_reg[7]_i_95_n_0 ),
        .I2(timing_sel[1]),
        .I3(timing_sel[0]),
        .O(\VGA_G[7]_i_21_n_0 ));
  LUT6 #(
    .INIT(64'h0000000155555555)) 
    \VGA_G[7]_i_3 
       (.I0(pattern_sel[1]),
        .I1(\VGA_G_reg[7]_i_6_n_0 ),
        .I2(\VGA_B_reg[7] ),
        .I3(\VGA_R[7]_i_35_n_0 ),
        .I4(\VGA_R[7]_i_36_n_0 ),
        .I5(\VGA_R[7]_i_37_n_0 ),
        .O(\VGA_G[7]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h0000FFAB000000AB)) 
    \VGA_G[7]_i_4 
       (.I0(\VGA_R[7]_i_41_n_0 ),
        .I1(\VGA_R[7]_i_42_n_0 ),
        .I2(\VGA_R[7]_i_31_n_0 ),
        .I3(pattern_sel[0]),
        .I4(pattern_sel[1]),
        .I5(FCNT[5]),
        .O(\VGA_G[7]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair33" *) 
  LUT4 #(
    .INIT(16'hFEFF)) 
    \VGA_G[7]_i_5 
       (.I0(sel0[2]),
        .I1(sel0[12]),
        .I2(sel0[11]),
        .I3(sel0[32]),
        .O(\VGA_G[7]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_G[7]_i_9 
       (.I0(\VGA_R_reg[7]_i_94_n_0 ),
        .I1(\VGA_R_reg[7]_i_94_n_5 ),
        .O(\VGA_G[7]_i_9_n_0 ));
  CARRY4 \VGA_G_reg[7]_i_6 
       (.CI(\VGA_R_reg[7]_i_87_n_0 ),
        .CO({\VGA_G_reg[7]_i_6_n_0 ,\VGA_G_reg[7]_i_6_n_1 ,\VGA_G_reg[7]_i_6_n_2 ,\VGA_G_reg[7]_i_6_n_3 }),
        .CYINIT(1'b0),
        .DI({\VGA_R_reg[7]_i_94_n_0 ,\VGA_R_reg[7]_i_94_n_6 ,\VGA_R_reg[7]_i_94_n_7 ,\VGA_G_reg[7]_i_8_n_4 }),
        .O({\NLW_VGA_G_reg[7]_i_6_O_UNCONNECTED [3],\VGA_G_reg[7]_i_6_n_5 ,\VGA_G_reg[7]_i_6_n_6 ,\VGA_G_reg[7]_i_6_n_7 }),
        .S({\VGA_G[7]_i_9_n_0 ,\VGA_G[7]_i_10_n_0 ,\VGA_G[7]_i_11_n_0 ,\VGA_G[7]_i_12_n_0 }));
  CARRY4 \VGA_G_reg[7]_i_7 
       (.CI(\VGA_R_reg[7]_i_122_n_0 ),
        .CO({sel0[2],\VGA_G_reg[7]_i_7_n_1 ,\VGA_G_reg[7]_i_7_n_2 ,\VGA_G_reg[7]_i_7_n_3 }),
        .CYINIT(1'b0),
        .DI({sel0[3],\VGA_R_reg[7]_i_75_n_6 ,\VGA_R_reg[7]_i_75_n_7 ,\VGA_R_reg[7]_i_157_n_4 }),
        .O({\NLW_VGA_G_reg[7]_i_7_O_UNCONNECTED [3],\VGA_G_reg[7]_i_7_n_5 ,\VGA_G_reg[7]_i_7_n_6 ,\VGA_G_reg[7]_i_7_n_7 }),
        .S({\VGA_G[7]_i_13_n_0 ,\VGA_G[7]_i_14_n_0 ,\VGA_G[7]_i_15_n_0 ,\VGA_G[7]_i_16_n_0 }));
  CARRY4 \VGA_G_reg[7]_i_8 
       (.CI(1'b0),
        .CO({\VGA_G_reg[7]_i_8_n_0 ,\VGA_G_reg[7]_i_8_n_1 ,\VGA_G_reg[7]_i_8_n_2 ,\VGA_G_reg[7]_i_8_n_3 }),
        .CYINIT(\VGA_R_reg[7]_i_95_n_0 ),
        .DI({\VGA_R_reg[7]_i_211_n_5 ,\VGA_R_reg[7]_i_211_n_6 ,\VGA_R_reg[7]_i_95_n_0 ,\VGA_G[7]_i_17_n_0 }),
        .O({\VGA_G_reg[7]_i_8_n_4 ,\VGA_G_reg[7]_i_8_n_5 ,\VGA_G_reg[7]_i_8_n_6 ,\VGA_G_reg[7]_i_8_n_7 }),
        .S({\VGA_G[7]_i_18_n_0 ,\VGA_G[7]_i_19_n_0 ,\VGA_G[7]_i_20_n_0 ,\VGA_G[7]_i_21_n_0 }));
  LUT5 #(
    .INIT(32'h66576654)) 
    VGA_HS_i_1
       (.I0(VGA_HS_i_2_n_0),
        .I1(RST),
        .I2(VGA_HS0),
        .I3(VGA_HS1),
        .I4(VGA_HS),
        .O(VGA_HS_i_1_n_0));
  LUT5 #(
    .INIT(32'h00000065)) 
    VGA_HS_i_10
       (.I0(HCNT[6]),
        .I1(timing_sel[0]),
        .I2(timing_sel[1]),
        .I3(HCNT[8]),
        .I4(HCNT[7]),
        .O(VGA_HS_i_10_n_0));
  LUT5 #(
    .INIT(32'h00202202)) 
    VGA_HS_i_11
       (.I0(HCNT[3]),
        .I1(HCNT[4]),
        .I2(timing_sel[1]),
        .I3(timing_sel[0]),
        .I4(HCNT[5]),
        .O(VGA_HS_i_11_n_0));
  LUT5 #(
    .INIT(32'h88080080)) 
    VGA_HS_i_12
       (.I0(HCNT[0]),
        .I1(HCNT[2]),
        .I2(timing_sel[1]),
        .I3(timing_sel[0]),
        .I4(HCNT[1]),
        .O(VGA_HS_i_12_n_0));
  (* SOFT_HLUTNM = "soft_lutpair31" *) 
  LUT2 #(
    .INIT(4'h2)) 
    VGA_HS_i_2
       (.I0(timing_sel[1]),
        .I1(timing_sel[0]),
        .O(VGA_HS_i_2_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    VGA_HS_i_5
       (.I0(HCNT[9]),
        .I1(HCNT[10]),
        .O(VGA_HS_i_5_n_0));
  LUT5 #(
    .INIT(32'h01002022)) 
    VGA_HS_i_6
       (.I0(HCNT[6]),
        .I1(HCNT[8]),
        .I2(timing_sel[0]),
        .I3(timing_sel[1]),
        .I4(HCNT[7]),
        .O(VGA_HS_i_6_n_0));
  LUT5 #(
    .INIT(32'h00048220)) 
    VGA_HS_i_7
       (.I0(HCNT[3]),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .I3(HCNT[5]),
        .I4(HCNT[4]),
        .O(VGA_HS_i_7_n_0));
  LUT5 #(
    .INIT(32'h82002800)) 
    VGA_HS_i_8
       (.I0(HCNT[0]),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .I3(HCNT[2]),
        .I4(HCNT[1]),
        .O(VGA_HS_i_8_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    VGA_HS_i_9
       (.I0(HCNT[9]),
        .I1(HCNT[10]),
        .O(VGA_HS_i_9_n_0));
  FDRE VGA_HS_reg
       (.C(PCK),
        .CE(1'b1),
        .D(VGA_HS_i_1_n_0),
        .Q(VGA_HS),
        .R(1'b0));
  CARRY4 VGA_HS_reg_i_3
       (.CI(1'b0),
        .CO({VGA_HS0,VGA_HS_reg_i_3_n_1,VGA_HS_reg_i_3_n_2,VGA_HS_reg_i_3_n_3}),
        .CYINIT(1'b1),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(NLW_VGA_HS_reg_i_3_O_UNCONNECTED[3:0]),
        .S({VGA_HS_i_5_n_0,VGA_HS_i_6_n_0,VGA_HS_i_7_n_0,VGA_HS_i_8_n_0}));
  CARRY4 VGA_HS_reg_i_4
       (.CI(1'b0),
        .CO({VGA_HS1,VGA_HS_reg_i_4_n_1,VGA_HS_reg_i_4_n_2,VGA_HS_reg_i_4_n_3}),
        .CYINIT(1'b1),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(NLW_VGA_HS_reg_i_4_O_UNCONNECTED[3:0]),
        .S({VGA_HS_i_9_n_0,VGA_HS_i_10_n_0,VGA_HS_i_11_n_0,VGA_HS_i_12_n_0}));
  LUT6 #(
    .INIT(64'hABBBABBBABBBAAAA)) 
    \VGA_R[0]_i_1 
       (.I0(\VGA_B_reg[0] ),
        .I1(pattern_sel[3]),
        .I2(\VGA_R[0]_i_3_n_0 ),
        .I3(\VGA_R[7]_i_10_n_0 ),
        .I4(\VGA_R[7]_i_8_n_0 ),
        .I5(\VGA_R[0]_i_4_n_0 ),
        .O(\pattern_sel[3]_0 [0]));
  LUT6 #(
    .INIT(64'h2AAA22222AAAAAAA)) 
    \VGA_R[0]_i_3 
       (.I0(pattern_sel[2]),
        .I1(pattern_sel[1]),
        .I2(\VGA_R_reg[7]_i_38_n_3 ),
        .I3(pattern_b11_in),
        .I4(pattern_sel[0]),
        .I5(data6[0]),
        .O(\VGA_R[0]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFAFEEEEAAAAAAAA)) 
    \VGA_R[0]_i_4 
       (.I0(pattern_sel[2]),
        .I1(data2[0]),
        .I2(\VGA_R[7]_i_31_n_0 ),
        .I3(\VGA_R[7]_i_32_n_0 ),
        .I4(pattern_sel[0]),
        .I5(pattern_sel[1]),
        .O(\VGA_R[0]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hABBBABBBABBBAAAA)) 
    \VGA_R[1]_i_1 
       (.I0(\VGA_B_reg[1] ),
        .I1(pattern_sel[3]),
        .I2(\VGA_R[1]_i_3_n_0 ),
        .I3(\VGA_R[7]_i_10_n_0 ),
        .I4(\VGA_R[7]_i_8_n_0 ),
        .I5(\VGA_R[1]_i_4_n_0 ),
        .O(\pattern_sel[3]_0 [1]));
  LUT6 #(
    .INIT(64'h2AAA22222AAAAAAA)) 
    \VGA_R[1]_i_3 
       (.I0(pattern_sel[2]),
        .I1(pattern_sel[1]),
        .I2(\VGA_R_reg[7]_i_38_n_3 ),
        .I3(pattern_b11_in),
        .I4(pattern_sel[0]),
        .I5(data6[1]),
        .O(\VGA_R[1]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFAFEEEEAAAAAAAA)) 
    \VGA_R[1]_i_4 
       (.I0(pattern_sel[2]),
        .I1(data2[1]),
        .I2(\VGA_R[7]_i_31_n_0 ),
        .I3(\VGA_R[7]_i_32_n_0 ),
        .I4(pattern_sel[0]),
        .I5(pattern_sel[1]),
        .O(\VGA_R[1]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hABBBABBBABBBAAAA)) 
    \VGA_R[2]_i_1 
       (.I0(\VGA_B_reg[2] ),
        .I1(pattern_sel[3]),
        .I2(\VGA_R[2]_i_3_n_0 ),
        .I3(\VGA_R[7]_i_10_n_0 ),
        .I4(\VGA_R[7]_i_8_n_0 ),
        .I5(\VGA_R[2]_i_4_n_0 ),
        .O(\pattern_sel[3]_0 [2]));
  LUT6 #(
    .INIT(64'h2AAA22222AAAAAAA)) 
    \VGA_R[2]_i_3 
       (.I0(pattern_sel[2]),
        .I1(pattern_sel[1]),
        .I2(\VGA_R_reg[7]_i_38_n_3 ),
        .I3(pattern_b11_in),
        .I4(pattern_sel[0]),
        .I5(data6[2]),
        .O(\VGA_R[2]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFAFEEEEAAAAAAAA)) 
    \VGA_R[2]_i_4 
       (.I0(pattern_sel[2]),
        .I1(data2[2]),
        .I2(\VGA_R[7]_i_31_n_0 ),
        .I3(\VGA_R[7]_i_32_n_0 ),
        .I4(pattern_sel[0]),
        .I5(pattern_sel[1]),
        .O(\VGA_R[2]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hABBBABBBABBBAAAA)) 
    \VGA_R[3]_i_1 
       (.I0(\VGA_R[3]_i_2_n_0 ),
        .I1(pattern_sel[3]),
        .I2(\VGA_R[3]_i_3_n_0 ),
        .I3(\VGA_R[7]_i_10_n_0 ),
        .I4(\VGA_R[7]_i_8_n_0 ),
        .I5(\VGA_R[3]_i_4_n_0 ),
        .O(\pattern_sel[3]_0 [3]));
  LUT6 #(
    .INIT(64'h0000008A00000080)) 
    \VGA_R[3]_i_2 
       (.I0(pattern_sel[3]),
        .I1(P[0]),
        .I2(pattern_sel[0]),
        .I3(pattern_sel[1]),
        .I4(pattern_sel[2]),
        .I5(\VGA_R[3]_i_5_n_0 ),
        .O(\VGA_R[3]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h2AAA22222AAAAAAA)) 
    \VGA_R[3]_i_3 
       (.I0(pattern_sel[2]),
        .I1(pattern_sel[1]),
        .I2(\VGA_R_reg[7]_i_38_n_3 ),
        .I3(pattern_b11_in),
        .I4(pattern_sel[0]),
        .I5(data6[3]),
        .O(\VGA_R[3]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFAFEEEEAAAAAAAA)) 
    \VGA_R[3]_i_4 
       (.I0(pattern_sel[2]),
        .I1(data2[3]),
        .I2(\VGA_R[7]_i_31_n_0 ),
        .I3(\VGA_R[7]_i_32_n_0 ),
        .I4(pattern_sel[0]),
        .I5(pattern_sel[1]),
        .O(\VGA_R[3]_i_4_n_0 ));
  LUT5 #(
    .INIT(32'h00000010)) 
    \VGA_R[3]_i_5 
       (.I0(\VGA_R_reg[5]_i_8_n_2 ),
        .I1(sel0[32]),
        .I2(\VGA_R_reg[5]_i_13_n_2 ),
        .I3(\VGA_R_reg[4]_i_5_n_2 ),
        .I4(\VGA_R_reg[5]_i_11_n_2 ),
        .O(\VGA_R[3]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hABBBABBBABBBAAAA)) 
    \VGA_R[4]_i_1 
       (.I0(\VGA_R[4]_i_2_n_0 ),
        .I1(pattern_sel[3]),
        .I2(\VGA_R[4]_i_3_n_0 ),
        .I3(\VGA_R[7]_i_10_n_0 ),
        .I4(\VGA_R[7]_i_8_n_0 ),
        .I5(\VGA_R[4]_i_4_n_0 ),
        .O(\pattern_sel[3]_0 [4]));
  LUT1 #(
    .INIT(2'h1)) 
    \VGA_R[4]_i_10 
       (.I0(p_1_in[10]),
        .O(\VGA_R[4]_i_10_n_0 ));
  LUT3 #(
    .INIT(8'h41)) 
    \VGA_R[4]_i_11 
       (.I0(p_1_in[9]),
        .I1(\VGA_R_reg[4]_i_5_0 ),
        .I2(p_1_in[8]),
        .O(\VGA_R[4]_i_11_n_0 ));
  LUT6 #(
    .INIT(64'h080808080808A808)) 
    \VGA_R[4]_i_2 
       (.I0(\VGA_R_reg[5] ),
        .I1(P[1]),
        .I2(\VGA_R_reg[6]_0 ),
        .I3(\VGA_R_reg[4]_i_5_n_2 ),
        .I4(sel0[32]),
        .I5(\VGA_R_reg[5]_i_8_n_2 ),
        .O(\VGA_R[4]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'h002FFFFF)) 
    \VGA_R[4]_i_22 
       (.I0(timing_sel[0]),
        .I1(timing_sel[1]),
        .I2(\VGA_R_reg[4]_i_5_0 ),
        .I3(p_1_in[6]),
        .I4(p_1_in[7]),
        .O(\VGA_R[4]_i_22_n_0 ));
  LUT5 #(
    .INIT(32'h5104515D)) 
    \VGA_R[4]_i_23 
       (.I0(p_1_in[5]),
        .I1(timing_sel[0]),
        .I2(timing_sel[1]),
        .I3(\VGA_R_reg[4]_i_5_0 ),
        .I4(p_1_in[4]),
        .O(\VGA_R[4]_i_23_n_0 ));
  LUT5 #(
    .INIT(32'h0000AAEF)) 
    \VGA_R[4]_i_24 
       (.I0(\VGA_R_reg[4]_i_5_0 ),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .I3(p_1_in[2]),
        .I4(p_1_in[3]),
        .O(\VGA_R[4]_i_24_n_0 ));
  LUT5 #(
    .INIT(32'h33332202)) 
    \VGA_R[4]_i_25 
       (.I0(HCNT[0]),
        .I1(p_1_in[1]),
        .I2(timing_sel[0]),
        .I3(timing_sel[1]),
        .I4(\VGA_R_reg[4]_i_5_0 ),
        .O(\VGA_R[4]_i_25_n_0 ));
  LUT5 #(
    .INIT(32'h08AAA200)) 
    \VGA_R[4]_i_26 
       (.I0(p_1_in[7]),
        .I1(timing_sel[0]),
        .I2(timing_sel[1]),
        .I3(\VGA_R_reg[4]_i_5_0 ),
        .I4(p_1_in[6]),
        .O(\VGA_R[4]_i_26_n_0 ));
  LUT5 #(
    .INIT(32'h12118488)) 
    \VGA_R[4]_i_27 
       (.I0(p_1_in[5]),
        .I1(\VGA_R_reg[4]_i_5_0 ),
        .I2(timing_sel[1]),
        .I3(timing_sel[0]),
        .I4(p_1_in[4]),
        .O(\VGA_R[4]_i_27_n_0 ));
  LUT5 #(
    .INIT(32'h0051AA04)) 
    \VGA_R[4]_i_28 
       (.I0(p_1_in[3]),
        .I1(timing_sel[0]),
        .I2(timing_sel[1]),
        .I3(\VGA_R_reg[4]_i_5_0 ),
        .I4(p_1_in[2]),
        .O(\VGA_R[4]_i_28_n_0 ));
  LUT5 #(
    .INIT(32'hAA040051)) 
    \VGA_R[4]_i_29 
       (.I0(p_1_in[1]),
        .I1(timing_sel[0]),
        .I2(timing_sel[1]),
        .I3(\VGA_R_reg[4]_i_5_0 ),
        .I4(HCNT[0]),
        .O(\VGA_R[4]_i_29_n_0 ));
  LUT6 #(
    .INIT(64'h2AAA22222AAAAAAA)) 
    \VGA_R[4]_i_3 
       (.I0(pattern_sel[2]),
        .I1(pattern_sel[1]),
        .I2(\VGA_R_reg[7]_i_38_n_3 ),
        .I3(pattern_b11_in),
        .I4(pattern_sel[0]),
        .I5(data6[4]),
        .O(\VGA_R[4]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFAFEEEEAAAAAAAA)) 
    \VGA_R[4]_i_4 
       (.I0(pattern_sel[2]),
        .I1(data2[4]),
        .I2(\VGA_R[7]_i_31_n_0 ),
        .I3(\VGA_R[7]_i_32_n_0 ),
        .I4(pattern_sel[0]),
        .I5(pattern_sel[1]),
        .O(\VGA_R[4]_i_4_n_0 ));
  LUT3 #(
    .INIT(8'h04)) 
    \VGA_R[4]_i_9 
       (.I0(p_1_in[9]),
        .I1(\VGA_R_reg[4]_i_5_0 ),
        .I2(p_1_in[8]),
        .O(\VGA_R[4]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'hABBBABBBABBBAAAA)) 
    \VGA_R[5]_i_1 
       (.I0(\VGA_R[5]_i_2_n_0 ),
        .I1(pattern_sel[3]),
        .I2(\VGA_R[5]_i_3_n_0 ),
        .I3(\VGA_R[7]_i_10_n_0 ),
        .I4(\VGA_R[7]_i_8_n_0 ),
        .I5(\VGA_R[5]_i_4_n_0 ),
        .O(\pattern_sel[3]_0 [5]));
  LUT2 #(
    .INIT(4'h1)) 
    \VGA_R[5]_i_15 
       (.I0(A[9]),
        .I1(A[8]),
        .O(\VGA_R[5]_i_15_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \VGA_R[5]_i_16 
       (.I0(A[10]),
        .O(\VGA_R[5]_i_16_n_0 ));
  LUT2 #(
    .INIT(4'h4)) 
    \VGA_R[5]_i_17 
       (.I0(A[9]),
        .I1(A[8]),
        .O(\VGA_R[5]_i_17_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \VGA_R[5]_i_19 
       (.I0(p_1_in[10]),
        .O(\VGA_R[5]_i_19_n_0 ));
  LUT6 #(
    .INIT(64'h080808080808A808)) 
    \VGA_R[5]_i_2 
       (.I0(\VGA_R_reg[5] ),
        .I1(P[2]),
        .I2(\VGA_R_reg[6]_0 ),
        .I3(\VGA_R[5]_i_6_n_0 ),
        .I4(sel0[32]),
        .I5(\VGA_R_reg[5]_i_8_n_2 ),
        .O(\VGA_R[5]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \VGA_R[5]_i_20 
       (.I0(p_1_in[8]),
        .I1(p_1_in[9]),
        .O(\VGA_R[5]_i_20_n_0 ));
  LUT6 #(
    .INIT(64'h2AAA22222AAAAAAA)) 
    \VGA_R[5]_i_3 
       (.I0(pattern_sel[2]),
        .I1(pattern_sel[1]),
        .I2(\VGA_R_reg[7]_i_38_n_3 ),
        .I3(pattern_b11_in),
        .I4(pattern_sel[0]),
        .I5(data6[5]),
        .O(\VGA_R[5]_i_3_n_0 ));
  LUT4 #(
    .INIT(16'h002B)) 
    \VGA_R[5]_i_32 
       (.I0(\VGA_R_reg[5]_i_31_0 ),
        .I1(\VGA_R_reg[5]_i_11_0 ),
        .I2(p_1_in[8]),
        .I3(p_1_in[9]),
        .O(\VGA_R[5]_i_32_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \VGA_R[5]_i_33 
       (.I0(p_1_in[10]),
        .O(\VGA_R[5]_i_33_n_0 ));
  LUT4 #(
    .INIT(16'h4118)) 
    \VGA_R[5]_i_34 
       (.I0(p_1_in[9]),
        .I1(\VGA_R_reg[5]_i_31_0 ),
        .I2(\VGA_R_reg[5]_i_11_0 ),
        .I3(p_1_in[8]),
        .O(\VGA_R[5]_i_34_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \VGA_R[5]_i_36 
       (.I0(\VGA_R_reg[4]_i_5_0 ),
        .I1(p_1_in[10]),
        .O(\VGA_R[5]_i_36_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \VGA_R[5]_i_37 
       (.I0(p_1_in[9]),
        .I1(\VGA_R_reg[4]_i_5_0 ),
        .O(\VGA_R[5]_i_37_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \VGA_R[5]_i_38 
       (.I0(p_1_in[10]),
        .I1(\VGA_R_reg[4]_i_5_0 ),
        .O(\VGA_R[5]_i_38_n_0 ));
  LUT3 #(
    .INIT(8'h14)) 
    \VGA_R[5]_i_39 
       (.I0(p_1_in[8]),
        .I1(\VGA_R_reg[4]_i_5_0 ),
        .I2(p_1_in[9]),
        .O(\VGA_R[5]_i_39_n_0 ));
  LUT6 #(
    .INIT(64'hFFAFEEEEAAAAAAAA)) 
    \VGA_R[5]_i_4 
       (.I0(pattern_sel[2]),
        .I1(data2[5]),
        .I2(\VGA_R[7]_i_31_n_0 ),
        .I3(\VGA_R[7]_i_32_n_0 ),
        .I4(pattern_sel[0]),
        .I5(pattern_sel[1]),
        .O(\VGA_R[5]_i_4_n_0 ));
  LUT3 #(
    .INIT(8'h71)) 
    \VGA_R[5]_i_41 
       (.I0(p_1_in[8]),
        .I1(p_1_in[9]),
        .I2(\VGA_R_reg[4]_i_5_0 ),
        .O(\VGA_R[5]_i_41_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \VGA_R[5]_i_42 
       (.I0(p_1_in[10]),
        .O(\VGA_R[5]_i_42_n_0 ));
  LUT3 #(
    .INIT(8'h90)) 
    \VGA_R[5]_i_43 
       (.I0(\VGA_R_reg[4]_i_5_0 ),
        .I1(p_1_in[9]),
        .I2(p_1_in[8]),
        .O(\VGA_R[5]_i_43_n_0 ));
  LUT6 #(
    .INIT(64'h55550000FFFF5540)) 
    \VGA_R[5]_i_44 
       (.I0(A[7]),
        .I1(\VGA_R_reg[5]_i_14_4 ),
        .I2(\VGA_R_reg[5]_i_14_2 ),
        .I3(\VGA_R_reg[5]_i_14_3 ),
        .I4(\VGA_R_reg[4]_i_5_0 ),
        .I5(A[6]),
        .O(\VGA_R[5]_i_44_n_0 ));
  LUT6 #(
    .INIT(64'h554000155555003F)) 
    \VGA_R[5]_i_45 
       (.I0(A[5]),
        .I1(\VGA_R_reg[5]_i_14_4 ),
        .I2(\VGA_R_reg[5]_i_14_2 ),
        .I3(\VGA_R_reg[5]_i_14_3 ),
        .I4(\VGA_R_reg[4]_i_5_0 ),
        .I5(A[4]),
        .O(\VGA_R[5]_i_45_n_0 ));
  LUT5 #(
    .INIT(32'h01114333)) 
    \VGA_R[5]_i_46 
       (.I0(A[3]),
        .I1(\VGA_R_reg[5]_i_14_3 ),
        .I2(\VGA_R_reg[5]_i_14_4 ),
        .I3(\VGA_R_reg[5]_i_14_2 ),
        .I4(A[2]),
        .O(\VGA_R[5]_i_46_n_0 ));
  LUT6 #(
    .INIT(64'h45441011CFCC5555)) 
    \VGA_R[5]_i_47 
       (.I0(A[1]),
        .I1(\VGA_R_reg[5]_i_14_0 ),
        .I2(\VGA_R_reg[4]_i_5_0 ),
        .I3(\VGA_R_reg[5]_i_14_1 ),
        .I4(\VGA_R_reg[5]_i_14_2 ),
        .I5(A[0]),
        .O(\VGA_R[5]_i_47_n_0 ));
  LUT6 #(
    .INIT(64'hA5A4A4A400010101)) 
    \VGA_R[5]_i_48 
       (.I0(A[7]),
        .I1(\VGA_R_reg[5]_i_14_3 ),
        .I2(\VGA_R_reg[4]_i_5_0 ),
        .I3(\VGA_R_reg[5]_i_14_4 ),
        .I4(\VGA_R_reg[5]_i_14_2 ),
        .I5(A[6]),
        .O(\VGA_R[5]_i_48_n_0 ));
  LUT6 #(
    .INIT(64'h0006060699909090)) 
    \VGA_R[5]_i_49 
       (.I0(\VGA_R_reg[4]_i_5_0 ),
        .I1(A[5]),
        .I2(\VGA_R_reg[5]_i_14_3 ),
        .I3(\VGA_R_reg[5]_i_14_4 ),
        .I4(\VGA_R_reg[5]_i_14_2 ),
        .I5(A[4]),
        .O(\VGA_R[5]_i_49_n_0 ));
  LUT5 #(
    .INIT(32'h42221444)) 
    \VGA_R[5]_i_50 
       (.I0(A[3]),
        .I1(\VGA_R_reg[5]_i_14_3 ),
        .I2(\VGA_R_reg[5]_i_14_4 ),
        .I3(\VGA_R_reg[5]_i_14_2 ),
        .I4(A[2]),
        .O(\VGA_R[5]_i_50_n_0 ));
  LUT6 #(
    .INIT(64'h9099909006000606)) 
    \VGA_R[5]_i_51 
       (.I0(\VGA_R_reg[5]_i_14_2 ),
        .I1(A[1]),
        .I2(\VGA_R_reg[5]_i_14_0 ),
        .I3(\VGA_R_reg[4]_i_5_0 ),
        .I4(\VGA_R_reg[5]_i_14_1 ),
        .I5(A[0]),
        .O(\VGA_R[5]_i_51_n_0 ));
  LUT3 #(
    .INIT(8'h4D)) 
    \VGA_R[5]_i_52 
       (.I0(p_1_in[7]),
        .I1(\VGA_R_reg[4]_i_5_0 ),
        .I2(p_1_in[6]),
        .O(\VGA_R[5]_i_52_n_0 ));
  LUT5 #(
    .INIT(32'h15115755)) 
    \VGA_R[5]_i_53 
       (.I0(p_1_in[5]),
        .I1(\VGA_R_reg[4]_i_5_0 ),
        .I2(timing_sel[1]),
        .I3(timing_sel[0]),
        .I4(p_1_in[4]),
        .O(\VGA_R[5]_i_53_n_0 ));
  LUT3 #(
    .INIT(8'h15)) 
    \VGA_R[5]_i_54 
       (.I0(p_1_in[3]),
        .I1(\VGA_R_reg[4]_i_5_0 ),
        .I2(p_1_in[2]),
        .O(\VGA_R[5]_i_54_n_0 ));
  LUT5 #(
    .INIT(32'h0000FB51)) 
    \VGA_R[5]_i_55 
       (.I0(\VGA_R_reg[4]_i_5_0 ),
        .I1(timing_sel[0]),
        .I2(timing_sel[1]),
        .I3(HCNT[0]),
        .I4(p_1_in[1]),
        .O(\VGA_R[5]_i_55_n_0 ));
  LUT3 #(
    .INIT(8'h82)) 
    \VGA_R[5]_i_56 
       (.I0(p_1_in[6]),
        .I1(\VGA_R_reg[4]_i_5_0 ),
        .I2(p_1_in[7]),
        .O(\VGA_R[5]_i_56_n_0 ));
  LUT5 #(
    .INIT(32'h42442822)) 
    \VGA_R[5]_i_57 
       (.I0(p_1_in[5]),
        .I1(\VGA_R_reg[4]_i_5_0 ),
        .I2(timing_sel[1]),
        .I3(timing_sel[0]),
        .I4(p_1_in[4]),
        .O(\VGA_R[5]_i_57_n_0 ));
  LUT3 #(
    .INIT(8'h42)) 
    \VGA_R[5]_i_58 
       (.I0(p_1_in[3]),
        .I1(\VGA_R_reg[4]_i_5_0 ),
        .I2(p_1_in[2]),
        .O(\VGA_R[5]_i_58_n_0 ));
  LUT5 #(
    .INIT(32'h22124444)) 
    \VGA_R[5]_i_59 
       (.I0(p_1_in[1]),
        .I1(\VGA_R_reg[4]_i_5_0 ),
        .I2(timing_sel[0]),
        .I3(timing_sel[1]),
        .I4(HCNT[0]),
        .O(\VGA_R[5]_i_59_n_0 ));
  LUT4 #(
    .INIT(16'h0001)) 
    \VGA_R[5]_i_6 
       (.I0(\VGA_R_reg[5]_i_11_n_2 ),
        .I1(\VGA_R_reg[4]_i_5_n_2 ),
        .I2(\VGA_R_reg[5]_i_12_n_2 ),
        .I3(\VGA_R_reg[5]_i_13_n_2 ),
        .O(\VGA_R[5]_i_6_n_0 ));
  LUT5 #(
    .INIT(32'h40544050)) 
    \VGA_R[5]_i_70 
       (.I0(p_1_in[7]),
        .I1(\VGA_R_reg[5]_i_31_3 [2]),
        .I2(\VGA_R_reg[5]_i_31_0 ),
        .I3(p_1_in[6]),
        .I4(\VGA_R_reg[5]_i_31_3 [1]),
        .O(\VGA_R[5]_i_70_n_0 ));
  LUT6 #(
    .INIT(64'h1005511051177551)) 
    \VGA_R[5]_i_71 
       (.I0(p_1_in[5]),
        .I1(\VGA_R_reg[7]_i_231_0 ),
        .I2(\VGA_R_reg[5]_i_31_3 [1]),
        .I3(\VGA_R_reg[5]_i_31_0 ),
        .I4(\VGA_R_reg[5]_i_31_3 [2]),
        .I5(p_1_in[4]),
        .O(\VGA_R[5]_i_71_n_0 ));
  LUT6 #(
    .INIT(64'h555440007DD55001)) 
    \VGA_R[5]_i_72 
       (.I0(p_1_in[3]),
        .I1(\VGA_R_reg[5]_i_31_3 [0]),
        .I2(\VGA_R_reg[5]_i_31_2 ),
        .I3(\VGA_R_reg[7]_i_231_0 ),
        .I4(\VGA_R_reg[5]_i_31_1 ),
        .I5(p_1_in[2]),
        .O(\VGA_R[5]_i_72_n_0 ));
  LUT6 #(
    .INIT(64'h200000003BB22CCE)) 
    \VGA_R[5]_i_73 
       (.I0(HCNT[0]),
        .I1(\VGA_R_reg[5]_i_31_3 [0]),
        .I2(\VGA_R_reg[5]_i_31_2 ),
        .I3(\VGA_R_reg[7]_i_231_0 ),
        .I4(\VGA_R_reg[5]_i_31_1 ),
        .I5(p_1_in[1]),
        .O(\VGA_R[5]_i_73_n_0 ));
  LUT5 #(
    .INIT(32'h0540A015)) 
    \VGA_R[5]_i_74 
       (.I0(p_1_in[7]),
        .I1(\VGA_R_reg[5]_i_31_3 [1]),
        .I2(\VGA_R_reg[5]_i_31_3 [2]),
        .I3(\VGA_R_reg[5]_i_31_0 ),
        .I4(p_1_in[6]),
        .O(\VGA_R[5]_i_74_n_0 ));
  LUT6 #(
    .INIT(64'h4124124124824824)) 
    \VGA_R[5]_i_75 
       (.I0(p_1_in[5]),
        .I1(\VGA_R_reg[7]_i_231_0 ),
        .I2(\VGA_R_reg[5]_i_31_0 ),
        .I3(\VGA_R_reg[5]_i_31_3 [2]),
        .I4(\VGA_R_reg[5]_i_31_3 [1]),
        .I5(p_1_in[4]),
        .O(\VGA_R[5]_i_75_n_0 ));
  LUT6 #(
    .INIT(64'h08809005A1190990)) 
    \VGA_R[5]_i_76 
       (.I0(p_1_in[3]),
        .I1(\VGA_R_reg[5]_i_31_1 ),
        .I2(\VGA_R_reg[7]_i_231_0 ),
        .I3(\VGA_R_reg[5]_i_31_2 ),
        .I4(\VGA_R_reg[5]_i_31_3 [0]),
        .I5(p_1_in[2]),
        .O(\VGA_R[5]_i_76_n_0 ));
  LUT6 #(
    .INIT(64'h5226099004409005)) 
    \VGA_R[5]_i_77 
       (.I0(p_1_in[1]),
        .I1(\VGA_R_reg[5]_i_31_1 ),
        .I2(\VGA_R_reg[7]_i_231_0 ),
        .I3(\VGA_R_reg[5]_i_31_2 ),
        .I4(\VGA_R_reg[5]_i_31_3 [0]),
        .I5(HCNT[0]),
        .O(\VGA_R[5]_i_77_n_0 ));
  LUT5 #(
    .INIT(32'h40544044)) 
    \VGA_R[5]_i_80 
       (.I0(p_1_in[7]),
        .I1(\VGA_R_reg[5]_i_35_0 ),
        .I2(\VGA_R_reg[5]_i_35_1 [1]),
        .I3(p_1_in[6]),
        .I4(\VGA_R_reg[5]_i_35_1 [0]),
        .O(\VGA_R[5]_i_80_n_0 ));
  LUT5 #(
    .INIT(32'h002400B6)) 
    \VGA_R[5]_i_81 
       (.I0(\VGA_R_reg[5]_i_35_0 ),
        .I1(\VGA_R_reg[5]_i_35_1 [1]),
        .I2(\VGA_R_reg[5]_i_35_1 [0]),
        .I3(p_1_in[5]),
        .I4(p_1_in[4]),
        .O(\VGA_R[5]_i_81_n_0 ));
  LUT6 #(
    .INIT(64'h1051051050750750)) 
    \VGA_R[5]_i_82 
       (.I0(p_1_in[3]),
        .I1(\VGA_R_reg[7]_i_231_0 ),
        .I2(\VGA_R_reg[5]_i_35_1 [0]),
        .I3(\VGA_R_reg[5]_i_35_1 [1]),
        .I4(\VGA_R_reg[5]_i_35_0 ),
        .I5(p_1_in[2]),
        .O(\VGA_R[5]_i_82_n_0 ));
  LUT6 #(
    .INIT(64'h0000000097E91681)) 
    \VGA_R[5]_i_83 
       (.I0(\VGA_R_reg[7]_i_231_0 ),
        .I1(\VGA_R_reg[5]_i_35_1 [0]),
        .I2(\VGA_R_reg[5]_i_35_0 ),
        .I3(\VGA_R_reg[5]_i_35_1 [1]),
        .I4(HCNT[0]),
        .I5(p_1_in[1]),
        .O(\VGA_R[5]_i_83_n_0 ));
  LUT5 #(
    .INIT(32'h0540A015)) 
    \VGA_R[5]_i_84 
       (.I0(p_1_in[7]),
        .I1(\VGA_R_reg[5]_i_35_1 [0]),
        .I2(\VGA_R_reg[5]_i_35_1 [1]),
        .I3(\VGA_R_reg[5]_i_35_0 ),
        .I4(p_1_in[6]),
        .O(\VGA_R[5]_i_84_n_0 ));
  LUT5 #(
    .INIT(32'h41041861)) 
    \VGA_R[5]_i_85 
       (.I0(p_1_in[5]),
        .I1(\VGA_R_reg[5]_i_35_0 ),
        .I2(\VGA_R_reg[5]_i_35_1 [1]),
        .I3(\VGA_R_reg[5]_i_35_1 [0]),
        .I4(p_1_in[4]),
        .O(\VGA_R[5]_i_85_n_0 ));
  LUT6 #(
    .INIT(64'h0410492492491041)) 
    \VGA_R[5]_i_86 
       (.I0(p_1_in[2]),
        .I1(\VGA_R_reg[5]_i_35_0 ),
        .I2(\VGA_R_reg[5]_i_35_1 [1]),
        .I3(\VGA_R_reg[5]_i_35_1 [0]),
        .I4(\VGA_R_reg[7]_i_231_0 ),
        .I5(p_1_in[3]),
        .O(\VGA_R[5]_i_86_n_0 ));
  LUT6 #(
    .INIT(64'h1668811640011440)) 
    \VGA_R[5]_i_87 
       (.I0(p_1_in[1]),
        .I1(\VGA_R_reg[7]_i_231_0 ),
        .I2(\VGA_R_reg[5]_i_35_1 [0]),
        .I3(\VGA_R_reg[5]_i_35_0 ),
        .I4(\VGA_R_reg[5]_i_35_1 [1]),
        .I5(HCNT[0]),
        .O(\VGA_R[5]_i_87_n_0 ));
  LUT5 #(
    .INIT(32'h00045DFF)) 
    \VGA_R[5]_i_88 
       (.I0(p_1_in[6]),
        .I1(timing_sel[0]),
        .I2(timing_sel[1]),
        .I3(\VGA_R_reg[4]_i_5_0 ),
        .I4(p_1_in[7]),
        .O(\VGA_R[5]_i_88_n_0 ));
  LUT3 #(
    .INIT(8'h15)) 
    \VGA_R[5]_i_89 
       (.I0(p_1_in[5]),
        .I1(\VGA_R_reg[4]_i_5_0 ),
        .I2(p_1_in[4]),
        .O(\VGA_R[5]_i_89_n_0 ));
  LUT5 #(
    .INIT(32'h11115055)) 
    \VGA_R[5]_i_90 
       (.I0(p_1_in[3]),
        .I1(p_1_in[2]),
        .I2(timing_sel[1]),
        .I3(timing_sel[0]),
        .I4(\VGA_R_reg[4]_i_5_0 ),
        .O(\VGA_R[5]_i_90_n_0 ));
  LUT5 #(
    .INIT(32'h0000FB51)) 
    \VGA_R[5]_i_91 
       (.I0(\VGA_R_reg[4]_i_5_0 ),
        .I1(timing_sel[0]),
        .I2(timing_sel[1]),
        .I3(HCNT[0]),
        .I4(p_1_in[1]),
        .O(\VGA_R[5]_i_91_n_0 ));
  LUT5 #(
    .INIT(32'h42442822)) 
    \VGA_R[5]_i_92 
       (.I0(p_1_in[7]),
        .I1(\VGA_R_reg[4]_i_5_0 ),
        .I2(timing_sel[1]),
        .I3(timing_sel[0]),
        .I4(p_1_in[6]),
        .O(\VGA_R[5]_i_92_n_0 ));
  LUT3 #(
    .INIT(8'h42)) 
    \VGA_R[5]_i_93 
       (.I0(p_1_in[5]),
        .I1(\VGA_R_reg[4]_i_5_0 ),
        .I2(p_1_in[4]),
        .O(\VGA_R[5]_i_93_n_0 ));
  LUT5 #(
    .INIT(32'h0051AA04)) 
    \VGA_R[5]_i_94 
       (.I0(p_1_in[2]),
        .I1(timing_sel[0]),
        .I2(timing_sel[1]),
        .I3(\VGA_R_reg[4]_i_5_0 ),
        .I4(p_1_in[3]),
        .O(\VGA_R[5]_i_94_n_0 ));
  LUT5 #(
    .INIT(32'h22124444)) 
    \VGA_R[5]_i_95 
       (.I0(p_1_in[1]),
        .I1(\VGA_R_reg[4]_i_5_0 ),
        .I2(timing_sel[0]),
        .I3(timing_sel[1]),
        .I4(HCNT[0]),
        .O(\VGA_R[5]_i_95_n_0 ));
  LUT6 #(
    .INIT(64'h8888BBB8BBB8BBB8)) 
    \VGA_R[6]_i_1 
       (.I0(\VGA_R[6]_i_2_n_0 ),
        .I1(pattern_sel[3]),
        .I2(\VGA_R[6]_i_3_n_0 ),
        .I3(\VGA_R[7]_i_8_n_0 ),
        .I4(\VGA_R[6]_i_4_n_0 ),
        .I5(\VGA_R[7]_i_10_n_0 ),
        .O(\pattern_sel[3]_0 [6]));
  LUT6 #(
    .INIT(64'h0A0A8A0A00008000)) 
    \VGA_R[6]_i_2 
       (.I0(\VGA_R_reg[6] ),
        .I1(\VGA_R[7]_i_26_n_0 ),
        .I2(\VGA_R_reg[6]_0 ),
        .I3(\VGA_R[7]_i_27_n_0 ),
        .I4(\VGA_R[7]_i_28_n_0 ),
        .I5(P[3]),
        .O(\VGA_R[6]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFAFEEEEAAAAAAAA)) 
    \VGA_R[6]_i_3 
       (.I0(pattern_sel[2]),
        .I1(data2[6]),
        .I2(\VGA_R[7]_i_31_n_0 ),
        .I3(\VGA_R[7]_i_32_n_0 ),
        .I4(pattern_sel[0]),
        .I5(pattern_sel[1]),
        .O(\VGA_R[6]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h2AAA22222AAAAAAA)) 
    \VGA_R[6]_i_4 
       (.I0(pattern_sel[2]),
        .I1(pattern_sel[1]),
        .I2(\VGA_R_reg[7]_i_38_n_3 ),
        .I3(pattern_b11_in),
        .I4(pattern_sel[0]),
        .I5(data6[6]),
        .O(\VGA_R[6]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair30" *) 
  LUT4 #(
    .INIT(16'hBFFF)) 
    \VGA_R[7]_i_1 
       (.I0(RST),
        .I1(disp_enable0),
        .I2(disp_enable1),
        .I3(disp_enable10_in),
        .O(SR));
  LUT6 #(
    .INIT(64'h00000000EFEFEFEE)) 
    \VGA_R[7]_i_10 
       (.I0(pattern_sel[0]),
        .I1(pattern_sel[1]),
        .I2(\VGA_R[7]_i_41_n_0 ),
        .I3(\VGA_R[7]_i_42_n_0 ),
        .I4(\VGA_R[7]_i_31_n_0 ),
        .I5(\VGA_R[7]_i_43_n_0 ),
        .O(\VGA_R[7]_i_10_n_0 ));
  LUT5 #(
    .INIT(32'h02000000)) 
    \VGA_R[7]_i_103 
       (.I0(\VGA_R[7]_i_258_n_0 ),
        .I1(\VGA_R[7]_i_259_n_0 ),
        .I2(p_1_in[10]),
        .I3(\VGA_R[7]_i_260_n_0 ),
        .I4(\VGA_R[7]_i_261_n_0 ),
        .O(\VGA_R[7]_i_103_n_0 ));
  LUT5 #(
    .INIT(32'h2D0F0F0F)) 
    \VGA_R[7]_i_104 
       (.I0(\VGA_R[7]_i_258_n_0 ),
        .I1(\VGA_R[7]_i_259_n_0 ),
        .I2(p_1_in[10]),
        .I3(\VGA_R[7]_i_260_n_0 ),
        .I4(\VGA_R[7]_i_261_n_0 ),
        .O(\VGA_R[7]_i_104_n_0 ));
  LUT4 #(
    .INIT(16'h22B2)) 
    \VGA_R[7]_i_106 
       (.I0(p_1_in[9]),
        .I1(\VGA_R[7]_i_260_n_0 ),
        .I2(p_1_in[8]),
        .I3(\VGA_R[7]_i_261_n_0 ),
        .O(\VGA_R[7]_i_106_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \VGA_R[7]_i_107 
       (.I0(p_1_in[10]),
        .O(\VGA_R[7]_i_107_n_0 ));
  LUT4 #(
    .INIT(16'h9009)) 
    \VGA_R[7]_i_108 
       (.I0(\VGA_R[7]_i_260_n_0 ),
        .I1(p_1_in[9]),
        .I2(\VGA_R[7]_i_261_n_0 ),
        .I3(p_1_in[8]),
        .O(\VGA_R[7]_i_108_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \VGA_R[7]_i_12 
       (.I0(VGA_HS_i_2_n_0),
        .I1(HCNT[10]),
        .O(\VGA_R[7]_i_12_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_123 
       (.I0(sel0[2]),
        .I1(\VGA_G_reg[7]_i_7_n_5 ),
        .O(\VGA_R[7]_i_123_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_124 
       (.I0(sel0[2]),
        .I1(zp_sum),
        .I2(\VGA_G_reg[7]_i_7_n_6 ),
        .O(\VGA_R[7]_i_124_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_125 
       (.I0(zp_sum),
        .I1(sel0[2]),
        .I2(\VGA_G_reg[7]_i_7_n_7 ),
        .O(\VGA_R[7]_i_125_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_126 
       (.I0(sel0[2]),
        .I1(zp_sum),
        .I2(\VGA_R_reg[7]_i_122_n_4 ),
        .O(\VGA_R[7]_i_126_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_128 
       (.I0(\VGA_R_reg[7]_i_317_n_4 ),
        .I1(sel0[12]),
        .O(\VGA_R[7]_i_128_n_0 ));
  LUT3 #(
    .INIT(8'h1F)) 
    \VGA_R[7]_i_13 
       (.I0(VGA_HS_i_2_n_0),
        .I1(HCNT[8]),
        .I2(HCNT[9]),
        .O(\VGA_R[7]_i_13_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_132 
       (.I0(sel0[12]),
        .I1(\VGA_R_reg[7]_i_70_0 [2]),
        .O(\VGA_R[7]_i_132_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_133 
       (.I0(sel0[12]),
        .I1(zp_sum),
        .I2(\VGA_R_reg[7]_i_70_0 [1]),
        .O(\VGA_R[7]_i_133_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_134 
       (.I0(zp_sum),
        .I1(sel0[12]),
        .I2(\VGA_R_reg[7]_i_70_0 [0]),
        .O(\VGA_R[7]_i_134_n_0 ));
  LUT3 #(
    .INIT(8'h65)) 
    \VGA_R[7]_i_135 
       (.I0(sel0[12]),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .O(\VGA_R[7]_i_135_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_138 
       (.I0(sel0[7]),
        .I1(\VGA_R_reg[7]_i_78_n_5 ),
        .O(\VGA_R[7]_i_138_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_139 
       (.I0(sel0[7]),
        .I1(zp_sum),
        .I2(\VGA_R_reg[7]_i_78_n_6 ),
        .O(\VGA_R[7]_i_139_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \VGA_R[7]_i_14 
       (.I0(HCNT[10]),
        .I1(VGA_HS_i_2_n_0),
        .O(\VGA_R[7]_i_14_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_140 
       (.I0(zp_sum),
        .I1(sel0[7]),
        .I2(\VGA_R_reg[7]_i_78_n_7 ),
        .O(\VGA_R[7]_i_140_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_141 
       (.I0(sel0[7]),
        .I1(zp_sum),
        .I2(\VGA_R_reg[7]_i_137_n_4 ),
        .O(\VGA_R[7]_i_141_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_144 
       (.I0(sel0[10]),
        .I1(\VGA_R_reg[7]_i_74_n_5 ),
        .O(\VGA_R[7]_i_144_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_145 
       (.I0(sel0[10]),
        .I1(zp_sum),
        .I2(\VGA_R_reg[7]_i_74_n_6 ),
        .O(\VGA_R[7]_i_145_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_146 
       (.I0(zp_sum),
        .I1(sel0[10]),
        .I2(\VGA_R_reg[7]_i_74_n_7 ),
        .O(\VGA_R[7]_i_146_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_147 
       (.I0(sel0[10]),
        .I1(zp_sum),
        .I2(\VGA_R_reg[7]_i_143_n_4 ),
        .O(\VGA_R[7]_i_147_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_149 
       (.I0(sel0[9]),
        .I1(\VGA_R_reg[7]_i_72_n_5 ),
        .O(\VGA_R[7]_i_149_n_0 ));
  LUT3 #(
    .INIT(8'h28)) 
    \VGA_R[7]_i_15 
       (.I0(HCNT[9]),
        .I1(VGA_HS_i_2_n_0),
        .I2(HCNT[8]),
        .O(\VGA_R[7]_i_15_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_150 
       (.I0(sel0[9]),
        .I1(zp_sum),
        .I2(\VGA_R_reg[7]_i_72_n_6 ),
        .O(\VGA_R[7]_i_150_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_151 
       (.I0(zp_sum),
        .I1(sel0[9]),
        .I2(\VGA_R_reg[7]_i_72_n_7 ),
        .O(\VGA_R[7]_i_151_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_152 
       (.I0(sel0[9]),
        .I1(zp_sum),
        .I2(\VGA_R_reg[7]_i_142_n_4 ),
        .O(\VGA_R[7]_i_152_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_153 
       (.I0(sel0[11]),
        .I1(\VGA_R_reg[7]_i_70_n_5 ),
        .O(\VGA_R[7]_i_153_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_154 
       (.I0(sel0[11]),
        .I1(zp_sum),
        .I2(\VGA_R_reg[7]_i_70_n_6 ),
        .O(\VGA_R[7]_i_154_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_155 
       (.I0(zp_sum),
        .I1(sel0[11]),
        .I2(\VGA_R_reg[7]_i_70_n_7 ),
        .O(\VGA_R[7]_i_155_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_156 
       (.I0(sel0[11]),
        .I1(zp_sum),
        .I2(\VGA_R_reg[7]_i_130_n_4 ),
        .O(\VGA_R[7]_i_156_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_159 
       (.I0(sel0[4]),
        .I1(\VGA_R_reg[7]_i_76_n_5 ),
        .O(\VGA_R[7]_i_159_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_160 
       (.I0(sel0[4]),
        .I1(zp_sum),
        .I2(\VGA_R_reg[7]_i_76_n_6 ),
        .O(\VGA_R[7]_i_160_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_161 
       (.I0(zp_sum),
        .I1(sel0[4]),
        .I2(\VGA_R_reg[7]_i_76_n_7 ),
        .O(\VGA_R[7]_i_161_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_162 
       (.I0(sel0[4]),
        .I1(zp_sum),
        .I2(\VGA_R_reg[7]_i_158_n_4 ),
        .O(\VGA_R[7]_i_162_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_164 
       (.I0(sel0[5]),
        .I1(\VGA_R_reg[7]_i_77_n_5 ),
        .O(\VGA_R[7]_i_164_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_165 
       (.I0(sel0[5]),
        .I1(zp_sum),
        .I2(\VGA_R_reg[7]_i_77_n_6 ),
        .O(\VGA_R[7]_i_165_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_166 
       (.I0(zp_sum),
        .I1(sel0[5]),
        .I2(\VGA_R_reg[7]_i_77_n_7 ),
        .O(\VGA_R[7]_i_166_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_167 
       (.I0(sel0[5]),
        .I1(zp_sum),
        .I2(\VGA_R_reg[7]_i_163_n_4 ),
        .O(\VGA_R[7]_i_167_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_168 
       (.I0(sel0[6]),
        .I1(\VGA_R_reg[7]_i_71_n_5 ),
        .O(\VGA_R[7]_i_168_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_169 
       (.I0(sel0[6]),
        .I1(zp_sum),
        .I2(\VGA_R_reg[7]_i_71_n_6 ),
        .O(\VGA_R[7]_i_169_n_0 ));
  LUT4 #(
    .INIT(16'hFB00)) 
    \VGA_R[7]_i_17 
       (.I0(zp_sum0[2]),
        .I1(\VGA_R_reg[7]_i_4_0 ),
        .I2(CO),
        .I3(HCNT[10]),
        .O(\VGA_R[7]_i_17_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_170 
       (.I0(zp_sum),
        .I1(sel0[6]),
        .I2(\VGA_R_reg[7]_i_71_n_7 ),
        .O(\VGA_R[7]_i_170_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_171 
       (.I0(sel0[6]),
        .I1(zp_sum),
        .I2(\VGA_R_reg[7]_i_136_n_4 ),
        .O(\VGA_R[7]_i_171_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_172 
       (.I0(sel0[8]),
        .I1(\VGA_R_reg[7]_i_73_n_5 ),
        .O(\VGA_R[7]_i_172_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_173 
       (.I0(sel0[8]),
        .I1(zp_sum),
        .I2(\VGA_R_reg[7]_i_73_n_6 ),
        .O(\VGA_R[7]_i_173_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_174 
       (.I0(zp_sum),
        .I1(sel0[8]),
        .I2(\VGA_R_reg[7]_i_73_n_7 ),
        .O(\VGA_R[7]_i_174_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_175 
       (.I0(sel0[8]),
        .I1(zp_sum),
        .I2(\VGA_R_reg[7]_i_148_n_4 ),
        .O(\VGA_R[7]_i_175_n_0 ));
  LUT5 #(
    .INIT(32'hCECEE0CE)) 
    \VGA_R[7]_i_18 
       (.I0(HCNT[8]),
        .I1(HCNT[9]),
        .I2(CO),
        .I3(\VGA_R_reg[7]_i_4_0 ),
        .I4(zp_sum0[2]),
        .O(\VGA_R[7]_i_18_n_0 ));
  LUT4 #(
    .INIT(16'h04FB)) 
    \VGA_R[7]_i_19 
       (.I0(zp_sum0[2]),
        .I1(\VGA_R_reg[7]_i_4_0 ),
        .I2(CO),
        .I3(HCNT[10]),
        .O(\VGA_R[7]_i_19_n_0 ));
  LUT1 #(
    .INIT(2'h2)) 
    \VGA_R[7]_i_193 
       (.I0(p_1_in[2]),
        .O(\VGA_R[7]_i_193_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_194 
       (.I0(zp_sum),
        .I1(\VGA_G_reg[7]_i_6_n_0 ),
        .I2(\VGA_R_reg[7]_i_87_n_5 ),
        .O(\VGA_R[7]_i_194_n_0 ));
  LUT4 #(
    .INIT(16'h659A)) 
    \VGA_R[7]_i_195 
       (.I0(\VGA_G_reg[7]_i_6_n_0 ),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .I3(\VGA_R_reg[7]_i_87_n_6 ),
        .O(\VGA_R[7]_i_195_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_196 
       (.I0(\VGA_G_reg[7]_i_6_n_0 ),
        .I1(\VGA_R_reg[7]_i_87_n_7 ),
        .O(\VGA_R[7]_i_196_n_0 ));
  LUT4 #(
    .INIT(16'h6966)) 
    \VGA_R[7]_i_197 
       (.I0(p_1_in[2]),
        .I1(\VGA_G_reg[7]_i_6_n_0 ),
        .I2(timing_sel[1]),
        .I3(timing_sel[0]),
        .O(\VGA_R[7]_i_197_n_0 ));
  LUT1 #(
    .INIT(2'h2)) 
    \VGA_R[7]_i_198 
       (.I0(p_1_in[3]),
        .O(\VGA_R[7]_i_198_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_199 
       (.I0(zp_sum),
        .I1(\VGA_R_reg[7]_i_94_n_0 ),
        .I2(\VGA_G_reg[7]_i_8_n_5 ),
        .O(\VGA_R[7]_i_199_n_0 ));
  LUT6 #(
    .INIT(64'h8888BBB8BBB8BBB8)) 
    \VGA_R[7]_i_2 
       (.I0(\VGA_R[7]_i_6_n_0 ),
        .I1(pattern_sel[3]),
        .I2(\VGA_R[7]_i_7_n_0 ),
        .I3(\VGA_R[7]_i_8_n_0 ),
        .I4(\VGA_R[7]_i_9_n_0 ),
        .I5(\VGA_R[7]_i_10_n_0 ),
        .O(\pattern_sel[3]_0 [7]));
  LUT5 #(
    .INIT(32'h42441411)) 
    \VGA_R[7]_i_20 
       (.I0(HCNT[9]),
        .I1(CO),
        .I2(zp_sum0[2]),
        .I3(\VGA_R_reg[7]_i_4_0 ),
        .I4(HCNT[8]),
        .O(\VGA_R[7]_i_20_n_0 ));
  LUT4 #(
    .INIT(16'h659A)) 
    \VGA_R[7]_i_200 
       (.I0(\VGA_R_reg[7]_i_94_n_0 ),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .I3(\VGA_G_reg[7]_i_8_n_6 ),
        .O(\VGA_R[7]_i_200_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_201 
       (.I0(\VGA_R_reg[7]_i_94_n_0 ),
        .I1(\VGA_G_reg[7]_i_8_n_7 ),
        .O(\VGA_R[7]_i_201_n_0 ));
  LUT4 #(
    .INIT(16'h6966)) 
    \VGA_R[7]_i_202 
       (.I0(p_1_in[3]),
        .I1(\VGA_R_reg[7]_i_94_n_0 ),
        .I2(timing_sel[1]),
        .I3(timing_sel[0]),
        .O(\VGA_R[7]_i_202_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_212 
       (.I0(\VGA_R_reg[7]_i_95_n_0 ),
        .I1(\VGA_R_reg[7]_i_95_n_5 ),
        .O(\VGA_R[7]_i_212_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_213 
       (.I0(\VGA_R_reg[7]_i_95_n_0 ),
        .I1(zp_sum),
        .I2(\VGA_R_reg[7]_i_95_n_6 ),
        .O(\VGA_R[7]_i_213_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_214 
       (.I0(zp_sum),
        .I1(\VGA_R_reg[7]_i_95_n_0 ),
        .I2(\VGA_R_reg[7]_i_95_n_7 ),
        .O(\VGA_R[7]_i_214_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_215 
       (.I0(\VGA_R_reg[7]_i_95_n_0 ),
        .I1(zp_sum),
        .I2(\VGA_R_reg[7]_i_211_n_4 ),
        .O(\VGA_R[7]_i_215_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_217 
       (.I0(\VGA_R_reg[7]_i_96_n_0 ),
        .I1(\VGA_R_reg[7]_i_96_n_5 ),
        .O(\VGA_R[7]_i_217_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_218 
       (.I0(\VGA_R_reg[7]_i_96_n_0 ),
        .I1(zp_sum),
        .I2(\VGA_R_reg[7]_i_96_n_6 ),
        .O(\VGA_R[7]_i_218_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_219 
       (.I0(zp_sum),
        .I1(\VGA_R_reg[7]_i_96_n_0 ),
        .I2(\VGA_R_reg[7]_i_96_n_7 ),
        .O(\VGA_R[7]_i_219_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \VGA_R[7]_i_22 
       (.I0(VCNT[9]),
        .I1(VCNT[8]),
        .O(\VGA_R[7]_i_22_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_220 
       (.I0(\VGA_R_reg[7]_i_96_n_0 ),
        .I1(zp_sum),
        .I2(\VGA_R_reg[7]_i_216_n_4 ),
        .O(\VGA_R[7]_i_220_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_222 
       (.I0(\VGA_R_reg[7]_i_97_n_0 ),
        .I1(\VGA_R_reg[7]_i_97_n_5 ),
        .O(\VGA_R[7]_i_222_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_223 
       (.I0(\VGA_R_reg[7]_i_97_n_0 ),
        .I1(zp_sum),
        .I2(\VGA_R_reg[7]_i_97_n_6 ),
        .O(\VGA_R[7]_i_223_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_224 
       (.I0(zp_sum),
        .I1(\VGA_R_reg[7]_i_97_n_0 ),
        .I2(\VGA_R_reg[7]_i_97_n_7 ),
        .O(\VGA_R[7]_i_224_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_225 
       (.I0(\VGA_R_reg[7]_i_97_n_0 ),
        .I1(zp_sum),
        .I2(\VGA_R_reg[7]_i_221_n_4 ),
        .O(\VGA_R[7]_i_225_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_227 
       (.I0(\VGA_R_reg[7]_i_98_n_0 ),
        .I1(\VGA_R_reg[7]_i_98_n_5 ),
        .O(\VGA_R[7]_i_227_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_228 
       (.I0(\VGA_R_reg[7]_i_98_n_0 ),
        .I1(zp_sum),
        .I2(\VGA_R_reg[7]_i_98_n_6 ),
        .O(\VGA_R[7]_i_228_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_229 
       (.I0(zp_sum),
        .I1(\VGA_R_reg[7]_i_98_n_0 ),
        .I2(\VGA_R_reg[7]_i_98_n_7 ),
        .O(\VGA_R[7]_i_229_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \VGA_R[7]_i_23 
       (.I0(VCNT[10]),
        .O(\VGA_R[7]_i_23_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_230 
       (.I0(\VGA_R_reg[7]_i_98_n_0 ),
        .I1(zp_sum),
        .I2(\VGA_R_reg[7]_i_226_n_4 ),
        .O(\VGA_R[7]_i_230_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_232 
       (.I0(\VGA_R_reg[7]_i_99_n_0 ),
        .I1(\VGA_R_reg[7]_i_99_n_5 ),
        .O(\VGA_R[7]_i_232_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_233 
       (.I0(\VGA_R_reg[7]_i_99_n_0 ),
        .I1(zp_sum),
        .I2(\VGA_R_reg[7]_i_99_n_6 ),
        .O(\VGA_R[7]_i_233_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_234 
       (.I0(zp_sum),
        .I1(\VGA_R_reg[7]_i_99_n_0 ),
        .I2(\VGA_R_reg[7]_i_99_n_7 ),
        .O(\VGA_R[7]_i_234_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_235 
       (.I0(\VGA_R_reg[7]_i_99_n_0 ),
        .I1(zp_sum),
        .I2(\VGA_R_reg[7]_i_231_n_4 ),
        .O(\VGA_R[7]_i_235_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_237 
       (.I0(\VGA_R_reg[7]_i_100_n_0 ),
        .I1(\VGA_R_reg[7]_i_100_n_5 ),
        .O(\VGA_R[7]_i_237_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_238 
       (.I0(\VGA_R_reg[7]_i_100_n_0 ),
        .I1(zp_sum),
        .I2(\VGA_R_reg[7]_i_100_n_6 ),
        .O(\VGA_R[7]_i_238_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_239 
       (.I0(zp_sum),
        .I1(\VGA_R_reg[7]_i_100_n_0 ),
        .I2(\VGA_R_reg[7]_i_100_n_7 ),
        .O(\VGA_R[7]_i_239_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \VGA_R[7]_i_24 
       (.I0(VCNT[8]),
        .I1(VCNT[9]),
        .O(\VGA_R[7]_i_24_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_240 
       (.I0(\VGA_R_reg[7]_i_100_n_0 ),
        .I1(zp_sum),
        .I2(\VGA_R_reg[7]_i_236_n_4 ),
        .O(\VGA_R[7]_i_240_n_0 ));
  LUT6 #(
    .INIT(64'h0D020F00DD0F2F02)) 
    \VGA_R[7]_i_250 
       (.I0(\VGA_R[7]_i_258_n_0 ),
        .I1(\VGA_R[7]_i_259_n_0 ),
        .I2(p_1_in[9]),
        .I3(\VGA_R[7]_i_260_n_0 ),
        .I4(\VGA_R[7]_i_261_n_0 ),
        .I5(p_1_in[8]),
        .O(\VGA_R[7]_i_250_n_0 ));
  LUT5 #(
    .INIT(32'h045145D3)) 
    \VGA_R[7]_i_251 
       (.I0(p_1_in[7]),
        .I1(\VGA_R[7]_i_428_n_0 ),
        .I2(\VGA_R[7]_i_429_n_0 ),
        .I3(\VGA_R[7]_i_259_n_0 ),
        .I4(p_1_in[6]),
        .O(\VGA_R[7]_i_251_n_0 ));
  LUT6 #(
    .INIT(64'h1111411171114777)) 
    \VGA_R[7]_i_252 
       (.I0(p_1_in[5]),
        .I1(\VGA_R[7]_i_430_n_0 ),
        .I2(FCNT[1]),
        .I3(FCNT[0]),
        .I4(\VGA_R[7]_i_431_n_0 ),
        .I5(p_1_in[4]),
        .O(\VGA_R[7]_i_252_n_0 ));
  LUT4 #(
    .INIT(16'h105B)) 
    \VGA_R[7]_i_253 
       (.I0(FCNT[0]),
        .I1(p_1_in[2]),
        .I2(FCNT[1]),
        .I3(p_1_in[3]),
        .O(\VGA_R[7]_i_253_n_0 ));
  LUT6 #(
    .INIT(64'hD00D20020220D00D)) 
    \VGA_R[7]_i_254 
       (.I0(\VGA_R[7]_i_258_n_0 ),
        .I1(\VGA_R[7]_i_259_n_0 ),
        .I2(\VGA_R[7]_i_260_n_0 ),
        .I3(p_1_in[9]),
        .I4(\VGA_R[7]_i_261_n_0 ),
        .I5(p_1_in[8]),
        .O(\VGA_R[7]_i_254_n_0 ));
  LUT5 #(
    .INIT(32'h60060690)) 
    \VGA_R[7]_i_255 
       (.I0(\VGA_R[7]_i_259_n_0 ),
        .I1(p_1_in[7]),
        .I2(\VGA_R[7]_i_428_n_0 ),
        .I3(\VGA_R[7]_i_429_n_0 ),
        .I4(p_1_in[6]),
        .O(\VGA_R[7]_i_255_n_0 ));
  LUT6 #(
    .INIT(64'h6000066606669000)) 
    \VGA_R[7]_i_256 
       (.I0(\VGA_R[7]_i_430_n_0 ),
        .I1(p_1_in[5]),
        .I2(FCNT[1]),
        .I3(FCNT[0]),
        .I4(\VGA_R[7]_i_431_n_0 ),
        .I5(p_1_in[4]),
        .O(\VGA_R[7]_i_256_n_0 ));
  LUT4 #(
    .INIT(16'h0690)) 
    \VGA_R[7]_i_257 
       (.I0(p_1_in[3]),
        .I1(FCNT[1]),
        .I2(p_1_in[2]),
        .I3(FCNT[0]),
        .O(\VGA_R[7]_i_257_n_0 ));
  LUT6 #(
    .INIT(64'h0800008000000000)) 
    \VGA_R[7]_i_258 
       (.I0(FCNT[1]),
        .I1(FCNT[0]),
        .I2(\VGA_R[7]_i_432_n_0 ),
        .I3(FCNT[2]),
        .I4(FCNT[3]),
        .I5(FCNT[4]),
        .O(\VGA_R[7]_i_258_n_0 ));
  LUT6 #(
    .INIT(64'h00F50000FB3BFFFF)) 
    \VGA_R[7]_i_259 
       (.I0(\VGA_R[7]_i_433_n_0 ),
        .I1(FCNT[6]),
        .I2(\VGA_R_reg[7]_i_231_0 ),
        .I3(VGA_HS_i_2_n_0),
        .I4(FCNT[7]),
        .I5(FCNT[5]),
        .O(\VGA_R[7]_i_259_n_0 ));
  LUT4 #(
    .INIT(16'h0100)) 
    \VGA_R[7]_i_26 
       (.I0(sel0[1]),
        .I1(sel0[12]),
        .I2(sel0[11]),
        .I3(sel0[32]),
        .O(\VGA_R[7]_i_26_n_0 ));
  LUT6 #(
    .INIT(64'h4044404440444444)) 
    \VGA_R[7]_i_260 
       (.I0(\VGA_R[7]_i_432_n_0 ),
        .I1(FCNT[7]),
        .I2(VGA_HS_i_2_n_0),
        .I3(\VGA_R_reg[7]_i_231_0 ),
        .I4(FCNT[5]),
        .I5(FCNT[6]),
        .O(\VGA_R[7]_i_260_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAA2AA88AA80AA)) 
    \VGA_R[7]_i_261 
       (.I0(FCNT[6]),
        .I1(\VGA_R_reg[7]_i_231_0 ),
        .I2(VGA_HS_i_2_n_0),
        .I3(FCNT[7]),
        .I4(FCNT[5]),
        .I5(\VGA_R[7]_i_434_n_0 ),
        .O(\VGA_R[7]_i_261_n_0 ));
  LUT4 #(
    .INIT(16'hE888)) 
    \VGA_R[7]_i_262 
       (.I0(p_1_in[7]),
        .I1(\VGA_R[7]_i_259_n_0 ),
        .I2(\VGA_R[7]_i_429_n_0 ),
        .I3(p_1_in[6]),
        .O(\VGA_R[7]_i_262_n_0 ));
  LUT5 #(
    .INIT(32'hA2CB208A)) 
    \VGA_R[7]_i_263 
       (.I0(p_1_in[5]),
        .I1(FCNT[2]),
        .I2(\VGA_R[7]_i_432_n_0 ),
        .I3(FCNT[3]),
        .I4(p_1_in[4]),
        .O(\VGA_R[7]_i_263_n_0 ));
  LUT4 #(
    .INIT(16'h22B2)) 
    \VGA_R[7]_i_264 
       (.I0(p_1_in[3]),
        .I1(FCNT[1]),
        .I2(p_1_in[2]),
        .I3(FCNT[0]),
        .O(\VGA_R[7]_i_264_n_0 ));
  LUT2 #(
    .INIT(4'hB)) 
    \VGA_R[7]_i_265 
       (.I0(p_1_in[1]),
        .I1(HCNT[0]),
        .O(\VGA_R[7]_i_265_n_0 ));
  LUT4 #(
    .INIT(16'h0660)) 
    \VGA_R[7]_i_266 
       (.I0(\VGA_R[7]_i_259_n_0 ),
        .I1(p_1_in[7]),
        .I2(\VGA_R[7]_i_429_n_0 ),
        .I3(p_1_in[6]),
        .O(\VGA_R[7]_i_266_n_0 ));
  LUT5 #(
    .INIT(32'h06909009)) 
    \VGA_R[7]_i_267 
       (.I0(FCNT[3]),
        .I1(p_1_in[5]),
        .I2(FCNT[2]),
        .I3(\VGA_R[7]_i_432_n_0 ),
        .I4(p_1_in[4]),
        .O(\VGA_R[7]_i_267_n_0 ));
  LUT4 #(
    .INIT(16'h9009)) 
    \VGA_R[7]_i_268 
       (.I0(FCNT[1]),
        .I1(p_1_in[3]),
        .I2(FCNT[0]),
        .I3(p_1_in[2]),
        .O(\VGA_R[7]_i_268_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \VGA_R[7]_i_269 
       (.I0(HCNT[0]),
        .I1(p_1_in[1]),
        .O(\VGA_R[7]_i_269_n_0 ));
  LUT4 #(
    .INIT(16'h0001)) 
    \VGA_R[7]_i_27 
       (.I0(sel0[6]),
        .I1(sel0[9]),
        .I2(sel0[8]),
        .I3(sel0[10]),
        .O(\VGA_R[7]_i_27_n_0 ));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \VGA_R[7]_i_28 
       (.I0(sel0[3]),
        .I1(sel0[4]),
        .I2(sel0[5]),
        .I3(sel0[7]),
        .O(\VGA_R[7]_i_28_n_0 ));
  LUT3 #(
    .INIT(8'h18)) 
    \VGA_R[7]_i_287 
       (.I0(p_1_in[10]),
        .I1(zp_sum),
        .I2(p_1_in[9]),
        .O(\VGA_R[7]_i_287_n_0 ));
  LUT6 #(
    .INIT(64'h0000000082888282)) 
    \VGA_R[7]_i_288 
       (.I0(p_1_in[6]),
        .I1(p_1_in[7]),
        .I2(zp_sum),
        .I3(timing_sel[1]),
        .I4(timing_sel[0]),
        .I5(p_1_in[8]),
        .O(\VGA_R[7]_i_288_n_0 ));
  LUT5 #(
    .INIT(32'h88080020)) 
    \VGA_R[7]_i_289 
       (.I0(p_1_in[3]),
        .I1(p_1_in[4]),
        .I2(timing_sel[0]),
        .I3(timing_sel[1]),
        .I4(p_1_in[5]),
        .O(\VGA_R[7]_i_289_n_0 ));
  LUT3 #(
    .INIT(8'h40)) 
    \VGA_R[7]_i_290 
       (.I0(HCNT[0]),
        .I1(p_1_in[1]),
        .I2(p_1_in[2]),
        .O(\VGA_R[7]_i_290_n_0 ));
  LUT3 #(
    .INIT(8'h41)) 
    \VGA_R[7]_i_291 
       (.I0(A[10]),
        .I1(\VGA_R_reg[4]_i_5_0 ),
        .I2(A[9]),
        .O(\VGA_R[7]_i_291_n_0 ));
  LUT4 #(
    .INIT(16'h0880)) 
    \VGA_R[7]_i_292 
       (.I0(A[6]),
        .I1(A[7]),
        .I2(A[8]),
        .I3(\VGA_R_reg[4]_i_5_0 ),
        .O(\VGA_R[7]_i_292_n_0 ));
  LUT4 #(
    .INIT(16'h0028)) 
    \VGA_R[7]_i_293 
       (.I0(A[3]),
        .I1(A[4]),
        .I2(\VGA_R_reg[4]_i_5_0 ),
        .I3(A[5]),
        .O(\VGA_R[7]_i_293_n_0 ));
  LUT3 #(
    .INIT(8'h80)) 
    \VGA_R[7]_i_294 
       (.I0(A[0]),
        .I1(A[1]),
        .I2(A[2]),
        .O(\VGA_R[7]_i_294_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \VGA_R[7]_i_295 
       (.I0(VCNT[9]),
        .I1(VCNT[10]),
        .O(\VGA_R[7]_i_295_n_0 ));
  LUT3 #(
    .INIT(8'h01)) 
    \VGA_R[7]_i_296 
       (.I0(VCNT[7]),
        .I1(VCNT[6]),
        .I2(VCNT[8]),
        .O(\VGA_R[7]_i_296_n_0 ));
  LUT4 #(
    .INIT(16'h0280)) 
    \VGA_R[7]_i_297 
       (.I0(VCNT[3]),
        .I1(\VGA_R_reg[4]_i_5_0 ),
        .I2(VCNT[4]),
        .I3(VCNT[5]),
        .O(\VGA_R[7]_i_297_n_0 ));
  LUT4 #(
    .INIT(16'h0280)) 
    \VGA_R[7]_i_298 
       (.I0(VCNT[2]),
        .I1(VCNT[1]),
        .I2(\VGA_R_reg[4]_i_5_0 ),
        .I3(VCNT[0]),
        .O(\VGA_R[7]_i_298_n_0 ));
  LUT1 #(
    .INIT(2'h2)) 
    \VGA_R[7]_i_299 
       (.I0(\VGA_R_reg[7]_i_448_n_7 ),
        .O(\VGA_R[7]_i_299_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_300 
       (.I0(zp_sum),
        .I1(sel0[2]),
        .I2(\VGA_R_reg[7]_i_122_n_5 ),
        .O(\VGA_R[7]_i_300_n_0 ));
  LUT4 #(
    .INIT(16'h659A)) 
    \VGA_R[7]_i_301 
       (.I0(sel0[2]),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .I3(\VGA_R_reg[7]_i_122_n_6 ),
        .O(\VGA_R[7]_i_301_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_302 
       (.I0(sel0[2]),
        .I1(\VGA_R_reg[7]_i_122_n_7 ),
        .O(\VGA_R[7]_i_302_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_303 
       (.I0(sel0[2]),
        .I1(\VGA_R_reg[7]_i_231_0 ),
        .I2(\VGA_R_reg[7]_i_448_n_7 ),
        .O(\VGA_R[7]_i_303_n_0 ));
  LUT1 #(
    .INIT(2'h2)) 
    \VGA_R[7]_i_304 
       (.I0(\VGA_R_reg[7]_i_449_n_7 ),
        .O(\VGA_R[7]_i_304_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_305 
       (.I0(zp_sum),
        .I1(sel0[3]),
        .I2(\VGA_R_reg[7]_i_157_n_5 ),
        .O(\VGA_R[7]_i_305_n_0 ));
  LUT4 #(
    .INIT(16'h659A)) 
    \VGA_R[7]_i_306 
       (.I0(sel0[3]),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .I3(\VGA_R_reg[7]_i_157_n_6 ),
        .O(\VGA_R[7]_i_306_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_307 
       (.I0(sel0[3]),
        .I1(\VGA_R_reg[7]_i_157_n_7 ),
        .O(\VGA_R[7]_i_307_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_308 
       (.I0(sel0[3]),
        .I1(\VGA_R_reg[7]_i_231_0 ),
        .I2(\VGA_R_reg[7]_i_449_n_7 ),
        .O(\VGA_R[7]_i_308_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFEFFFF)) 
    \VGA_R[7]_i_31 
       (.I0(p_1_in[4]),
        .I1(p_1_in[5]),
        .I2(p_1_in[2]),
        .I3(p_1_in[3]),
        .I4(HCNT[0]),
        .I5(p_1_in[1]),
        .O(\VGA_R[7]_i_31_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \VGA_R[7]_i_318 
       (.I0(sel0[12]),
        .I1(zp_sum),
        .O(\VGA_R[7]_i_318_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000001)) 
    \VGA_R[7]_i_32 
       (.I0(A[0]),
        .I1(A[1]),
        .I2(A[5]),
        .I3(A[3]),
        .I4(A[2]),
        .I5(A[4]),
        .O(\VGA_R[7]_i_32_n_0 ));
  LUT3 #(
    .INIT(8'hD2)) 
    \VGA_R[7]_i_320 
       (.I0(timing_sel[0]),
        .I1(timing_sel[1]),
        .I2(sel0[12]),
        .O(\VGA_R[7]_i_320_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \VGA_R[7]_i_321 
       (.I0(sel0[12]),
        .I1(zp_sum),
        .O(\VGA_R[7]_i_321_n_0 ));
  LUT1 #(
    .INIT(2'h2)) 
    \VGA_R[7]_i_322 
       (.I0(sel0[12]),
        .O(\VGA_R[7]_i_322_n_0 ));
  LUT3 #(
    .INIT(8'hA6)) 
    \VGA_R[7]_i_323 
       (.I0(sel0[12]),
        .I1(timing_sel[0]),
        .I2(timing_sel[1]),
        .O(\VGA_R[7]_i_323_n_0 ));
  LUT3 #(
    .INIT(8'hD2)) 
    \VGA_R[7]_i_324 
       (.I0(timing_sel[0]),
        .I1(timing_sel[1]),
        .I2(sel0[12]),
        .O(\VGA_R[7]_i_324_n_0 ));
  LUT1 #(
    .INIT(2'h2)) 
    \VGA_R[7]_i_325 
       (.I0(\VGA_R_reg[7]_i_455_n_7 ),
        .O(\VGA_R[7]_i_325_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_326 
       (.I0(zp_sum),
        .I1(sel0[7]),
        .I2(\VGA_R_reg[7]_i_137_n_5 ),
        .O(\VGA_R[7]_i_326_n_0 ));
  LUT4 #(
    .INIT(16'h659A)) 
    \VGA_R[7]_i_327 
       (.I0(sel0[7]),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .I3(\VGA_R_reg[7]_i_137_n_6 ),
        .O(\VGA_R[7]_i_327_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_328 
       (.I0(sel0[7]),
        .I1(\VGA_R_reg[7]_i_137_n_7 ),
        .O(\VGA_R[7]_i_328_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_329 
       (.I0(sel0[7]),
        .I1(\VGA_R_reg[7]_i_231_0 ),
        .I2(\VGA_R_reg[7]_i_455_n_7 ),
        .O(\VGA_R[7]_i_329_n_0 ));
  LUT1 #(
    .INIT(2'h2)) 
    \VGA_R[7]_i_330 
       (.I0(\VGA_R_reg[7]_i_69_n_6 ),
        .O(\VGA_R[7]_i_330_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_331 
       (.I0(zp_sum),
        .I1(sel0[8]),
        .I2(\VGA_R_reg[7]_i_148_n_5 ),
        .O(\VGA_R[7]_i_331_n_0 ));
  LUT4 #(
    .INIT(16'h659A)) 
    \VGA_R[7]_i_332 
       (.I0(sel0[8]),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .I3(\VGA_R_reg[7]_i_148_n_6 ),
        .O(\VGA_R[7]_i_332_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_333 
       (.I0(sel0[8]),
        .I1(\VGA_R_reg[7]_i_148_n_7 ),
        .O(\VGA_R[7]_i_333_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_334 
       (.I0(sel0[8]),
        .I1(\VGA_R_reg[7]_i_231_0 ),
        .I2(\VGA_R_reg[7]_i_69_n_6 ),
        .O(\VGA_R[7]_i_334_n_0 ));
  LUT1 #(
    .INIT(2'h2)) 
    \VGA_R[7]_i_335 
       (.I0(\VGA_R_reg[7]_i_456_n_6 ),
        .O(\VGA_R[7]_i_335_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_336 
       (.I0(zp_sum),
        .I1(sel0[10]),
        .I2(\VGA_R_reg[7]_i_143_n_5 ),
        .O(\VGA_R[7]_i_336_n_0 ));
  LUT4 #(
    .INIT(16'h659A)) 
    \VGA_R[7]_i_337 
       (.I0(sel0[10]),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .I3(\VGA_R_reg[7]_i_143_n_6 ),
        .O(\VGA_R[7]_i_337_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_338 
       (.I0(sel0[10]),
        .I1(\VGA_R_reg[7]_i_143_n_7 ),
        .O(\VGA_R[7]_i_338_n_0 ));
  LUT4 #(
    .INIT(16'h659A)) 
    \VGA_R[7]_i_339 
       (.I0(sel0[10]),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .I3(\VGA_R_reg[7]_i_456_n_6 ),
        .O(\VGA_R[7]_i_339_n_0 ));
  LUT3 #(
    .INIT(8'hD2)) 
    \VGA_R[7]_i_340 
       (.I0(timing_sel[0]),
        .I1(timing_sel[1]),
        .I2(sel0[11]),
        .O(\VGA_R[7]_i_340_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_341 
       (.I0(zp_sum),
        .I1(sel0[11]),
        .I2(\VGA_R_reg[7]_i_130_n_5 ),
        .O(\VGA_R[7]_i_341_n_0 ));
  LUT4 #(
    .INIT(16'h659A)) 
    \VGA_R[7]_i_342 
       (.I0(sel0[11]),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .I3(\VGA_R_reg[7]_i_130_n_6 ),
        .O(\VGA_R[7]_i_342_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_343 
       (.I0(sel0[11]),
        .I1(\VGA_R_reg[7]_i_130_n_7 ),
        .O(\VGA_R[7]_i_343_n_0 ));
  LUT3 #(
    .INIT(8'hD2)) 
    \VGA_R[7]_i_344 
       (.I0(timing_sel[0]),
        .I1(timing_sel[1]),
        .I2(sel0[11]),
        .O(\VGA_R[7]_i_344_n_0 ));
  LUT1 #(
    .INIT(2'h2)) 
    \VGA_R[7]_i_345 
       (.I0(\VGA_R_reg[7]_i_456_n_7 ),
        .O(\VGA_R[7]_i_345_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_346 
       (.I0(zp_sum),
        .I1(sel0[9]),
        .I2(\VGA_R_reg[7]_i_142_n_5 ),
        .O(\VGA_R[7]_i_346_n_0 ));
  LUT4 #(
    .INIT(16'h659A)) 
    \VGA_R[7]_i_347 
       (.I0(sel0[9]),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .I3(\VGA_R_reg[7]_i_142_n_6 ),
        .O(\VGA_R[7]_i_347_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_348 
       (.I0(sel0[9]),
        .I1(\VGA_R_reg[7]_i_142_n_7 ),
        .O(\VGA_R[7]_i_348_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_349 
       (.I0(sel0[9]),
        .I1(\VGA_R_reg[7]_i_231_0 ),
        .I2(\VGA_R_reg[7]_i_456_n_7 ),
        .O(\VGA_R[7]_i_349_n_0 ));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \VGA_R[7]_i_35 
       (.I0(\VGA_R_reg[7]_i_94_n_0 ),
        .I1(\VGA_R_reg[7]_i_95_n_0 ),
        .I2(\VGA_R_reg[7]_i_96_n_0 ),
        .I3(\VGA_R_reg[7]_i_97_n_0 ),
        .O(\VGA_R[7]_i_35_n_0 ));
  LUT1 #(
    .INIT(2'h2)) 
    \VGA_R[7]_i_350 
       (.I0(\VGA_R_reg[7]_i_457_n_7 ),
        .O(\VGA_R[7]_i_350_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_351 
       (.I0(zp_sum),
        .I1(sel0[4]),
        .I2(\VGA_R_reg[7]_i_158_n_5 ),
        .O(\VGA_R[7]_i_351_n_0 ));
  LUT4 #(
    .INIT(16'h659A)) 
    \VGA_R[7]_i_352 
       (.I0(sel0[4]),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .I3(\VGA_R_reg[7]_i_158_n_6 ),
        .O(\VGA_R[7]_i_352_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_353 
       (.I0(sel0[4]),
        .I1(\VGA_R_reg[7]_i_158_n_7 ),
        .O(\VGA_R[7]_i_353_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_354 
       (.I0(sel0[4]),
        .I1(\VGA_R_reg[7]_i_231_0 ),
        .I2(\VGA_R_reg[7]_i_457_n_7 ),
        .O(\VGA_R[7]_i_354_n_0 ));
  LUT1 #(
    .INIT(2'h2)) 
    \VGA_R[7]_i_355 
       (.I0(\VGA_R_reg[7]_i_458_n_7 ),
        .O(\VGA_R[7]_i_355_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_356 
       (.I0(zp_sum),
        .I1(sel0[5]),
        .I2(\VGA_R_reg[7]_i_163_n_5 ),
        .O(\VGA_R[7]_i_356_n_0 ));
  LUT4 #(
    .INIT(16'h659A)) 
    \VGA_R[7]_i_357 
       (.I0(sel0[5]),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .I3(\VGA_R_reg[7]_i_163_n_6 ),
        .O(\VGA_R[7]_i_357_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_358 
       (.I0(sel0[5]),
        .I1(\VGA_R_reg[7]_i_163_n_7 ),
        .O(\VGA_R[7]_i_358_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_359 
       (.I0(sel0[5]),
        .I1(\VGA_R_reg[7]_i_231_0 ),
        .I2(\VGA_R_reg[7]_i_458_n_7 ),
        .O(\VGA_R[7]_i_359_n_0 ));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \VGA_R[7]_i_36 
       (.I0(\VGA_R_reg[7]_i_98_n_0 ),
        .I1(\VGA_R_reg[7]_i_99_n_0 ),
        .I2(\VGA_R_reg[7]_i_100_n_0 ),
        .I3(\VGA_R_reg[7]_i_236_0 ),
        .O(\VGA_R[7]_i_36_n_0 ));
  LUT1 #(
    .INIT(2'h2)) 
    \VGA_R[7]_i_360 
       (.I0(\VGA_R_reg[7]_i_459_n_7 ),
        .O(\VGA_R[7]_i_360_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_361 
       (.I0(zp_sum),
        .I1(sel0[6]),
        .I2(\VGA_R_reg[7]_i_136_n_5 ),
        .O(\VGA_R[7]_i_361_n_0 ));
  LUT4 #(
    .INIT(16'h659A)) 
    \VGA_R[7]_i_362 
       (.I0(sel0[6]),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .I3(\VGA_R_reg[7]_i_136_n_6 ),
        .O(\VGA_R[7]_i_362_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_363 
       (.I0(sel0[6]),
        .I1(\VGA_R_reg[7]_i_136_n_7 ),
        .O(\VGA_R[7]_i_363_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_364 
       (.I0(sel0[6]),
        .I1(\VGA_R_reg[7]_i_231_0 ),
        .I2(\VGA_R_reg[7]_i_459_n_7 ),
        .O(\VGA_R[7]_i_364_n_0 ));
  LUT3 #(
    .INIT(8'hD7)) 
    \VGA_R[7]_i_37 
       (.I0(pattern_sel[0]),
        .I1(A[5]),
        .I2(p_1_in[5]),
        .O(\VGA_R[7]_i_37_n_0 ));
  LUT1 #(
    .INIT(2'h2)) 
    \VGA_R[7]_i_393 
       (.I0(p_1_in[5]),
        .O(\VGA_R[7]_i_393_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_394 
       (.I0(zp_sum),
        .I1(\VGA_R_reg[7]_i_96_n_0 ),
        .I2(\VGA_R_reg[7]_i_216_n_5 ),
        .O(\VGA_R[7]_i_394_n_0 ));
  LUT4 #(
    .INIT(16'h659A)) 
    \VGA_R[7]_i_395 
       (.I0(\VGA_R_reg[7]_i_96_n_0 ),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .I3(\VGA_R_reg[7]_i_216_n_6 ),
        .O(\VGA_R[7]_i_395_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_396 
       (.I0(\VGA_R_reg[7]_i_96_n_0 ),
        .I1(\VGA_R_reg[7]_i_216_n_7 ),
        .O(\VGA_R[7]_i_396_n_0 ));
  LUT4 #(
    .INIT(16'h6966)) 
    \VGA_R[7]_i_397 
       (.I0(p_1_in[5]),
        .I1(\VGA_R_reg[7]_i_96_n_0 ),
        .I2(timing_sel[1]),
        .I3(timing_sel[0]),
        .O(\VGA_R[7]_i_397_n_0 ));
  LUT1 #(
    .INIT(2'h2)) 
    \VGA_R[7]_i_398 
       (.I0(p_1_in[6]),
        .O(\VGA_R[7]_i_398_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_399 
       (.I0(zp_sum),
        .I1(\VGA_R_reg[7]_i_97_n_0 ),
        .I2(\VGA_R_reg[7]_i_221_n_5 ),
        .O(\VGA_R[7]_i_399_n_0 ));
  LUT4 #(
    .INIT(16'h659A)) 
    \VGA_R[7]_i_400 
       (.I0(\VGA_R_reg[7]_i_97_n_0 ),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .I3(\VGA_R_reg[7]_i_221_n_6 ),
        .O(\VGA_R[7]_i_400_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_401 
       (.I0(\VGA_R_reg[7]_i_97_n_0 ),
        .I1(\VGA_R_reg[7]_i_221_n_7 ),
        .O(\VGA_R[7]_i_401_n_0 ));
  LUT4 #(
    .INIT(16'h6966)) 
    \VGA_R[7]_i_402 
       (.I0(p_1_in[6]),
        .I1(\VGA_R_reg[7]_i_97_n_0 ),
        .I2(timing_sel[1]),
        .I3(timing_sel[0]),
        .O(\VGA_R[7]_i_402_n_0 ));
  LUT1 #(
    .INIT(2'h2)) 
    \VGA_R[7]_i_403 
       (.I0(p_1_in[7]),
        .O(\VGA_R[7]_i_403_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_404 
       (.I0(zp_sum),
        .I1(\VGA_R_reg[7]_i_98_n_0 ),
        .I2(\VGA_R_reg[7]_i_226_n_5 ),
        .O(\VGA_R[7]_i_404_n_0 ));
  LUT4 #(
    .INIT(16'h659A)) 
    \VGA_R[7]_i_405 
       (.I0(\VGA_R_reg[7]_i_98_n_0 ),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .I3(\VGA_R_reg[7]_i_226_n_6 ),
        .O(\VGA_R[7]_i_405_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_406 
       (.I0(\VGA_R_reg[7]_i_98_n_0 ),
        .I1(\VGA_R_reg[7]_i_226_n_7 ),
        .O(\VGA_R[7]_i_406_n_0 ));
  LUT4 #(
    .INIT(16'h6966)) 
    \VGA_R[7]_i_407 
       (.I0(p_1_in[7]),
        .I1(\VGA_R_reg[7]_i_98_n_0 ),
        .I2(timing_sel[1]),
        .I3(timing_sel[0]),
        .O(\VGA_R[7]_i_407_n_0 ));
  LUT1 #(
    .INIT(2'h2)) 
    \VGA_R[7]_i_408 
       (.I0(p_1_in[8]),
        .O(\VGA_R[7]_i_408_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_409 
       (.I0(zp_sum),
        .I1(\VGA_R_reg[7]_i_99_n_0 ),
        .I2(\VGA_R_reg[7]_i_231_n_5 ),
        .O(\VGA_R[7]_i_409_n_0 ));
  LUT3 #(
    .INIT(8'hFE)) 
    \VGA_R[7]_i_41 
       (.I0(pattern_b3__4),
        .I1(pattern_b1__1),
        .I2(pattern_b20_out),
        .O(\VGA_R[7]_i_41_n_0 ));
  LUT4 #(
    .INIT(16'h659A)) 
    \VGA_R[7]_i_410 
       (.I0(\VGA_R_reg[7]_i_99_n_0 ),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .I3(\VGA_R_reg[7]_i_231_n_6 ),
        .O(\VGA_R[7]_i_410_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_411 
       (.I0(\VGA_R_reg[7]_i_99_n_0 ),
        .I1(\VGA_R_reg[7]_i_231_n_7 ),
        .O(\VGA_R[7]_i_411_n_0 ));
  LUT4 #(
    .INIT(16'h6966)) 
    \VGA_R[7]_i_412 
       (.I0(p_1_in[8]),
        .I1(\VGA_R_reg[7]_i_99_n_0 ),
        .I2(timing_sel[1]),
        .I3(timing_sel[0]),
        .O(\VGA_R[7]_i_412_n_0 ));
  LUT1 #(
    .INIT(2'h2)) 
    \VGA_R[7]_i_413 
       (.I0(p_1_in[9]),
        .O(\VGA_R[7]_i_413_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_414 
       (.I0(zp_sum),
        .I1(\VGA_R_reg[7]_i_100_n_0 ),
        .I2(\VGA_R_reg[7]_i_236_n_5 ),
        .O(\VGA_R[7]_i_414_n_0 ));
  LUT4 #(
    .INIT(16'h659A)) 
    \VGA_R[7]_i_415 
       (.I0(\VGA_R_reg[7]_i_100_n_0 ),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .I3(\VGA_R_reg[7]_i_236_n_6 ),
        .O(\VGA_R[7]_i_415_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_416 
       (.I0(\VGA_R_reg[7]_i_100_n_0 ),
        .I1(\VGA_R_reg[7]_i_236_n_7 ),
        .O(\VGA_R[7]_i_416_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_417 
       (.I0(\VGA_R_reg[7]_i_100_n_0 ),
        .I1(\VGA_R_reg[7]_i_231_0 ),
        .I2(p_1_in[9]),
        .O(\VGA_R[7]_i_417_n_0 ));
  LUT1 #(
    .INIT(2'h2)) 
    \VGA_R[7]_i_418 
       (.I0(p_1_in[10]),
        .O(\VGA_R[7]_i_418_n_0 ));
  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    \VGA_R[7]_i_42 
       (.I0(p_1_in[9]),
        .I1(p_1_in[8]),
        .I2(p_1_in[6]),
        .I3(p_1_in[10]),
        .I4(p_1_in[7]),
        .O(\VGA_R[7]_i_42_n_0 ));
  LUT4 #(
    .INIT(16'h659A)) 
    \VGA_R[7]_i_422 
       (.I0(\VGA_R_reg[7]_i_236_0 ),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .I3(p_1_in[10]),
        .O(\VGA_R[7]_i_422_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair22" *) 
  LUT5 #(
    .INIT(32'h00800800)) 
    \VGA_R[7]_i_428 
       (.I0(FCNT[0]),
        .I1(FCNT[1]),
        .I2(FCNT[2]),
        .I3(\VGA_R[7]_i_432_n_0 ),
        .I4(FCNT[3]),
        .O(\VGA_R[7]_i_428_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair29" *) 
  LUT4 #(
    .INIT(16'hA955)) 
    \VGA_R[7]_i_429 
       (.I0(FCNT[4]),
        .I1(FCNT[3]),
        .I2(FCNT[2]),
        .I3(\VGA_R[7]_i_432_n_0 ),
        .O(\VGA_R[7]_i_429_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair32" *) 
  LUT4 #(
    .INIT(16'h4004)) 
    \VGA_R[7]_i_43 
       (.I0(pattern_sel[1]),
        .I1(pattern_sel[0]),
        .I2(FCNT[5]),
        .I3(FCNT[6]),
        .O(\VGA_R[7]_i_43_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair34" *) 
  LUT3 #(
    .INIT(8'h59)) 
    \VGA_R[7]_i_430 
       (.I0(FCNT[3]),
        .I1(\VGA_R[7]_i_432_n_0 ),
        .I2(FCNT[2]),
        .O(\VGA_R[7]_i_430_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair34" *) 
  LUT2 #(
    .INIT(4'h9)) 
    \VGA_R[7]_i_431 
       (.I0(FCNT[2]),
        .I1(\VGA_R[7]_i_432_n_0 ),
        .O(\VGA_R[7]_i_431_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair31" *) 
  LUT4 #(
    .INIT(16'h0400)) 
    \VGA_R[7]_i_432 
       (.I0(\VGA_R[7]_i_476_n_0 ),
        .I1(FCNT[7]),
        .I2(timing_sel[1]),
        .I3(timing_sel[0]),
        .O(\VGA_R[7]_i_432_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair29" *) 
  LUT3 #(
    .INIT(8'h1F)) 
    \VGA_R[7]_i_433 
       (.I0(FCNT[2]),
        .I1(FCNT[3]),
        .I2(FCNT[4]),
        .O(\VGA_R[7]_i_433_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair23" *) 
  LUT4 #(
    .INIT(16'h8880)) 
    \VGA_R[7]_i_434 
       (.I0(FCNT[5]),
        .I1(FCNT[4]),
        .I2(FCNT[3]),
        .I3(FCNT[2]),
        .O(\VGA_R[7]_i_434_n_0 ));
  LUT5 #(
    .INIT(32'h00005504)) 
    \VGA_R[7]_i_44 
       (.I0(HCNT[7]),
        .I1(timing_sel[0]),
        .I2(timing_sel[1]),
        .I3(VGA_HS_i_2_n_0),
        .I4(HCNT[6]),
        .O(\VGA_R[7]_i_44_n_0 ));
  LUT3 #(
    .INIT(8'h4D)) 
    \VGA_R[7]_i_45 
       (.I0(HCNT[5]),
        .I1(VGA_HS_i_2_n_0),
        .I2(HCNT[4]),
        .O(\VGA_R[7]_i_45_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \VGA_R[7]_i_451 
       (.I0(p_1_in[8]),
        .O(\VGA_R[7]_i_451_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \VGA_R[7]_i_452 
       (.I0(p_1_in[7]),
        .I1(p_1_in[10]),
        .O(\VGA_R[7]_i_452_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \VGA_R[7]_i_453 
       (.I0(p_1_in[6]),
        .I1(p_1_in[9]),
        .O(\VGA_R[7]_i_453_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \VGA_R[7]_i_454 
       (.I0(p_1_in[5]),
        .I1(p_1_in[8]),
        .O(\VGA_R[7]_i_454_n_0 ));
  LUT5 #(
    .INIT(32'h105510DF)) 
    \VGA_R[7]_i_46 
       (.I0(HCNT[3]),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .I3(VGA_HS_i_2_n_0),
        .I4(HCNT[2]),
        .O(\VGA_R[7]_i_46_n_0 ));
  LUT5 #(
    .INIT(32'h10117577)) 
    \VGA_R[7]_i_47 
       (.I0(HCNT[1]),
        .I1(VGA_HS_i_2_n_0),
        .I2(timing_sel[1]),
        .I3(timing_sel[0]),
        .I4(HCNT[0]),
        .O(\VGA_R[7]_i_47_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair23" *) 
  LUT5 #(
    .INIT(32'h01555555)) 
    \VGA_R[7]_i_476 
       (.I0(FCNT[6]),
        .I1(FCNT[2]),
        .I2(FCNT[3]),
        .I3(FCNT[4]),
        .I4(FCNT[5]),
        .O(\VGA_R[7]_i_476_n_0 ));
  LUT5 #(
    .INIT(32'h55040051)) 
    \VGA_R[7]_i_48 
       (.I0(HCNT[7]),
        .I1(timing_sel[0]),
        .I2(timing_sel[1]),
        .I3(VGA_HS_i_2_n_0),
        .I4(HCNT[6]),
        .O(\VGA_R[7]_i_48_n_0 ));
  LUT3 #(
    .INIT(8'h82)) 
    \VGA_R[7]_i_49 
       (.I0(HCNT[4]),
        .I1(VGA_HS_i_2_n_0),
        .I2(HCNT[5]),
        .O(\VGA_R[7]_i_49_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_499 
       (.I0(\VGA_R_reg[7]_i_450_n_6 ),
        .I1(sel0[6]),
        .O(\VGA_R[7]_i_499_n_0 ));
  LUT5 #(
    .INIT(32'h00A25908)) 
    \VGA_R[7]_i_50 
       (.I0(HCNT[3]),
        .I1(timing_sel[0]),
        .I2(timing_sel[1]),
        .I3(VGA_HS_i_2_n_0),
        .I4(HCNT[2]),
        .O(\VGA_R[7]_i_50_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_500 
       (.I0(\VGA_R_reg[7]_i_450_n_5 ),
        .I1(sel0[7]),
        .O(\VGA_R[7]_i_500_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \VGA_R[7]_i_502 
       (.I0(p_1_in[4]),
        .I1(p_1_in[7]),
        .O(\VGA_R[7]_i_502_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \VGA_R[7]_i_503 
       (.I0(p_1_in[3]),
        .I1(p_1_in[6]),
        .O(\VGA_R[7]_i_503_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \VGA_R[7]_i_504 
       (.I0(p_1_in[2]),
        .I1(p_1_in[5]),
        .O(\VGA_R[7]_i_504_n_0 ));
  LUT2 #(
    .INIT(4'h9)) 
    \VGA_R[7]_i_505 
       (.I0(p_1_in[1]),
        .I1(p_1_in[4]),
        .O(\VGA_R[7]_i_505_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_506 
       (.I0(\VGA_R_reg[7]_i_317_n_5 ),
        .I1(sel0[11]),
        .O(\VGA_R[7]_i_506_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \VGA_R[7]_i_507 
       (.I0(p_1_in[10]),
        .O(\VGA_R[7]_i_507_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \VGA_R[7]_i_508 
       (.I0(p_1_in[9]),
        .O(\VGA_R[7]_i_508_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_509 
       (.I0(\VGA_R_reg[7]_i_450_n_4 ),
        .I1(sel0[8]),
        .O(\VGA_R[7]_i_509_n_0 ));
  LUT5 #(
    .INIT(32'h00A2AA08)) 
    \VGA_R[7]_i_51 
       (.I0(HCNT[0]),
        .I1(timing_sel[0]),
        .I2(timing_sel[1]),
        .I3(VGA_HS_i_2_n_0),
        .I4(HCNT[1]),
        .O(\VGA_R[7]_i_51_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_510 
       (.I0(\VGA_R_reg[7]_i_317_n_7 ),
        .I1(sel0[9]),
        .O(\VGA_R[7]_i_510_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_511 
       (.I0(\VGA_R_reg[7]_i_317_n_6 ),
        .I1(sel0[10]),
        .O(\VGA_R[7]_i_511_n_0 ));
  LUT5 #(
    .INIT(32'h8AE308A2)) 
    \VGA_R[7]_i_52 
       (.I0(HCNT[7]),
        .I1(\VGA_R_reg[7]_i_16_1 ),
        .I2(zp_sum0[1]),
        .I3(zp_sum0[2]),
        .I4(HCNT[6]),
        .O(\VGA_R[7]_i_52_n_0 ));
  LUT5 #(
    .INIT(32'h8AE308A2)) 
    \VGA_R[7]_i_53 
       (.I0(HCNT[5]),
        .I1(\VGA_R_reg[7]_i_16_0 ),
        .I2(zp_sum0_0),
        .I3(zp_sum0[0]),
        .I4(HCNT[4]),
        .O(\VGA_R[7]_i_53_n_0 ));
  LUT5 #(
    .INIT(32'h2ABC02A8)) 
    \VGA_R[7]_i_54 
       (.I0(HCNT[3]),
        .I1(O[0]),
        .I2(O[1]),
        .I3(O[2]),
        .I4(HCNT[2]),
        .O(\VGA_R[7]_i_54_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \VGA_R[7]_i_55 
       (.I0(HCNT[1]),
        .I1(O[0]),
        .O(\VGA_R[7]_i_55_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \VGA_R[7]_i_556 
       (.I0(HCNT[0]),
        .O(\VGA_R[7]_i_556_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_557 
       (.I0(HCNT[0]),
        .I1(p_1_in[3]),
        .O(\VGA_R[7]_i_557_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \VGA_R[7]_i_558 
       (.I0(p_1_in[2]),
        .O(\VGA_R[7]_i_558_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \VGA_R[7]_i_559 
       (.I0(p_1_in[1]),
        .O(\VGA_R[7]_i_559_n_0 ));
  LUT5 #(
    .INIT(32'h06909009)) 
    \VGA_R[7]_i_56 
       (.I0(zp_sum0[2]),
        .I1(HCNT[7]),
        .I2(zp_sum0[1]),
        .I3(\VGA_R_reg[7]_i_16_1 ),
        .I4(HCNT[6]),
        .O(\VGA_R[7]_i_56_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \VGA_R[7]_i_560 
       (.I0(HCNT[0]),
        .O(\VGA_R[7]_i_560_n_0 ));
  LUT5 #(
    .INIT(32'h06909009)) 
    \VGA_R[7]_i_57 
       (.I0(zp_sum0[0]),
        .I1(HCNT[5]),
        .I2(zp_sum0_0),
        .I3(\VGA_R_reg[7]_i_16_0 ),
        .I4(HCNT[4]),
        .O(\VGA_R[7]_i_57_n_0 ));
  LUT5 #(
    .INIT(32'h90060990)) 
    \VGA_R[7]_i_58 
       (.I0(O[2]),
        .I1(HCNT[3]),
        .I2(O[0]),
        .I3(O[1]),
        .I4(HCNT[2]),
        .O(\VGA_R[7]_i_58_n_0 ));
  LUT3 #(
    .INIT(8'h60)) 
    \VGA_R[7]_i_59 
       (.I0(O[0]),
        .I1(HCNT[1]),
        .I2(HCNT[0]),
        .O(\VGA_R[7]_i_59_n_0 ));
  LUT6 #(
    .INIT(64'h2222E22200000000)) 
    \VGA_R[7]_i_6 
       (.I0(P[4]),
        .I1(\VGA_R_reg[6]_0 ),
        .I2(\VGA_R[7]_i_26_n_0 ),
        .I3(\VGA_R[7]_i_27_n_0 ),
        .I4(\VGA_R[7]_i_28_n_0 ),
        .I5(\VGA_R_reg[6] ),
        .O(\VGA_R[7]_i_6_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \VGA_R[7]_i_61 
       (.I0(VCNT[7]),
        .I1(VCNT[6]),
        .O(\VGA_R[7]_i_61_n_0 ));
  LUT3 #(
    .INIT(8'hA8)) 
    \VGA_R[7]_i_62 
       (.I0(VCNT[5]),
        .I1(VGA_HS_i_2_n_0),
        .I2(VCNT[4]),
        .O(\VGA_R[7]_i_62_n_0 ));
  LUT3 #(
    .INIT(8'h8A)) 
    \VGA_R[7]_i_63 
       (.I0(VCNT[1]),
        .I1(VCNT[0]),
        .I2(VGA_HS_i_2_n_0),
        .O(\VGA_R[7]_i_63_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \VGA_R[7]_i_64 
       (.I0(VCNT[6]),
        .I1(VCNT[7]),
        .O(\VGA_R[7]_i_64_n_0 ));
  LUT3 #(
    .INIT(8'h42)) 
    \VGA_R[7]_i_65 
       (.I0(VCNT[5]),
        .I1(VCNT[4]),
        .I2(VGA_HS_i_2_n_0),
        .O(\VGA_R[7]_i_65_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \VGA_R[7]_i_66 
       (.I0(VCNT[2]),
        .I1(VCNT[3]),
        .O(\VGA_R[7]_i_66_n_0 ));
  LUT3 #(
    .INIT(8'h42)) 
    \VGA_R[7]_i_67 
       (.I0(VCNT[0]),
        .I1(VGA_HS_i_2_n_0),
        .I2(VCNT[1]),
        .O(\VGA_R[7]_i_67_n_0 ));
  LUT6 #(
    .INIT(64'hFFAFEEEEAAAAAAAA)) 
    \VGA_R[7]_i_7 
       (.I0(pattern_sel[2]),
        .I1(data2[7]),
        .I2(\VGA_R[7]_i_31_n_0 ),
        .I3(\VGA_R[7]_i_32_n_0 ),
        .I4(pattern_sel[0]),
        .I5(pattern_sel[1]),
        .O(\VGA_R[7]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'h0000000155555555)) 
    \VGA_R[7]_i_8 
       (.I0(pattern_sel[1]),
        .I1(\VGA_R_reg[7]_i_33_n_0 ),
        .I2(\VGA_B_reg[7] ),
        .I3(\VGA_R[7]_i_35_n_0 ),
        .I4(\VGA_R[7]_i_36_n_0 ),
        .I5(\VGA_R[7]_i_37_n_0 ),
        .O(\VGA_R[7]_i_8_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \VGA_R[7]_i_88 
       (.I0(\VGA_G_reg[7]_i_6_n_0 ),
        .I1(\VGA_G_reg[7]_i_6_n_5 ),
        .O(\VGA_R[7]_i_88_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_89 
       (.I0(\VGA_G_reg[7]_i_6_n_0 ),
        .I1(zp_sum),
        .I2(\VGA_G_reg[7]_i_6_n_6 ),
        .O(\VGA_R[7]_i_89_n_0 ));
  LUT6 #(
    .INIT(64'h2AAA22222AAAAAAA)) 
    \VGA_R[7]_i_9 
       (.I0(pattern_sel[2]),
        .I1(pattern_sel[1]),
        .I2(\VGA_R_reg[7]_i_38_n_3 ),
        .I3(pattern_b11_in),
        .I4(pattern_sel[0]),
        .I5(data6[7]),
        .O(\VGA_R[7]_i_9_n_0 ));
  LUT3 #(
    .INIT(8'h69)) 
    \VGA_R[7]_i_90 
       (.I0(zp_sum),
        .I1(\VGA_G_reg[7]_i_6_n_0 ),
        .I2(\VGA_G_reg[7]_i_6_n_7 ),
        .O(\VGA_R[7]_i_90_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \VGA_R[7]_i_91 
       (.I0(\VGA_G_reg[7]_i_6_n_0 ),
        .I1(zp_sum),
        .I2(\VGA_R_reg[7]_i_87_n_4 ),
        .O(\VGA_R[7]_i_91_n_0 ));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \VGA_R_reg[4]_i_5 
       (.CI(\VGA_R_reg[4]_i_8_n_0 ),
        .CO({\NLW_VGA_R_reg[4]_i_5_CO_UNCONNECTED [3:2],\VGA_R_reg[4]_i_5_n_2 ,\VGA_R_reg[4]_i_5_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,\VGA_R[4]_i_9_n_0 }),
        .O(\NLW_VGA_R_reg[4]_i_5_O_UNCONNECTED [3:0]),
        .S({1'b0,1'b0,\VGA_R[4]_i_10_n_0 ,\VGA_R[4]_i_11_n_0 }));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \VGA_R_reg[4]_i_8 
       (.CI(1'b0),
        .CO({\VGA_R_reg[4]_i_8_n_0 ,\VGA_R_reg[4]_i_8_n_1 ,\VGA_R_reg[4]_i_8_n_2 ,\VGA_R_reg[4]_i_8_n_3 }),
        .CYINIT(1'b0),
        .DI({\VGA_R[4]_i_22_n_0 ,\VGA_R[4]_i_23_n_0 ,\VGA_R[4]_i_24_n_0 ,\VGA_R[4]_i_25_n_0 }),
        .O(\NLW_VGA_R_reg[4]_i_8_O_UNCONNECTED [3:0]),
        .S({\VGA_R[4]_i_26_n_0 ,\VGA_R[4]_i_27_n_0 ,\VGA_R[4]_i_28_n_0 ,\VGA_R[4]_i_29_n_0 }));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \VGA_R_reg[5]_i_11 
       (.CI(\VGA_R_reg[5]_i_31_n_0 ),
        .CO({\NLW_VGA_R_reg[5]_i_11_CO_UNCONNECTED [3:2],\VGA_R_reg[5]_i_11_n_2 ,\VGA_R_reg[5]_i_11_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,\VGA_R[5]_i_32_n_0 }),
        .O(\NLW_VGA_R_reg[5]_i_11_O_UNCONNECTED [3:0]),
        .S({1'b0,1'b0,\VGA_R[5]_i_33_n_0 ,\VGA_R[5]_i_34_n_0 }));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \VGA_R_reg[5]_i_12 
       (.CI(\VGA_R_reg[5]_i_35_n_0 ),
        .CO({\NLW_VGA_R_reg[5]_i_12_CO_UNCONNECTED [3:2],\VGA_R_reg[5]_i_12_n_2 ,\VGA_R_reg[5]_i_12_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\VGA_R[5]_i_36_n_0 ,\VGA_R[5]_i_37_n_0 }),
        .O(\NLW_VGA_R_reg[5]_i_12_O_UNCONNECTED [3:0]),
        .S({1'b0,1'b0,\VGA_R[5]_i_38_n_0 ,\VGA_R[5]_i_39_n_0 }));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \VGA_R_reg[5]_i_13 
       (.CI(\VGA_R_reg[5]_i_40_n_0 ),
        .CO({\NLW_VGA_R_reg[5]_i_13_CO_UNCONNECTED [3:2],\VGA_R_reg[5]_i_13_n_2 ,\VGA_R_reg[5]_i_13_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,\VGA_R[5]_i_41_n_0 }),
        .O(\NLW_VGA_R_reg[5]_i_13_O_UNCONNECTED [3:0]),
        .S({1'b0,1'b0,\VGA_R[5]_i_42_n_0 ,\VGA_R[5]_i_43_n_0 }));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \VGA_R_reg[5]_i_14 
       (.CI(1'b0),
        .CO({\VGA_R_reg[5]_i_14_n_0 ,\VGA_R_reg[5]_i_14_n_1 ,\VGA_R_reg[5]_i_14_n_2 ,\VGA_R_reg[5]_i_14_n_3 }),
        .CYINIT(1'b0),
        .DI({\VGA_R[5]_i_44_n_0 ,\VGA_R[5]_i_45_n_0 ,\VGA_R[5]_i_46_n_0 ,\VGA_R[5]_i_47_n_0 }),
        .O(\NLW_VGA_R_reg[5]_i_14_O_UNCONNECTED [3:0]),
        .S({\VGA_R[5]_i_48_n_0 ,\VGA_R[5]_i_49_n_0 ,\VGA_R[5]_i_50_n_0 ,\VGA_R[5]_i_51_n_0 }));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \VGA_R_reg[5]_i_18 
       (.CI(1'b0),
        .CO({\VGA_R_reg[5]_i_18_n_0 ,\VGA_R_reg[5]_i_18_n_1 ,\VGA_R_reg[5]_i_18_n_2 ,\VGA_R_reg[5]_i_18_n_3 }),
        .CYINIT(1'b0),
        .DI({\VGA_R[5]_i_52_n_0 ,\VGA_R[5]_i_53_n_0 ,\VGA_R[5]_i_54_n_0 ,\VGA_R[5]_i_55_n_0 }),
        .O(\NLW_VGA_R_reg[5]_i_18_O_UNCONNECTED [3:0]),
        .S({\VGA_R[5]_i_56_n_0 ,\VGA_R[5]_i_57_n_0 ,\VGA_R[5]_i_58_n_0 ,\VGA_R[5]_i_59_n_0 }));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \VGA_R_reg[5]_i_31 
       (.CI(1'b0),
        .CO({\VGA_R_reg[5]_i_31_n_0 ,\VGA_R_reg[5]_i_31_n_1 ,\VGA_R_reg[5]_i_31_n_2 ,\VGA_R_reg[5]_i_31_n_3 }),
        .CYINIT(1'b0),
        .DI({\VGA_R[5]_i_70_n_0 ,\VGA_R[5]_i_71_n_0 ,\VGA_R[5]_i_72_n_0 ,\VGA_R[5]_i_73_n_0 }),
        .O(\NLW_VGA_R_reg[5]_i_31_O_UNCONNECTED [3:0]),
        .S({\VGA_R[5]_i_74_n_0 ,\VGA_R[5]_i_75_n_0 ,\VGA_R[5]_i_76_n_0 ,\VGA_R[5]_i_77_n_0 }));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \VGA_R_reg[5]_i_35 
       (.CI(1'b0),
        .CO({\VGA_R_reg[5]_i_35_n_0 ,\VGA_R_reg[5]_i_35_n_1 ,\VGA_R_reg[5]_i_35_n_2 ,\VGA_R_reg[5]_i_35_n_3 }),
        .CYINIT(1'b0),
        .DI({\VGA_R[5]_i_80_n_0 ,\VGA_R[5]_i_81_n_0 ,\VGA_R[5]_i_82_n_0 ,\VGA_R[5]_i_83_n_0 }),
        .O(\NLW_VGA_R_reg[5]_i_35_O_UNCONNECTED [3:0]),
        .S({\VGA_R[5]_i_84_n_0 ,\VGA_R[5]_i_85_n_0 ,\VGA_R[5]_i_86_n_0 ,\VGA_R[5]_i_87_n_0 }));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \VGA_R_reg[5]_i_40 
       (.CI(1'b0),
        .CO({\VGA_R_reg[5]_i_40_n_0 ,\VGA_R_reg[5]_i_40_n_1 ,\VGA_R_reg[5]_i_40_n_2 ,\VGA_R_reg[5]_i_40_n_3 }),
        .CYINIT(1'b0),
        .DI({\VGA_R[5]_i_88_n_0 ,\VGA_R[5]_i_89_n_0 ,\VGA_R[5]_i_90_n_0 ,\VGA_R[5]_i_91_n_0 }),
        .O(\NLW_VGA_R_reg[5]_i_40_O_UNCONNECTED [3:0]),
        .S({\VGA_R[5]_i_92_n_0 ,\VGA_R[5]_i_93_n_0 ,\VGA_R[5]_i_94_n_0 ,\VGA_R[5]_i_95_n_0 }));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \VGA_R_reg[5]_i_7 
       (.CI(\VGA_R_reg[5]_i_14_n_0 ),
        .CO({\NLW_VGA_R_reg[5]_i_7_CO_UNCONNECTED [3:2],sel0[32],\VGA_R_reg[5]_i_7_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,\VGA_R[5]_i_15_n_0 }),
        .O(\NLW_VGA_R_reg[5]_i_7_O_UNCONNECTED [3:0]),
        .S({1'b0,1'b0,\VGA_R[5]_i_16_n_0 ,\VGA_R[5]_i_17_n_0 }));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \VGA_R_reg[5]_i_8 
       (.CI(\VGA_R_reg[5]_i_18_n_0 ),
        .CO({\NLW_VGA_R_reg[5]_i_8_CO_UNCONNECTED [3:2],\VGA_R_reg[5]_i_8_n_2 ,\VGA_R_reg[5]_i_8_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(\NLW_VGA_R_reg[5]_i_8_O_UNCONNECTED [3:0]),
        .S({1'b0,1'b0,\VGA_R[5]_i_19_n_0 ,\VGA_R[5]_i_20_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_100 
       (.CI(\VGA_R_reg[7]_i_236_n_0 ),
        .CO({\VGA_R_reg[7]_i_100_n_0 ,\VGA_R_reg[7]_i_100_n_1 ,\VGA_R_reg[7]_i_100_n_2 ,\VGA_R_reg[7]_i_100_n_3 }),
        .CYINIT(1'b0),
        .DI({\VGA_R_reg[7]_i_236_0 ,\VGA_R_reg[7]_i_99_1 ,\VGA_R_reg[7]_i_99_0 [2]}),
        .O({\NLW_VGA_R_reg[7]_i_100_O_UNCONNECTED [3],\VGA_R_reg[7]_i_100_n_5 ,\VGA_R_reg[7]_i_100_n_6 ,\VGA_R_reg[7]_i_100_n_7 }),
        .S(\VGA_R_reg[7]_i_99_2 ));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \VGA_R_reg[7]_i_102 
       (.CI(1'b0),
        .CO({\VGA_R_reg[7]_i_102_n_0 ,\VGA_R_reg[7]_i_102_n_1 ,\VGA_R_reg[7]_i_102_n_2 ,\VGA_R_reg[7]_i_102_n_3 }),
        .CYINIT(1'b0),
        .DI({\VGA_R[7]_i_250_n_0 ,\VGA_R[7]_i_251_n_0 ,\VGA_R[7]_i_252_n_0 ,\VGA_R[7]_i_253_n_0 }),
        .O(\NLW_VGA_R_reg[7]_i_102_O_UNCONNECTED [3:0]),
        .S({\VGA_R[7]_i_254_n_0 ,\VGA_R[7]_i_255_n_0 ,\VGA_R[7]_i_256_n_0 ,\VGA_R[7]_i_257_n_0 }));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \VGA_R_reg[7]_i_105 
       (.CI(1'b0),
        .CO({\VGA_R_reg[7]_i_105_n_0 ,\VGA_R_reg[7]_i_105_n_1 ,\VGA_R_reg[7]_i_105_n_2 ,\VGA_R_reg[7]_i_105_n_3 }),
        .CYINIT(1'b1),
        .DI({\VGA_R[7]_i_262_n_0 ,\VGA_R[7]_i_263_n_0 ,\VGA_R[7]_i_264_n_0 ,\VGA_R[7]_i_265_n_0 }),
        .O(\NLW_VGA_R_reg[7]_i_105_O_UNCONNECTED [3:0]),
        .S({\VGA_R[7]_i_266_n_0 ,\VGA_R[7]_i_267_n_0 ,\VGA_R[7]_i_268_n_0 ,\VGA_R[7]_i_269_n_0 }));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \VGA_R_reg[7]_i_11 
       (.CI(1'b0),
        .CO({\VGA_R_reg[7]_i_11_n_0 ,\VGA_R_reg[7]_i_11_n_1 ,\VGA_R_reg[7]_i_11_n_2 ,\VGA_R_reg[7]_i_11_n_3 }),
        .CYINIT(1'b0),
        .DI({\VGA_R[7]_i_44_n_0 ,\VGA_R[7]_i_45_n_0 ,\VGA_R[7]_i_46_n_0 ,\VGA_R[7]_i_47_n_0 }),
        .O(\NLW_VGA_R_reg[7]_i_11_O_UNCONNECTED [3:0]),
        .S({\VGA_R[7]_i_48_n_0 ,\VGA_R[7]_i_49_n_0 ,\VGA_R[7]_i_50_n_0 ,\VGA_R[7]_i_51_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_116 
       (.CI(1'b0),
        .CO({pattern_b3__4,\VGA_R_reg[7]_i_116_n_1 ,\VGA_R_reg[7]_i_116_n_2 ,\VGA_R_reg[7]_i_116_n_3 }),
        .CYINIT(1'b1),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(\NLW_VGA_R_reg[7]_i_116_O_UNCONNECTED [3:0]),
        .S({\VGA_R[7]_i_287_n_0 ,\VGA_R[7]_i_288_n_0 ,\VGA_R[7]_i_289_n_0 ,\VGA_R[7]_i_290_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_117 
       (.CI(1'b0),
        .CO({pattern_b1__1,\VGA_R_reg[7]_i_117_n_1 ,\VGA_R_reg[7]_i_117_n_2 ,\VGA_R_reg[7]_i_117_n_3 }),
        .CYINIT(1'b1),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(\NLW_VGA_R_reg[7]_i_117_O_UNCONNECTED [3:0]),
        .S({\VGA_R[7]_i_291_n_0 ,\VGA_R[7]_i_292_n_0 ,\VGA_R[7]_i_293_n_0 ,\VGA_R[7]_i_294_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_118 
       (.CI(1'b0),
        .CO({pattern_b20_out,\VGA_R_reg[7]_i_118_n_1 ,\VGA_R_reg[7]_i_118_n_2 ,\VGA_R_reg[7]_i_118_n_3 }),
        .CYINIT(1'b1),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(\NLW_VGA_R_reg[7]_i_118_O_UNCONNECTED [3:0]),
        .S({\VGA_R[7]_i_295_n_0 ,\VGA_R[7]_i_296_n_0 ,\VGA_R[7]_i_297_n_0 ,\VGA_R[7]_i_298_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_121 
       (.CI(1'b0),
        .CO({\VGA_R_reg[7]_i_121_n_0 ,\VGA_R_reg[7]_i_121_n_1 ,\VGA_R_reg[7]_i_121_n_2 ,\VGA_R_reg[7]_i_121_n_3 }),
        .CYINIT(sel0[2]),
        .DI({\VGA_R_reg[7]_i_122_n_5 ,\VGA_R_reg[7]_i_122_n_6 ,sel0[2],\VGA_R[7]_i_299_n_0 }),
        .O({\VGA_R_reg[7]_i_121_n_4 ,\VGA_R_reg[7]_i_121_n_5 ,\VGA_R_reg[7]_i_121_n_6 ,\VGA_R_reg[7]_i_121_n_7 }),
        .S({\VGA_R[7]_i_300_n_0 ,\VGA_R[7]_i_301_n_0 ,\VGA_R[7]_i_302_n_0 ,\VGA_R[7]_i_303_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_122 
       (.CI(1'b0),
        .CO({\VGA_R_reg[7]_i_122_n_0 ,\VGA_R_reg[7]_i_122_n_1 ,\VGA_R_reg[7]_i_122_n_2 ,\VGA_R_reg[7]_i_122_n_3 }),
        .CYINIT(sel0[3]),
        .DI({\VGA_R_reg[7]_i_157_n_5 ,\VGA_R_reg[7]_i_157_n_6 ,sel0[3],\VGA_R[7]_i_304_n_0 }),
        .O({\VGA_R_reg[7]_i_122_n_4 ,\VGA_R_reg[7]_i_122_n_5 ,\VGA_R_reg[7]_i_122_n_6 ,\VGA_R_reg[7]_i_122_n_7 }),
        .S({\VGA_R[7]_i_305_n_0 ,\VGA_R[7]_i_306_n_0 ,\VGA_R[7]_i_307_n_0 ,\VGA_R[7]_i_308_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_130 
       (.CI(1'b0),
        .CO({\VGA_R_reg[7]_i_130_n_0 ,\VGA_R_reg[7]_i_130_n_1 ,\VGA_R_reg[7]_i_130_n_2 ,\VGA_R_reg[7]_i_130_n_3 }),
        .CYINIT(sel0[12]),
        .DI({\VGA_R[7]_i_318_n_0 ,\VGA_R[7]_i_343_0 ,sel0[12],\VGA_R[7]_i_320_n_0 }),
        .O({\VGA_R_reg[7]_i_130_n_4 ,\VGA_R_reg[7]_i_130_n_5 ,\VGA_R_reg[7]_i_130_n_6 ,\VGA_R_reg[7]_i_130_n_7 }),
        .S({\VGA_R[7]_i_321_n_0 ,\VGA_R[7]_i_322_n_0 ,\VGA_R[7]_i_323_n_0 ,\VGA_R[7]_i_324_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_136 
       (.CI(1'b0),
        .CO({\VGA_R_reg[7]_i_136_n_0 ,\VGA_R_reg[7]_i_136_n_1 ,\VGA_R_reg[7]_i_136_n_2 ,\VGA_R_reg[7]_i_136_n_3 }),
        .CYINIT(sel0[7]),
        .DI({\VGA_R_reg[7]_i_137_n_5 ,\VGA_R_reg[7]_i_137_n_6 ,sel0[7],\VGA_R[7]_i_325_n_0 }),
        .O({\VGA_R_reg[7]_i_136_n_4 ,\VGA_R_reg[7]_i_136_n_5 ,\VGA_R_reg[7]_i_136_n_6 ,\VGA_R_reg[7]_i_136_n_7 }),
        .S({\VGA_R[7]_i_326_n_0 ,\VGA_R[7]_i_327_n_0 ,\VGA_R[7]_i_328_n_0 ,\VGA_R[7]_i_329_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_137 
       (.CI(1'b0),
        .CO({\VGA_R_reg[7]_i_137_n_0 ,\VGA_R_reg[7]_i_137_n_1 ,\VGA_R_reg[7]_i_137_n_2 ,\VGA_R_reg[7]_i_137_n_3 }),
        .CYINIT(sel0[8]),
        .DI({\VGA_R_reg[7]_i_148_n_5 ,\VGA_R_reg[7]_i_148_n_6 ,sel0[8],\VGA_R[7]_i_330_n_0 }),
        .O({\VGA_R_reg[7]_i_137_n_4 ,\VGA_R_reg[7]_i_137_n_5 ,\VGA_R_reg[7]_i_137_n_6 ,\VGA_R_reg[7]_i_137_n_7 }),
        .S({\VGA_R[7]_i_331_n_0 ,\VGA_R[7]_i_332_n_0 ,\VGA_R[7]_i_333_n_0 ,\VGA_R[7]_i_334_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_142 
       (.CI(1'b0),
        .CO({\VGA_R_reg[7]_i_142_n_0 ,\VGA_R_reg[7]_i_142_n_1 ,\VGA_R_reg[7]_i_142_n_2 ,\VGA_R_reg[7]_i_142_n_3 }),
        .CYINIT(sel0[10]),
        .DI({\VGA_R_reg[7]_i_143_n_5 ,\VGA_R_reg[7]_i_143_n_6 ,sel0[10],\VGA_R[7]_i_335_n_0 }),
        .O({\VGA_R_reg[7]_i_142_n_4 ,\VGA_R_reg[7]_i_142_n_5 ,\VGA_R_reg[7]_i_142_n_6 ,\VGA_R_reg[7]_i_142_n_7 }),
        .S({\VGA_R[7]_i_336_n_0 ,\VGA_R[7]_i_337_n_0 ,\VGA_R[7]_i_338_n_0 ,\VGA_R[7]_i_339_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_143 
       (.CI(1'b0),
        .CO({\VGA_R_reg[7]_i_143_n_0 ,\VGA_R_reg[7]_i_143_n_1 ,\VGA_R_reg[7]_i_143_n_2 ,\VGA_R_reg[7]_i_143_n_3 }),
        .CYINIT(sel0[11]),
        .DI({\VGA_R_reg[7]_i_130_n_5 ,\VGA_R_reg[7]_i_130_n_6 ,sel0[11],\VGA_R[7]_i_340_n_0 }),
        .O({\VGA_R_reg[7]_i_143_n_4 ,\VGA_R_reg[7]_i_143_n_5 ,\VGA_R_reg[7]_i_143_n_6 ,\VGA_R_reg[7]_i_143_n_7 }),
        .S({\VGA_R[7]_i_341_n_0 ,\VGA_R[7]_i_342_n_0 ,\VGA_R[7]_i_343_n_0 ,\VGA_R[7]_i_344_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_148 
       (.CI(1'b0),
        .CO({\VGA_R_reg[7]_i_148_n_0 ,\VGA_R_reg[7]_i_148_n_1 ,\VGA_R_reg[7]_i_148_n_2 ,\VGA_R_reg[7]_i_148_n_3 }),
        .CYINIT(sel0[9]),
        .DI({\VGA_R_reg[7]_i_142_n_5 ,\VGA_R_reg[7]_i_142_n_6 ,sel0[9],\VGA_R[7]_i_345_n_0 }),
        .O({\VGA_R_reg[7]_i_148_n_4 ,\VGA_R_reg[7]_i_148_n_5 ,\VGA_R_reg[7]_i_148_n_6 ,\VGA_R_reg[7]_i_148_n_7 }),
        .S({\VGA_R[7]_i_346_n_0 ,\VGA_R[7]_i_347_n_0 ,\VGA_R[7]_i_348_n_0 ,\VGA_R[7]_i_349_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_157 
       (.CI(1'b0),
        .CO({\VGA_R_reg[7]_i_157_n_0 ,\VGA_R_reg[7]_i_157_n_1 ,\VGA_R_reg[7]_i_157_n_2 ,\VGA_R_reg[7]_i_157_n_3 }),
        .CYINIT(sel0[4]),
        .DI({\VGA_R_reg[7]_i_158_n_5 ,\VGA_R_reg[7]_i_158_n_6 ,sel0[4],\VGA_R[7]_i_350_n_0 }),
        .O({\VGA_R_reg[7]_i_157_n_4 ,\VGA_R_reg[7]_i_157_n_5 ,\VGA_R_reg[7]_i_157_n_6 ,\VGA_R_reg[7]_i_157_n_7 }),
        .S({\VGA_R[7]_i_351_n_0 ,\VGA_R[7]_i_352_n_0 ,\VGA_R[7]_i_353_n_0 ,\VGA_R[7]_i_354_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_158 
       (.CI(1'b0),
        .CO({\VGA_R_reg[7]_i_158_n_0 ,\VGA_R_reg[7]_i_158_n_1 ,\VGA_R_reg[7]_i_158_n_2 ,\VGA_R_reg[7]_i_158_n_3 }),
        .CYINIT(sel0[5]),
        .DI({\VGA_R_reg[7]_i_163_n_5 ,\VGA_R_reg[7]_i_163_n_6 ,sel0[5],\VGA_R[7]_i_355_n_0 }),
        .O({\VGA_R_reg[7]_i_158_n_4 ,\VGA_R_reg[7]_i_158_n_5 ,\VGA_R_reg[7]_i_158_n_6 ,\VGA_R_reg[7]_i_158_n_7 }),
        .S({\VGA_R[7]_i_356_n_0 ,\VGA_R[7]_i_357_n_0 ,\VGA_R[7]_i_358_n_0 ,\VGA_R[7]_i_359_n_0 }));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \VGA_R_reg[7]_i_16 
       (.CI(1'b0),
        .CO({\VGA_R_reg[7]_i_16_n_0 ,\VGA_R_reg[7]_i_16_n_1 ,\VGA_R_reg[7]_i_16_n_2 ,\VGA_R_reg[7]_i_16_n_3 }),
        .CYINIT(1'b1),
        .DI({\VGA_R[7]_i_52_n_0 ,\VGA_R[7]_i_53_n_0 ,\VGA_R[7]_i_54_n_0 ,\VGA_R[7]_i_55_n_0 }),
        .O(\NLW_VGA_R_reg[7]_i_16_O_UNCONNECTED [3:0]),
        .S({\VGA_R[7]_i_56_n_0 ,\VGA_R[7]_i_57_n_0 ,\VGA_R[7]_i_58_n_0 ,\VGA_R[7]_i_59_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_163 
       (.CI(1'b0),
        .CO({\VGA_R_reg[7]_i_163_n_0 ,\VGA_R_reg[7]_i_163_n_1 ,\VGA_R_reg[7]_i_163_n_2 ,\VGA_R_reg[7]_i_163_n_3 }),
        .CYINIT(sel0[6]),
        .DI({\VGA_R_reg[7]_i_136_n_5 ,\VGA_R_reg[7]_i_136_n_6 ,sel0[6],\VGA_R[7]_i_360_n_0 }),
        .O({\VGA_R_reg[7]_i_163_n_4 ,\VGA_R_reg[7]_i_163_n_5 ,\VGA_R_reg[7]_i_163_n_6 ,\VGA_R_reg[7]_i_163_n_7 }),
        .S({\VGA_R[7]_i_361_n_0 ,\VGA_R[7]_i_362_n_0 ,\VGA_R[7]_i_363_n_0 ,\VGA_R[7]_i_364_n_0 }));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \VGA_R_reg[7]_i_21 
       (.CI(1'b0),
        .CO({\VGA_R_reg[7]_i_21_n_0 ,\VGA_R_reg[7]_i_21_n_1 ,\VGA_R_reg[7]_i_21_n_2 ,\VGA_R_reg[7]_i_21_n_3 }),
        .CYINIT(1'b1),
        .DI({\VGA_R[7]_i_61_n_0 ,\VGA_R[7]_i_62_n_0 ,1'b0,\VGA_R[7]_i_63_n_0 }),
        .O(\NLW_VGA_R_reg[7]_i_21_O_UNCONNECTED [3:0]),
        .S({\VGA_R[7]_i_64_n_0 ,\VGA_R[7]_i_65_n_0 ,\VGA_R[7]_i_66_n_0 ,\VGA_R[7]_i_67_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_211 
       (.CI(1'b0),
        .CO({\VGA_R_reg[7]_i_211_n_0 ,\VGA_R_reg[7]_i_211_n_1 ,\VGA_R_reg[7]_i_211_n_2 ,\VGA_R_reg[7]_i_211_n_3 }),
        .CYINIT(\VGA_R_reg[7]_i_96_n_0 ),
        .DI({\VGA_R_reg[7]_i_216_n_5 ,\VGA_R_reg[7]_i_216_n_6 ,\VGA_R_reg[7]_i_96_n_0 ,\VGA_R[7]_i_393_n_0 }),
        .O({\VGA_R_reg[7]_i_211_n_4 ,\VGA_R_reg[7]_i_211_n_5 ,\VGA_R_reg[7]_i_211_n_6 ,\VGA_R_reg[7]_i_211_n_7 }),
        .S({\VGA_R[7]_i_394_n_0 ,\VGA_R[7]_i_395_n_0 ,\VGA_R[7]_i_396_n_0 ,\VGA_R[7]_i_397_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_216 
       (.CI(1'b0),
        .CO({\VGA_R_reg[7]_i_216_n_0 ,\VGA_R_reg[7]_i_216_n_1 ,\VGA_R_reg[7]_i_216_n_2 ,\VGA_R_reg[7]_i_216_n_3 }),
        .CYINIT(\VGA_R_reg[7]_i_97_n_0 ),
        .DI({\VGA_R_reg[7]_i_221_n_5 ,\VGA_R_reg[7]_i_221_n_6 ,\VGA_R_reg[7]_i_97_n_0 ,\VGA_R[7]_i_398_n_0 }),
        .O({\VGA_R_reg[7]_i_216_n_4 ,\VGA_R_reg[7]_i_216_n_5 ,\VGA_R_reg[7]_i_216_n_6 ,\VGA_R_reg[7]_i_216_n_7 }),
        .S({\VGA_R[7]_i_399_n_0 ,\VGA_R[7]_i_400_n_0 ,\VGA_R[7]_i_401_n_0 ,\VGA_R[7]_i_402_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_221 
       (.CI(1'b0),
        .CO({\VGA_R_reg[7]_i_221_n_0 ,\VGA_R_reg[7]_i_221_n_1 ,\VGA_R_reg[7]_i_221_n_2 ,\VGA_R_reg[7]_i_221_n_3 }),
        .CYINIT(\VGA_R_reg[7]_i_98_n_0 ),
        .DI({\VGA_R_reg[7]_i_226_n_5 ,\VGA_R_reg[7]_i_226_n_6 ,\VGA_R_reg[7]_i_98_n_0 ,\VGA_R[7]_i_403_n_0 }),
        .O({\VGA_R_reg[7]_i_221_n_4 ,\VGA_R_reg[7]_i_221_n_5 ,\VGA_R_reg[7]_i_221_n_6 ,\VGA_R_reg[7]_i_221_n_7 }),
        .S({\VGA_R[7]_i_404_n_0 ,\VGA_R[7]_i_405_n_0 ,\VGA_R[7]_i_406_n_0 ,\VGA_R[7]_i_407_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_226 
       (.CI(1'b0),
        .CO({\VGA_R_reg[7]_i_226_n_0 ,\VGA_R_reg[7]_i_226_n_1 ,\VGA_R_reg[7]_i_226_n_2 ,\VGA_R_reg[7]_i_226_n_3 }),
        .CYINIT(\VGA_R_reg[7]_i_99_n_0 ),
        .DI({\VGA_R_reg[7]_i_231_n_5 ,\VGA_R_reg[7]_i_231_n_6 ,\VGA_R_reg[7]_i_99_n_0 ,\VGA_R[7]_i_408_n_0 }),
        .O({\VGA_R_reg[7]_i_226_n_4 ,\VGA_R_reg[7]_i_226_n_5 ,\VGA_R_reg[7]_i_226_n_6 ,\VGA_R_reg[7]_i_226_n_7 }),
        .S({\VGA_R[7]_i_409_n_0 ,\VGA_R[7]_i_410_n_0 ,\VGA_R[7]_i_411_n_0 ,\VGA_R[7]_i_412_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_231 
       (.CI(1'b0),
        .CO({\VGA_R_reg[7]_i_231_n_0 ,\VGA_R_reg[7]_i_231_n_1 ,\VGA_R_reg[7]_i_231_n_2 ,\VGA_R_reg[7]_i_231_n_3 }),
        .CYINIT(\VGA_R_reg[7]_i_100_n_0 ),
        .DI({\VGA_R_reg[7]_i_236_n_5 ,\VGA_R_reg[7]_i_236_n_6 ,\VGA_R_reg[7]_i_100_n_0 ,\VGA_R[7]_i_413_n_0 }),
        .O({\VGA_R_reg[7]_i_231_n_4 ,\VGA_R_reg[7]_i_231_n_5 ,\VGA_R_reg[7]_i_231_n_6 ,\VGA_R_reg[7]_i_231_n_7 }),
        .S({\VGA_R[7]_i_414_n_0 ,\VGA_R[7]_i_415_n_0 ,\VGA_R[7]_i_416_n_0 ,\VGA_R[7]_i_417_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_236 
       (.CI(1'b0),
        .CO({\VGA_R_reg[7]_i_236_n_0 ,\VGA_R_reg[7]_i_236_n_1 ,\VGA_R_reg[7]_i_236_n_2 ,\VGA_R_reg[7]_i_236_n_3 }),
        .CYINIT(\VGA_R_reg[7]_i_236_0 ),
        .DI({\VGA_R_reg[7]_i_99_0 [1:0],\VGA_R_reg[7]_i_236_0 ,\VGA_R[7]_i_418_n_0 }),
        .O({\VGA_R_reg[7]_i_236_n_4 ,\VGA_R_reg[7]_i_236_n_5 ,\VGA_R_reg[7]_i_236_n_6 ,\VGA_R_reg[7]_i_236_n_7 }),
        .S({S,\VGA_R[7]_i_422_n_0 }));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \VGA_R_reg[7]_i_3 
       (.CI(\VGA_R_reg[7]_i_11_n_0 ),
        .CO({\NLW_VGA_R_reg[7]_i_3_CO_UNCONNECTED [3:2],disp_enable0,\VGA_R_reg[7]_i_3_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\VGA_R[7]_i_12_n_0 ,\VGA_R[7]_i_13_n_0 }),
        .O(\NLW_VGA_R_reg[7]_i_3_O_UNCONNECTED [3:0]),
        .S({1'b0,1'b0,\VGA_R[7]_i_14_n_0 ,\VGA_R[7]_i_15_n_0 }));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \VGA_R_reg[7]_i_317 
       (.CI(\VGA_R_reg[7]_i_450_n_0 ),
        .CO({\VGA_R_reg[7]_i_317_n_0 ,\VGA_R_reg[7]_i_317_n_1 ,\VGA_R_reg[7]_i_317_n_2 ,\VGA_R_reg[7]_i_317_n_3 }),
        .CYINIT(1'b0),
        .DI(p_1_in[8:5]),
        .O({\VGA_R_reg[7]_i_317_n_4 ,\VGA_R_reg[7]_i_317_n_5 ,\VGA_R_reg[7]_i_317_n_6 ,\VGA_R_reg[7]_i_317_n_7 }),
        .S({\VGA_R[7]_i_451_n_0 ,\VGA_R[7]_i_452_n_0 ,\VGA_R[7]_i_453_n_0 ,\VGA_R[7]_i_454_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_33 
       (.CI(\VGA_R_reg[7]_i_86_n_0 ),
        .CO({\VGA_R_reg[7]_i_33_n_0 ,\VGA_R_reg[7]_i_33_n_1 ,\VGA_R_reg[7]_i_33_n_2 ,\VGA_R_reg[7]_i_33_n_3 }),
        .CYINIT(1'b0),
        .DI({\VGA_G_reg[7]_i_6_n_0 ,\VGA_G_reg[7]_i_6_n_6 ,\VGA_G_reg[7]_i_6_n_7 ,\VGA_R_reg[7]_i_87_n_4 }),
        .O({\NLW_VGA_R_reg[7]_i_33_O_UNCONNECTED [3],\VGA_R_reg[7]_i_33_n_5 ,\VGA_R_reg[7]_i_33_n_6 ,\VGA_R_reg[7]_i_33_n_7 }),
        .S({\VGA_R[7]_i_88_n_0 ,\VGA_R[7]_i_89_n_0 ,\VGA_R[7]_i_90_n_0 ,\VGA_R[7]_i_91_n_0 }));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \VGA_R_reg[7]_i_38 
       (.CI(\VGA_R_reg[7]_i_102_n_0 ),
        .CO({\NLW_VGA_R_reg[7]_i_38_CO_UNCONNECTED [3:1],\VGA_R_reg[7]_i_38_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,\VGA_R[7]_i_103_n_0 }),
        .O(\NLW_VGA_R_reg[7]_i_38_O_UNCONNECTED [3:0]),
        .S({1'b0,1'b0,1'b0,\VGA_R[7]_i_104_n_0 }));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \VGA_R_reg[7]_i_39 
       (.CI(\VGA_R_reg[7]_i_105_n_0 ),
        .CO({\NLW_VGA_R_reg[7]_i_39_CO_UNCONNECTED [3:2],pattern_b11_in,\VGA_R_reg[7]_i_39_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,p_1_in[10],\VGA_R[7]_i_106_n_0 }),
        .O(\NLW_VGA_R_reg[7]_i_39_O_UNCONNECTED [3:0]),
        .S({1'b0,1'b0,\VGA_R[7]_i_107_n_0 ,\VGA_R[7]_i_108_n_0 }));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \VGA_R_reg[7]_i_4 
       (.CI(\VGA_R_reg[7]_i_16_n_0 ),
        .CO({\NLW_VGA_R_reg[7]_i_4_CO_UNCONNECTED [3:2],disp_enable1,\VGA_R_reg[7]_i_4_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\VGA_R[7]_i_17_n_0 ,\VGA_R[7]_i_18_n_0 }),
        .O(\NLW_VGA_R_reg[7]_i_4_O_UNCONNECTED [3:0]),
        .S({1'b0,1'b0,\VGA_R[7]_i_19_n_0 ,\VGA_R[7]_i_20_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_448 
       (.CI(sel0[6]),
        .CO(\NLW_VGA_R_reg[7]_i_448_CO_UNCONNECTED [3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_VGA_R_reg[7]_i_448_O_UNCONNECTED [3:1],\VGA_R_reg[7]_i_448_n_7 }),
        .S({1'b0,1'b0,1'b0,\VGA_R[7]_i_499_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_449 
       (.CI(sel0[7]),
        .CO(\NLW_VGA_R_reg[7]_i_449_CO_UNCONNECTED [3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_VGA_R_reg[7]_i_449_O_UNCONNECTED [3:1],\VGA_R_reg[7]_i_449_n_7 }),
        .S({1'b0,1'b0,1'b0,\VGA_R[7]_i_500_n_0 }));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \VGA_R_reg[7]_i_450 
       (.CI(\VGA_R_reg[7]_i_501_n_0 ),
        .CO({\VGA_R_reg[7]_i_450_n_0 ,\VGA_R_reg[7]_i_450_n_1 ,\VGA_R_reg[7]_i_450_n_2 ,\VGA_R_reg[7]_i_450_n_3 }),
        .CYINIT(1'b0),
        .DI(p_1_in[4:1]),
        .O({\VGA_R_reg[7]_i_450_n_4 ,\VGA_R_reg[7]_i_450_n_5 ,\VGA_R_reg[7]_i_450_n_6 ,\VGA_R_reg[7]_i_450_n_7 }),
        .S({\VGA_R[7]_i_502_n_0 ,\VGA_R[7]_i_503_n_0 ,\VGA_R[7]_i_504_n_0 ,\VGA_R[7]_i_505_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_455 
       (.CI(sel0[11]),
        .CO(\NLW_VGA_R_reg[7]_i_455_CO_UNCONNECTED [3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_VGA_R_reg[7]_i_455_O_UNCONNECTED [3:1],\VGA_R_reg[7]_i_455_n_7 }),
        .S({1'b0,1'b0,1'b0,\VGA_R[7]_i_506_n_0 }));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \VGA_R_reg[7]_i_456 
       (.CI(\VGA_R_reg[7]_i_317_n_0 ),
        .CO({\NLW_VGA_R_reg[7]_i_456_CO_UNCONNECTED [3:1],\VGA_R_reg[7]_i_456_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,p_1_in[9]}),
        .O({\NLW_VGA_R_reg[7]_i_456_O_UNCONNECTED [3:2],\VGA_R_reg[7]_i_456_n_6 ,\VGA_R_reg[7]_i_456_n_7 }),
        .S({1'b0,1'b0,\VGA_R[7]_i_507_n_0 ,\VGA_R[7]_i_508_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_457 
       (.CI(sel0[8]),
        .CO(\NLW_VGA_R_reg[7]_i_457_CO_UNCONNECTED [3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_VGA_R_reg[7]_i_457_O_UNCONNECTED [3:1],\VGA_R_reg[7]_i_457_n_7 }),
        .S({1'b0,1'b0,1'b0,\VGA_R[7]_i_509_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_458 
       (.CI(sel0[9]),
        .CO(\NLW_VGA_R_reg[7]_i_458_CO_UNCONNECTED [3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_VGA_R_reg[7]_i_458_O_UNCONNECTED [3:1],\VGA_R_reg[7]_i_458_n_7 }),
        .S({1'b0,1'b0,1'b0,\VGA_R[7]_i_510_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_459 
       (.CI(sel0[10]),
        .CO(\NLW_VGA_R_reg[7]_i_459_CO_UNCONNECTED [3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_VGA_R_reg[7]_i_459_O_UNCONNECTED [3:1],\VGA_R_reg[7]_i_459_n_7 }),
        .S({1'b0,1'b0,1'b0,\VGA_R[7]_i_511_n_0 }));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \VGA_R_reg[7]_i_5 
       (.CI(\VGA_R_reg[7]_i_21_n_0 ),
        .CO({\NLW_VGA_R_reg[7]_i_5_CO_UNCONNECTED [3:2],disp_enable10_in,\VGA_R_reg[7]_i_5_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,VCNT[10],\VGA_R[7]_i_22_n_0 }),
        .O(\NLW_VGA_R_reg[7]_i_5_O_UNCONNECTED [3:0]),
        .S({1'b0,1'b0,\VGA_R[7]_i_23_n_0 ,\VGA_R[7]_i_24_n_0 }));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \VGA_R_reg[7]_i_501 
       (.CI(1'b0),
        .CO({\VGA_R_reg[7]_i_501_n_0 ,\VGA_R_reg[7]_i_501_n_1 ,\VGA_R_reg[7]_i_501_n_2 ,\VGA_R_reg[7]_i_501_n_3 }),
        .CYINIT(1'b0),
        .DI({\VGA_R[7]_i_556_n_0 ,1'b0,1'b0,1'b1}),
        .O(\NLW_VGA_R_reg[7]_i_501_O_UNCONNECTED [3:0]),
        .S({\VGA_R[7]_i_557_n_0 ,\VGA_R[7]_i_558_n_0 ,\VGA_R[7]_i_559_n_0 ,\VGA_R[7]_i_560_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_68 
       (.CI(\VGA_R_reg[7]_i_121_n_0 ),
        .CO({sel0[1],\VGA_R_reg[7]_i_68_n_1 ,\VGA_R_reg[7]_i_68_n_2 ,\VGA_R_reg[7]_i_68_n_3 }),
        .CYINIT(1'b0),
        .DI({sel0[2],\VGA_G_reg[7]_i_7_n_6 ,\VGA_G_reg[7]_i_7_n_7 ,\VGA_R_reg[7]_i_122_n_4 }),
        .O({\NLW_VGA_R_reg[7]_i_68_O_UNCONNECTED [3],\VGA_R_reg[7]_i_68_n_5 ,\VGA_R_reg[7]_i_68_n_6 ,\VGA_R_reg[7]_i_68_n_7 }),
        .S({\VGA_R[7]_i_123_n_0 ,\VGA_R[7]_i_124_n_0 ,\VGA_R[7]_i_125_n_0 ,\VGA_R[7]_i_126_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_69 
       (.CI(\VGA_R[7]_i_330_0 ),
        .CO({\NLW_VGA_R_reg[7]_i_69_CO_UNCONNECTED [3:1],sel0[12]}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_VGA_R_reg[7]_i_69_O_UNCONNECTED [3:2],\VGA_R_reg[7]_i_69_n_6 ,\NLW_VGA_R_reg[7]_i_69_O_UNCONNECTED [0]}),
        .S({1'b0,1'b0,\VGA_R[7]_i_128_n_0 ,\VGA_R[7]_i_330_1 }));
  CARRY4 \VGA_R_reg[7]_i_70 
       (.CI(\VGA_R_reg[7]_i_130_n_0 ),
        .CO({sel0[11],\VGA_R_reg[7]_i_70_n_1 ,\VGA_R_reg[7]_i_70_n_2 ,\VGA_R_reg[7]_i_70_n_3 }),
        .CYINIT(1'b0),
        .DI({sel0[12],\VGA_R_reg[7]_i_70_0 [1:0],\VGA_R_reg[7]_i_74_0 }),
        .O({\NLW_VGA_R_reg[7]_i_70_O_UNCONNECTED [3],\VGA_R_reg[7]_i_70_n_5 ,\VGA_R_reg[7]_i_70_n_6 ,\VGA_R_reg[7]_i_70_n_7 }),
        .S({\VGA_R[7]_i_132_n_0 ,\VGA_R[7]_i_133_n_0 ,\VGA_R[7]_i_134_n_0 ,\VGA_R[7]_i_135_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_71 
       (.CI(\VGA_R_reg[7]_i_136_n_0 ),
        .CO({sel0[6],\VGA_R_reg[7]_i_71_n_1 ,\VGA_R_reg[7]_i_71_n_2 ,\VGA_R_reg[7]_i_71_n_3 }),
        .CYINIT(1'b0),
        .DI({sel0[7],\VGA_R_reg[7]_i_78_n_6 ,\VGA_R_reg[7]_i_78_n_7 ,\VGA_R_reg[7]_i_137_n_4 }),
        .O({\NLW_VGA_R_reg[7]_i_71_O_UNCONNECTED [3],\VGA_R_reg[7]_i_71_n_5 ,\VGA_R_reg[7]_i_71_n_6 ,\VGA_R_reg[7]_i_71_n_7 }),
        .S({\VGA_R[7]_i_138_n_0 ,\VGA_R[7]_i_139_n_0 ,\VGA_R[7]_i_140_n_0 ,\VGA_R[7]_i_141_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_72 
       (.CI(\VGA_R_reg[7]_i_142_n_0 ),
        .CO({sel0[9],\VGA_R_reg[7]_i_72_n_1 ,\VGA_R_reg[7]_i_72_n_2 ,\VGA_R_reg[7]_i_72_n_3 }),
        .CYINIT(1'b0),
        .DI({sel0[10],\VGA_R_reg[7]_i_74_n_6 ,\VGA_R_reg[7]_i_74_n_7 ,\VGA_R_reg[7]_i_143_n_4 }),
        .O({\NLW_VGA_R_reg[7]_i_72_O_UNCONNECTED [3],\VGA_R_reg[7]_i_72_n_5 ,\VGA_R_reg[7]_i_72_n_6 ,\VGA_R_reg[7]_i_72_n_7 }),
        .S({\VGA_R[7]_i_144_n_0 ,\VGA_R[7]_i_145_n_0 ,\VGA_R[7]_i_146_n_0 ,\VGA_R[7]_i_147_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_73 
       (.CI(\VGA_R_reg[7]_i_148_n_0 ),
        .CO({sel0[8],\VGA_R_reg[7]_i_73_n_1 ,\VGA_R_reg[7]_i_73_n_2 ,\VGA_R_reg[7]_i_73_n_3 }),
        .CYINIT(1'b0),
        .DI({sel0[9],\VGA_R_reg[7]_i_72_n_6 ,\VGA_R_reg[7]_i_72_n_7 ,\VGA_R_reg[7]_i_142_n_4 }),
        .O({\NLW_VGA_R_reg[7]_i_73_O_UNCONNECTED [3],\VGA_R_reg[7]_i_73_n_5 ,\VGA_R_reg[7]_i_73_n_6 ,\VGA_R_reg[7]_i_73_n_7 }),
        .S({\VGA_R[7]_i_149_n_0 ,\VGA_R[7]_i_150_n_0 ,\VGA_R[7]_i_151_n_0 ,\VGA_R[7]_i_152_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_74 
       (.CI(\VGA_R_reg[7]_i_143_n_0 ),
        .CO({sel0[10],\VGA_R_reg[7]_i_74_n_1 ,\VGA_R_reg[7]_i_74_n_2 ,\VGA_R_reg[7]_i_74_n_3 }),
        .CYINIT(1'b0),
        .DI({sel0[11],\VGA_R_reg[7]_i_70_n_6 ,\VGA_R_reg[7]_i_70_n_7 ,\VGA_R_reg[7]_i_130_n_4 }),
        .O({\NLW_VGA_R_reg[7]_i_74_O_UNCONNECTED [3],\VGA_R_reg[7]_i_74_n_5 ,\VGA_R_reg[7]_i_74_n_6 ,\VGA_R_reg[7]_i_74_n_7 }),
        .S({\VGA_R[7]_i_153_n_0 ,\VGA_R[7]_i_154_n_0 ,\VGA_R[7]_i_155_n_0 ,\VGA_R[7]_i_156_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_75 
       (.CI(\VGA_R_reg[7]_i_157_n_0 ),
        .CO({sel0[3],\VGA_R_reg[7]_i_75_n_1 ,\VGA_R_reg[7]_i_75_n_2 ,\VGA_R_reg[7]_i_75_n_3 }),
        .CYINIT(1'b0),
        .DI({sel0[4],\VGA_R_reg[7]_i_76_n_6 ,\VGA_R_reg[7]_i_76_n_7 ,\VGA_R_reg[7]_i_158_n_4 }),
        .O({\NLW_VGA_R_reg[7]_i_75_O_UNCONNECTED [3],\VGA_R_reg[7]_i_75_n_5 ,\VGA_R_reg[7]_i_75_n_6 ,\VGA_R_reg[7]_i_75_n_7 }),
        .S({\VGA_R[7]_i_159_n_0 ,\VGA_R[7]_i_160_n_0 ,\VGA_R[7]_i_161_n_0 ,\VGA_R[7]_i_162_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_76 
       (.CI(\VGA_R_reg[7]_i_158_n_0 ),
        .CO({sel0[4],\VGA_R_reg[7]_i_76_n_1 ,\VGA_R_reg[7]_i_76_n_2 ,\VGA_R_reg[7]_i_76_n_3 }),
        .CYINIT(1'b0),
        .DI({sel0[5],\VGA_R_reg[7]_i_77_n_6 ,\VGA_R_reg[7]_i_77_n_7 ,\VGA_R_reg[7]_i_163_n_4 }),
        .O({\NLW_VGA_R_reg[7]_i_76_O_UNCONNECTED [3],\VGA_R_reg[7]_i_76_n_5 ,\VGA_R_reg[7]_i_76_n_6 ,\VGA_R_reg[7]_i_76_n_7 }),
        .S({\VGA_R[7]_i_164_n_0 ,\VGA_R[7]_i_165_n_0 ,\VGA_R[7]_i_166_n_0 ,\VGA_R[7]_i_167_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_77 
       (.CI(\VGA_R_reg[7]_i_163_n_0 ),
        .CO({sel0[5],\VGA_R_reg[7]_i_77_n_1 ,\VGA_R_reg[7]_i_77_n_2 ,\VGA_R_reg[7]_i_77_n_3 }),
        .CYINIT(1'b0),
        .DI({sel0[6],\VGA_R_reg[7]_i_71_n_6 ,\VGA_R_reg[7]_i_71_n_7 ,\VGA_R_reg[7]_i_136_n_4 }),
        .O({\NLW_VGA_R_reg[7]_i_77_O_UNCONNECTED [3],\VGA_R_reg[7]_i_77_n_5 ,\VGA_R_reg[7]_i_77_n_6 ,\VGA_R_reg[7]_i_77_n_7 }),
        .S({\VGA_R[7]_i_168_n_0 ,\VGA_R[7]_i_169_n_0 ,\VGA_R[7]_i_170_n_0 ,\VGA_R[7]_i_171_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_78 
       (.CI(\VGA_R_reg[7]_i_137_n_0 ),
        .CO({sel0[7],\VGA_R_reg[7]_i_78_n_1 ,\VGA_R_reg[7]_i_78_n_2 ,\VGA_R_reg[7]_i_78_n_3 }),
        .CYINIT(1'b0),
        .DI({sel0[8],\VGA_R_reg[7]_i_73_n_6 ,\VGA_R_reg[7]_i_73_n_7 ,\VGA_R_reg[7]_i_148_n_4 }),
        .O({\NLW_VGA_R_reg[7]_i_78_O_UNCONNECTED [3],\VGA_R_reg[7]_i_78_n_5 ,\VGA_R_reg[7]_i_78_n_6 ,\VGA_R_reg[7]_i_78_n_7 }),
        .S({\VGA_R[7]_i_172_n_0 ,\VGA_R[7]_i_173_n_0 ,\VGA_R[7]_i_174_n_0 ,\VGA_R[7]_i_175_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_86 
       (.CI(1'b0),
        .CO({\VGA_R_reg[7]_i_86_n_0 ,\VGA_R_reg[7]_i_86_n_1 ,\VGA_R_reg[7]_i_86_n_2 ,\VGA_R_reg[7]_i_86_n_3 }),
        .CYINIT(\VGA_G_reg[7]_i_6_n_0 ),
        .DI({\VGA_R_reg[7]_i_87_n_5 ,\VGA_R_reg[7]_i_87_n_6 ,\VGA_G_reg[7]_i_6_n_0 ,\VGA_R[7]_i_193_n_0 }),
        .O({\VGA_R_reg[7]_i_86_n_4 ,\VGA_R_reg[7]_i_86_n_5 ,\VGA_R_reg[7]_i_86_n_6 ,\VGA_R_reg[7]_i_86_n_7 }),
        .S({\VGA_R[7]_i_194_n_0 ,\VGA_R[7]_i_195_n_0 ,\VGA_R[7]_i_196_n_0 ,\VGA_R[7]_i_197_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_87 
       (.CI(1'b0),
        .CO({\VGA_R_reg[7]_i_87_n_0 ,\VGA_R_reg[7]_i_87_n_1 ,\VGA_R_reg[7]_i_87_n_2 ,\VGA_R_reg[7]_i_87_n_3 }),
        .CYINIT(\VGA_R_reg[7]_i_94_n_0 ),
        .DI({\VGA_G_reg[7]_i_8_n_5 ,\VGA_G_reg[7]_i_8_n_6 ,\VGA_R_reg[7]_i_94_n_0 ,\VGA_R[7]_i_198_n_0 }),
        .O({\VGA_R_reg[7]_i_87_n_4 ,\VGA_R_reg[7]_i_87_n_5 ,\VGA_R_reg[7]_i_87_n_6 ,\VGA_R_reg[7]_i_87_n_7 }),
        .S({\VGA_R[7]_i_199_n_0 ,\VGA_R[7]_i_200_n_0 ,\VGA_R[7]_i_201_n_0 ,\VGA_R[7]_i_202_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_94 
       (.CI(\VGA_G_reg[7]_i_8_n_0 ),
        .CO({\VGA_R_reg[7]_i_94_n_0 ,\VGA_R_reg[7]_i_94_n_1 ,\VGA_R_reg[7]_i_94_n_2 ,\VGA_R_reg[7]_i_94_n_3 }),
        .CYINIT(1'b0),
        .DI({\VGA_R_reg[7]_i_95_n_0 ,\VGA_R_reg[7]_i_95_n_6 ,\VGA_R_reg[7]_i_95_n_7 ,\VGA_R_reg[7]_i_211_n_4 }),
        .O({\NLW_VGA_R_reg[7]_i_94_O_UNCONNECTED [3],\VGA_R_reg[7]_i_94_n_5 ,\VGA_R_reg[7]_i_94_n_6 ,\VGA_R_reg[7]_i_94_n_7 }),
        .S({\VGA_R[7]_i_212_n_0 ,\VGA_R[7]_i_213_n_0 ,\VGA_R[7]_i_214_n_0 ,\VGA_R[7]_i_215_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_95 
       (.CI(\VGA_R_reg[7]_i_211_n_0 ),
        .CO({\VGA_R_reg[7]_i_95_n_0 ,\VGA_R_reg[7]_i_95_n_1 ,\VGA_R_reg[7]_i_95_n_2 ,\VGA_R_reg[7]_i_95_n_3 }),
        .CYINIT(1'b0),
        .DI({\VGA_R_reg[7]_i_96_n_0 ,\VGA_R_reg[7]_i_96_n_6 ,\VGA_R_reg[7]_i_96_n_7 ,\VGA_R_reg[7]_i_216_n_4 }),
        .O({\NLW_VGA_R_reg[7]_i_95_O_UNCONNECTED [3],\VGA_R_reg[7]_i_95_n_5 ,\VGA_R_reg[7]_i_95_n_6 ,\VGA_R_reg[7]_i_95_n_7 }),
        .S({\VGA_R[7]_i_217_n_0 ,\VGA_R[7]_i_218_n_0 ,\VGA_R[7]_i_219_n_0 ,\VGA_R[7]_i_220_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_96 
       (.CI(\VGA_R_reg[7]_i_216_n_0 ),
        .CO({\VGA_R_reg[7]_i_96_n_0 ,\VGA_R_reg[7]_i_96_n_1 ,\VGA_R_reg[7]_i_96_n_2 ,\VGA_R_reg[7]_i_96_n_3 }),
        .CYINIT(1'b0),
        .DI({\VGA_R_reg[7]_i_97_n_0 ,\VGA_R_reg[7]_i_97_n_6 ,\VGA_R_reg[7]_i_97_n_7 ,\VGA_R_reg[7]_i_221_n_4 }),
        .O({\NLW_VGA_R_reg[7]_i_96_O_UNCONNECTED [3],\VGA_R_reg[7]_i_96_n_5 ,\VGA_R_reg[7]_i_96_n_6 ,\VGA_R_reg[7]_i_96_n_7 }),
        .S({\VGA_R[7]_i_222_n_0 ,\VGA_R[7]_i_223_n_0 ,\VGA_R[7]_i_224_n_0 ,\VGA_R[7]_i_225_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_97 
       (.CI(\VGA_R_reg[7]_i_221_n_0 ),
        .CO({\VGA_R_reg[7]_i_97_n_0 ,\VGA_R_reg[7]_i_97_n_1 ,\VGA_R_reg[7]_i_97_n_2 ,\VGA_R_reg[7]_i_97_n_3 }),
        .CYINIT(1'b0),
        .DI({\VGA_R_reg[7]_i_98_n_0 ,\VGA_R_reg[7]_i_98_n_6 ,\VGA_R_reg[7]_i_98_n_7 ,\VGA_R_reg[7]_i_226_n_4 }),
        .O({\NLW_VGA_R_reg[7]_i_97_O_UNCONNECTED [3],\VGA_R_reg[7]_i_97_n_5 ,\VGA_R_reg[7]_i_97_n_6 ,\VGA_R_reg[7]_i_97_n_7 }),
        .S({\VGA_R[7]_i_227_n_0 ,\VGA_R[7]_i_228_n_0 ,\VGA_R[7]_i_229_n_0 ,\VGA_R[7]_i_230_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_98 
       (.CI(\VGA_R_reg[7]_i_226_n_0 ),
        .CO({\VGA_R_reg[7]_i_98_n_0 ,\VGA_R_reg[7]_i_98_n_1 ,\VGA_R_reg[7]_i_98_n_2 ,\VGA_R_reg[7]_i_98_n_3 }),
        .CYINIT(1'b0),
        .DI({\VGA_R_reg[7]_i_99_n_0 ,\VGA_R_reg[7]_i_99_n_6 ,\VGA_R_reg[7]_i_99_n_7 ,\VGA_R_reg[7]_i_231_n_4 }),
        .O({\NLW_VGA_R_reg[7]_i_98_O_UNCONNECTED [3],\VGA_R_reg[7]_i_98_n_5 ,\VGA_R_reg[7]_i_98_n_6 ,\VGA_R_reg[7]_i_98_n_7 }),
        .S({\VGA_R[7]_i_232_n_0 ,\VGA_R[7]_i_233_n_0 ,\VGA_R[7]_i_234_n_0 ,\VGA_R[7]_i_235_n_0 }));
  CARRY4 \VGA_R_reg[7]_i_99 
       (.CI(\VGA_R_reg[7]_i_231_n_0 ),
        .CO({\VGA_R_reg[7]_i_99_n_0 ,\VGA_R_reg[7]_i_99_n_1 ,\VGA_R_reg[7]_i_99_n_2 ,\VGA_R_reg[7]_i_99_n_3 }),
        .CYINIT(1'b0),
        .DI({\VGA_R_reg[7]_i_100_n_0 ,\VGA_R_reg[7]_i_100_n_6 ,\VGA_R_reg[7]_i_100_n_7 ,\VGA_R_reg[7]_i_236_n_4 }),
        .O({\NLW_VGA_R_reg[7]_i_99_O_UNCONNECTED [3],\VGA_R_reg[7]_i_99_n_5 ,\VGA_R_reg[7]_i_99_n_6 ,\VGA_R_reg[7]_i_99_n_7 }),
        .S({\VGA_R[7]_i_237_n_0 ,\VGA_R[7]_i_238_n_0 ,\VGA_R[7]_i_239_n_0 ,\VGA_R[7]_i_240_n_0 }));
  LUT6 #(
    .INIT(64'h6567777765644444)) 
    VGA_VS_i_1
       (.I0(VGA_HS_i_2_n_0),
        .I1(RST),
        .I2(VGA_VS1),
        .I3(VGA_VS0),
        .I4(VGA_HS1),
        .I5(VGA_VS),
        .O(VGA_VS_i_1_n_0));
  LUT3 #(
    .INIT(8'h02)) 
    VGA_VS_i_10
       (.I0(VCNT[3]),
        .I1(VCNT[5]),
        .I2(VCNT[4]),
        .O(VGA_VS_i_10_n_0));
  LUT5 #(
    .INIT(32'h08104100)) 
    VGA_VS_i_11
       (.I0(VCNT[0]),
        .I1(timing_sel[0]),
        .I2(timing_sel[1]),
        .I3(VCNT[2]),
        .I4(VCNT[1]),
        .O(VGA_VS_i_11_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    VGA_VS_i_4
       (.I0(VCNT[9]),
        .I1(VCNT[10]),
        .O(VGA_VS_i_4_n_0));
  LUT3 #(
    .INIT(8'h01)) 
    VGA_VS_i_5
       (.I0(VCNT[8]),
        .I1(VCNT[7]),
        .I2(VCNT[6]),
        .O(VGA_VS_i_5_n_0));
  LUT5 #(
    .INIT(32'h0000009A)) 
    VGA_VS_i_6
       (.I0(VCNT[3]),
        .I1(timing_sel[0]),
        .I2(timing_sel[1]),
        .I3(VCNT[5]),
        .I4(VCNT[4]),
        .O(VGA_VS_i_6_n_0));
  LUT5 #(
    .INIT(32'h00410820)) 
    VGA_VS_i_7
       (.I0(VCNT[0]),
        .I1(timing_sel[1]),
        .I2(timing_sel[0]),
        .I3(VCNT[2]),
        .I4(VCNT[1]),
        .O(VGA_VS_i_7_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    VGA_VS_i_8
       (.I0(VCNT[9]),
        .I1(VCNT[10]),
        .O(VGA_VS_i_8_n_0));
  LUT3 #(
    .INIT(8'h01)) 
    VGA_VS_i_9
       (.I0(VCNT[8]),
        .I1(VCNT[7]),
        .I2(VCNT[6]),
        .O(VGA_VS_i_9_n_0));
  FDRE VGA_VS_reg
       (.C(PCK),
        .CE(1'b1),
        .D(VGA_VS_i_1_n_0),
        .Q(VGA_VS),
        .R(1'b0));
  CARRY4 VGA_VS_reg_i_2
       (.CI(1'b0),
        .CO({VGA_VS1,VGA_VS_reg_i_2_n_1,VGA_VS_reg_i_2_n_2,VGA_VS_reg_i_2_n_3}),
        .CYINIT(1'b1),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(NLW_VGA_VS_reg_i_2_O_UNCONNECTED[3:0]),
        .S({VGA_VS_i_4_n_0,VGA_VS_i_5_n_0,VGA_VS_i_6_n_0,VGA_VS_i_7_n_0}));
  CARRY4 VGA_VS_reg_i_3
       (.CI(1'b0),
        .CO({VGA_VS0,VGA_VS_reg_i_3_n_1,VGA_VS_reg_i_3_n_2,VGA_VS_reg_i_3_n_3}),
        .CYINIT(1'b1),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(NLW_VGA_VS_reg_i_3_O_UNCONNECTED[3:0]),
        .S({VGA_VS_i_8_n_0,VGA_VS_i_9_n_0,VGA_VS_i_10_n_0,VGA_VS_i_11_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 pattern_b1__0_i_1
       (.CI(pattern_b1__0_i_2_n_0),
        .CO({NLW_pattern_b1__0_i_1_CO_UNCONNECTED[3:2],pattern_b1__0_i_1_n_2,pattern_b1__0_i_1_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,VCNT[9:8]}),
        .O({NLW_pattern_b1__0_i_1_O_UNCONNECTED[3],A[10:8]}),
        .S({1'b0,pattern_b1__0_i_4_n_0,pattern_b1__0_i_5_n_0,pattern_b1__0_i_6_n_0}));
  LUT2 #(
    .INIT(4'h9)) 
    pattern_b1__0_i_10
       (.I0(VCNT[4]),
        .I1(zp_sum),
        .O(pattern_b1__0_i_10_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    pattern_b1__0_i_11
       (.I0(zp_sum),
        .I1(VCNT[1]),
        .O(pattern_b1__0_i_11_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    pattern_b1__0_i_12
       (.I0(VCNT[0]),
        .I1(zp_sum),
        .O(pattern_b1__0_i_12_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 pattern_b1__0_i_2
       (.CI(pattern_b1__0_i_3_n_0),
        .CO({pattern_b1__0_i_2_n_0,pattern_b1__0_i_2_n_1,pattern_b1__0_i_2_n_2,pattern_b1__0_i_2_n_3}),
        .CYINIT(1'b0),
        .DI(VCNT[7:4]),
        .O(A[7:4]),
        .S({pattern_b1__0_i_7_n_0,pattern_b1__0_i_8_n_0,pattern_b1__0_i_9_n_0,pattern_b1__0_i_10_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 pattern_b1__0_i_3
       (.CI(1'b0),
        .CO({pattern_b1__0_i_3_n_0,pattern_b1__0_i_3_n_1,pattern_b1__0_i_3_n_2,pattern_b1__0_i_3_n_3}),
        .CYINIT(1'b1),
        .DI(VCNT[3:0]),
        .O(A[3:0]),
        .S({VCNT[3:2],pattern_b1__0_i_11_n_0,pattern_b1__0_i_12_n_0}));
  LUT1 #(
    .INIT(2'h1)) 
    pattern_b1__0_i_4
       (.I0(VCNT[10]),
        .O(pattern_b1__0_i_4_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    pattern_b1__0_i_5
       (.I0(VCNT[9]),
        .O(pattern_b1__0_i_5_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    pattern_b1__0_i_6
       (.I0(VCNT[8]),
        .O(pattern_b1__0_i_6_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    pattern_b1__0_i_7
       (.I0(VCNT[7]),
        .O(pattern_b1__0_i_7_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    pattern_b1__0_i_8
       (.I0(VCNT[6]),
        .O(pattern_b1__0_i_8_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    pattern_b1__0_i_9
       (.I0(VCNT[5]),
        .I1(zp_sum),
        .O(pattern_b1__0_i_9_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 pattern_b1_i_1
       (.CI(pattern_b1_i_2_n_0),
        .CO({NLW_pattern_b1_i_1_CO_UNCONNECTED[3:1],pattern_b1_i_1_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,pattern_b1_i_4_n_0}),
        .O({NLW_pattern_b1_i_1_O_UNCONNECTED[3:2],p_1_in[10:9]}),
        .S({1'b0,1'b0,pattern_b1_i_5_n_0,pattern_b1_i_6_n_0}));
  LUT2 #(
    .INIT(4'h2)) 
    pattern_b1_i_10
       (.I0(HCNT[4]),
        .I1(zp_sum0_0),
        .O(pattern_b1_i_10_n_0));
  LUT4 #(
    .INIT(16'hB44B)) 
    pattern_b1_i_11
       (.I0(zp_sum0[2]),
        .I1(HCNT[7]),
        .I2(CO),
        .I3(HCNT[8]),
        .O(pattern_b1_i_11_n_0));
  LUT4 #(
    .INIT(16'hB44B)) 
    pattern_b1_i_12
       (.I0(zp_sum0[1]),
        .I1(HCNT[6]),
        .I2(zp_sum0[2]),
        .I3(HCNT[7]),
        .O(pattern_b1_i_12_n_0));
  LUT4 #(
    .INIT(16'hB44B)) 
    pattern_b1_i_13
       (.I0(zp_sum0[0]),
        .I1(HCNT[5]),
        .I2(zp_sum0[1]),
        .I3(HCNT[6]),
        .O(pattern_b1_i_13_n_0));
  LUT4 #(
    .INIT(16'hB44B)) 
    pattern_b1_i_14
       (.I0(zp_sum0_0),
        .I1(HCNT[4]),
        .I2(zp_sum0[0]),
        .I3(HCNT[5]),
        .O(pattern_b1_i_14_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    pattern_b1_i_15
       (.I0(HCNT[3]),
        .I1(O[2]),
        .O(pattern_b1_i_15_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    pattern_b1_i_16
       (.I0(HCNT[2]),
        .I1(O[1]),
        .O(pattern_b1_i_16_n_0));
  LUT4 #(
    .INIT(16'hB44B)) 
    pattern_b1_i_19
       (.I0(O[2]),
        .I1(HCNT[3]),
        .I2(zp_sum0_0),
        .I3(HCNT[4]),
        .O(pattern_b1_i_19_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 pattern_b1_i_2
       (.CI(pattern_b1_i_3_n_0),
        .CO({pattern_b1_i_2_n_0,pattern_b1_i_2_n_1,pattern_b1_i_2_n_2,pattern_b1_i_2_n_3}),
        .CYINIT(1'b0),
        .DI({pattern_b1_i_7_n_0,pattern_b1_i_8_n_0,pattern_b1_i_9_n_0,pattern_b1_i_10_n_0}),
        .O(p_1_in[8:5]),
        .S({pattern_b1_i_11_n_0,pattern_b1_i_12_n_0,pattern_b1_i_13_n_0,pattern_b1_i_14_n_0}));
  LUT4 #(
    .INIT(16'hB44B)) 
    pattern_b1_i_20
       (.I0(O[1]),
        .I1(HCNT[2]),
        .I2(O[2]),
        .I3(HCNT[3]),
        .O(pattern_b1_i_20_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    pattern_b1_i_21
       (.I0(O[0]),
        .I1(O[1]),
        .I2(HCNT[2]),
        .O(pattern_b1_i_21_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    pattern_b1_i_22
       (.I0(O[0]),
        .I1(HCNT[1]),
        .O(pattern_b1_i_22_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 pattern_b1_i_3
       (.CI(1'b0),
        .CO({pattern_b1_i_3_n_0,pattern_b1_i_3_n_1,pattern_b1_i_3_n_2,pattern_b1_i_3_n_3}),
        .CYINIT(HCNT[0]),
        .DI({pattern_b1_i_15_n_0,pattern_b1_i_16_n_0,DI,O[0]}),
        .O(p_1_in[4:1]),
        .S({pattern_b1_i_19_n_0,pattern_b1_i_20_n_0,pattern_b1_i_21_n_0,pattern_b1_i_22_n_0}));
  LUT1 #(
    .INIT(2'h1)) 
    pattern_b1_i_4
       (.I0(HCNT[9]),
        .O(pattern_b1_i_4_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    pattern_b1_i_5
       (.I0(HCNT[9]),
        .I1(HCNT[10]),
        .O(pattern_b1_i_5_n_0));
  LUT3 #(
    .INIT(8'h4B)) 
    pattern_b1_i_6
       (.I0(CO),
        .I1(HCNT[8]),
        .I2(HCNT[9]),
        .O(pattern_b1_i_6_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    pattern_b1_i_7
       (.I0(HCNT[7]),
        .I1(zp_sum0[2]),
        .O(pattern_b1_i_7_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    pattern_b1_i_8
       (.I0(HCNT[6]),
        .I1(zp_sum0[1]),
        .O(pattern_b1_i_8_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    pattern_b1_i_9
       (.I0(HCNT[5]),
        .I1(zp_sum0[0]),
        .O(pattern_b1_i_9_n_0));
  system_pattern_multi_0_0_pckgen_triple pckgen_triple
       (.CLK(CLK),
        .PCK(PCK),
        .SerialClk(SerialClk),
        .locked(locked),
        .reconfig_done(reconfig_done),
        .reconfig_req(reconfig_req),
        .timing_sel_imm(timing_sel_imm));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
