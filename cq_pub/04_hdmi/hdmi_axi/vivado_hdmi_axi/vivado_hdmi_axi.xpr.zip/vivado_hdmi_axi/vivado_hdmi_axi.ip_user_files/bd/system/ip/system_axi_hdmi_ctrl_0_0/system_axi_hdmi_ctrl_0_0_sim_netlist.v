// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2024.2.2 (lin64) Build 6060944 Thu Mar 06 19:10:09 MST 2025
// Date        : Sun May 10 11:26:34 2026
// Host        : firebat running 64-bit Ubuntu 24.04.4 LTS
// Command     : write_verilog -force -mode funcsim
//               /home/tomorrow56/ws/vivado/hdmi_axi_test/vivado_hdmi_axi_720p_mod/vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ip/system_axi_hdmi_ctrl_0_0/system_axi_hdmi_ctrl_0_0_sim_netlist.v
// Design      : system_axi_hdmi_ctrl_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7z010clg400-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "system_axi_hdmi_ctrl_0_0,axi_hdmi_ctrl,{}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* IP_DEFINITION_SOURCE = "module_ref" *) 
(* X_CORE_INFO = "axi_hdmi_ctrl,Vivado 2024.2.2" *) 
(* NotValidForBitStream *)
module system_axi_hdmi_ctrl_0_0
   (S_AXI_ACLK,
    S_AXI_ARESETN,
    S_AXI_AWADDR,
    S_AXI_AWPROT,
    S_AXI_AWVALID,
    S_AXI_AWREADY,
    S_AXI_WDATA,
    S_AXI_WSTRB,
    S_AXI_WVALID,
    S_AXI_WREADY,
    S_AXI_BRESP,
    S_AXI_BVALID,
    S_AXI_BREADY,
    S_AXI_ARADDR,
    S_AXI_ARPROT,
    S_AXI_ARVALID,
    S_AXI_ARREADY,
    S_AXI_RDATA,
    S_AXI_RRESP,
    S_AXI_RVALID,
    S_AXI_RREADY,
    PCK,
    VGA_VS,
    locked,
    reconfig_done,
    timing_sel_sync,
    pattern_sel_sync,
    reconfig_req,
    timing_sel_imm);
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 S_AXI_ACLK CLK" *) (* X_INTERFACE_MODE = "slave" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME S_AXI_ACLK, ASSOCIATED_BUSIF S_AXI, ASSOCIATED_RESET S_AXI_ARESETN, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN system_processing_system7_0_0_FCLK_CLK0, INSERT_VIP 0" *) input S_AXI_ACLK;
  (* X_INTERFACE_INFO = "xilinx.com:signal:reset:1.0 S_AXI_ARESETN RST" *) (* X_INTERFACE_MODE = "slave" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME S_AXI_ARESETN, POLARITY ACTIVE_LOW, INSERT_VIP 0" *) input S_AXI_ARESETN;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI AWADDR" *) (* X_INTERFACE_MODE = "slave" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME S_AXI, DATA_WIDTH 32, PROTOCOL AXI4LITE, FREQ_HZ 100000000, ID_WIDTH 0, ADDR_WIDTH 4, AWUSER_WIDTH 0, ARUSER_WIDTH 0, WUSER_WIDTH 0, RUSER_WIDTH 0, BUSER_WIDTH 0, READ_WRITE_MODE READ_WRITE, HAS_BURST 0, HAS_LOCK 0, HAS_PROT 1, HAS_CACHE 0, HAS_QOS 0, HAS_REGION 0, HAS_WSTRB 1, HAS_BRESP 1, HAS_RRESP 1, SUPPORTS_NARROW_BURST 0, NUM_READ_OUTSTANDING 1, NUM_WRITE_OUTSTANDING 1, MAX_BURST_LENGTH 1, PHASE 0.0, CLK_DOMAIN system_processing_system7_0_0_FCLK_CLK0, NUM_READ_THREADS 1, NUM_WRITE_THREADS 1, RUSER_BITS_PER_BYTE 0, WUSER_BITS_PER_BYTE 0, INSERT_VIP 0" *) input [3:0]S_AXI_AWADDR;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI AWPROT" *) input [2:0]S_AXI_AWPROT;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI AWVALID" *) input S_AXI_AWVALID;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI AWREADY" *) output S_AXI_AWREADY;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI WDATA" *) input [31:0]S_AXI_WDATA;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI WSTRB" *) input [3:0]S_AXI_WSTRB;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI WVALID" *) input S_AXI_WVALID;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI WREADY" *) output S_AXI_WREADY;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI BRESP" *) output [1:0]S_AXI_BRESP;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI BVALID" *) output S_AXI_BVALID;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI BREADY" *) input S_AXI_BREADY;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI ARADDR" *) input [3:0]S_AXI_ARADDR;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI ARPROT" *) input [2:0]S_AXI_ARPROT;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI ARVALID" *) input S_AXI_ARVALID;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI ARREADY" *) output S_AXI_ARREADY;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI RDATA" *) output [31:0]S_AXI_RDATA;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI RRESP" *) output [1:0]S_AXI_RRESP;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI RVALID" *) output S_AXI_RVALID;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S_AXI RREADY" *) input S_AXI_RREADY;
  input PCK;
  input VGA_VS;
  input locked;
  input reconfig_done;
  output [1:0]timing_sel_sync;
  output [3:0]pattern_sel_sync;
  output reconfig_req;
  output [1:0]timing_sel_imm;

  wire \<const0> ;
  wire PCK;
  wire S_AXI_ACLK;
  wire [3:0]S_AXI_ARADDR;
  wire S_AXI_ARESETN;
  wire S_AXI_ARREADY;
  wire S_AXI_ARVALID;
  wire [3:0]S_AXI_AWADDR;
  wire S_AXI_AWREADY;
  wire S_AXI_AWVALID;
  wire S_AXI_BREADY;
  wire S_AXI_BVALID;
  wire [5:0]\^S_AXI_RDATA ;
  wire S_AXI_RREADY;
  wire S_AXI_RVALID;
  wire [31:0]S_AXI_WDATA;
  wire S_AXI_WREADY;
  wire [3:0]S_AXI_WSTRB;
  wire S_AXI_WVALID;
  wire VGA_VS;
  wire locked;
  wire [3:0]pattern_sel_sync;
  wire reconfig_done;
  wire reconfig_req;
  wire [1:0]timing_sel_imm;
  wire [1:0]timing_sel_sync;

  assign S_AXI_BRESP[1] = \<const0> ;
  assign S_AXI_BRESP[0] = \<const0> ;
  assign S_AXI_RDATA[31] = \<const0> ;
  assign S_AXI_RDATA[30] = \<const0> ;
  assign S_AXI_RDATA[29] = \<const0> ;
  assign S_AXI_RDATA[28] = \<const0> ;
  assign S_AXI_RDATA[27] = \<const0> ;
  assign S_AXI_RDATA[26] = \<const0> ;
  assign S_AXI_RDATA[25] = \<const0> ;
  assign S_AXI_RDATA[24] = \<const0> ;
  assign S_AXI_RDATA[23] = \<const0> ;
  assign S_AXI_RDATA[22] = \<const0> ;
  assign S_AXI_RDATA[21] = \<const0> ;
  assign S_AXI_RDATA[20] = \<const0> ;
  assign S_AXI_RDATA[19] = \<const0> ;
  assign S_AXI_RDATA[18] = \<const0> ;
  assign S_AXI_RDATA[17] = \<const0> ;
  assign S_AXI_RDATA[16] = \<const0> ;
  assign S_AXI_RDATA[15] = \<const0> ;
  assign S_AXI_RDATA[14] = \<const0> ;
  assign S_AXI_RDATA[13] = \<const0> ;
  assign S_AXI_RDATA[12] = \<const0> ;
  assign S_AXI_RDATA[11] = \<const0> ;
  assign S_AXI_RDATA[10] = \<const0> ;
  assign S_AXI_RDATA[9] = \<const0> ;
  assign S_AXI_RDATA[8] = \<const0> ;
  assign S_AXI_RDATA[7] = \<const0> ;
  assign S_AXI_RDATA[6] = \<const0> ;
  assign S_AXI_RDATA[5:0] = \^S_AXI_RDATA [5:0];
  assign S_AXI_RRESP[1] = \<const0> ;
  assign S_AXI_RRESP[0] = \<const0> ;
  GND GND
       (.G(\<const0> ));
  system_axi_hdmi_ctrl_0_0_axi_hdmi_ctrl inst
       (.PCK(PCK),
        .Q(timing_sel_imm),
        .S_AXI_ACLK(S_AXI_ACLK),
        .S_AXI_ARADDR(S_AXI_ARADDR[3:2]),
        .S_AXI_ARESETN(S_AXI_ARESETN),
        .S_AXI_ARREADY(S_AXI_ARREADY),
        .S_AXI_ARVALID(S_AXI_ARVALID),
        .S_AXI_AWADDR(S_AXI_AWADDR[3:2]),
        .S_AXI_AWREADY(S_AXI_AWREADY),
        .S_AXI_AWVALID(S_AXI_AWVALID),
        .S_AXI_BREADY(S_AXI_BREADY),
        .S_AXI_BVALID(S_AXI_BVALID),
        .S_AXI_RDATA(\^S_AXI_RDATA ),
        .S_AXI_RREADY(S_AXI_RREADY),
        .S_AXI_WDATA(S_AXI_WDATA[5:0]),
        .S_AXI_WREADY(S_AXI_WREADY),
        .S_AXI_WSTRB(S_AXI_WSTRB[0]),
        .S_AXI_WVALID(S_AXI_WVALID),
        .VGA_VS(VGA_VS),
        .axi_rvalid_reg_0(S_AXI_RVALID),
        .locked(locked),
        .pattern_sel_sync(pattern_sel_sync),
        .reconfig_done(reconfig_done),
        .reconfig_req(reconfig_req),
        .timing_sel_sync(timing_sel_sync));
endmodule

(* ORIG_REF_NAME = "axi_hdmi_ctrl" *) 
module system_axi_hdmi_ctrl_0_0_axi_hdmi_ctrl
   (S_AXI_AWREADY,
    S_AXI_WREADY,
    S_AXI_ARREADY,
    Q,
    S_AXI_RDATA,
    axi_rvalid_reg_0,
    timing_sel_sync,
    pattern_sel_sync,
    reconfig_req,
    S_AXI_BVALID,
    S_AXI_ACLK,
    S_AXI_AWADDR,
    S_AXI_AWVALID,
    S_AXI_WVALID,
    S_AXI_WDATA,
    S_AXI_ARADDR,
    S_AXI_ARVALID,
    S_AXI_ARESETN,
    VGA_VS,
    PCK,
    S_AXI_WSTRB,
    reconfig_done,
    locked,
    S_AXI_BREADY,
    S_AXI_RREADY);
  output S_AXI_AWREADY;
  output S_AXI_WREADY;
  output S_AXI_ARREADY;
  output [1:0]Q;
  output [5:0]S_AXI_RDATA;
  output axi_rvalid_reg_0;
  output [1:0]timing_sel_sync;
  output [3:0]pattern_sel_sync;
  output reconfig_req;
  output S_AXI_BVALID;
  input S_AXI_ACLK;
  input [1:0]S_AXI_AWADDR;
  input S_AXI_AWVALID;
  input S_AXI_WVALID;
  input [5:0]S_AXI_WDATA;
  input [1:0]S_AXI_ARADDR;
  input S_AXI_ARVALID;
  input S_AXI_ARESETN;
  input VGA_VS;
  input PCK;
  input [0:0]S_AXI_WSTRB;
  input reconfig_done;
  input locked;
  input S_AXI_BREADY;
  input S_AXI_RREADY;

  wire PCK;
  wire [1:0]Q;
  wire S_AXI_ACLK;
  wire [1:0]S_AXI_ARADDR;
  wire S_AXI_ARESETN;
  wire S_AXI_ARREADY;
  wire S_AXI_ARVALID;
  wire [1:0]S_AXI_AWADDR;
  wire S_AXI_AWREADY;
  wire S_AXI_AWVALID;
  wire S_AXI_BREADY;
  wire S_AXI_BVALID;
  wire [5:0]S_AXI_RDATA;
  wire S_AXI_RREADY;
  wire [5:0]S_AXI_WDATA;
  wire S_AXI_WREADY;
  wire [0:0]S_AXI_WSTRB;
  wire S_AXI_WVALID;
  wire VGA_VS;
  wire [3:2]axi_araddr;
  wire \axi_araddr[2]_i_1_n_0 ;
  wire \axi_araddr[3]_i_1_n_0 ;
  wire axi_arready0;
  wire [3:2]axi_awaddr;
  wire \axi_awaddr[2]_i_1_n_0 ;
  wire \axi_awaddr[3]_i_1_n_0 ;
  wire axi_awready0;
  wire axi_bvalid_i_1_n_0;
  wire axi_rdata;
  wire \axi_rdata[0]_i_1_n_0 ;
  wire \axi_rdata[1]_i_1_n_0 ;
  wire \axi_rdata[2]_i_1_n_0 ;
  wire \axi_rdata[3]_i_1_n_0 ;
  wire \axi_rdata[4]_i_1_n_0 ;
  wire \axi_rdata[5]_i_1_n_0 ;
  wire \axi_rdata[5]_i_3_n_0 ;
  wire axi_rvalid_i_1_n_0;
  wire axi_rvalid_reg_0;
  wire axi_wready0;
  wire locked;
  wire p_0_in;
  wire p_1_in;
  wire [3:0]pattern_sel_meta;
  wire [3:0]pattern_sel_reg;
  wire [3:0]pattern_sel_sync;
  wire [3:0]pattern_sel_sync_ff;
  wire reconfig_busy;
  wire reconfig_busy_i_1_n_0;
  wire reconfig_done;
  wire reconfig_req;
  wire [1:0]timing_sel_meta;
  wire [1:0]timing_sel_prev;
  wire timing_sel_reg;
  wire \timing_sel_reg[1]_i_2_n_0 ;
  wire [1:0]timing_sel_sync;
  wire timing_sel_sync0;
  wire [1:0]timing_sel_sync_ff;
  wire vsync_prev;

  LUT4 #(
    .INIT(16'hFB08)) 
    \axi_araddr[2]_i_1 
       (.I0(S_AXI_ARADDR[0]),
        .I1(S_AXI_ARVALID),
        .I2(S_AXI_ARREADY),
        .I3(axi_araddr[2]),
        .O(\axi_araddr[2]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT4 #(
    .INIT(16'hFB08)) 
    \axi_araddr[3]_i_1 
       (.I0(S_AXI_ARADDR[1]),
        .I1(S_AXI_ARVALID),
        .I2(S_AXI_ARREADY),
        .I3(axi_araddr[3]),
        .O(\axi_araddr[3]_i_1_n_0 ));
  FDRE \axi_araddr_reg[2] 
       (.C(S_AXI_ACLK),
        .CE(1'b1),
        .D(\axi_araddr[2]_i_1_n_0 ),
        .Q(axi_araddr[2]),
        .R(p_0_in));
  FDRE \axi_araddr_reg[3] 
       (.C(S_AXI_ACLK),
        .CE(1'b1),
        .D(\axi_araddr[3]_i_1_n_0 ),
        .Q(axi_araddr[3]),
        .R(p_0_in));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT2 #(
    .INIT(4'h2)) 
    axi_arready_i_1
       (.I0(S_AXI_ARVALID),
        .I1(S_AXI_ARREADY),
        .O(axi_arready0));
  FDRE axi_arready_reg
       (.C(S_AXI_ACLK),
        .CE(1'b1),
        .D(axi_arready0),
        .Q(S_AXI_ARREADY),
        .R(p_0_in));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT5 #(
    .INIT(32'hFFBF0080)) 
    \axi_awaddr[2]_i_1 
       (.I0(S_AXI_AWADDR[0]),
        .I1(S_AXI_AWVALID),
        .I2(S_AXI_WVALID),
        .I3(S_AXI_AWREADY),
        .I4(axi_awaddr[2]),
        .O(\axi_awaddr[2]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'hFFBF0080)) 
    \axi_awaddr[3]_i_1 
       (.I0(S_AXI_AWADDR[1]),
        .I1(S_AXI_AWVALID),
        .I2(S_AXI_WVALID),
        .I3(S_AXI_AWREADY),
        .I4(axi_awaddr[3]),
        .O(\axi_awaddr[3]_i_1_n_0 ));
  FDRE \axi_awaddr_reg[2] 
       (.C(S_AXI_ACLK),
        .CE(1'b1),
        .D(\axi_awaddr[2]_i_1_n_0 ),
        .Q(axi_awaddr[2]),
        .R(p_0_in));
  FDRE \axi_awaddr_reg[3] 
       (.C(S_AXI_ACLK),
        .CE(1'b1),
        .D(\axi_awaddr[3]_i_1_n_0 ),
        .Q(axi_awaddr[3]),
        .R(p_0_in));
  LUT1 #(
    .INIT(2'h1)) 
    axi_awready_i_1
       (.I0(S_AXI_ARESETN),
        .O(p_0_in));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT3 #(
    .INIT(8'h08)) 
    axi_awready_i_2
       (.I0(S_AXI_AWVALID),
        .I1(S_AXI_WVALID),
        .I2(S_AXI_AWREADY),
        .O(axi_awready0));
  FDRE axi_awready_reg
       (.C(S_AXI_ACLK),
        .CE(1'b1),
        .D(axi_awready0),
        .Q(S_AXI_AWREADY),
        .R(p_0_in));
  LUT6 #(
    .INIT(64'h0000FFFF80008000)) 
    axi_bvalid_i_1
       (.I0(S_AXI_AWVALID),
        .I1(S_AXI_WVALID),
        .I2(S_AXI_WREADY),
        .I3(S_AXI_AWREADY),
        .I4(S_AXI_BREADY),
        .I5(S_AXI_BVALID),
        .O(axi_bvalid_i_1_n_0));
  FDRE axi_bvalid_reg
       (.C(S_AXI_ACLK),
        .CE(1'b1),
        .D(axi_bvalid_i_1_n_0),
        .Q(S_AXI_BVALID),
        .R(p_0_in));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \axi_rdata[0]_i_1 
       (.I0(locked),
        .I1(axi_araddr[2]),
        .I2(Q[0]),
        .O(\axi_rdata[0]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \axi_rdata[1]_i_1 
       (.I0(reconfig_busy),
        .I1(axi_araddr[2]),
        .I2(Q[1]),
        .O(\axi_rdata[1]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \axi_rdata[2]_i_1 
       (.I0(pattern_sel_reg[0]),
        .I1(axi_araddr[2]),
        .O(\axi_rdata[2]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \axi_rdata[3]_i_1 
       (.I0(pattern_sel_reg[1]),
        .I1(axi_araddr[2]),
        .O(\axi_rdata[3]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \axi_rdata[4]_i_1 
       (.I0(pattern_sel_reg[2]),
        .I1(axi_araddr[2]),
        .O(\axi_rdata[4]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'h08000000)) 
    \axi_rdata[5]_i_1 
       (.I0(axi_araddr[3]),
        .I1(S_AXI_ARVALID),
        .I2(axi_rvalid_reg_0),
        .I3(S_AXI_ARREADY),
        .I4(S_AXI_ARESETN),
        .O(\axi_rdata[5]_i_1_n_0 ));
  LUT4 #(
    .INIT(16'h0800)) 
    \axi_rdata[5]_i_2 
       (.I0(S_AXI_ARESETN),
        .I1(S_AXI_ARREADY),
        .I2(axi_rvalid_reg_0),
        .I3(S_AXI_ARVALID),
        .O(axi_rdata));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \axi_rdata[5]_i_3 
       (.I0(pattern_sel_reg[3]),
        .I1(axi_araddr[2]),
        .O(\axi_rdata[5]_i_3_n_0 ));
  FDRE \axi_rdata_reg[0] 
       (.C(S_AXI_ACLK),
        .CE(axi_rdata),
        .D(\axi_rdata[0]_i_1_n_0 ),
        .Q(S_AXI_RDATA[0]),
        .R(\axi_rdata[5]_i_1_n_0 ));
  FDRE \axi_rdata_reg[1] 
       (.C(S_AXI_ACLK),
        .CE(axi_rdata),
        .D(\axi_rdata[1]_i_1_n_0 ),
        .Q(S_AXI_RDATA[1]),
        .R(\axi_rdata[5]_i_1_n_0 ));
  FDRE \axi_rdata_reg[2] 
       (.C(S_AXI_ACLK),
        .CE(axi_rdata),
        .D(\axi_rdata[2]_i_1_n_0 ),
        .Q(S_AXI_RDATA[2]),
        .R(\axi_rdata[5]_i_1_n_0 ));
  FDRE \axi_rdata_reg[3] 
       (.C(S_AXI_ACLK),
        .CE(axi_rdata),
        .D(\axi_rdata[3]_i_1_n_0 ),
        .Q(S_AXI_RDATA[3]),
        .R(\axi_rdata[5]_i_1_n_0 ));
  FDRE \axi_rdata_reg[4] 
       (.C(S_AXI_ACLK),
        .CE(axi_rdata),
        .D(\axi_rdata[4]_i_1_n_0 ),
        .Q(S_AXI_RDATA[4]),
        .R(\axi_rdata[5]_i_1_n_0 ));
  FDRE \axi_rdata_reg[5] 
       (.C(S_AXI_ACLK),
        .CE(axi_rdata),
        .D(\axi_rdata[5]_i_3_n_0 ),
        .Q(S_AXI_RDATA[5]),
        .R(\axi_rdata[5]_i_1_n_0 ));
  LUT4 #(
    .INIT(16'h08F8)) 
    axi_rvalid_i_1
       (.I0(S_AXI_ARREADY),
        .I1(S_AXI_ARVALID),
        .I2(axi_rvalid_reg_0),
        .I3(S_AXI_RREADY),
        .O(axi_rvalid_i_1_n_0));
  FDRE axi_rvalid_reg
       (.C(S_AXI_ACLK),
        .CE(1'b1),
        .D(axi_rvalid_i_1_n_0),
        .Q(axi_rvalid_reg_0),
        .R(p_0_in));
  LUT3 #(
    .INIT(8'h08)) 
    axi_wready_i_1
       (.I0(S_AXI_AWVALID),
        .I1(S_AXI_WVALID),
        .I2(S_AXI_WREADY),
        .O(axi_wready0));
  FDRE axi_wready_reg
       (.C(S_AXI_ACLK),
        .CE(1'b1),
        .D(axi_wready0),
        .Q(S_AXI_WREADY),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \pattern_sel_meta_reg[0] 
       (.C(PCK),
        .CE(1'b1),
        .D(pattern_sel_reg[0]),
        .Q(pattern_sel_meta[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pattern_sel_meta_reg[1] 
       (.C(PCK),
        .CE(1'b1),
        .D(pattern_sel_reg[1]),
        .Q(pattern_sel_meta[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pattern_sel_meta_reg[2] 
       (.C(PCK),
        .CE(1'b1),
        .D(pattern_sel_reg[2]),
        .Q(pattern_sel_meta[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pattern_sel_meta_reg[3] 
       (.C(PCK),
        .CE(1'b1),
        .D(pattern_sel_reg[3]),
        .Q(pattern_sel_meta[3]),
        .R(1'b0));
  FDRE \pattern_sel_reg_reg[0] 
       (.C(S_AXI_ACLK),
        .CE(timing_sel_reg),
        .D(S_AXI_WDATA[2]),
        .Q(pattern_sel_reg[0]),
        .R(p_0_in));
  FDRE \pattern_sel_reg_reg[1] 
       (.C(S_AXI_ACLK),
        .CE(timing_sel_reg),
        .D(S_AXI_WDATA[3]),
        .Q(pattern_sel_reg[1]),
        .R(p_0_in));
  FDRE \pattern_sel_reg_reg[2] 
       (.C(S_AXI_ACLK),
        .CE(timing_sel_reg),
        .D(S_AXI_WDATA[4]),
        .Q(pattern_sel_reg[2]),
        .R(p_0_in));
  FDRE \pattern_sel_reg_reg[3] 
       (.C(S_AXI_ACLK),
        .CE(timing_sel_reg),
        .D(S_AXI_WDATA[5]),
        .Q(pattern_sel_reg[3]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \pattern_sel_sync_ff_reg[0] 
       (.C(PCK),
        .CE(1'b1),
        .D(pattern_sel_meta[0]),
        .Q(pattern_sel_sync_ff[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pattern_sel_sync_ff_reg[1] 
       (.C(PCK),
        .CE(1'b1),
        .D(pattern_sel_meta[1]),
        .Q(pattern_sel_sync_ff[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pattern_sel_sync_ff_reg[2] 
       (.C(PCK),
        .CE(1'b1),
        .D(pattern_sel_meta[2]),
        .Q(pattern_sel_sync_ff[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pattern_sel_sync_ff_reg[3] 
       (.C(PCK),
        .CE(1'b1),
        .D(pattern_sel_meta[3]),
        .Q(pattern_sel_sync_ff[3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pattern_sel_sync_reg[0] 
       (.C(PCK),
        .CE(timing_sel_sync0),
        .D(pattern_sel_sync_ff[0]),
        .Q(pattern_sel_sync[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pattern_sel_sync_reg[1] 
       (.C(PCK),
        .CE(timing_sel_sync0),
        .D(pattern_sel_sync_ff[1]),
        .Q(pattern_sel_sync[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pattern_sel_sync_reg[2] 
       (.C(PCK),
        .CE(timing_sel_sync0),
        .D(pattern_sel_sync_ff[2]),
        .Q(pattern_sel_sync[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pattern_sel_sync_reg[3] 
       (.C(PCK),
        .CE(timing_sel_sync0),
        .D(pattern_sel_sync_ff[3]),
        .Q(pattern_sel_sync[3]),
        .R(1'b0));
  LUT4 #(
    .INIT(16'h00E0)) 
    reconfig_busy_i_1
       (.I0(reconfig_busy),
        .I1(p_1_in),
        .I2(S_AXI_ARESETN),
        .I3(reconfig_done),
        .O(reconfig_busy_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    reconfig_busy_reg
       (.C(S_AXI_ACLK),
        .CE(1'b1),
        .D(reconfig_busy_i_1_n_0),
        .Q(reconfig_busy),
        .R(1'b0));
  LUT4 #(
    .INIT(16'h6FF6)) 
    reconfig_req0
       (.I0(Q[0]),
        .I1(timing_sel_prev[0]),
        .I2(Q[1]),
        .I3(timing_sel_prev[1]),
        .O(p_1_in));
  FDRE reconfig_req_reg
       (.C(S_AXI_ACLK),
        .CE(1'b1),
        .D(p_1_in),
        .Q(reconfig_req),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \timing_sel_meta_reg[0] 
       (.C(PCK),
        .CE(1'b1),
        .D(Q[0]),
        .Q(timing_sel_meta[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \timing_sel_meta_reg[1] 
       (.C(PCK),
        .CE(1'b1),
        .D(Q[1]),
        .Q(timing_sel_meta[1]),
        .R(1'b0));
  FDRE \timing_sel_prev_reg[0] 
       (.C(S_AXI_ACLK),
        .CE(1'b1),
        .D(Q[0]),
        .Q(timing_sel_prev[0]),
        .R(p_0_in));
  FDRE \timing_sel_prev_reg[1] 
       (.C(S_AXI_ACLK),
        .CE(1'b1),
        .D(Q[1]),
        .Q(timing_sel_prev[1]),
        .R(p_0_in));
  LUT6 #(
    .INIT(64'h0000008000000000)) 
    \timing_sel_reg[1]_i_1 
       (.I0(S_AXI_AWREADY),
        .I1(S_AXI_WREADY),
        .I2(\timing_sel_reg[1]_i_2_n_0 ),
        .I3(axi_awaddr[3]),
        .I4(axi_awaddr[2]),
        .I5(S_AXI_WSTRB),
        .O(timing_sel_reg));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \timing_sel_reg[1]_i_2 
       (.I0(S_AXI_WVALID),
        .I1(S_AXI_AWVALID),
        .O(\timing_sel_reg[1]_i_2_n_0 ));
  FDRE \timing_sel_reg_reg[0] 
       (.C(S_AXI_ACLK),
        .CE(timing_sel_reg),
        .D(S_AXI_WDATA[0]),
        .Q(Q[0]),
        .R(p_0_in));
  FDRE \timing_sel_reg_reg[1] 
       (.C(S_AXI_ACLK),
        .CE(timing_sel_reg),
        .D(S_AXI_WDATA[1]),
        .Q(Q[1]),
        .R(p_0_in));
  LUT2 #(
    .INIT(4'h2)) 
    \timing_sel_sync[1]_i_1 
       (.I0(VGA_VS),
        .I1(vsync_prev),
        .O(timing_sel_sync0));
  FDRE #(
    .INIT(1'b0)) 
    \timing_sel_sync_ff_reg[0] 
       (.C(PCK),
        .CE(1'b1),
        .D(timing_sel_meta[0]),
        .Q(timing_sel_sync_ff[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \timing_sel_sync_ff_reg[1] 
       (.C(PCK),
        .CE(1'b1),
        .D(timing_sel_meta[1]),
        .Q(timing_sel_sync_ff[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \timing_sel_sync_reg[0] 
       (.C(PCK),
        .CE(timing_sel_sync0),
        .D(timing_sel_sync_ff[0]),
        .Q(timing_sel_sync[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \timing_sel_sync_reg[1] 
       (.C(PCK),
        .CE(timing_sel_sync0),
        .D(timing_sel_sync_ff[1]),
        .Q(timing_sel_sync[1]),
        .R(1'b0));
  FDRE vsync_prev_reg
       (.C(PCK),
        .CE(1'b1),
        .D(VGA_VS),
        .Q(vsync_prev),
        .R(1'b0));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
