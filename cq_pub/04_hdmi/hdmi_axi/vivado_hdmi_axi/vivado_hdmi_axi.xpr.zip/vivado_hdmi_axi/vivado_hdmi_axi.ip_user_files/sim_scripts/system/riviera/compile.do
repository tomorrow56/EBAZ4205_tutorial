transcript off
onbreak {quit -force}
onerror {quit -force}
transcript on

vlib work
vlib riviera/xilinx_vip
vlib riviera/xpm
vlib riviera/axi_infrastructure_v1_1_0
vlib riviera/axi_vip_v1_1_19
vlib riviera/processing_system7_vip_v1_0_21
vlib riviera/work
vlib riviera/xlconstant_v1_1_9
vlib riviera/lib_cdc_v1_0_3
vlib riviera/proc_sys_reset_v5_0_16
vlib riviera/smartconnect_v1_0
vlib riviera/axi_register_slice_v2_1_33
vlib riviera/xil_defaultlib

vmap xilinx_vip riviera/xilinx_vip
vmap xpm riviera/xpm
vmap axi_infrastructure_v1_1_0 riviera/axi_infrastructure_v1_1_0
vmap axi_vip_v1_1_19 riviera/axi_vip_v1_1_19
vmap processing_system7_vip_v1_0_21 riviera/processing_system7_vip_v1_0_21
vmap work riviera/work
vmap xlconstant_v1_1_9 riviera/xlconstant_v1_1_9
vmap lib_cdc_v1_0_3 riviera/lib_cdc_v1_0_3
vmap proc_sys_reset_v5_0_16 riviera/proc_sys_reset_v5_0_16
vmap smartconnect_v1_0 riviera/smartconnect_v1_0
vmap axi_register_slice_v2_1_33 riviera/axi_register_slice_v2_1_33
vmap xil_defaultlib riviera/xil_defaultlib

vlog -work xilinx_vip  -incr "+incdir+V:/Xilinx/Vivado/2024.2/data/xilinx_vip/include" -l xilinx_vip -l xpm -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_19 -l processing_system7_vip_v1_0_21 -l work -l xlconstant_v1_1_9 -l lib_cdc_v1_0_3 -l proc_sys_reset_v5_0_16 -l smartconnect_v1_0 -l axi_register_slice_v2_1_33 \
"V:/Xilinx/Vivado/2024.2/data/xilinx_vip/hdl/axi4stream_vip_axi4streampc.sv" \
"V:/Xilinx/Vivado/2024.2/data/xilinx_vip/hdl/axi_vip_axi4pc.sv" \
"V:/Xilinx/Vivado/2024.2/data/xilinx_vip/hdl/xil_common_vip_pkg.sv" \
"V:/Xilinx/Vivado/2024.2/data/xilinx_vip/hdl/axi4stream_vip_pkg.sv" \
"V:/Xilinx/Vivado/2024.2/data/xilinx_vip/hdl/axi_vip_pkg.sv" \
"V:/Xilinx/Vivado/2024.2/data/xilinx_vip/hdl/axi4stream_vip_if.sv" \
"V:/Xilinx/Vivado/2024.2/data/xilinx_vip/hdl/axi_vip_if.sv" \
"V:/Xilinx/Vivado/2024.2/data/xilinx_vip/hdl/clk_vip_if.sv" \
"V:/Xilinx/Vivado/2024.2/data/xilinx_vip/hdl/rst_vip_if.sv" \

vlog -work xpm  -incr "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/ec67/hdl" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/86fe/hdl" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/f0b6/hdl/verilog" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/0127/hdl/verilog" "+incdir+V:/Xilinx/Vivado/2024.2/data/xilinx_vip/include" -l xilinx_vip -l xpm -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_19 -l processing_system7_vip_v1_0_21 -l work -l xlconstant_v1_1_9 -l lib_cdc_v1_0_3 -l proc_sys_reset_v5_0_16 -l smartconnect_v1_0 -l axi_register_slice_v2_1_33 \
"V:/Xilinx/Vivado/2024.2/data/ip/xpm/xpm_fifo/hdl/xpm_fifo.sv" \
"V:/Xilinx/Vivado/2024.2/data/ip/xpm/xpm_memory/hdl/xpm_memory.sv" \
"V:/Xilinx/Vivado/2024.2/data/ip/xpm/xpm_cdc/hdl/xpm_cdc.sv" \

vcom -work xpm -93  -incr \
"V:/Xilinx/Vivado/2024.2/data/ip/xpm/xpm_VCOMP.vhd" \

vlog -work axi_infrastructure_v1_1_0  -incr -v2k5 "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/ec67/hdl" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/86fe/hdl" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/f0b6/hdl/verilog" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/0127/hdl/verilog" "+incdir+V:/Xilinx/Vivado/2024.2/data/xilinx_vip/include" -l xilinx_vip -l xpm -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_19 -l processing_system7_vip_v1_0_21 -l work -l xlconstant_v1_1_9 -l lib_cdc_v1_0_3 -l proc_sys_reset_v5_0_16 -l smartconnect_v1_0 -l axi_register_slice_v2_1_33 \
"../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/ec67/hdl/axi_infrastructure_v1_1_vl_rfs.v" \

vlog -work axi_vip_v1_1_19  -incr "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/ec67/hdl" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/86fe/hdl" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/f0b6/hdl/verilog" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/0127/hdl/verilog" "+incdir+V:/Xilinx/Vivado/2024.2/data/xilinx_vip/include" -l xilinx_vip -l xpm -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_19 -l processing_system7_vip_v1_0_21 -l work -l xlconstant_v1_1_9 -l lib_cdc_v1_0_3 -l proc_sys_reset_v5_0_16 -l smartconnect_v1_0 -l axi_register_slice_v2_1_33 \
"../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/8c45/hdl/axi_vip_v1_1_vl_rfs.sv" \

vlog -work processing_system7_vip_v1_0_21  -incr "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/ec67/hdl" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/86fe/hdl" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/f0b6/hdl/verilog" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/0127/hdl/verilog" "+incdir+V:/Xilinx/Vivado/2024.2/data/xilinx_vip/include" -l xilinx_vip -l xpm -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_19 -l processing_system7_vip_v1_0_21 -l work -l xlconstant_v1_1_9 -l lib_cdc_v1_0_3 -l proc_sys_reset_v5_0_16 -l smartconnect_v1_0 -l axi_register_slice_v2_1_33 \
"../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/86fe/hdl/processing_system7_vip_v1_0_vl_rfs.sv" \

vlog -work work  -incr -v2k5 "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/ec67/hdl" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/86fe/hdl" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/f0b6/hdl/verilog" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/0127/hdl/verilog" "+incdir+V:/Xilinx/Vivado/2024.2/data/xilinx_vip/include" -l xilinx_vip -l xpm -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_19 -l processing_system7_vip_v1_0_21 -l work -l xlconstant_v1_1_9 -l lib_cdc_v1_0_3 -l proc_sys_reset_v5_0_16 -l smartconnect_v1_0 -l axi_register_slice_v2_1_33 \
"../../../bd/system/ip/system_processing_system7_0_0/sim/system_processing_system7_0_0.v" \

vlog -work xlconstant_v1_1_9  -incr -v2k5 "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/ec67/hdl" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/86fe/hdl" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/f0b6/hdl/verilog" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/0127/hdl/verilog" "+incdir+V:/Xilinx/Vivado/2024.2/data/xilinx_vip/include" -l xilinx_vip -l xpm -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_19 -l processing_system7_vip_v1_0_21 -l work -l xlconstant_v1_1_9 -l lib_cdc_v1_0_3 -l proc_sys_reset_v5_0_16 -l smartconnect_v1_0 -l axi_register_slice_v2_1_33 \
"../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/e2d2/hdl/xlconstant_v1_1_vl_rfs.v" \

vlog -work work  -incr -v2k5 "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/ec67/hdl" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/86fe/hdl" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/f0b6/hdl/verilog" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/0127/hdl/verilog" "+incdir+V:/Xilinx/Vivado/2024.2/data/xilinx_vip/include" -l xilinx_vip -l xpm -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_19 -l processing_system7_vip_v1_0_21 -l work -l xlconstant_v1_1_9 -l lib_cdc_v1_0_3 -l proc_sys_reset_v5_0_16 -l smartconnect_v1_0 -l axi_register_slice_v2_1_33 \
"../../../bd/system/ip/system_axi_smc_0/bd_0/ip/ip_0/sim/bd_44e3_one_0.v" \

vcom -work lib_cdc_v1_0_3 -93  -incr \
"../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/2a4f/hdl/lib_cdc_v1_0_rfs.vhd" \

vcom -work proc_sys_reset_v5_0_16 -93  -incr \
"../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/0831/hdl/proc_sys_reset_v5_0_vh_rfs.vhd" \

vcom -work work -93  -incr \
"../../../bd/system/ip/system_axi_smc_0/bd_0/ip/ip_1/sim/bd_44e3_psr_aclk_0.vhd" \

vlog -work smartconnect_v1_0  -incr "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/ec67/hdl" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/86fe/hdl" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/f0b6/hdl/verilog" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/0127/hdl/verilog" "+incdir+V:/Xilinx/Vivado/2024.2/data/xilinx_vip/include" -l xilinx_vip -l xpm -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_19 -l processing_system7_vip_v1_0_21 -l work -l xlconstant_v1_1_9 -l lib_cdc_v1_0_3 -l proc_sys_reset_v5_0_16 -l smartconnect_v1_0 -l axi_register_slice_v2_1_33 \
"../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/f0b6/hdl/sc_util_v1_0_vl_rfs.sv" \
"../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/f49a/hdl/sc_mmu_v1_0_vl_rfs.sv" \

vlog -work work  -incr "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/ec67/hdl" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/86fe/hdl" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/f0b6/hdl/verilog" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/0127/hdl/verilog" "+incdir+V:/Xilinx/Vivado/2024.2/data/xilinx_vip/include" -l xilinx_vip -l xpm -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_19 -l processing_system7_vip_v1_0_21 -l work -l xlconstant_v1_1_9 -l lib_cdc_v1_0_3 -l proc_sys_reset_v5_0_16 -l smartconnect_v1_0 -l axi_register_slice_v2_1_33 \
"../../../bd/system/ip/system_axi_smc_0/bd_0/ip/ip_2/sim/bd_44e3_s00mmu_0.sv" \

vlog -work smartconnect_v1_0  -incr "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/ec67/hdl" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/86fe/hdl" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/f0b6/hdl/verilog" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/0127/hdl/verilog" "+incdir+V:/Xilinx/Vivado/2024.2/data/xilinx_vip/include" -l xilinx_vip -l xpm -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_19 -l processing_system7_vip_v1_0_21 -l work -l xlconstant_v1_1_9 -l lib_cdc_v1_0_3 -l proc_sys_reset_v5_0_16 -l smartconnect_v1_0 -l axi_register_slice_v2_1_33 \
"../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/2da8/hdl/sc_transaction_regulator_v1_0_vl_rfs.sv" \

vlog -work work  -incr "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/ec67/hdl" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/86fe/hdl" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/f0b6/hdl/verilog" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/0127/hdl/verilog" "+incdir+V:/Xilinx/Vivado/2024.2/data/xilinx_vip/include" -l xilinx_vip -l xpm -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_19 -l processing_system7_vip_v1_0_21 -l work -l xlconstant_v1_1_9 -l lib_cdc_v1_0_3 -l proc_sys_reset_v5_0_16 -l smartconnect_v1_0 -l axi_register_slice_v2_1_33 \
"../../../bd/system/ip/system_axi_smc_0/bd_0/ip/ip_3/sim/bd_44e3_s00tr_0.sv" \

vlog -work smartconnect_v1_0  -incr "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/ec67/hdl" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/86fe/hdl" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/f0b6/hdl/verilog" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/0127/hdl/verilog" "+incdir+V:/Xilinx/Vivado/2024.2/data/xilinx_vip/include" -l xilinx_vip -l xpm -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_19 -l processing_system7_vip_v1_0_21 -l work -l xlconstant_v1_1_9 -l lib_cdc_v1_0_3 -l proc_sys_reset_v5_0_16 -l smartconnect_v1_0 -l axi_register_slice_v2_1_33 \
"../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/63ed/hdl/sc_si_converter_v1_0_vl_rfs.sv" \

vlog -work work  -incr "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/ec67/hdl" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/86fe/hdl" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/f0b6/hdl/verilog" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/0127/hdl/verilog" "+incdir+V:/Xilinx/Vivado/2024.2/data/xilinx_vip/include" -l xilinx_vip -l xpm -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_19 -l processing_system7_vip_v1_0_21 -l work -l xlconstant_v1_1_9 -l lib_cdc_v1_0_3 -l proc_sys_reset_v5_0_16 -l smartconnect_v1_0 -l axi_register_slice_v2_1_33 \
"../../../bd/system/ip/system_axi_smc_0/bd_0/ip/ip_4/sim/bd_44e3_s00sic_0.sv" \

vlog -work smartconnect_v1_0  -incr "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/ec67/hdl" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/86fe/hdl" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/f0b6/hdl/verilog" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/0127/hdl/verilog" "+incdir+V:/Xilinx/Vivado/2024.2/data/xilinx_vip/include" -l xilinx_vip -l xpm -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_19 -l processing_system7_vip_v1_0_21 -l work -l xlconstant_v1_1_9 -l lib_cdc_v1_0_3 -l proc_sys_reset_v5_0_16 -l smartconnect_v1_0 -l axi_register_slice_v2_1_33 \
"../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/cef3/hdl/sc_axi2sc_v1_0_vl_rfs.sv" \

vlog -work work  -incr "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/ec67/hdl" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/86fe/hdl" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/f0b6/hdl/verilog" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/0127/hdl/verilog" "+incdir+V:/Xilinx/Vivado/2024.2/data/xilinx_vip/include" -l xilinx_vip -l xpm -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_19 -l processing_system7_vip_v1_0_21 -l work -l xlconstant_v1_1_9 -l lib_cdc_v1_0_3 -l proc_sys_reset_v5_0_16 -l smartconnect_v1_0 -l axi_register_slice_v2_1_33 \
"../../../bd/system/ip/system_axi_smc_0/bd_0/ip/ip_5/sim/bd_44e3_s00a2s_0.sv" \

vlog -work smartconnect_v1_0  -incr "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/ec67/hdl" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/86fe/hdl" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/f0b6/hdl/verilog" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/0127/hdl/verilog" "+incdir+V:/Xilinx/Vivado/2024.2/data/xilinx_vip/include" -l xilinx_vip -l xpm -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_19 -l processing_system7_vip_v1_0_21 -l work -l xlconstant_v1_1_9 -l lib_cdc_v1_0_3 -l proc_sys_reset_v5_0_16 -l smartconnect_v1_0 -l axi_register_slice_v2_1_33 \
"../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/0127/hdl/sc_node_v1_0_vl_rfs.sv" \

vlog -work work  -incr "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/ec67/hdl" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/86fe/hdl" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/f0b6/hdl/verilog" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/0127/hdl/verilog" "+incdir+V:/Xilinx/Vivado/2024.2/data/xilinx_vip/include" -l xilinx_vip -l xpm -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_19 -l processing_system7_vip_v1_0_21 -l work -l xlconstant_v1_1_9 -l lib_cdc_v1_0_3 -l proc_sys_reset_v5_0_16 -l smartconnect_v1_0 -l axi_register_slice_v2_1_33 \
"../../../bd/system/ip/system_axi_smc_0/bd_0/ip/ip_6/sim/bd_44e3_sarn_0.sv" \
"../../../bd/system/ip/system_axi_smc_0/bd_0/ip/ip_7/sim/bd_44e3_srn_0.sv" \
"../../../bd/system/ip/system_axi_smc_0/bd_0/ip/ip_8/sim/bd_44e3_sawn_0.sv" \
"../../../bd/system/ip/system_axi_smc_0/bd_0/ip/ip_9/sim/bd_44e3_swn_0.sv" \
"../../../bd/system/ip/system_axi_smc_0/bd_0/ip/ip_10/sim/bd_44e3_sbn_0.sv" \

vlog -work smartconnect_v1_0  -incr "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/ec67/hdl" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/86fe/hdl" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/f0b6/hdl/verilog" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/0127/hdl/verilog" "+incdir+V:/Xilinx/Vivado/2024.2/data/xilinx_vip/include" -l xilinx_vip -l xpm -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_19 -l processing_system7_vip_v1_0_21 -l work -l xlconstant_v1_1_9 -l lib_cdc_v1_0_3 -l proc_sys_reset_v5_0_16 -l smartconnect_v1_0 -l axi_register_slice_v2_1_33 \
"../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/7f4f/hdl/sc_sc2axi_v1_0_vl_rfs.sv" \

vlog -work work  -incr "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/ec67/hdl" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/86fe/hdl" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/f0b6/hdl/verilog" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/0127/hdl/verilog" "+incdir+V:/Xilinx/Vivado/2024.2/data/xilinx_vip/include" -l xilinx_vip -l xpm -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_19 -l processing_system7_vip_v1_0_21 -l work -l xlconstant_v1_1_9 -l lib_cdc_v1_0_3 -l proc_sys_reset_v5_0_16 -l smartconnect_v1_0 -l axi_register_slice_v2_1_33 \
"../../../bd/system/ip/system_axi_smc_0/bd_0/ip/ip_11/sim/bd_44e3_m00s2a_0.sv" \

vlog -work smartconnect_v1_0  -incr "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/ec67/hdl" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/86fe/hdl" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/f0b6/hdl/verilog" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/0127/hdl/verilog" "+incdir+V:/Xilinx/Vivado/2024.2/data/xilinx_vip/include" -l xilinx_vip -l xpm -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_19 -l processing_system7_vip_v1_0_21 -l work -l xlconstant_v1_1_9 -l lib_cdc_v1_0_3 -l proc_sys_reset_v5_0_16 -l smartconnect_v1_0 -l axi_register_slice_v2_1_33 \
"../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/37bc/hdl/sc_exit_v1_0_vl_rfs.sv" \

vlog -work work  -incr "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/ec67/hdl" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/86fe/hdl" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/f0b6/hdl/verilog" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/0127/hdl/verilog" "+incdir+V:/Xilinx/Vivado/2024.2/data/xilinx_vip/include" -l xilinx_vip -l xpm -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_19 -l processing_system7_vip_v1_0_21 -l work -l xlconstant_v1_1_9 -l lib_cdc_v1_0_3 -l proc_sys_reset_v5_0_16 -l smartconnect_v1_0 -l axi_register_slice_v2_1_33 \
"../../../bd/system/ip/system_axi_smc_0/bd_0/ip/ip_12/sim/bd_44e3_m00e_0.sv" \

vlog -work work  -incr -v2k5 "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/ec67/hdl" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/86fe/hdl" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/f0b6/hdl/verilog" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/0127/hdl/verilog" "+incdir+V:/Xilinx/Vivado/2024.2/data/xilinx_vip/include" -l xilinx_vip -l xpm -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_19 -l processing_system7_vip_v1_0_21 -l work -l xlconstant_v1_1_9 -l lib_cdc_v1_0_3 -l proc_sys_reset_v5_0_16 -l smartconnect_v1_0 -l axi_register_slice_v2_1_33 \
"../../../bd/system/ip/system_axi_smc_0/bd_0/sim/bd_44e3.v" \

vlog -work smartconnect_v1_0  -incr "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/ec67/hdl" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/86fe/hdl" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/f0b6/hdl/verilog" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/0127/hdl/verilog" "+incdir+V:/Xilinx/Vivado/2024.2/data/xilinx_vip/include" -l xilinx_vip -l xpm -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_19 -l processing_system7_vip_v1_0_21 -l work -l xlconstant_v1_1_9 -l lib_cdc_v1_0_3 -l proc_sys_reset_v5_0_16 -l smartconnect_v1_0 -l axi_register_slice_v2_1_33 \
"../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/3718/hdl/sc_switchboard_v1_0_vl_rfs.sv" \

vlog -work axi_register_slice_v2_1_33  -incr -v2k5 "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/ec67/hdl" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/86fe/hdl" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/f0b6/hdl/verilog" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/0127/hdl/verilog" "+incdir+V:/Xilinx/Vivado/2024.2/data/xilinx_vip/include" -l xilinx_vip -l xpm -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_19 -l processing_system7_vip_v1_0_21 -l work -l xlconstant_v1_1_9 -l lib_cdc_v1_0_3 -l proc_sys_reset_v5_0_16 -l smartconnect_v1_0 -l axi_register_slice_v2_1_33 \
"../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/3ee4/hdl/axi_register_slice_v2_1_vl_rfs.v" \

vlog -work work  -incr -v2k5 "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/ec67/hdl" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/86fe/hdl" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/f0b6/hdl/verilog" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/0127/hdl/verilog" "+incdir+V:/Xilinx/Vivado/2024.2/data/xilinx_vip/include" -l xilinx_vip -l xpm -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_19 -l processing_system7_vip_v1_0_21 -l work -l xlconstant_v1_1_9 -l lib_cdc_v1_0_3 -l proc_sys_reset_v5_0_16 -l smartconnect_v1_0 -l axi_register_slice_v2_1_33 \
"../../../bd/system/ip/system_axi_smc_0/sim/system_axi_smc_0.v" \

vcom -work work -93  -incr \
"../../../bd/system/ip/system_rst_ps7_0_100M_0/sim/system_rst_ps7_0_100M_0.vhd" \

vlog -work work  -incr -v2k5 "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/ec67/hdl" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/86fe/hdl" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/f0b6/hdl/verilog" "+incdir+../../../../vivado_hdmi_axi_720p_mod.gen/sources_1/bd/system/ipshared/0127/hdl/verilog" "+incdir+V:/Xilinx/Vivado/2024.2/data/xilinx_vip/include" -l xilinx_vip -l xpm -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_19 -l processing_system7_vip_v1_0_21 -l work -l xlconstant_v1_1_9 -l lib_cdc_v1_0_3 -l proc_sys_reset_v5_0_16 -l smartconnect_v1_0 -l axi_register_slice_v2_1_33 \
"../../../bd/system/ip/system_pattern_multi_0_0/sim/system_pattern_multi_0_0.v" \
"../../../bd/system/ip/system_axi_hdmi_ctrl_0_0/sim/system_axi_hdmi_ctrl_0_0.v" \
"../../../bd/system/ip/system_rgb2dvi_0_0/sim/system_rgb2dvi_0_0.v" \
"../../../bd/system/sim/system.v" \

vlog -work work \
"glbl.v"

