-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2024.2 (win64) Build 5239630 Fri Nov 08 22:35:27 MST 2024
-- Date        : Sat Jun  6 11:20:13 2026
-- Host        : MASAO running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode synth_stub
--               v:/IPI/vivado_hdmi_axi/vivado_hdmi_axi.gen/sources_1/bd/system/ip/system_pattern_multi_0_0/system_pattern_multi_0_0_stub.vhdl
-- Design      : system_pattern_multi_0_0
-- Purpose     : Stub declaration of top-level module interface
-- Device      : xc7z010clg400-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity system_pattern_multi_0_0 is
  Port ( 
    CLK : in STD_LOGIC;
    RST : in STD_LOGIC;
    timing_sel : in STD_LOGIC_VECTOR ( 1 downto 0 );
    timing_sel_imm : in STD_LOGIC_VECTOR ( 1 downto 0 );
    pattern_sel : in STD_LOGIC_VECTOR ( 3 downto 0 );
    reconfig_req : in STD_LOGIC;
    VGA_R : out STD_LOGIC_VECTOR ( 7 downto 0 );
    VGA_G : out STD_LOGIC_VECTOR ( 7 downto 0 );
    VGA_B : out STD_LOGIC_VECTOR ( 7 downto 0 );
    VGA_HS : out STD_LOGIC;
    VGA_VS : out STD_LOGIC;
    VGA_DE : out STD_LOGIC;
    PCK : out STD_LOGIC;
    SerialClk : out STD_LOGIC;
    locked : out STD_LOGIC;
    reconfig_done : out STD_LOGIC
  );

  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of system_pattern_multi_0_0 : entity is "system_pattern_multi_0_0,pattern_multi,{}";
  attribute CORE_GENERATION_INFO : string;
  attribute CORE_GENERATION_INFO of system_pattern_multi_0_0 : entity is "system_pattern_multi_0_0,pattern_multi,{x_ipProduct=Vivado 2024.2.2,x_ipVendor=xilinx.com,x_ipLibrary=module_ref,x_ipName=pattern_multi,x_ipVersion=1.0,x_ipCoreRevision=1,x_ipLanguage=VERILOG,x_ipSimLanguage=MIXED}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of system_pattern_multi_0_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of system_pattern_multi_0_0 : entity is "module_ref";
end system_pattern_multi_0_0;

architecture stub of system_pattern_multi_0_0 is
  attribute syn_black_box : boolean;
  attribute black_box_pad_pin : string;
  attribute syn_black_box of stub : architecture is true;
  attribute black_box_pad_pin of stub : architecture is "CLK,RST,timing_sel[1:0],timing_sel_imm[1:0],pattern_sel[3:0],reconfig_req,VGA_R[7:0],VGA_G[7:0],VGA_B[7:0],VGA_HS,VGA_VS,VGA_DE,PCK,SerialClk,locked,reconfig_done";
  attribute X_INTERFACE_INFO : string;
  attribute X_INTERFACE_INFO of CLK : signal is "xilinx.com:signal:clock:1.0 CLK CLK";
  attribute X_INTERFACE_MODE : string;
  attribute X_INTERFACE_MODE of CLK : signal is "slave";
  attribute X_INTERFACE_PARAMETER : string;
  attribute X_INTERFACE_PARAMETER of CLK : signal is "XIL_INTERFACENAME CLK, ASSOCIATED_RESET RST, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN system_processing_system7_0_0_FCLK_CLK0, INSERT_VIP 0";
  attribute X_INTERFACE_INFO of RST : signal is "xilinx.com:signal:reset:1.0 RST RST";
  attribute X_INTERFACE_MODE of RST : signal is "slave";
  attribute X_INTERFACE_PARAMETER of RST : signal is "XIL_INTERFACENAME RST, POLARITY ACTIVE_HIGH, INSERT_VIP 0";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of stub : architecture is "pattern_multi,Vivado 2024.2.2";
begin
end;
