-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2024.2 (win64) Build 5239630 Fri Nov 08 22:35:27 MST 2024
-- Date        : Sat Jun  6 11:20:13 2026
-- Host        : MASAO running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim
--               v:/IPI/vivado_hdmi_axi/vivado_hdmi_axi.gen/sources_1/bd/system/ip/system_pattern_multi_0_0/system_pattern_multi_0_0_sim_netlist.vhdl
-- Design      : system_pattern_multi_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7z010clg400-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity system_pattern_multi_0_0_mmcm_drp is
  port (
    DI : out STD_LOGIC_VECTOR ( 15 downto 0 );
    \FSM_sequential_state_reg[1]\ : out STD_LOGIC;
    DWE : out STD_LOGIC;
    DEN : out STD_LOGIC;
    DADDR : out STD_LOGIC_VECTOR ( 6 downto 0 );
    mmcm_rst : out STD_LOGIC;
    drp_drdy : in STD_LOGIC;
    DO : in STD_LOGIC_VECTOR ( 14 downto 0 );
    timing_sel_imm : in STD_LOGIC_VECTOR ( 1 downto 0 );
    state : in STD_LOGIC_VECTOR ( 2 downto 0 );
    reconfig_req : in STD_LOGIC;
    CLK : in STD_LOGIC;
    \ram_reg[26][0]_0\ : in STD_LOGIC;
    \ram_addr_reg[0]_0\ : in STD_LOGIC;
    locked : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of system_pattern_multi_0_0_mmcm_drp : entity is "mmcm_drp";
end system_pattern_multi_0_0_mmcm_drp;

architecture STRUCTURE of system_pattern_multi_0_0_mmcm_drp is
  signal \DADDR[6]_i_1_n_0\ : STD_LOGIC;
  signal \DADDR[6]_i_2_n_0\ : STD_LOGIC;
  signal \^di\ : STD_LOGIC_VECTOR ( 15 downto 0 );
  signal \DI[0]_i_1_n_0\ : STD_LOGIC;
  signal \DI[10]_i_1_n_0\ : STD_LOGIC;
  signal \DI[11]_i_1_n_0\ : STD_LOGIC;
  signal \DI[12]_i_1_n_0\ : STD_LOGIC;
  signal \DI[13]_i_1_n_0\ : STD_LOGIC;
  signal \DI[14]_i_1_n_0\ : STD_LOGIC;
  signal \DI[15]_i_1_n_0\ : STD_LOGIC;
  signal \DI[15]_i_2_n_0\ : STD_LOGIC;
  signal \DI[15]_i_3_n_0\ : STD_LOGIC;
  signal \DI[1]_i_1_n_0\ : STD_LOGIC;
  signal \DI[2]_i_1_n_0\ : STD_LOGIC;
  signal \DI[3]_i_1_n_0\ : STD_LOGIC;
  signal \DI[4]_i_1_n_0\ : STD_LOGIC;
  signal \DI[5]_i_1_n_0\ : STD_LOGIC;
  signal \DI[6]_i_1_n_0\ : STD_LOGIC;
  signal \DI[7]_i_1_n_0\ : STD_LOGIC;
  signal \DI[8]_i_1_n_0\ : STD_LOGIC;
  signal \DI[9]_i_1_n_0\ : STD_LOGIC;
  signal RST_MMCM_PLL_i_1_n_0 : STD_LOGIC;
  signal current_state : STD_LOGIC_VECTOR ( 3 downto 0 );
  attribute DONT_TOUCH : boolean;
  attribute DONT_TOUCH of current_state : signal is std.standard.true;
  signal \current_state[0]_i_2_n_0\ : STD_LOGIC;
  signal \current_state[1]_i_2_n_0\ : STD_LOGIC;
  signal \current_state[1]_i_3_n_0\ : STD_LOGIC;
  signal \current_state[1]_i_4_n_0\ : STD_LOGIC;
  signal \current_state[2]_i_2_n_0\ : STD_LOGIC;
  signal \^mmcm_rst\ : STD_LOGIC;
  signal next_den : STD_LOGIC;
  signal next_dwe : STD_LOGIC;
  signal next_srdy : STD_LOGIC;
  signal next_state : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal p_17_in : STD_LOGIC_VECTOR ( 9 downto 0 );
  signal p_18_in : STD_LOGIC_VECTOR ( 14 downto 0 );
  signal p_19_in : STD_LOGIC_VECTOR ( 14 downto 0 );
  signal p_1_out : STD_LOGIC_VECTOR ( 10 to 10 );
  signal p_20_in : STD_LOGIC_VECTOR ( 15 downto 8 );
  signal p_21_in : STD_LOGIC_VECTOR ( 15 downto 4 );
  signal ram : STD_LOGIC_VECTOR ( 38 downto 0 );
  signal \ram[23][37]_i_1_n_0\ : STD_LOGIC;
  signal \ram[25][10]_i_1_n_0\ : STD_LOGIC;
  signal \ram[25][8]_i_1_n_0\ : STD_LOGIC;
  signal \ram[26][5]_i_2_n_0\ : STD_LOGIC;
  signal \ram[26][5]_i_3_n_0\ : STD_LOGIC;
  signal \ram[26][5]_i_4_n_0\ : STD_LOGIC;
  signal \ram[26][5]_i_5_n_0\ : STD_LOGIC;
  signal \ram[26][5]_i_6_n_0\ : STD_LOGIC;
  signal \ram[37][10]_i_1_n_0\ : STD_LOGIC;
  signal \ram[38][0]_i_2_n_0\ : STD_LOGIC;
  signal \ram[38][0]_i_3_n_0\ : STD_LOGIC;
  signal \ram[38][0]_i_4_n_0\ : STD_LOGIC;
  signal \ram[38][0]_i_5_n_0\ : STD_LOGIC;
  signal \ram[38][6]_i_1_n_0\ : STD_LOGIC;
  signal \ram[39][0]_i_1_n_0\ : STD_LOGIC;
  signal \ram[39][10]_i_1_n_0\ : STD_LOGIC;
  signal \ram[39][6]_i_1_n_0\ : STD_LOGIC;
  signal \ram[39][7]_i_1_n_0\ : STD_LOGIC;
  signal \ram[39][8]_i_1_n_0\ : STD_LOGIC;
  signal \ram[39][9]_i_1_n_0\ : STD_LOGIC;
  signal \ram[40][11]_i_1_n_0\ : STD_LOGIC;
  signal \ram[40][12]_i_10_n_0\ : STD_LOGIC;
  signal \ram[40][12]_i_11_n_0\ : STD_LOGIC;
  signal \ram[40][12]_i_12_n_0\ : STD_LOGIC;
  signal \ram[40][12]_i_13_n_0\ : STD_LOGIC;
  signal \ram[40][12]_i_14_n_0\ : STD_LOGIC;
  signal \ram[40][12]_i_15_n_0\ : STD_LOGIC;
  signal \ram[40][12]_i_16_n_0\ : STD_LOGIC;
  signal \ram[40][12]_i_17_n_0\ : STD_LOGIC;
  signal \ram[40][12]_i_18_n_0\ : STD_LOGIC;
  signal \ram[40][12]_i_1_n_0\ : STD_LOGIC;
  signal \ram[40][12]_i_20_n_0\ : STD_LOGIC;
  signal \ram[40][12]_i_21_n_0\ : STD_LOGIC;
  signal \ram[40][12]_i_22_n_0\ : STD_LOGIC;
  signal \ram[40][12]_i_23_n_0\ : STD_LOGIC;
  signal \ram[40][12]_i_24_n_0\ : STD_LOGIC;
  signal \ram[40][12]_i_25_n_0\ : STD_LOGIC;
  signal \ram[40][12]_i_26_n_0\ : STD_LOGIC;
  signal \ram[40][12]_i_27_n_0\ : STD_LOGIC;
  signal \ram[40][12]_i_28_n_0\ : STD_LOGIC;
  signal \ram[40][12]_i_5_n_0\ : STD_LOGIC;
  signal \ram[40][12]_i_6_n_0\ : STD_LOGIC;
  signal \ram[40][12]_i_7_n_0\ : STD_LOGIC;
  signal \ram[40][12]_i_8_n_0\ : STD_LOGIC;
  signal \ram[40][13]_i_1_n_0\ : STD_LOGIC;
  signal \ram[41][4]_i_2_n_0\ : STD_LOGIC;
  signal \ram[41][5]_i_2_n_0\ : STD_LOGIC;
  signal \ram[41][6]_i_2_n_0\ : STD_LOGIC;
  signal \ram[41][7]_i_2_n_0\ : STD_LOGIC;
  signal \ram[41][8]_i_2_n_0\ : STD_LOGIC;
  signal \ram[41][9]_i_2_n_0\ : STD_LOGIC;
  signal \ram[42][0]_i_2_n_0\ : STD_LOGIC;
  signal \ram[42][10]_i_2_n_0\ : STD_LOGIC;
  signal \ram[42][11]_i_2_n_0\ : STD_LOGIC;
  signal \ram[42][12]_i_2_n_0\ : STD_LOGIC;
  signal \ram[42][12]_i_3_n_0\ : STD_LOGIC;
  signal \ram[42][13]_i_2_n_0\ : STD_LOGIC;
  signal \ram[42][14]_i_2_n_0\ : STD_LOGIC;
  signal \ram[42][1]_i_2_n_0\ : STD_LOGIC;
  signal \ram[42][2]_i_2_n_0\ : STD_LOGIC;
  signal \ram[42][3]_i_2_n_0\ : STD_LOGIC;
  signal \ram[42][3]_i_3_n_0\ : STD_LOGIC;
  signal \ram[42][4]_i_2_n_0\ : STD_LOGIC;
  signal \ram[42][4]_i_3_n_0\ : STD_LOGIC;
  signal \ram[42][5]_i_2_n_0\ : STD_LOGIC;
  signal \ram[42][5]_i_3_n_0\ : STD_LOGIC;
  signal \ram[42][6]_i_2_n_0\ : STD_LOGIC;
  signal \ram[42][6]_i_3_n_0\ : STD_LOGIC;
  signal \ram[42][7]_i_2_n_0\ : STD_LOGIC;
  signal \ram[42][7]_i_3_n_0\ : STD_LOGIC;
  signal \ram[42][8]_i_3_n_0\ : STD_LOGIC;
  signal \ram[42][8]_i_4_n_0\ : STD_LOGIC;
  signal \ram[42][8]_i_5_n_0\ : STD_LOGIC;
  signal \ram[42][8]_i_6_n_0\ : STD_LOGIC;
  signal \ram[42][9]_i_3_n_0\ : STD_LOGIC;
  signal \ram[42][9]_i_4_n_0\ : STD_LOGIC;
  signal \ram[42][9]_i_5_n_0\ : STD_LOGIC;
  signal \ram[42][9]_i_6_n_0\ : STD_LOGIC;
  signal \ram[43][0]_i_3_n_0\ : STD_LOGIC;
  signal \ram[43][0]_i_4_n_0\ : STD_LOGIC;
  signal \ram[43][0]_i_5_n_0\ : STD_LOGIC;
  signal \ram[43][10]_i_2_n_0\ : STD_LOGIC;
  signal \ram[43][10]_i_3_n_0\ : STD_LOGIC;
  signal \ram[43][10]_i_4_n_0\ : STD_LOGIC;
  signal \ram[43][10]_i_5_n_0\ : STD_LOGIC;
  signal \ram[43][10]_i_6_n_0\ : STD_LOGIC;
  signal \ram[43][11]_i_2_n_0\ : STD_LOGIC;
  signal \ram[43][11]_i_3_n_0\ : STD_LOGIC;
  signal \ram[43][11]_i_4_n_0\ : STD_LOGIC;
  signal \ram[43][11]_i_5_n_0\ : STD_LOGIC;
  signal \ram[43][12]_i_2_n_0\ : STD_LOGIC;
  signal \ram[43][12]_i_3_n_0\ : STD_LOGIC;
  signal \ram[43][12]_i_4_n_0\ : STD_LOGIC;
  signal \ram[43][12]_i_5_n_0\ : STD_LOGIC;
  signal \ram[43][13]_i_2_n_0\ : STD_LOGIC;
  signal \ram[43][13]_i_3_n_0\ : STD_LOGIC;
  signal \ram[43][13]_i_4_n_0\ : STD_LOGIC;
  signal \ram[43][13]_i_5_n_0\ : STD_LOGIC;
  signal \ram[43][14]_i_10_n_0\ : STD_LOGIC;
  signal \ram[43][14]_i_11_n_0\ : STD_LOGIC;
  signal \ram[43][14]_i_12_n_0\ : STD_LOGIC;
  signal \ram[43][14]_i_13_n_0\ : STD_LOGIC;
  signal \ram[43][14]_i_14_n_0\ : STD_LOGIC;
  signal \ram[43][14]_i_15_n_0\ : STD_LOGIC;
  signal \ram[43][14]_i_16_n_0\ : STD_LOGIC;
  signal \ram[43][14]_i_2_n_0\ : STD_LOGIC;
  signal \ram[43][14]_i_4_n_0\ : STD_LOGIC;
  signal \ram[43][14]_i_5_n_0\ : STD_LOGIC;
  signal \ram[43][14]_i_6_n_0\ : STD_LOGIC;
  signal \ram[43][14]_i_9_n_0\ : STD_LOGIC;
  signal \ram[43][1]_i_3_n_0\ : STD_LOGIC;
  signal \ram[43][1]_i_4_n_0\ : STD_LOGIC;
  signal \ram[43][1]_i_5_n_0\ : STD_LOGIC;
  signal \ram[43][1]_i_6_n_0\ : STD_LOGIC;
  signal \ram[43][2]_i_3_n_0\ : STD_LOGIC;
  signal \ram[43][2]_i_4_n_0\ : STD_LOGIC;
  signal \ram[43][2]_i_5_n_0\ : STD_LOGIC;
  signal \ram[43][2]_i_6_n_0\ : STD_LOGIC;
  signal \ram[43][3]_i_3_n_0\ : STD_LOGIC;
  signal \ram[43][3]_i_4_n_0\ : STD_LOGIC;
  signal \ram[43][3]_i_5_n_0\ : STD_LOGIC;
  signal \ram[43][3]_i_6_n_0\ : STD_LOGIC;
  signal \ram[43][4]_i_3_n_0\ : STD_LOGIC;
  signal \ram[43][4]_i_4_n_0\ : STD_LOGIC;
  signal \ram[43][4]_i_5_n_0\ : STD_LOGIC;
  signal \ram[43][4]_i_6_n_0\ : STD_LOGIC;
  signal \ram[43][5]_i_3_n_0\ : STD_LOGIC;
  signal \ram[43][5]_i_4_n_0\ : STD_LOGIC;
  signal \ram[43][5]_i_5_n_0\ : STD_LOGIC;
  signal \ram[43][5]_i_6_n_0\ : STD_LOGIC;
  signal \ram[43][6]_i_2_n_0\ : STD_LOGIC;
  signal \ram[43][6]_i_3_n_0\ : STD_LOGIC;
  signal \ram[43][6]_i_4_n_0\ : STD_LOGIC;
  signal \ram[43][6]_i_5_n_0\ : STD_LOGIC;
  signal \ram[43][6]_i_6_n_0\ : STD_LOGIC;
  signal \ram[43][7]_i_2_n_0\ : STD_LOGIC;
  signal \ram[43][7]_i_3_n_0\ : STD_LOGIC;
  signal \ram[43][7]_i_4_n_0\ : STD_LOGIC;
  signal \ram[43][7]_i_5_n_0\ : STD_LOGIC;
  signal \ram[43][8]_i_2_n_0\ : STD_LOGIC;
  signal \ram[43][8]_i_3_n_0\ : STD_LOGIC;
  signal \ram[43][8]_i_4_n_0\ : STD_LOGIC;
  signal \ram[43][8]_i_5_n_0\ : STD_LOGIC;
  signal \ram[43][9]_i_2_n_0\ : STD_LOGIC;
  signal \ram[44][11]_i_2_n_0\ : STD_LOGIC;
  signal \ram[44][12]_i_2_n_0\ : STD_LOGIC;
  signal \ram[44][12]_i_3_n_0\ : STD_LOGIC;
  signal \ram[44][15]_i_2_n_0\ : STD_LOGIC;
  signal \ram[44][15]_i_3_n_0\ : STD_LOGIC;
  signal \ram[44][38]_i_1_n_0\ : STD_LOGIC;
  signal \ram[44][8]_i_2_n_0\ : STD_LOGIC;
  signal \ram[45][11]_i_10_n_0\ : STD_LOGIC;
  signal \ram[45][11]_i_11_n_0\ : STD_LOGIC;
  signal \ram[45][11]_i_12_n_0\ : STD_LOGIC;
  signal \ram[45][11]_i_13_n_0\ : STD_LOGIC;
  signal \ram[45][11]_i_14_n_0\ : STD_LOGIC;
  signal \ram[45][11]_i_15_n_0\ : STD_LOGIC;
  signal \ram[45][11]_i_16_n_0\ : STD_LOGIC;
  signal \ram[45][11]_i_17_n_0\ : STD_LOGIC;
  signal \ram[45][11]_i_18_n_0\ : STD_LOGIC;
  signal \ram[45][11]_i_19_n_0\ : STD_LOGIC;
  signal \ram[45][11]_i_2_n_0\ : STD_LOGIC;
  signal \ram[45][11]_i_4_n_0\ : STD_LOGIC;
  signal \ram[45][11]_i_6_n_0\ : STD_LOGIC;
  signal \ram[45][11]_i_9_n_0\ : STD_LOGIC;
  signal \ram[45][12]_i_2_n_0\ : STD_LOGIC;
  signal \ram[45][12]_i_3_n_0\ : STD_LOGIC;
  signal \ram[45][12]_i_4_n_0\ : STD_LOGIC;
  signal \ram[45][12]_i_5_n_0\ : STD_LOGIC;
  signal \ram[45][15]_i_2_n_0\ : STD_LOGIC;
  signal \ram[45][15]_i_3_n_0\ : STD_LOGIC;
  signal \ram[45][15]_i_4_n_0\ : STD_LOGIC;
  signal \ram[45][15]_i_5_n_0\ : STD_LOGIC;
  signal \ram[45][15]_i_6_n_0\ : STD_LOGIC;
  signal \ram[45][4]_i_2_n_0\ : STD_LOGIC;
  signal \ram[45][4]_i_3_n_0\ : STD_LOGIC;
  signal \ram[45][7]_i_2_n_0\ : STD_LOGIC;
  signal \ram[45][7]_i_3_n_0\ : STD_LOGIC;
  signal \ram[45][8]_i_2_n_0\ : STD_LOGIC;
  signal \ram[45][8]_i_3_n_0\ : STD_LOGIC;
  signal \ram[45][8]_i_5_n_0\ : STD_LOGIC;
  signal \ram[45][8]_i_6_n_0\ : STD_LOGIC;
  signal ram_addr : STD_LOGIC_VECTOR ( 5 downto 0 );
  signal \ram_addr[0]_i_1_n_0\ : STD_LOGIC;
  signal \ram_addr[1]_i_1_n_0\ : STD_LOGIC;
  signal \ram_addr[2]_i_1_n_0\ : STD_LOGIC;
  signal \ram_addr[3]_i_1_n_0\ : STD_LOGIC;
  signal \ram_addr[4]_i_1_n_0\ : STD_LOGIC;
  signal \ram_addr[4]_i_2_n_0\ : STD_LOGIC;
  signal \ram_addr[4]_i_3_n_0\ : STD_LOGIC;
  signal \ram_addr[5]_i_1_n_0\ : STD_LOGIC;
  signal \ram_addr[5]_i_2_n_0\ : STD_LOGIC;
  signal ram_do : STD_LOGIC_VECTOR ( 38 downto 0 );
  signal \ram_do[0]_i_2_n_0\ : STD_LOGIC;
  signal \ram_do[0]_i_3_n_0\ : STD_LOGIC;
  signal \ram_do[0]_i_4_n_0\ : STD_LOGIC;
  signal \ram_do[0]_i_5_n_0\ : STD_LOGIC;
  signal \ram_do[0]_i_6_n_0\ : STD_LOGIC;
  signal \ram_do[10]_i_3_n_0\ : STD_LOGIC;
  signal \ram_do[10]_i_4_n_0\ : STD_LOGIC;
  signal \ram_do[10]_i_5_n_0\ : STD_LOGIC;
  signal \ram_do[10]_i_6_n_0\ : STD_LOGIC;
  signal \ram_do[11]_i_2_n_0\ : STD_LOGIC;
  signal \ram_do[11]_i_3_n_0\ : STD_LOGIC;
  signal \ram_do[11]_i_4_n_0\ : STD_LOGIC;
  signal \ram_do[11]_i_5_n_0\ : STD_LOGIC;
  signal \ram_do[12]_i_2_n_0\ : STD_LOGIC;
  signal \ram_do[12]_i_3_n_0\ : STD_LOGIC;
  signal \ram_do[12]_i_4_n_0\ : STD_LOGIC;
  signal \ram_do[12]_i_5_n_0\ : STD_LOGIC;
  signal \ram_do[13]_i_2_n_0\ : STD_LOGIC;
  signal \ram_do[13]_i_3_n_0\ : STD_LOGIC;
  signal \ram_do[13]_i_4_n_0\ : STD_LOGIC;
  signal \ram_do[14]_i_2_n_0\ : STD_LOGIC;
  signal \ram_do[14]_i_3_n_0\ : STD_LOGIC;
  signal \ram_do[15]_i_2_n_0\ : STD_LOGIC;
  signal \ram_do[15]_i_3_n_0\ : STD_LOGIC;
  signal \ram_do[1]_i_2_n_0\ : STD_LOGIC;
  signal \ram_do[1]_i_3_n_0\ : STD_LOGIC;
  signal \ram_do[1]_i_4_n_0\ : STD_LOGIC;
  signal \ram_do[1]_i_5_n_0\ : STD_LOGIC;
  signal \ram_do[23]_i_2_n_0\ : STD_LOGIC;
  signal \ram_do[23]_i_3_n_0\ : STD_LOGIC;
  signal \ram_do[27]_i_2_n_0\ : STD_LOGIC;
  signal \ram_do[27]_i_3_n_0\ : STD_LOGIC;
  signal \ram_do[28]_i_2_n_0\ : STD_LOGIC;
  signal \ram_do[28]_i_3_n_0\ : STD_LOGIC;
  signal \ram_do[29]_i_2_n_0\ : STD_LOGIC;
  signal \ram_do[29]_i_3_n_0\ : STD_LOGIC;
  signal \ram_do[2]_i_2_n_0\ : STD_LOGIC;
  signal \ram_do[2]_i_3_n_0\ : STD_LOGIC;
  signal \ram_do[2]_i_4_n_0\ : STD_LOGIC;
  signal \ram_do[2]_i_5_n_0\ : STD_LOGIC;
  signal \ram_do[30]_i_2_n_0\ : STD_LOGIC;
  signal \ram_do[30]_i_3_n_0\ : STD_LOGIC;
  signal \ram_do[31]_i_2_n_0\ : STD_LOGIC;
  signal \ram_do[31]_i_3_n_0\ : STD_LOGIC;
  signal \ram_do[32]_i_2_n_0\ : STD_LOGIC;
  signal \ram_do[32]_i_3_n_0\ : STD_LOGIC;
  signal \ram_do[33]_i_2_n_0\ : STD_LOGIC;
  signal \ram_do[33]_i_3_n_0\ : STD_LOGIC;
  signal \ram_do[34]_i_2_n_0\ : STD_LOGIC;
  signal \ram_do[34]_i_3_n_0\ : STD_LOGIC;
  signal \ram_do[35]_i_2_n_0\ : STD_LOGIC;
  signal \ram_do[35]_i_3_n_0\ : STD_LOGIC;
  signal \ram_do[35]_i_4_n_0\ : STD_LOGIC;
  signal \ram_do[36]_i_2_n_0\ : STD_LOGIC;
  signal \ram_do[36]_i_3_n_0\ : STD_LOGIC;
  signal \ram_do[37]_i_2_n_0\ : STD_LOGIC;
  signal \ram_do[37]_i_3_n_0\ : STD_LOGIC;
  signal \ram_do[38]_i_2_n_0\ : STD_LOGIC;
  signal \ram_do[38]_i_3_n_0\ : STD_LOGIC;
  signal \ram_do[3]_i_3_n_0\ : STD_LOGIC;
  signal \ram_do[3]_i_4_n_0\ : STD_LOGIC;
  signal \ram_do[3]_i_5_n_0\ : STD_LOGIC;
  signal \ram_do[4]_i_2_n_0\ : STD_LOGIC;
  signal \ram_do[4]_i_3_n_0\ : STD_LOGIC;
  signal \ram_do[4]_i_4_n_0\ : STD_LOGIC;
  signal \ram_do[4]_i_5_n_0\ : STD_LOGIC;
  signal \ram_do[4]_i_6_n_0\ : STD_LOGIC;
  signal \ram_do[4]_i_7_n_0\ : STD_LOGIC;
  signal \ram_do[5]_i_3_n_0\ : STD_LOGIC;
  signal \ram_do[5]_i_4_n_0\ : STD_LOGIC;
  signal \ram_do[5]_i_5_n_0\ : STD_LOGIC;
  signal \ram_do[6]_i_2_n_0\ : STD_LOGIC;
  signal \ram_do[6]_i_3_n_0\ : STD_LOGIC;
  signal \ram_do[6]_i_4_n_0\ : STD_LOGIC;
  signal \ram_do[6]_i_5_n_0\ : STD_LOGIC;
  signal \ram_do[7]_i_2_n_0\ : STD_LOGIC;
  signal \ram_do[7]_i_3_n_0\ : STD_LOGIC;
  signal \ram_do[7]_i_4_n_0\ : STD_LOGIC;
  signal \ram_do[7]_i_5_n_0\ : STD_LOGIC;
  signal \ram_do[7]_i_6_n_0\ : STD_LOGIC;
  signal \ram_do[8]_i_2_n_0\ : STD_LOGIC;
  signal \ram_do[8]_i_3_n_0\ : STD_LOGIC;
  signal \ram_do[8]_i_4_n_0\ : STD_LOGIC;
  signal \ram_do[8]_i_5_n_0\ : STD_LOGIC;
  signal \ram_do[9]_i_2_n_0\ : STD_LOGIC;
  signal \ram_do[9]_i_3_n_0\ : STD_LOGIC;
  signal \ram_do[9]_i_4_n_0\ : STD_LOGIC;
  signal \ram_do[9]_i_5_n_0\ : STD_LOGIC;
  signal \ram_do_reg[10]_i_2_n_0\ : STD_LOGIC;
  signal \ram_do_reg[3]_i_2_n_0\ : STD_LOGIC;
  signal \ram_do_reg[5]_i_2_n_0\ : STD_LOGIC;
  signal \ram_reg[23]_11\ : STD_LOGIC_VECTOR ( 37 to 37 );
  signal \ram_reg[25]_10\ : STD_LOGIC_VECTOR ( 10 downto 8 );
  signal \ram_reg[26][5]_i_1_n_1\ : STD_LOGIC;
  signal \ram_reg[26][5]_i_1_n_2\ : STD_LOGIC;
  signal \ram_reg[26][5]_i_1_n_3\ : STD_LOGIC;
  signal \ram_reg[26][5]_i_1_n_4\ : STD_LOGIC;
  signal \ram_reg[26][5]_i_1_n_5\ : STD_LOGIC;
  signal \ram_reg[26][5]_i_1_n_6\ : STD_LOGIC;
  signal \ram_reg[26][5]_i_1_n_7\ : STD_LOGIC;
  signal \ram_reg[26]_9\ : STD_LOGIC_VECTOR ( 5 downto 0 );
  signal \ram_reg[37]_8\ : STD_LOGIC_VECTOR ( 13 downto 10 );
  signal \ram_reg[38][0]_i_1_n_0\ : STD_LOGIC;
  signal \ram_reg[38][0]_i_1_n_1\ : STD_LOGIC;
  signal \ram_reg[38][0]_i_1_n_2\ : STD_LOGIC;
  signal \ram_reg[38][0]_i_1_n_3\ : STD_LOGIC;
  signal \ram_reg[38][0]_i_1_n_4\ : STD_LOGIC;
  signal \ram_reg[38][0]_i_1_n_5\ : STD_LOGIC;
  signal \ram_reg[38][0]_i_1_n_6\ : STD_LOGIC;
  signal \ram_reg[38][0]_i_1_n_7\ : STD_LOGIC;
  signal \ram_reg[38][5]_i_1_n_3\ : STD_LOGIC;
  signal \ram_reg[38][5]_i_1_n_6\ : STD_LOGIC;
  signal \ram_reg[38][5]_i_1_n_7\ : STD_LOGIC;
  signal \ram_reg[38]_7\ : STD_LOGIC_VECTOR ( 13 downto 0 );
  signal \ram_reg[39]_6\ : STD_LOGIC_VECTOR ( 10 downto 0 );
  signal \ram_reg[40][12]_i_19_n_0\ : STD_LOGIC;
  signal \ram_reg[40][12]_i_19_n_1\ : STD_LOGIC;
  signal \ram_reg[40][12]_i_19_n_2\ : STD_LOGIC;
  signal \ram_reg[40][12]_i_19_n_3\ : STD_LOGIC;
  signal \ram_reg[40][12]_i_2_n_0\ : STD_LOGIC;
  signal \ram_reg[40][12]_i_2_n_2\ : STD_LOGIC;
  signal \ram_reg[40][12]_i_2_n_3\ : STD_LOGIC;
  signal \ram_reg[40][12]_i_2_n_5\ : STD_LOGIC;
  signal \ram_reg[40][12]_i_2_n_6\ : STD_LOGIC;
  signal \ram_reg[40][12]_i_2_n_7\ : STD_LOGIC;
  signal \ram_reg[40][12]_i_3_n_2\ : STD_LOGIC;
  signal \ram_reg[40][12]_i_3_n_3\ : STD_LOGIC;
  signal \ram_reg[40][12]_i_4_n_0\ : STD_LOGIC;
  signal \ram_reg[40][12]_i_4_n_1\ : STD_LOGIC;
  signal \ram_reg[40][12]_i_4_n_2\ : STD_LOGIC;
  signal \ram_reg[40][12]_i_4_n_3\ : STD_LOGIC;
  signal \ram_reg[40][12]_i_4_n_4\ : STD_LOGIC;
  signal \ram_reg[40][12]_i_4_n_5\ : STD_LOGIC;
  signal \ram_reg[40][12]_i_4_n_6\ : STD_LOGIC;
  signal \ram_reg[40][12]_i_4_n_7\ : STD_LOGIC;
  signal \ram_reg[40][12]_i_9_n_0\ : STD_LOGIC;
  signal \ram_reg[40][12]_i_9_n_1\ : STD_LOGIC;
  signal \ram_reg[40][12]_i_9_n_2\ : STD_LOGIC;
  signal \ram_reg[40][12]_i_9_n_3\ : STD_LOGIC;
  signal \ram_reg[40]_5\ : STD_LOGIC_VECTOR ( 14 downto 7 );
  signal \ram_reg[41]_4\ : STD_LOGIC_VECTOR ( 9 downto 0 );
  signal \ram_reg[42][8]_i_2_n_0\ : STD_LOGIC;
  signal \ram_reg[42][9]_i_2_n_0\ : STD_LOGIC;
  signal \ram_reg[42]_3\ : STD_LOGIC_VECTOR ( 14 downto 0 );
  signal \ram_reg[43][0]_i_2_n_0\ : STD_LOGIC;
  signal \ram_reg[43][14]_i_3_n_1\ : STD_LOGIC;
  signal \ram_reg[43][14]_i_3_n_3\ : STD_LOGIC;
  signal \ram_reg[43][14]_i_3_n_6\ : STD_LOGIC;
  signal \ram_reg[43][14]_i_3_n_7\ : STD_LOGIC;
  signal \ram_reg[43][14]_i_7_n_0\ : STD_LOGIC;
  signal \ram_reg[43][14]_i_7_n_1\ : STD_LOGIC;
  signal \ram_reg[43][14]_i_7_n_2\ : STD_LOGIC;
  signal \ram_reg[43][14]_i_7_n_3\ : STD_LOGIC;
  signal \ram_reg[43][14]_i_7_n_4\ : STD_LOGIC;
  signal \ram_reg[43][14]_i_7_n_5\ : STD_LOGIC;
  signal \ram_reg[43][14]_i_7_n_6\ : STD_LOGIC;
  signal \ram_reg[43][14]_i_7_n_7\ : STD_LOGIC;
  signal \ram_reg[43][14]_i_8_n_3\ : STD_LOGIC;
  signal \ram_reg[43][1]_i_2_n_0\ : STD_LOGIC;
  signal \ram_reg[43][2]_i_2_n_0\ : STD_LOGIC;
  signal \ram_reg[43][3]_i_2_n_0\ : STD_LOGIC;
  signal \ram_reg[43][4]_i_2_n_0\ : STD_LOGIC;
  signal \ram_reg[43][5]_i_2_n_0\ : STD_LOGIC;
  signal \ram_reg[43]_2\ : STD_LOGIC_VECTOR ( 14 downto 0 );
  signal \ram_reg[44]_1\ : STD_LOGIC_VECTOR ( 38 downto 8 );
  signal \ram_reg[45][11]_i_3_n_1\ : STD_LOGIC;
  signal \ram_reg[45][11]_i_3_n_3\ : STD_LOGIC;
  signal \ram_reg[45][11]_i_3_n_6\ : STD_LOGIC;
  signal \ram_reg[45][11]_i_5_n_0\ : STD_LOGIC;
  signal \ram_reg[45][11]_i_7_n_0\ : STD_LOGIC;
  signal \ram_reg[45][11]_i_7_n_1\ : STD_LOGIC;
  signal \ram_reg[45][11]_i_7_n_2\ : STD_LOGIC;
  signal \ram_reg[45][11]_i_7_n_3\ : STD_LOGIC;
  signal \ram_reg[45][11]_i_7_n_4\ : STD_LOGIC;
  signal \ram_reg[45][11]_i_7_n_5\ : STD_LOGIC;
  signal \ram_reg[45][11]_i_7_n_6\ : STD_LOGIC;
  signal \ram_reg[45][11]_i_8_n_3\ : STD_LOGIC;
  signal \ram_reg[45][8]_i_4_n_0\ : STD_LOGIC;
  signal \ram_reg[45]_0\ : STD_LOGIC_VECTOR ( 15 downto 4 );
  signal s2_clkfbout_mult : STD_LOGIC_VECTOR ( 5 to 5 );
  signal srdy : STD_LOGIC;
  signal state_count : STD_LOGIC_VECTOR ( 4 downto 0 );
  signal \state_count[0]_i_1_n_0\ : STD_LOGIC;
  signal \state_count[1]_i_1_n_0\ : STD_LOGIC;
  signal \state_count[2]_i_1_n_0\ : STD_LOGIC;
  signal \state_count[3]_i_1_n_0\ : STD_LOGIC;
  signal \state_count[4]_i_1_n_0\ : STD_LOGIC;
  signal \state_count[4]_i_2_n_0\ : STD_LOGIC;
  signal \state_count[4]_i_3_n_0\ : STD_LOGIC;
  signal \NLW_ram_reg[26][5]_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_ram_reg[38][5]_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_ram_reg[38][5]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_ram_reg[40][12]_i_19_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_ram_reg[40][12]_i_2_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 2 to 2 );
  signal \NLW_ram_reg[40][12]_i_2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_ram_reg[40][12]_i_3_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_ram_reg[40][12]_i_3_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_ram_reg[40][12]_i_9_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_ram_reg[43][14]_i_3_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_ram_reg[43][14]_i_3_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_ram_reg[43][14]_i_8_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_ram_reg[43][14]_i_8_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_ram_reg[45][11]_i_3_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_ram_reg[45][11]_i_3_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_ram_reg[45][11]_i_7_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_ram_reg[45][11]_i_8_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_ram_reg[45][11]_i_8_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \current_state[1]_i_4\ : label is "soft_lutpair0";
  attribute DONT_TOUCH of \current_state_reg[0]\ : label is std.standard.true;
  attribute FSM_ENCODED_STATES : string;
  attribute FSM_ENCODED_STATES of \current_state_reg[0]\ : label is "RESTART:0001,WAIT_LOCK:0010,WAIT_SEN:0011,ADDRESS:0100,WAIT_A_DRDY:0101,BITMASK:0110,BITSET:0111,WRITE:1000,WAIT_DRDY:1001";
  attribute KEEP : string;
  attribute KEEP of \current_state_reg[0]\ : label is "yes";
  attribute DONT_TOUCH of \current_state_reg[1]\ : label is std.standard.true;
  attribute FSM_ENCODED_STATES of \current_state_reg[1]\ : label is "RESTART:0001,WAIT_LOCK:0010,WAIT_SEN:0011,ADDRESS:0100,WAIT_A_DRDY:0101,BITMASK:0110,BITSET:0111,WRITE:1000,WAIT_DRDY:1001";
  attribute KEEP of \current_state_reg[1]\ : label is "yes";
  attribute DONT_TOUCH of \current_state_reg[2]\ : label is std.standard.true;
  attribute FSM_ENCODED_STATES of \current_state_reg[2]\ : label is "RESTART:0001,WAIT_LOCK:0010,WAIT_SEN:0011,ADDRESS:0100,WAIT_A_DRDY:0101,BITMASK:0110,BITSET:0111,WRITE:1000,WAIT_DRDY:1001";
  attribute KEEP of \current_state_reg[2]\ : label is "yes";
  attribute DONT_TOUCH of \current_state_reg[3]\ : label is std.standard.true;
  attribute FSM_ENCODED_STATES of \current_state_reg[3]\ : label is "RESTART:0001,WAIT_LOCK:0010,WAIT_SEN:0011,ADDRESS:0100,WAIT_A_DRDY:0101,BITMASK:0110,BITSET:0111,WRITE:1000,WAIT_DRDY:1001";
  attribute KEEP of \current_state_reg[3]\ : label is "yes";
  attribute SOFT_HLUTNM of \ram[23][37]_i_1\ : label is "soft_lutpair19";
  attribute SOFT_HLUTNM of \ram[25][10]_i_1\ : label is "soft_lutpair13";
  attribute SOFT_HLUTNM of \ram[25][8]_i_1\ : label is "soft_lutpair12";
  attribute SOFT_HLUTNM of \ram[37][10]_i_1\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \ram[38][6]_i_1\ : label is "soft_lutpair11";
  attribute SOFT_HLUTNM of \ram[39][0]_i_1\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \ram[39][10]_i_1\ : label is "soft_lutpair17";
  attribute SOFT_HLUTNM of \ram[39][6]_i_1\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \ram[39][7]_i_1\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \ram[39][8]_i_1\ : label is "soft_lutpair18";
  attribute SOFT_HLUTNM of \ram[39][9]_i_1\ : label is "soft_lutpair18";
  attribute SOFT_HLUTNM of \ram[40][10]_i_1\ : label is "soft_lutpair11";
  attribute SOFT_HLUTNM of \ram[40][11]_i_1\ : label is "soft_lutpair19";
  attribute SOFT_HLUTNM of \ram[40][12]_i_1\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \ram[40][13]_i_1\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \ram[43][10]_i_5\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \ram[43][10]_i_6\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \ram[43][6]_i_5\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \ram[43][6]_i_6\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \ram[45][11]_i_6\ : label is "soft_lutpair17";
  attribute SOFT_HLUTNM of \ram[45][12]_i_1\ : label is "soft_lutpair13";
  attribute SOFT_HLUTNM of \ram[45][12]_i_2\ : label is "soft_lutpair16";
  attribute SOFT_HLUTNM of \ram[45][12]_i_3\ : label is "soft_lutpair16";
  attribute SOFT_HLUTNM of \ram[45][15]_i_1\ : label is "soft_lutpair12";
  attribute SOFT_HLUTNM of \ram_addr[5]_i_2\ : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of \ram_do[11]_i_2\ : label is "soft_lutpair10";
  attribute SOFT_HLUTNM of \ram_do[12]_i_2\ : label is "soft_lutpair10";
  attribute SOFT_HLUTNM of \ram_do[1]_i_5\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \ram_do[23]_i_2\ : label is "soft_lutpair15";
  attribute SOFT_HLUTNM of \ram_do[23]_i_3\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \ram_do[2]_i_5\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \ram_do[38]_i_2\ : label is "soft_lutpair15";
  attribute SOFT_HLUTNM of \ram_do[38]_i_3\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \ram_do[4]_i_7\ : label is "soft_lutpair9";
  attribute SOFT_HLUTNM of \ram_do[9]_i_3\ : label is "soft_lutpair9";
  attribute SOFT_HLUTNM of \ram_do[9]_i_4\ : label is "soft_lutpair8";
  attribute RAM_STYLE : string;
  attribute RAM_STYLE of \ram_reg[23][37]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[25][10]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[25][8]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[26][0]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[26][1]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[26][2]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[26][5]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[37][10]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[37][13]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[38][0]\ : label is "distributed";
  attribute ADDER_THRESHOLD : integer;
  attribute ADDER_THRESHOLD of \ram_reg[38][0]_i_1\ : label is 35;
  attribute RAM_STYLE of \ram_reg[38][13]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[38][1]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[38][2]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[38][3]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[38][4]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[38][5]\ : label is "distributed";
  attribute ADDER_THRESHOLD of \ram_reg[38][5]_i_1\ : label is 35;
  attribute RAM_STYLE of \ram_reg[38][6]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[39][0]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[39][10]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[39][6]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[39][7]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[39][8]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[39][9]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[40][10]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[40][11]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[40][12]\ : label is "distributed";
  attribute ADDER_THRESHOLD of \ram_reg[40][12]_i_19\ : label is 35;
  attribute ADDER_THRESHOLD of \ram_reg[40][12]_i_3\ : label is 35;
  attribute ADDER_THRESHOLD of \ram_reg[40][12]_i_9\ : label is 35;
  attribute RAM_STYLE of \ram_reg[40][13]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[40][14]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[40][7]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[41][0]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[41][1]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[41][2]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[41][3]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[41][4]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[41][5]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[41][6]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[41][7]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[41][8]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[41][9]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[42][0]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[42][10]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[42][11]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[42][12]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[42][13]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[42][14]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[42][1]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[42][2]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[42][3]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[42][4]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[42][5]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[42][6]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[42][7]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[42][8]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[42][9]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[43][0]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[43][10]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[43][11]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[43][12]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[43][13]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[43][14]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[43][1]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[43][2]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[43][3]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[43][4]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[43][5]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[43][6]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[43][7]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[43][8]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[43][9]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[44][11]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[44][12]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[44][15]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[44][38]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[44][8]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[45][11]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[45][12]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[45][15]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[45][4]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[45][7]\ : label is "distributed";
  attribute RAM_STYLE of \ram_reg[45][8]\ : label is "distributed";
  attribute SOFT_HLUTNM of \state_count[1]_i_1\ : label is "soft_lutpair14";
  attribute SOFT_HLUTNM of \state_count[2]_i_1\ : label is "soft_lutpair14";
  attribute SOFT_HLUTNM of \state_count[4]_i_3\ : label is "soft_lutpair0";
begin
  DI(15 downto 0) <= \^di\(15 downto 0);
  mmcm_rst <= \^mmcm_rst\;
\DADDR[6]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0010"
    )
        port map (
      I0 => current_state(1),
      I1 => current_state(3),
      I2 => current_state(0),
      I3 => current_state(2),
      O => \DADDR[6]_i_1_n_0\
    );
\DADDR[6]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0006"
    )
        port map (
      I0 => current_state(2),
      I1 => current_state(0),
      I2 => current_state(3),
      I3 => current_state(1),
      O => \DADDR[6]_i_2_n_0\
    );
\DADDR_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => \DADDR[6]_i_2_n_0\,
      D => ram_do(32),
      Q => DADDR(0),
      R => \DADDR[6]_i_1_n_0\
    );
\DADDR_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => \DADDR[6]_i_2_n_0\,
      D => ram_do(33),
      Q => DADDR(1),
      R => \DADDR[6]_i_1_n_0\
    );
\DADDR_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => \DADDR[6]_i_2_n_0\,
      D => ram_do(34),
      Q => DADDR(2),
      R => \DADDR[6]_i_1_n_0\
    );
\DADDR_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => \DADDR[6]_i_2_n_0\,
      D => ram_do(35),
      Q => DADDR(3),
      R => \DADDR[6]_i_1_n_0\
    );
\DADDR_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => \DADDR[6]_i_2_n_0\,
      D => ram_do(36),
      Q => DADDR(4),
      R => \DADDR[6]_i_1_n_0\
    );
\DADDR_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => \DADDR[6]_i_2_n_0\,
      D => ram_do(37),
      Q => DADDR(5),
      R => \DADDR[6]_i_1_n_0\
    );
\DADDR_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => \DADDR[6]_i_2_n_0\,
      D => ram_do(38),
      Q => DADDR(6),
      R => \DADDR[6]_i_1_n_0\
    );
DEN_i_1: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0006"
    )
        port map (
      I0 => current_state(3),
      I1 => current_state(2),
      I2 => current_state(0),
      I3 => current_state(1),
      O => next_den
    );
DEN_reg: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => '1',
      D => next_den,
      Q => DEN,
      R => '0'
    );
\DI[0]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"F8F8F808"
    )
        port map (
      I0 => ram_do(38),
      I1 => DO(0),
      I2 => current_state(0),
      I3 => ram_do(0),
      I4 => \^di\(0),
      O => \DI[0]_i_1_n_0\
    );
\DI[10]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"F8F8F808"
    )
        port map (
      I0 => ram_do(29),
      I1 => DO(9),
      I2 => current_state(0),
      I3 => ram_do(10),
      I4 => \^di\(10),
      O => \DI[10]_i_1_n_0\
    );
\DI[11]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"F8F8F808"
    )
        port map (
      I0 => ram_do(27),
      I1 => DO(10),
      I2 => current_state(0),
      I3 => ram_do(11),
      I4 => \^di\(11),
      O => \DI[11]_i_1_n_0\
    );
\DI[12]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"F8F8F808"
    )
        port map (
      I0 => ram_do(28),
      I1 => DO(11),
      I2 => current_state(0),
      I3 => ram_do(12),
      I4 => \^di\(12),
      O => \DI[12]_i_1_n_0\
    );
\DI[13]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"F8F8F808"
    )
        port map (
      I0 => ram_do(29),
      I1 => DO(12),
      I2 => current_state(0),
      I3 => ram_do(13),
      I4 => \^di\(13),
      O => \DI[13]_i_1_n_0\
    );
\DI[14]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"F8F8F808"
    )
        port map (
      I0 => ram_do(30),
      I1 => DO(13),
      I2 => current_state(0),
      I3 => ram_do(14),
      I4 => \^di\(14),
      O => \DI[14]_i_1_n_0\
    );
\DI[15]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0004"
    )
        port map (
      I0 => current_state(3),
      I1 => current_state(0),
      I2 => current_state(2),
      I3 => current_state(1),
      O => \DI[15]_i_1_n_0\
    );
\DI[15]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"00A4"
    )
        port map (
      I0 => current_state(2),
      I1 => current_state(0),
      I2 => current_state(1),
      I3 => current_state(3),
      O => \DI[15]_i_2_n_0\
    );
\DI[15]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"F8F8F808"
    )
        port map (
      I0 => ram_do(31),
      I1 => DO(14),
      I2 => current_state(0),
      I3 => ram_do(15),
      I4 => \^di\(15),
      O => \DI[15]_i_3_n_0\
    );
\DI[1]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"F8F8F808"
    )
        port map (
      I0 => ram_do(38),
      I1 => DO(1),
      I2 => current_state(0),
      I3 => ram_do(1),
      I4 => \^di\(1),
      O => \DI[1]_i_1_n_0\
    );
\DI[2]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"F8F8F808"
    )
        port map (
      I0 => ram_do(38),
      I1 => DO(2),
      I2 => current_state(0),
      I3 => ram_do(2),
      I4 => \^di\(2),
      O => \DI[2]_i_1_n_0\
    );
\DI[3]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"F8F8F808"
    )
        port map (
      I0 => ram_do(38),
      I1 => DO(3),
      I2 => current_state(0),
      I3 => ram_do(3),
      I4 => \^di\(3),
      O => \DI[3]_i_1_n_0\
    );
\DI[4]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"F8F8F808"
    )
        port map (
      I0 => ram_do(23),
      I1 => DO(4),
      I2 => current_state(0),
      I3 => ram_do(4),
      I4 => \^di\(4),
      O => \DI[4]_i_1_n_0\
    );
\DI[5]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"F8F8F808"
    )
        port map (
      I0 => ram_do(38),
      I1 => DO(5),
      I2 => current_state(0),
      I3 => ram_do(5),
      I4 => \^di\(5),
      O => \DI[5]_i_1_n_0\
    );
\DI[6]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"F8F8F808"
    )
        port map (
      I0 => ram_do(38),
      I1 => DO(6),
      I2 => current_state(0),
      I3 => ram_do(6),
      I4 => \^di\(6),
      O => \DI[6]_i_1_n_0\
    );
\DI[7]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"F8F8F808"
    )
        port map (
      I0 => ram_do(23),
      I1 => DO(7),
      I2 => current_state(0),
      I3 => ram_do(7),
      I4 => \^di\(7),
      O => \DI[7]_i_1_n_0\
    );
\DI[8]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E0"
    )
        port map (
      I0 => \^di\(8),
      I1 => ram_do(8),
      I2 => current_state(0),
      O => \DI[8]_i_1_n_0\
    );
\DI[9]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"F8F8F808"
    )
        port map (
      I0 => ram_do(38),
      I1 => DO(8),
      I2 => current_state(0),
      I3 => ram_do(9),
      I4 => \^di\(9),
      O => \DI[9]_i_1_n_0\
    );
\DI_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => \DI[15]_i_2_n_0\,
      D => \DI[0]_i_1_n_0\,
      Q => \^di\(0),
      R => \DI[15]_i_1_n_0\
    );
\DI_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => \DI[15]_i_2_n_0\,
      D => \DI[10]_i_1_n_0\,
      Q => \^di\(10),
      R => \DI[15]_i_1_n_0\
    );
\DI_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => \DI[15]_i_2_n_0\,
      D => \DI[11]_i_1_n_0\,
      Q => \^di\(11),
      R => \DI[15]_i_1_n_0\
    );
\DI_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => \DI[15]_i_2_n_0\,
      D => \DI[12]_i_1_n_0\,
      Q => \^di\(12),
      R => \DI[15]_i_1_n_0\
    );
\DI_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => \DI[15]_i_2_n_0\,
      D => \DI[13]_i_1_n_0\,
      Q => \^di\(13),
      R => \DI[15]_i_1_n_0\
    );
\DI_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => \DI[15]_i_2_n_0\,
      D => \DI[14]_i_1_n_0\,
      Q => \^di\(14),
      R => \DI[15]_i_1_n_0\
    );
\DI_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => \DI[15]_i_2_n_0\,
      D => \DI[15]_i_3_n_0\,
      Q => \^di\(15),
      R => \DI[15]_i_1_n_0\
    );
\DI_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => \DI[15]_i_2_n_0\,
      D => \DI[1]_i_1_n_0\,
      Q => \^di\(1),
      R => \DI[15]_i_1_n_0\
    );
\DI_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => \DI[15]_i_2_n_0\,
      D => \DI[2]_i_1_n_0\,
      Q => \^di\(2),
      R => \DI[15]_i_1_n_0\
    );
\DI_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => \DI[15]_i_2_n_0\,
      D => \DI[3]_i_1_n_0\,
      Q => \^di\(3),
      R => \DI[15]_i_1_n_0\
    );
\DI_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => \DI[15]_i_2_n_0\,
      D => \DI[4]_i_1_n_0\,
      Q => \^di\(4),
      R => \DI[15]_i_1_n_0\
    );
\DI_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => \DI[15]_i_2_n_0\,
      D => \DI[5]_i_1_n_0\,
      Q => \^di\(5),
      R => \DI[15]_i_1_n_0\
    );
\DI_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => \DI[15]_i_2_n_0\,
      D => \DI[6]_i_1_n_0\,
      Q => \^di\(6),
      R => \DI[15]_i_1_n_0\
    );
\DI_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => \DI[15]_i_2_n_0\,
      D => \DI[7]_i_1_n_0\,
      Q => \^di\(7),
      R => \DI[15]_i_1_n_0\
    );
\DI_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => \DI[15]_i_2_n_0\,
      D => \DI[8]_i_1_n_0\,
      Q => \^di\(8),
      R => \DI[15]_i_1_n_0\
    );
\DI_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => \DI[15]_i_2_n_0\,
      D => \DI[9]_i_1_n_0\,
      Q => \^di\(9),
      R => \DI[15]_i_1_n_0\
    );
DWE_i_1: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0010"
    )
        port map (
      I0 => current_state(0),
      I1 => current_state(2),
      I2 => current_state(3),
      I3 => current_state(1),
      O => next_dwe
    );
DWE_reg: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => '1',
      D => next_dwe,
      Q => DWE,
      R => '0'
    );
\FSM_sequential_state[0]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"CD77CD22"
    )
        port map (
      I0 => state(1),
      I1 => state(2),
      I2 => reconfig_req,
      I3 => state(0),
      I4 => srdy,
      O => \FSM_sequential_state_reg[1]\
    );
RST_MMCM_PLL_i_1: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFEF0006"
    )
        port map (
      I0 => current_state(0),
      I1 => current_state(2),
      I2 => current_state(1),
      I3 => current_state(3),
      I4 => \^mmcm_rst\,
      O => RST_MMCM_PLL_i_1_n_0
    );
RST_MMCM_PLL_reg: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => '1',
      D => RST_MMCM_PLL_i_1_n_0,
      Q => \^mmcm_rst\,
      R => '0'
    );
SRDY_i_1: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000020"
    )
        port map (
      I0 => current_state(1),
      I1 => current_state(2),
      I2 => locked,
      I3 => current_state(3),
      I4 => current_state(0),
      O => next_srdy
    );
SRDY_reg: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => '1',
      D => next_srdy,
      Q => srdy,
      R => '0'
    );
\current_state[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FDFFFFFFFDFF0000"
    )
        port map (
      I0 => drp_drdy,
      I1 => current_state(2),
      I2 => current_state(1),
      I3 => current_state(0),
      I4 => current_state(3),
      I5 => \current_state[0]_i_2_n_0\,
      O => next_state(0)
    );
\current_state[0]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"03034444FFCCFFFF"
    )
        port map (
      I0 => drp_drdy,
      I1 => current_state(2),
      I2 => \ram_addr_reg[0]_0\,
      I3 => locked,
      I4 => current_state(1),
      I5 => current_state(0),
      O => \current_state[0]_i_2_n_0\
    );
\current_state[1]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"03BBFF00"
    )
        port map (
      I0 => drp_drdy,
      I1 => current_state(2),
      I2 => \ram_addr_reg[0]_0\,
      I3 => current_state(1),
      I4 => current_state(0),
      O => \current_state[1]_i_2_n_0\
    );
\current_state[1]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000020"
    )
        port map (
      I0 => drp_drdy,
      I1 => \current_state[1]_i_4_n_0\,
      I2 => current_state(0),
      I3 => current_state(2),
      I4 => current_state(1),
      O => \current_state[1]_i_3_n_0\
    );
\current_state[1]_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFFE"
    )
        port map (
      I0 => state_count(1),
      I1 => state_count(4),
      I2 => state_count(0),
      I3 => state_count(2),
      I4 => state_count(3),
      O => \current_state[1]_i_4_n_0\
    );
\current_state[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0338003830303030"
    )
        port map (
      I0 => \current_state[2]_i_2_n_0\,
      I1 => current_state(3),
      I2 => current_state(2),
      I3 => current_state(1),
      I4 => \ram_addr_reg[0]_0\,
      I5 => current_state(0),
      O => next_state(2)
    );
\current_state[2]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAAAAAAAAA8"
    )
        port map (
      I0 => drp_drdy,
      I1 => state_count(3),
      I2 => state_count(2),
      I3 => state_count(0),
      I4 => state_count(4),
      I5 => state_count(1),
      O => \current_state[2]_i_2_n_0\
    );
\current_state[3]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"3000040C"
    )
        port map (
      I0 => drp_drdy,
      I1 => current_state(3),
      I2 => current_state(2),
      I3 => current_state(0),
      I4 => current_state(1),
      O => next_state(3)
    );
\current_state_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '1'
    )
        port map (
      C => CLK,
      CE => '1',
      D => next_state(0),
      Q => current_state(0),
      R => '0'
    );
\current_state_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => '1',
      D => next_state(1),
      Q => current_state(1),
      R => '0'
    );
\current_state_reg[1]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \current_state[1]_i_2_n_0\,
      I1 => \current_state[1]_i_3_n_0\,
      O => next_state(1),
      S => current_state(3)
    );
\current_state_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => '1',
      D => next_state(2),
      Q => current_state(2),
      R => '0'
    );
\current_state_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => '1',
      D => next_state(3),
      Q => current_state(3),
      R => '0'
    );
\ram[23][37]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \ram_reg[23]_11\(37),
      I1 => \ram_reg[26][0]_0\,
      O => \ram[23][37]_i_1_n_0\
    );
\ram[25][10]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => timing_sel_imm(0),
      I1 => timing_sel_imm(1),
      O => \ram[25][10]_i_1_n_0\
    );
\ram[25][8]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => timing_sel_imm(1),
      I1 => timing_sel_imm(0),
      O => \ram[25][8]_i_1_n_0\
    );
\ram[26][5]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => timing_sel_imm(0),
      I1 => timing_sel_imm(1),
      O => \ram[26][5]_i_2_n_0\
    );
\ram[26][5]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => timing_sel_imm(0),
      I1 => timing_sel_imm(1),
      O => \ram[26][5]_i_3_n_0\
    );
\ram[26][5]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => timing_sel_imm(1),
      I1 => timing_sel_imm(0),
      O => \ram[26][5]_i_4_n_0\
    );
\ram[26][5]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => timing_sel_imm(0),
      I1 => timing_sel_imm(1),
      O => \ram[26][5]_i_5_n_0\
    );
\ram[26][5]_i_6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => timing_sel_imm(0),
      I1 => timing_sel_imm(1),
      O => \ram[26][5]_i_6_n_0\
    );
\ram[37][10]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6662"
    )
        port map (
      I0 => timing_sel_imm(1),
      I1 => timing_sel_imm(0),
      I2 => \ram_reg[40][12]_i_2_n_0\,
      I3 => \ram_reg[40][12]_i_3_n_2\,
      O => \ram[37][10]_i_1_n_0\
    );
\ram[38][0]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => timing_sel_imm(0),
      I1 => timing_sel_imm(1),
      O => \ram[38][0]_i_2_n_0\
    );
\ram[38][0]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => timing_sel_imm(1),
      I1 => timing_sel_imm(0),
      O => \ram[38][0]_i_3_n_0\
    );
\ram[38][0]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => timing_sel_imm(0),
      I1 => timing_sel_imm(1),
      O => \ram[38][0]_i_4_n_0\
    );
\ram[38][0]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => timing_sel_imm(1),
      I1 => timing_sel_imm(0),
      O => \ram[38][0]_i_5_n_0\
    );
\ram[38][13]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => timing_sel_imm(0),
      I1 => timing_sel_imm(1),
      O => s2_clkfbout_mult(5)
    );
\ram[38][6]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => timing_sel_imm(1),
      I1 => timing_sel_imm(0),
      O => \ram[38][6]_i_1_n_0\
    );
\ram[39][0]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2226"
    )
        port map (
      I0 => timing_sel_imm(1),
      I1 => timing_sel_imm(0),
      I2 => \ram_reg[40][12]_i_2_n_0\,
      I3 => \ram_reg[40][12]_i_3_n_2\,
      O => \ram[39][0]_i_1_n_0\
    );
\ram[39][10]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => timing_sel_imm(1),
      I1 => timing_sel_imm(0),
      O => \ram[39][10]_i_1_n_0\
    );
\ram[39][6]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0FE0"
    )
        port map (
      I0 => \ram_reg[40][12]_i_2_n_0\,
      I1 => \ram_reg[40][12]_i_3_n_2\,
      I2 => timing_sel_imm(1),
      I3 => timing_sel_imm(0),
      O => \ram[39][6]_i_1_n_0\
    );
\ram[39][7]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0F10"
    )
        port map (
      I0 => \ram_reg[40][12]_i_3_n_2\,
      I1 => \ram_reg[40][12]_i_2_n_0\,
      I2 => timing_sel_imm(1),
      I3 => timing_sel_imm(0),
      O => \ram[39][7]_i_1_n_0\
    );
\ram[39][8]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"4"
    )
        port map (
      I0 => timing_sel_imm(1),
      I1 => timing_sel_imm(0),
      O => \ram[39][8]_i_1_n_0\
    );
\ram[39][9]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => timing_sel_imm(1),
      I1 => timing_sel_imm(0),
      O => \ram[39][9]_i_1_n_0\
    );
\ram[40][10]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"4440"
    )
        port map (
      I0 => timing_sel_imm(0),
      I1 => timing_sel_imm(1),
      I2 => \ram_reg[40][12]_i_3_n_2\,
      I3 => \ram_reg[40][12]_i_2_n_0\,
      O => p_1_out(10)
    );
\ram[40][11]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \ram_reg[26][0]_0\,
      I1 => \ram_reg[40]_5\(11),
      O => \ram[40][11]_i_1_n_0\
    );
\ram[40][12]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"3E13"
    )
        port map (
      I0 => \ram_reg[40][12]_i_2_n_0\,
      I1 => \ram_reg[40][12]_i_3_n_2\,
      I2 => timing_sel_imm(1),
      I3 => timing_sel_imm(0),
      O => \ram[40][12]_i_1_n_0\
    );
\ram[40][12]_i_10\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8A"
    )
        port map (
      I0 => \ram_reg[40][12]_i_2_n_6\,
      I1 => timing_sel_imm(1),
      I2 => timing_sel_imm(0),
      O => \ram[40][12]_i_10_n_0\
    );
\ram[40][12]_i_11\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \ram_reg[40][12]_i_2_n_5\,
      I1 => \ram_reg[40][12]_i_2_n_0\,
      I2 => timing_sel_imm(1),
      I3 => timing_sel_imm(0),
      O => \ram[40][12]_i_11_n_0\
    );
\ram[40][12]_i_12\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"D02F"
    )
        port map (
      I0 => timing_sel_imm(0),
      I1 => timing_sel_imm(1),
      I2 => \ram_reg[40][12]_i_2_n_6\,
      I3 => \ram_reg[40][12]_i_2_n_5\,
      O => \ram[40][12]_i_12_n_0\
    );
\ram[40][12]_i_13\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => timing_sel_imm(0),
      I1 => timing_sel_imm(1),
      O => \ram[40][12]_i_13_n_0\
    );
\ram[40][12]_i_14\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => timing_sel_imm(1),
      I1 => timing_sel_imm(0),
      O => \ram[40][12]_i_14_n_0\
    );
\ram[40][12]_i_15\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"D"
    )
        port map (
      I0 => timing_sel_imm(1),
      I1 => timing_sel_imm(0),
      O => \ram[40][12]_i_15_n_0\
    );
\ram[40][12]_i_16\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"D"
    )
        port map (
      I0 => timing_sel_imm(1),
      I1 => timing_sel_imm(0),
      O => \ram[40][12]_i_16_n_0\
    );
\ram[40][12]_i_17\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => timing_sel_imm(0),
      I1 => timing_sel_imm(1),
      O => \ram[40][12]_i_17_n_0\
    );
\ram[40][12]_i_18\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"D"
    )
        port map (
      I0 => timing_sel_imm(1),
      I1 => timing_sel_imm(0),
      O => \ram[40][12]_i_18_n_0\
    );
\ram[40][12]_i_20\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"EB"
    )
        port map (
      I0 => \ram_reg[40][12]_i_4_n_6\,
      I1 => timing_sel_imm(1),
      I2 => timing_sel_imm(0),
      O => \ram[40][12]_i_20_n_0\
    );
\ram[40][12]_i_21\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9969"
    )
        port map (
      I0 => \ram_reg[40][12]_i_2_n_7\,
      I1 => \ram_reg[40][12]_i_2_n_6\,
      I2 => timing_sel_imm(0),
      I3 => timing_sel_imm(1),
      O => \ram[40][12]_i_21_n_0\
    );
\ram[40][12]_i_22\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \ram_reg[40][12]_i_4_n_4\,
      I1 => \ram_reg[40][12]_i_2_n_7\,
      O => \ram[40][12]_i_22_n_0\
    );
\ram[40][12]_i_23\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \ram_reg[40][12]_i_4_n_5\,
      I1 => \ram_reg[40][12]_i_4_n_4\,
      O => \ram[40][12]_i_23_n_0\
    );
\ram[40][12]_i_24\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F906"
    )
        port map (
      I0 => timing_sel_imm(0),
      I1 => timing_sel_imm(1),
      I2 => \ram_reg[40][12]_i_4_n_6\,
      I3 => \ram_reg[40][12]_i_4_n_5\,
      O => \ram[40][12]_i_24_n_0\
    );
\ram[40][12]_i_25\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"EF"
    )
        port map (
      I0 => \ram_reg[40][12]_i_4_n_7\,
      I1 => timing_sel_imm(0),
      I2 => timing_sel_imm(1),
      O => \ram[40][12]_i_25_n_0\
    );
\ram[40][12]_i_26\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => timing_sel_imm(0),
      I1 => timing_sel_imm(1),
      O => \ram[40][12]_i_26_n_0\
    );
\ram[40][12]_i_27\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"39C3"
    )
        port map (
      I0 => \ram_reg[40][12]_i_4_n_7\,
      I1 => \ram_reg[40][12]_i_4_n_6\,
      I2 => timing_sel_imm(0),
      I3 => timing_sel_imm(1),
      O => \ram[40][12]_i_27_n_0\
    );
\ram[40][12]_i_28\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B4"
    )
        port map (
      I0 => timing_sel_imm(0),
      I1 => timing_sel_imm(1),
      I2 => \ram_reg[40][12]_i_4_n_7\,
      O => \ram[40][12]_i_28_n_0\
    );
\ram[40][12]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => timing_sel_imm(1),
      I1 => timing_sel_imm(0),
      O => \ram[40][12]_i_5_n_0\
    );
\ram[40][12]_i_6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => timing_sel_imm(1),
      I1 => timing_sel_imm(0),
      O => \ram[40][12]_i_6_n_0\
    );
\ram[40][12]_i_7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => timing_sel_imm(0),
      I1 => timing_sel_imm(1),
      O => \ram[40][12]_i_7_n_0\
    );
\ram[40][12]_i_8\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"D"
    )
        port map (
      I0 => timing_sel_imm(1),
      I1 => timing_sel_imm(0),
      O => \ram[40][12]_i_8_n_0\
    );
\ram[40][13]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0004"
    )
        port map (
      I0 => \ram_reg[40][12]_i_2_n_0\,
      I1 => timing_sel_imm(0),
      I2 => timing_sel_imm(1),
      I3 => \ram_reg[40][12]_i_3_n_2\,
      O => \ram[40][13]_i_1_n_0\
    );
\ram[41][0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8B8B8B8FF33CC00"
    )
        port map (
      I0 => \ram[43][11]_i_2_n_0\,
      I1 => \ram_reg[43][14]_i_3_n_6\,
      I2 => \ram[43][11]_i_3_n_0\,
      I3 => \ram[43][11]_i_5_n_0\,
      I4 => \ram[42][4]_i_2_n_0\,
      I5 => \ram_reg[43][14]_i_3_n_7\,
      O => p_17_in(0)
    );
\ram[41][1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FF33CC00B8B8B8B8"
    )
        port map (
      I0 => \ram[43][12]_i_5_n_0\,
      I1 => \ram_reg[43][14]_i_3_n_6\,
      I2 => \ram[42][5]_i_2_n_0\,
      I3 => \ram[43][12]_i_2_n_0\,
      I4 => \ram[43][12]_i_3_n_0\,
      I5 => \ram_reg[43][14]_i_3_n_7\,
      O => p_17_in(1)
    );
\ram[41][2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8B8B8B8FF33CC00"
    )
        port map (
      I0 => \ram[43][13]_i_2_n_0\,
      I1 => \ram_reg[43][14]_i_3_n_6\,
      I2 => \ram[43][13]_i_3_n_0\,
      I3 => \ram[43][13]_i_5_n_0\,
      I4 => \ram[42][6]_i_2_n_0\,
      I5 => \ram_reg[43][14]_i_3_n_7\,
      O => p_17_in(2)
    );
\ram[41][3]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FF33CC00B8B8B8B8"
    )
        port map (
      I0 => \ram[43][14]_i_6_n_0\,
      I1 => \ram_reg[43][14]_i_3_n_6\,
      I2 => \ram[42][7]_i_2_n_0\,
      I3 => \ram[43][14]_i_2_n_0\,
      I4 => \ram[43][14]_i_4_n_0\,
      I5 => \ram_reg[43][14]_i_3_n_7\,
      O => p_17_in(3)
    );
\ram[41][4]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \ram[41][4]_i_2_n_0\,
      I1 => \ram_reg[43][14]_i_3_n_6\,
      I2 => \ram[42][8]_i_3_n_0\,
      I3 => \ram_reg[43][14]_i_3_n_7\,
      I4 => \ram_reg[42][8]_i_2_n_0\,
      O => p_17_in(4)
    );
\ram[41][4]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000040E7E7F97DB"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_7_n_4\,
      I3 => \ram_reg[43][14]_i_7_n_6\,
      I4 => \ram_reg[43][14]_i_7_n_5\,
      I5 => \ram_reg[43][14]_i_8_n_3\,
      O => \ram[41][4]_i_2_n_0\
    );
\ram[41][5]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \ram[41][5]_i_2_n_0\,
      I1 => \ram_reg[43][14]_i_3_n_6\,
      I2 => \ram[42][9]_i_3_n_0\,
      I3 => \ram_reg[43][14]_i_3_n_7\,
      I4 => \ram_reg[42][9]_i_2_n_0\,
      O => p_17_in(5)
    );
\ram[41][5]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0B060815010B0D6A"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_4\,
      I4 => \ram_reg[43][14]_i_7_n_5\,
      I5 => \ram_reg[43][14]_i_7_n_6\,
      O => \ram[41][5]_i_2_n_0\
    );
\ram[41][6]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \ram[41][6]_i_2_n_0\,
      I1 => \ram_reg[43][14]_i_3_n_6\,
      I2 => \ram[43][0]_i_3_n_0\,
      I3 => \ram_reg[43][14]_i_3_n_7\,
      I4 => \ram_reg[43][0]_i_2_n_0\,
      O => p_17_in(6)
    );
\ram[41][6]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0B070D0B0E3D0F7E"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_4\,
      I4 => \ram_reg[43][14]_i_7_n_6\,
      I5 => \ram_reg[43][14]_i_7_n_5\,
      O => \ram[41][6]_i_2_n_0\
    );
\ram[41][7]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \ram[41][7]_i_2_n_0\,
      I1 => \ram_reg[43][14]_i_3_n_6\,
      I2 => \ram[43][1]_i_3_n_0\,
      I3 => \ram_reg[43][14]_i_3_n_7\,
      I4 => \ram_reg[43][1]_i_2_n_0\,
      O => p_17_in(7)
    );
\ram[41][7]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0B060815050B0D4A"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_4\,
      I4 => \ram_reg[43][14]_i_7_n_5\,
      I5 => \ram_reg[43][14]_i_7_n_6\,
      O => \ram[41][7]_i_2_n_0\
    );
\ram[41][8]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \ram[41][8]_i_2_n_0\,
      I1 => \ram_reg[43][14]_i_3_n_6\,
      I2 => \ram[43][2]_i_3_n_0\,
      I3 => \ram_reg[43][14]_i_3_n_7\,
      I4 => \ram_reg[43][2]_i_2_n_0\,
      O => p_17_in(8)
    );
\ram[41][8]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"03020A5004010408"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_4\,
      I4 => \ram_reg[43][14]_i_7_n_5\,
      I5 => \ram_reg[43][14]_i_7_n_6\,
      O => \ram[41][8]_i_2_n_0\
    );
\ram[41][9]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \ram[41][9]_i_2_n_0\,
      I1 => \ram_reg[43][14]_i_3_n_6\,
      I2 => \ram[43][3]_i_3_n_0\,
      I3 => \ram_reg[43][14]_i_3_n_7\,
      I4 => \ram_reg[43][3]_i_2_n_0\,
      O => p_17_in(9)
    );
\ram[41][9]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"090708030C79063C"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_4\,
      I4 => \ram_reg[43][14]_i_7_n_6\,
      I5 => \ram_reg[43][14]_i_7_n_5\,
      O => \ram[41][9]_i_2_n_0\
    );
\ram[42][0]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \ram[43][6]_i_4_n_0\,
      I1 => \ram_reg[43][14]_i_3_n_7\,
      I2 => \ram[43][6]_i_3_n_0\,
      I3 => \ram_reg[43][14]_i_3_n_6\,
      I4 => \ram[42][0]_i_2_n_0\,
      O => p_18_in(0)
    );
\ram[42][0]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"09070D0B0E6D0F3E"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_4\,
      I4 => \ram_reg[43][14]_i_7_n_6\,
      I5 => \ram_reg[43][14]_i_7_n_5\,
      O => \ram[42][0]_i_2_n_0\
    );
\ram[42][10]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \ram[42][10]_i_2_n_0\,
      I1 => \ram_reg[43][14]_i_3_n_6\,
      I2 => \ram[43][4]_i_3_n_0\,
      I3 => \ram_reg[43][14]_i_3_n_7\,
      I4 => \ram_reg[43][4]_i_2_n_0\,
      O => p_18_in(10)
    );
\ram[42][10]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000294AD294A"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_7_n_6\,
      I3 => \ram_reg[43][14]_i_7_n_5\,
      I4 => \ram_reg[43][14]_i_7_n_4\,
      I5 => \ram_reg[43][14]_i_8_n_3\,
      O => \ram[42][10]_i_2_n_0\
    );
\ram[42][11]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \ram[42][11]_i_2_n_0\,
      I1 => \ram_reg[43][14]_i_3_n_6\,
      I2 => \ram[43][5]_i_3_n_0\,
      I3 => \ram_reg[43][14]_i_3_n_7\,
      I4 => \ram_reg[43][5]_i_2_n_0\,
      O => p_18_in(11)
    );
\ram[42][11]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"09070C0B0E3D0F7E"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_4\,
      I4 => \ram_reg[43][14]_i_7_n_6\,
      I5 => \ram_reg[43][14]_i_7_n_5\,
      O => \ram[42][11]_i_2_n_0\
    );
\ram[42][12]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FF33CC00B8B8B8B8"
    )
        port map (
      I0 => \ram[43][6]_i_2_n_0\,
      I1 => \ram_reg[43][14]_i_3_n_6\,
      I2 => \ram[43][6]_i_3_n_0\,
      I3 => \ram[42][12]_i_2_n_0\,
      I4 => \ram[42][12]_i_3_n_0\,
      I5 => \ram_reg[43][14]_i_3_n_7\,
      O => p_18_in(12)
    );
\ram[42][12]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0B070D0B0E7D073E"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_4\,
      I4 => \ram_reg[43][14]_i_7_n_6\,
      I5 => \ram_reg[43][14]_i_7_n_5\,
      O => \ram[42][12]_i_2_n_0\
    );
\ram[42][12]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0E0D0F0E079F0B97"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_4\,
      I4 => \ram_reg[43][14]_i_7_n_6\,
      I5 => \ram_reg[43][14]_i_7_n_5\,
      O => \ram[42][12]_i_3_n_0\
    );
\ram[42][13]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FF33CC00B8B8B8B8"
    )
        port map (
      I0 => \ram[43][7]_i_2_n_0\,
      I1 => \ram_reg[43][14]_i_3_n_6\,
      I2 => \ram[43][7]_i_3_n_0\,
      I3 => \ram[42][13]_i_2_n_0\,
      I4 => \ram[43][7]_i_4_n_0\,
      I5 => \ram_reg[43][14]_i_3_n_7\,
      O => p_18_in(13)
    );
\ram[42][13]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0A06053D0C0B0A56"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_5\,
      I4 => \ram_reg[43][14]_i_7_n_4\,
      I5 => \ram_reg[43][14]_i_7_n_6\,
      O => \ram[42][13]_i_2_n_0\
    );
\ram[42][14]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FF33CC00B8B8B8B8"
    )
        port map (
      I0 => \ram[43][8]_i_2_n_0\,
      I1 => \ram_reg[43][14]_i_3_n_6\,
      I2 => \ram[43][8]_i_3_n_0\,
      I3 => \ram[42][14]_i_2_n_0\,
      I4 => \ram[43][8]_i_4_n_0\,
      I5 => \ram_reg[43][14]_i_3_n_7\,
      O => p_18_in(14)
    );
\ram[42][14]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0E0D0E0E072F03D7"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_4\,
      I4 => \ram_reg[43][14]_i_7_n_6\,
      I5 => \ram_reg[43][14]_i_7_n_5\,
      O => \ram[42][14]_i_2_n_0\
    );
\ram[42][1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8FFB833B8CCB800"
    )
        port map (
      I0 => \ram[43][7]_i_4_n_0\,
      I1 => \ram_reg[43][14]_i_3_n_6\,
      I2 => \ram[43][7]_i_5_n_0\,
      I3 => \ram_reg[43][14]_i_3_n_7\,
      I4 => \ram[43][7]_i_3_n_0\,
      I5 => \ram[42][1]_i_2_n_0\,
      O => p_18_in(1)
    );
\ram[42][1]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00A60A5D00D305A6"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_7_n_5\,
      I3 => \ram_reg[43][14]_i_8_n_3\,
      I4 => \ram_reg[43][14]_i_7_n_4\,
      I5 => \ram_reg[43][14]_i_7_n_6\,
      O => \ram[42][1]_i_2_n_0\
    );
\ram[42][2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8FFB833B8CCB800"
    )
        port map (
      I0 => \ram[43][8]_i_4_n_0\,
      I1 => \ram_reg[43][14]_i_3_n_6\,
      I2 => \ram[43][8]_i_5_n_0\,
      I3 => \ram_reg[43][14]_i_3_n_7\,
      I4 => \ram[43][8]_i_3_n_0\,
      I5 => \ram[42][2]_i_2_n_0\,
      O => p_18_in(2)
    );
\ram[42][2]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0C0D0F0E07BF03D7"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_4\,
      I4 => \ram_reg[43][14]_i_7_n_6\,
      I5 => \ram_reg[43][14]_i_7_n_5\,
      O => \ram[42][2]_i_2_n_0\
    );
\ram[42][3]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8FFB833B8CCB800"
    )
        port map (
      I0 => \ram[43][10]_i_3_n_0\,
      I1 => \ram_reg[43][14]_i_3_n_6\,
      I2 => \ram[43][9]_i_2_n_0\,
      I3 => \ram_reg[43][14]_i_3_n_7\,
      I4 => \ram[42][3]_i_2_n_0\,
      I5 => \ram[42][3]_i_3_n_0\,
      O => p_18_in(3)
    );
\ram[42][3]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0B060895050B0D6A"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_4\,
      I4 => \ram_reg[43][14]_i_7_n_5\,
      I5 => \ram_reg[43][14]_i_7_n_6\,
      O => \ram[42][3]_i_2_n_0\
    );
\ram[42][3]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"080605BD0C030A56"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_5\,
      I4 => \ram_reg[43][14]_i_7_n_4\,
      I5 => \ram_reg[43][14]_i_7_n_6\,
      O => \ram[42][3]_i_3_n_0\
    );
\ram[42][4]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8FFB833B8CCB800"
    )
        port map (
      I0 => \ram[43][11]_i_5_n_0\,
      I1 => \ram_reg[43][14]_i_3_n_6\,
      I2 => \ram[42][4]_i_2_n_0\,
      I3 => \ram_reg[43][14]_i_3_n_7\,
      I4 => \ram[43][11]_i_3_n_0\,
      I5 => \ram[42][4]_i_3_n_0\,
      O => p_18_in(4)
    );
\ram[42][4]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"010105280A000694"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_4\,
      I4 => \ram_reg[43][14]_i_7_n_5\,
      I5 => \ram_reg[43][14]_i_7_n_6\,
      O => \ram[42][4]_i_2_n_0\
    );
\ram[42][4]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0086090400D90482"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_7_n_5\,
      I3 => \ram_reg[43][14]_i_8_n_3\,
      I4 => \ram_reg[43][14]_i_7_n_4\,
      I5 => \ram_reg[43][14]_i_7_n_6\,
      O => \ram[42][4]_i_3_n_0\
    );
\ram[42][5]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8FFB833B8CCB800"
    )
        port map (
      I0 => \ram[43][12]_i_5_n_0\,
      I1 => \ram_reg[43][14]_i_3_n_6\,
      I2 => \ram[42][5]_i_2_n_0\,
      I3 => \ram_reg[43][14]_i_3_n_7\,
      I4 => \ram[43][12]_i_3_n_0\,
      I5 => \ram[42][5]_i_3_n_0\,
      O => p_18_in(5)
    );
\ram[42][5]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0C0C03090E073C9E"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_6\,
      I4 => \ram_reg[43][14]_i_7_n_4\,
      I5 => \ram_reg[43][14]_i_7_n_5\,
      O => \ram[42][5]_i_2_n_0\
    );
\ram[42][5]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0E09038E0E0C03D7"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_4\,
      I4 => \ram_reg[43][14]_i_7_n_5\,
      I5 => \ram_reg[43][14]_i_7_n_6\,
      O => \ram[42][5]_i_3_n_0\
    );
\ram[42][6]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8FFB833B8CCB800"
    )
        port map (
      I0 => \ram[43][13]_i_5_n_0\,
      I1 => \ram_reg[43][14]_i_3_n_6\,
      I2 => \ram[42][6]_i_2_n_0\,
      I3 => \ram_reg[43][14]_i_3_n_7\,
      I4 => \ram[43][13]_i_3_n_0\,
      I5 => \ram[42][6]_i_3_n_0\,
      O => p_18_in(6)
    );
\ram[42][6]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"05090D2A0A040235"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_4\,
      I4 => \ram_reg[43][14]_i_7_n_5\,
      I5 => \ram_reg[43][14]_i_7_n_6\,
      O => \ram[42][6]_i_2_n_0\
    );
\ram[42][6]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0A04050A06050912"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_4\,
      I4 => \ram_reg[43][14]_i_7_n_6\,
      I5 => \ram_reg[43][14]_i_7_n_5\,
      O => \ram[42][6]_i_3_n_0\
    );
\ram[42][7]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8FFB833B8CCB800"
    )
        port map (
      I0 => \ram[43][14]_i_6_n_0\,
      I1 => \ram_reg[43][14]_i_3_n_6\,
      I2 => \ram[42][7]_i_2_n_0\,
      I3 => \ram_reg[43][14]_i_3_n_7\,
      I4 => \ram[43][14]_i_4_n_0\,
      I5 => \ram[42][7]_i_3_n_0\,
      O => p_18_in(7)
    );
\ram[42][7]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0D0B0F5E0E0D039F"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_4\,
      I4 => \ram_reg[43][14]_i_7_n_5\,
      I5 => \ram_reg[43][14]_i_7_n_6\,
      O => \ram[42][7]_i_2_n_0\
    );
\ram[42][7]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0E0D0F0E03BF0B97"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_4\,
      I4 => \ram_reg[43][14]_i_7_n_6\,
      I5 => \ram_reg[43][14]_i_7_n_5\,
      O => \ram[42][7]_i_3_n_0\
    );
\ram[42][8]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \ram_reg[42][8]_i_2_n_0\,
      I1 => \ram_reg[43][14]_i_3_n_7\,
      I2 => \ram[42][8]_i_3_n_0\,
      I3 => \ram_reg[43][14]_i_3_n_6\,
      I4 => \ram[42][8]_i_4_n_0\,
      O => p_18_in(8)
    );
\ram[42][8]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0B070D0B0E6D073E"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_4\,
      I4 => \ram_reg[43][14]_i_7_n_6\,
      I5 => \ram_reg[43][14]_i_7_n_5\,
      O => \ram[42][8]_i_3_n_0\
    );
\ram[42][8]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0E0D0F0E039F0BC7"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_4\,
      I4 => \ram_reg[43][14]_i_7_n_6\,
      I5 => \ram_reg[43][14]_i_7_n_5\,
      O => \ram[42][8]_i_4_n_0\
    );
\ram[42][8]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0C0B0F3E0E0D079F"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_4\,
      I4 => \ram_reg[43][14]_i_7_n_5\,
      I5 => \ram_reg[43][14]_i_7_n_6\,
      O => \ram[42][8]_i_5_n_0\
    );
\ram[42][8]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"003900CE00F747BD"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_7_n_6\,
      I3 => \ram_reg[43][14]_i_8_n_3\,
      I4 => \ram_reg[43][14]_i_7_n_5\,
      I5 => \ram_reg[43][14]_i_7_n_4\,
      O => \ram[42][8]_i_6_n_0\
    );
\ram[42][9]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \ram_reg[42][9]_i_2_n_0\,
      I1 => \ram_reg[43][14]_i_3_n_7\,
      I2 => \ram[42][9]_i_3_n_0\,
      I3 => \ram_reg[43][14]_i_3_n_6\,
      I4 => \ram[42][9]_i_4_n_0\,
      O => p_18_in(9)
    );
\ram[42][9]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0A0605AD0C0B0A56"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_5\,
      I4 => \ram_reg[43][14]_i_7_n_4\,
      I5 => \ram_reg[43][14]_i_7_n_6\,
      O => \ram[42][9]_i_3_n_0\
    );
\ram[42][9]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"060D0306012B0AD5"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_4\,
      I4 => \ram_reg[43][14]_i_7_n_6\,
      I5 => \ram_reg[43][14]_i_7_n_5\,
      O => \ram[42][9]_i_4_n_0\
    );
\ram[42][9]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0C030A5606010D0B"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_5\,
      I4 => \ram_reg[43][14]_i_7_n_4\,
      I5 => \ram_reg[43][14]_i_7_n_6\,
      O => \ram[42][9]_i_5_n_0\
    );
\ram[42][9]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"010B0D6A0A0506BD"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_4\,
      I4 => \ram_reg[43][14]_i_7_n_5\,
      I5 => \ram_reg[43][14]_i_7_n_6\,
      O => \ram[42][9]_i_6_n_0\
    );
\ram[43][0]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \ram_reg[43][0]_i_2_n_0\,
      I1 => \ram_reg[43][14]_i_3_n_7\,
      I2 => \ram[43][0]_i_3_n_0\,
      I3 => \ram_reg[43][14]_i_3_n_6\,
      I4 => \ram[43][14]_i_6_n_0\,
      O => p_19_in(0)
    );
\ram[43][0]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0C0D0E0E07BF03D7"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_4\,
      I4 => \ram_reg[43][14]_i_7_n_6\,
      I5 => \ram_reg[43][14]_i_7_n_5\,
      O => \ram[43][0]_i_3_n_0\
    );
\ram[43][0]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00EE007F0DB70C9B"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_7_n_4\,
      I3 => \ram_reg[43][14]_i_8_n_3\,
      I4 => \ram_reg[43][14]_i_7_n_6\,
      I5 => \ram_reg[43][14]_i_7_n_5\,
      O => \ram[43][0]_i_4_n_0\
    );
\ram[43][0]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"090B0E5E0C0D07BF"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_4\,
      I4 => \ram_reg[43][14]_i_7_n_5\,
      I5 => \ram_reg[43][14]_i_7_n_6\,
      O => \ram[43][0]_i_5_n_0\
    );
\ram[43][10]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \ram[43][10]_i_2_n_0\,
      I1 => \ram_reg[43][14]_i_3_n_6\,
      I2 => \ram[43][10]_i_3_n_0\,
      I3 => \ram_reg[43][14]_i_3_n_7\,
      I4 => \ram[43][10]_i_4_n_0\,
      O => p_19_in(10)
    );
\ram[43][10]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0086025D00D305A6"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_7_n_5\,
      I3 => \ram_reg[43][14]_i_8_n_3\,
      I4 => \ram_reg[43][14]_i_7_n_4\,
      I5 => \ram_reg[43][14]_i_7_n_6\,
      O => \ram[43][10]_i_2_n_0\
    );
\ram[43][10]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020C61B8DB65"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_7_n_5\,
      I3 => \ram_reg[43][14]_i_7_n_6\,
      I4 => \ram_reg[43][14]_i_7_n_4\,
      I5 => \ram_reg[43][14]_i_8_n_3\,
      O => \ram[43][10]_i_3_n_0\
    );
\ram[43][10]_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \ram[43][10]_i_5_n_0\,
      I1 => \ram_reg[43][14]_i_3_n_1\,
      I2 => \ram[43][10]_i_6_n_0\,
      I3 => \ram_reg[43][14]_i_3_n_6\,
      I4 => \ram[42][3]_i_2_n_0\,
      O => \ram[43][10]_i_4_n_0\
    );
\ram[43][10]_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"2312110F"
    )
        port map (
      I0 => \ram_reg[43][14]_i_7_n_7\,
      I1 => \ram_reg[43][14]_i_8_n_3\,
      I2 => \ram_reg[43][14]_i_7_n_4\,
      I3 => \ram_reg[43][14]_i_7_n_6\,
      I4 => \ram_reg[43][14]_i_7_n_5\,
      O => \ram[43][10]_i_5_n_0\
    );
\ram[43][10]_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"210E2131"
    )
        port map (
      I0 => \ram_reg[43][14]_i_7_n_7\,
      I1 => \ram_reg[43][14]_i_8_n_3\,
      I2 => \ram_reg[43][14]_i_7_n_5\,
      I3 => \ram_reg[43][14]_i_7_n_4\,
      I4 => \ram_reg[43][14]_i_7_n_6\,
      O => \ram[43][10]_i_6_n_0\
    );
\ram[43][11]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FF33CC00B8B8B8B8"
    )
        port map (
      I0 => \ram[43][11]_i_2_n_0\,
      I1 => \ram_reg[43][14]_i_3_n_6\,
      I2 => \ram[43][11]_i_3_n_0\,
      I3 => \ram[43][11]_i_4_n_0\,
      I4 => \ram[43][11]_i_5_n_0\,
      I5 => \ram_reg[43][14]_i_3_n_7\,
      O => p_19_in(11)
    );
\ram[43][11]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000004A46B48421"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_7_n_6\,
      I3 => \ram_reg[43][14]_i_7_n_5\,
      I4 => \ram_reg[43][14]_i_7_n_4\,
      I5 => \ram_reg[43][14]_i_8_n_3\,
      O => \ram[43][11]_i_2_n_0\
    );
\ram[43][11]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"03020A1004010428"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_4\,
      I4 => \ram_reg[43][14]_i_7_n_5\,
      I5 => \ram_reg[43][14]_i_7_n_6\,
      O => \ram[43][11]_i_3_n_0\
    );
\ram[43][11]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0082010400DB0482"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_7_n_5\,
      I3 => \ram_reg[43][14]_i_8_n_3\,
      I4 => \ram_reg[43][14]_i_7_n_4\,
      I5 => \ram_reg[43][14]_i_7_n_6\,
      O => \ram[43][11]_i_4_n_0\
    );
\ram[43][11]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"02040B0204A10A10"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_4\,
      I4 => \ram_reg[43][14]_i_7_n_6\,
      I5 => \ram_reg[43][14]_i_7_n_5\,
      O => \ram[43][11]_i_5_n_0\
    );
\ram[43][12]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FF33CC00B8B8B8B8"
    )
        port map (
      I0 => \ram[43][12]_i_2_n_0\,
      I1 => \ram_reg[43][14]_i_3_n_6\,
      I2 => \ram[43][12]_i_3_n_0\,
      I3 => \ram[43][12]_i_4_n_0\,
      I4 => \ram[43][12]_i_5_n_0\,
      I5 => \ram_reg[43][14]_i_3_n_7\,
      O => p_19_in(12)
    );
\ram[43][12]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000052DF25F24F"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_6\,
      I2 => \ram_reg[43][14]_i_7_n_7\,
      I3 => \ram_reg[43][14]_i_7_n_5\,
      I4 => \ram_reg[43][14]_i_7_n_4\,
      I5 => \ram_reg[43][14]_i_8_n_3\,
      O => \ram[43][12]_i_2_n_0\
    );
\ram[43][12]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0B0708030C39063C"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_4\,
      I4 => \ram_reg[43][14]_i_7_n_6\,
      I5 => \ram_reg[43][14]_i_7_n_5\,
      O => \ram[43][12]_i_3_n_0\
    );
\ram[43][12]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0E09071E060C03C7"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_4\,
      I4 => \ram_reg[43][14]_i_7_n_5\,
      I5 => \ram_reg[43][14]_i_7_n_6\,
      O => \ram[43][12]_i_4_n_0\
    );
\ram[43][12]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"070E010708E30C39"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_4\,
      I4 => \ram_reg[43][14]_i_7_n_6\,
      I5 => \ram_reg[43][14]_i_7_n_5\,
      O => \ram[43][12]_i_5_n_0\
    );
\ram[43][13]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FF33CC00B8B8B8B8"
    )
        port map (
      I0 => \ram[43][13]_i_2_n_0\,
      I1 => \ram_reg[43][14]_i_3_n_6\,
      I2 => \ram[43][13]_i_3_n_0\,
      I3 => \ram[43][13]_i_4_n_0\,
      I4 => \ram[43][13]_i_5_n_0\,
      I5 => \ram_reg[43][14]_i_3_n_7\,
      O => p_19_in(13)
    );
\ram[43][13]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000E7188A65"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_5\,
      I2 => \ram_reg[43][14]_i_7_n_7\,
      I3 => \ram_reg[43][14]_i_7_n_6\,
      I4 => \ram_reg[43][14]_i_7_n_4\,
      I5 => \ram_reg[43][14]_i_8_n_3\,
      O => \ram[43][13]_i_2_n_0\
    );
\ram[43][13]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0B020A5404090D2A"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_4\,
      I4 => \ram_reg[43][14]_i_7_n_5\,
      I5 => \ram_reg[43][14]_i_7_n_6\,
      O => \ram[43][13]_i_3_n_0\
    );
\ram[43][13]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0A040D0A06150912"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_4\,
      I4 => \ram_reg[43][14]_i_7_n_6\,
      I5 => \ram_reg[43][14]_i_7_n_5\,
      O => \ram[43][13]_i_4_n_0\
    );
\ram[43][13]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"02050529090A0254"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_5\,
      I4 => \ram_reg[43][14]_i_7_n_4\,
      I5 => \ram_reg[43][14]_i_7_n_6\,
      O => \ram[43][13]_i_5_n_0\
    );
\ram[43][14]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FF33CC00B8B8B8B8"
    )
        port map (
      I0 => \ram[43][14]_i_2_n_0\,
      I1 => \ram_reg[43][14]_i_3_n_6\,
      I2 => \ram[43][14]_i_4_n_0\,
      I3 => \ram[43][14]_i_5_n_0\,
      I4 => \ram[43][14]_i_6_n_0\,
      I5 => \ram_reg[43][14]_i_3_n_7\,
      O => p_19_in(14)
    );
\ram[43][14]_i_10\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => timing_sel_imm(0),
      I1 => timing_sel_imm(1),
      O => \ram[43][14]_i_10_n_0\
    );
\ram[43][14]_i_11\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => timing_sel_imm(1),
      I1 => timing_sel_imm(0),
      O => \ram[43][14]_i_11_n_0\
    );
\ram[43][14]_i_12\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => timing_sel_imm(1),
      I1 => timing_sel_imm(0),
      O => \ram[43][14]_i_12_n_0\
    );
\ram[43][14]_i_13\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => timing_sel_imm(0),
      I1 => timing_sel_imm(1),
      O => \ram[43][14]_i_13_n_0\
    );
\ram[43][14]_i_14\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => timing_sel_imm(1),
      I1 => timing_sel_imm(0),
      O => \ram[43][14]_i_14_n_0\
    );
\ram[43][14]_i_15\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => timing_sel_imm(0),
      I1 => timing_sel_imm(1),
      O => \ram[43][14]_i_15_n_0\
    );
\ram[43][14]_i_16\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => timing_sel_imm(1),
      I1 => timing_sel_imm(0),
      O => \ram[43][14]_i_16_n_0\
    );
\ram[43][14]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0F09070D0E570FCB"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_5\,
      I4 => \ram_reg[43][14]_i_7_n_6\,
      I5 => \ram_reg[43][14]_i_7_n_4\,
      O => \ram[43][14]_i_2_n_0\
    );
\ram[43][14]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0B070C0B0EAD0F7E"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_4\,
      I4 => \ram_reg[43][14]_i_7_n_6\,
      I5 => \ram_reg[43][14]_i_7_n_5\,
      O => \ram[43][14]_i_4_n_0\
    );
\ram[43][14]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000020CE7F9DFE7"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_7_n_5\,
      I3 => \ram_reg[43][14]_i_7_n_6\,
      I4 => \ram_reg[43][14]_i_7_n_4\,
      I5 => \ram_reg[43][14]_i_8_n_3\,
      O => \ram[43][14]_i_5_n_0\
    );
\ram[43][14]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"070D0B0E0F6B07FD"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_5\,
      I4 => \ram_reg[43][14]_i_7_n_6\,
      I5 => \ram_reg[43][14]_i_7_n_4\,
      O => \ram[43][14]_i_6_n_0\
    );
\ram[43][14]_i_9\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => timing_sel_imm(1),
      I1 => timing_sel_imm(0),
      O => \ram[43][14]_i_9_n_0\
    );
\ram[43][1]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \ram_reg[43][1]_i_2_n_0\,
      I1 => \ram_reg[43][14]_i_3_n_7\,
      I2 => \ram[43][1]_i_3_n_0\,
      I3 => \ram_reg[43][14]_i_3_n_6\,
      I4 => \ram[43][1]_i_4_n_0\,
      O => p_19_in(1)
    );
\ram[43][1]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00860B5D00D305A6"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_7_n_5\,
      I3 => \ram_reg[43][14]_i_8_n_3\,
      I4 => \ram_reg[43][14]_i_7_n_4\,
      I5 => \ram_reg[43][14]_i_7_n_6\,
      O => \ram[43][1]_i_3_n_0\
    );
\ram[43][1]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"060D0B06012B0A95"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_4\,
      I4 => \ram_reg[43][14]_i_7_n_6\,
      I5 => \ram_reg[43][14]_i_7_n_5\,
      O => \ram[43][1]_i_4_n_0\
    );
\ram[43][1]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0C030A5606010D2B"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_5\,
      I4 => \ram_reg[43][14]_i_7_n_4\,
      I5 => \ram_reg[43][14]_i_7_n_6\,
      O => \ram[43][1]_i_5_n_0\
    );
\ram[43][1]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"050B0C6A0A0506BD"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_4\,
      I4 => \ram_reg[43][14]_i_7_n_5\,
      I5 => \ram_reg[43][14]_i_7_n_6\,
      O => \ram[43][1]_i_6_n_0\
    );
\ram[43][2]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \ram_reg[43][2]_i_2_n_0\,
      I1 => \ram_reg[43][14]_i_3_n_7\,
      I2 => \ram[43][2]_i_3_n_0\,
      I3 => \ram_reg[43][14]_i_3_n_6\,
      I4 => \ram[43][2]_i_4_n_0\,
      O => p_19_in(2)
    );
\ram[43][2]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00820804005B0582"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_7_n_5\,
      I3 => \ram_reg[43][14]_i_8_n_3\,
      I4 => \ram_reg[43][14]_i_7_n_4\,
      I5 => \ram_reg[43][14]_i_7_n_6\,
      O => \ram[43][2]_i_3_n_0\
    );
\ram[43][2]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000A0064984120"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_7_n_5\,
      I3 => \ram_reg[43][14]_i_7_n_6\,
      I4 => \ram_reg[43][14]_i_7_n_4\,
      I5 => \ram_reg[43][14]_i_8_n_3\,
      O => \ram[43][2]_i_4_n_0\
    );
\ram[43][2]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000004A42B48421"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_7_n_6\,
      I3 => \ram_reg[43][14]_i_7_n_5\,
      I4 => \ram_reg[43][14]_i_7_n_4\,
      I5 => \ram_reg[43][14]_i_8_n_3\,
      O => \ram[43][2]_i_5_n_0\
    );
\ram[43][2]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00010D280A000694"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_4\,
      I4 => \ram_reg[43][14]_i_7_n_5\,
      I5 => \ram_reg[43][14]_i_7_n_6\,
      O => \ram[43][2]_i_6_n_0\
    );
\ram[43][3]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \ram_reg[43][3]_i_2_n_0\,
      I1 => \ram_reg[43][14]_i_3_n_7\,
      I2 => \ram[43][3]_i_3_n_0\,
      I3 => \ram_reg[43][14]_i_3_n_6\,
      I4 => \ram[43][3]_i_4_n_0\,
      O => p_19_in(3)
    );
\ram[43][3]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000008CE6739CE7"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_7_n_6\,
      I3 => \ram_reg[43][14]_i_7_n_5\,
      I4 => \ram_reg[43][14]_i_7_n_4\,
      I5 => \ram_reg[43][14]_i_8_n_3\,
      O => \ram[43][3]_i_3_n_0\
    );
\ram[43][3]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"030E010708E30C79"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_4\,
      I4 => \ram_reg[43][14]_i_7_n_6\,
      I5 => \ram_reg[43][14]_i_7_n_5\,
      O => \ram[43][3]_i_4_n_0\
    );
\ram[43][3]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000F25F25F24F"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_6\,
      I2 => \ram_reg[43][14]_i_7_n_7\,
      I3 => \ram_reg[43][14]_i_7_n_5\,
      I4 => \ram_reg[43][14]_i_7_n_4\,
      I5 => \ram_reg[43][14]_i_8_n_3\,
      O => \ram[43][3]_i_5_n_0\
    );
\ram[43][3]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0D0C03090E071C9E"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_6\,
      I4 => \ram_reg[43][14]_i_7_n_4\,
      I5 => \ram_reg[43][14]_i_7_n_5\,
      O => \ram[43][3]_i_6_n_0\
    );
\ram[43][4]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \ram_reg[43][4]_i_2_n_0\,
      I1 => \ram_reg[43][14]_i_3_n_7\,
      I2 => \ram[43][4]_i_3_n_0\,
      I3 => \ram_reg[43][14]_i_3_n_6\,
      I4 => \ram[43][4]_i_4_n_0\,
      O => p_19_in(4)
    );
\ram[43][4]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000004A6D945A2"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_7_n_5\,
      I3 => \ram_reg[43][14]_i_7_n_6\,
      I4 => \ram_reg[43][14]_i_7_n_4\,
      I5 => \ram_reg[43][14]_i_8_n_3\,
      O => \ram[43][4]_i_3_n_0\
    );
\ram[43][4]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"02050509090A0254"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_5\,
      I4 => \ram_reg[43][14]_i_7_n_4\,
      I5 => \ram_reg[43][14]_i_7_n_6\,
      O => \ram[43][4]_i_4_n_0\
    );
\ram[43][4]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000002E7188A65"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_5\,
      I2 => \ram_reg[43][14]_i_7_n_7\,
      I3 => \ram_reg[43][14]_i_7_n_6\,
      I4 => \ram_reg[43][14]_i_7_n_4\,
      I5 => \ram_reg[43][14]_i_8_n_3\,
      O => \ram[43][4]_i_5_n_0\
    );
\ram[43][4]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"05090D2A0A040295"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_4\,
      I4 => \ram_reg[43][14]_i_7_n_5\,
      I5 => \ram_reg[43][14]_i_7_n_6\,
      O => \ram[43][4]_i_6_n_0\
    );
\ram[43][5]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \ram_reg[43][5]_i_2_n_0\,
      I1 => \ram_reg[43][14]_i_3_n_7\,
      I2 => \ram[43][5]_i_3_n_0\,
      I3 => \ram_reg[43][14]_i_3_n_6\,
      I4 => \ram[43][5]_i_4_n_0\,
      O => p_19_in(5)
    );
\ram[43][5]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0E0D070E07BF0997"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_4\,
      I4 => \ram_reg[43][14]_i_7_n_6\,
      I5 => \ram_reg[43][14]_i_7_n_5\,
      O => \ram[43][5]_i_3_n_0\
    );
\ram[43][5]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"030D090E0F6B07FD"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_5\,
      I4 => \ram_reg[43][14]_i_7_n_6\,
      I5 => \ram_reg[43][14]_i_7_n_4\,
      O => \ram[43][5]_i_4_n_0\
    );
\ram[43][5]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0F09030D0E970FEB"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_5\,
      I4 => \ram_reg[43][14]_i_7_n_6\,
      I5 => \ram_reg[43][14]_i_7_n_4\,
      O => \ram[43][5]_i_5_n_0\
    );
\ram[43][5]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0C0B075E0E0D03BF"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_4\,
      I4 => \ram_reg[43][14]_i_7_n_5\,
      I5 => \ram_reg[43][14]_i_7_n_6\,
      O => \ram[43][5]_i_6_n_0\
    );
\ram[43][6]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \ram[43][6]_i_2_n_0\,
      I1 => \ram_reg[43][14]_i_3_n_6\,
      I2 => \ram[43][6]_i_3_n_0\,
      I3 => \ram_reg[43][14]_i_3_n_7\,
      I4 => \ram[43][6]_i_4_n_0\,
      O => p_19_in(6)
    );
\ram[43][6]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0C0B0F3E0E0D071F"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_4\,
      I4 => \ram_reg[43][14]_i_7_n_5\,
      I5 => \ram_reg[43][14]_i_7_n_6\,
      O => \ram[43][6]_i_2_n_0\
    );
\ram[43][6]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000080EFE3F97DB"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_7_n_4\,
      I3 => \ram_reg[43][14]_i_7_n_6\,
      I4 => \ram_reg[43][14]_i_7_n_5\,
      I5 => \ram_reg[43][14]_i_8_n_3\,
      O => \ram[43][6]_i_3_n_0\
    );
\ram[43][6]_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \ram[42][12]_i_3_n_0\,
      I1 => \ram_reg[43][14]_i_3_n_6\,
      I2 => \ram[43][6]_i_5_n_0\,
      I3 => \ram_reg[43][14]_i_3_n_1\,
      I4 => \ram[43][6]_i_6_n_0\,
      O => \ram[43][6]_i_4_n_0\
    );
\ram[43][6]_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"13312F36"
    )
        port map (
      I0 => \ram_reg[43][14]_i_7_n_7\,
      I1 => \ram_reg[43][14]_i_8_n_3\,
      I2 => \ram_reg[43][14]_i_7_n_4\,
      I3 => \ram_reg[43][14]_i_7_n_6\,
      I4 => \ram_reg[43][14]_i_7_n_5\,
      O => \ram[43][6]_i_5_n_0\
    );
\ram[43][6]_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0D0A0FB7"
    )
        port map (
      I0 => \ram_reg[43][14]_i_7_n_7\,
      I1 => \ram_reg[43][14]_i_7_n_6\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_5\,
      I4 => \ram_reg[43][14]_i_7_n_4\,
      O => \ram[43][6]_i_6_n_0\
    );
\ram[43][7]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8B8B8B8FF33CC00"
    )
        port map (
      I0 => \ram[43][7]_i_2_n_0\,
      I1 => \ram_reg[43][14]_i_3_n_6\,
      I2 => \ram[43][7]_i_3_n_0\,
      I3 => \ram[43][7]_i_4_n_0\,
      I4 => \ram[43][7]_i_5_n_0\,
      I5 => \ram_reg[43][14]_i_3_n_7\,
      O => p_19_in(7)
    );
\ram[43][7]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0D0B0A5606010D2B"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_5\,
      I4 => \ram_reg[43][14]_i_7_n_4\,
      I5 => \ram_reg[43][14]_i_7_n_6\,
      O => \ram[43][7]_i_2_n_0\
    );
\ram[43][7]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0B0608D5010B0D6A"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_4\,
      I4 => \ram_reg[43][14]_i_7_n_5\,
      I5 => \ram_reg[43][14]_i_7_n_6\,
      O => \ram[43][7]_i_3_n_0\
    );
\ram[43][7]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"060D0B06012B08D5"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_4\,
      I4 => \ram_reg[43][14]_i_7_n_6\,
      I5 => \ram_reg[43][14]_i_7_n_5\,
      O => \ram[43][7]_i_4_n_0\
    );
\ram[43][7]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"050B0D6A080506BD"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_4\,
      I4 => \ram_reg[43][14]_i_7_n_5\,
      I5 => \ram_reg[43][14]_i_7_n_6\,
      O => \ram[43][7]_i_5_n_0\
    );
\ram[43][8]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8B8B8B8FF33CC00"
    )
        port map (
      I0 => \ram[43][8]_i_2_n_0\,
      I1 => \ram_reg[43][14]_i_3_n_6\,
      I2 => \ram[43][8]_i_3_n_0\,
      I3 => \ram[43][8]_i_4_n_0\,
      I4 => \ram[43][8]_i_5_n_0\,
      I5 => \ram_reg[43][14]_i_3_n_7\,
      O => p_19_in(8)
    );
\ram[43][8]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00EE007F05B70E9B"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_7_n_4\,
      I3 => \ram_reg[43][14]_i_8_n_3\,
      I4 => \ram_reg[43][14]_i_7_n_6\,
      I5 => \ram_reg[43][14]_i_7_n_5\,
      O => \ram[43][8]_i_2_n_0\
    );
\ram[43][8]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"03070D0B0EBD0F7E"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_4\,
      I4 => \ram_reg[43][14]_i_7_n_6\,
      I5 => \ram_reg[43][14]_i_7_n_5\,
      O => \ram[43][8]_i_3_n_0\
    );
\ram[43][8]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000060E7FB7DBCD"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_7_n_4\,
      I3 => \ram_reg[43][14]_i_7_n_6\,
      I4 => \ram_reg[43][14]_i_7_n_5\,
      I5 => \ram_reg[43][14]_i_8_n_3\,
      O => \ram[43][8]_i_4_n_0\
    );
\ram[43][8]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0D0B0E5E0C0D07BF"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_4\,
      I4 => \ram_reg[43][14]_i_7_n_5\,
      I5 => \ram_reg[43][14]_i_7_n_6\,
      O => \ram[43][8]_i_5_n_0\
    );
\ram[43][9]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FF00B8B8"
    )
        port map (
      I0 => \ram[43][10]_i_3_n_0\,
      I1 => \ram_reg[43][14]_i_3_n_6\,
      I2 => \ram[43][9]_i_2_n_0\,
      I3 => \ram[43][10]_i_4_n_0\,
      I4 => \ram_reg[43][14]_i_3_n_7\,
      O => p_19_in(9)
    );
\ram[43][9]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"010B0C4A0A0506BD"
    )
        port map (
      I0 => \ram_reg[43][14]_i_3_n_1\,
      I1 => \ram_reg[43][14]_i_7_n_7\,
      I2 => \ram_reg[43][14]_i_8_n_3\,
      I3 => \ram_reg[43][14]_i_7_n_4\,
      I4 => \ram_reg[43][14]_i_7_n_5\,
      I5 => \ram_reg[43][14]_i_7_n_6\,
      O => \ram[43][9]_i_2_n_0\
    );
\ram[44][11]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FB08FBFBFB080808"
    )
        port map (
      I0 => \ram_reg[45][11]_i_5_n_0\,
      I1 => timing_sel_imm(0),
      I2 => timing_sel_imm(1),
      I3 => \ram[44][11]_i_2_n_0\,
      I4 => \ram_reg[45][11]_i_3_n_6\,
      I5 => \ram[45][11]_i_2_n_0\,
      O => p_20_in(11)
    );
\ram[44][11]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"008C0048006930C6"
    )
        port map (
      I0 => \ram_reg[45][11]_i_3_n_1\,
      I1 => \ram[45][11]_i_6_n_0\,
      I2 => \ram_reg[45][11]_i_7_n_6\,
      I3 => \ram_reg[45][11]_i_8_n_3\,
      I4 => \ram_reg[45][11]_i_7_n_4\,
      I5 => \ram_reg[45][11]_i_7_n_5\,
      O => \ram[44][11]_i_2_n_0\
    );
\ram[44][12]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FB08FBFBFB080808"
    )
        port map (
      I0 => \ram[45][12]_i_3_n_0\,
      I1 => timing_sel_imm(0),
      I2 => timing_sel_imm(1),
      I3 => \ram[44][12]_i_2_n_0\,
      I4 => \ram_reg[45][11]_i_3_n_6\,
      I5 => \ram[44][12]_i_3_n_0\,
      O => p_20_in(12)
    );
\ram[44][12]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000028002040020"
    )
        port map (
      I0 => \ram_reg[45][11]_i_3_n_1\,
      I1 => \ram_reg[45][11]_i_7_n_5\,
      I2 => \ram_reg[45][11]_i_7_n_4\,
      I3 => \ram_reg[45][11]_i_8_n_3\,
      I4 => \ram_reg[45][11]_i_7_n_6\,
      I5 => \ram[45][11]_i_6_n_0\,
      O => \ram[44][12]_i_2_n_0\
    );
\ram[44][12]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000450810228040"
    )
        port map (
      I0 => \ram_reg[45][11]_i_3_n_1\,
      I1 => \ram_reg[45][11]_i_7_n_5\,
      I2 => \ram[45][11]_i_6_n_0\,
      I3 => \ram_reg[45][11]_i_7_n_6\,
      I4 => \ram_reg[45][11]_i_8_n_3\,
      I5 => \ram_reg[45][11]_i_7_n_4\,
      O => \ram[44][12]_i_3_n_0\
    );
\ram[44][15]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FB08FBFBFB080808"
    )
        port map (
      I0 => \ram[45][15]_i_3_n_0\,
      I1 => timing_sel_imm(0),
      I2 => timing_sel_imm(1),
      I3 => \ram[44][15]_i_2_n_0\,
      I4 => \ram_reg[45][11]_i_3_n_6\,
      I5 => \ram[44][15]_i_3_n_0\,
      O => p_20_in(15)
    );
\ram[44][15]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0063005A00522D31"
    )
        port map (
      I0 => \ram_reg[45][11]_i_3_n_1\,
      I1 => \ram[45][11]_i_6_n_0\,
      I2 => \ram_reg[45][11]_i_7_n_6\,
      I3 => \ram_reg[45][11]_i_8_n_3\,
      I4 => \ram_reg[45][11]_i_7_n_5\,
      I5 => \ram_reg[45][11]_i_7_n_4\,
      O => \ram[44][15]_i_2_n_0\
    );
\ram[44][15]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000048D20069958C"
    )
        port map (
      I0 => \ram_reg[45][11]_i_3_n_1\,
      I1 => \ram[45][11]_i_6_n_0\,
      I2 => \ram_reg[45][11]_i_7_n_6\,
      I3 => \ram_reg[45][11]_i_7_n_5\,
      I4 => \ram_reg[45][11]_i_8_n_3\,
      I5 => \ram_reg[45][11]_i_7_n_4\,
      O => \ram[44][15]_i_3_n_0\
    );
\ram[44][38]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \ram_reg[44]_1\(38),
      I1 => \ram_reg[26][0]_0\,
      O => \ram[44][38]_i_1_n_0\
    );
\ram[44][8]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FB08FBFBFB080808"
    )
        port map (
      I0 => \ram_reg[45][8]_i_4_n_0\,
      I1 => timing_sel_imm(0),
      I2 => timing_sel_imm(1),
      I3 => \ram[44][8]_i_2_n_0\,
      I4 => \ram_reg[45][11]_i_3_n_6\,
      I5 => \ram[45][8]_i_2_n_0\,
      O => p_20_in(8)
    );
\ram[44][8]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0004020000100180"
    )
        port map (
      I0 => \ram_reg[45][11]_i_3_n_1\,
      I1 => \ram[45][11]_i_6_n_0\,
      I2 => \ram_reg[45][11]_i_7_n_4\,
      I3 => \ram_reg[45][11]_i_8_n_3\,
      I4 => \ram_reg[45][11]_i_7_n_5\,
      I5 => \ram_reg[45][11]_i_7_n_6\,
      O => \ram[44][8]_i_2_n_0\
    );
\ram[45][11]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFB8FF0000B800"
    )
        port map (
      I0 => \ram[45][11]_i_2_n_0\,
      I1 => \ram_reg[45][11]_i_3_n_6\,
      I2 => \ram[45][11]_i_4_n_0\,
      I3 => timing_sel_imm(0),
      I4 => timing_sel_imm(1),
      I5 => \ram_reg[45][11]_i_5_n_0\,
      O => p_21_in(11)
    );
\ram[45][11]_i_10\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => timing_sel_imm(0),
      I1 => timing_sel_imm(1),
      O => \ram[45][11]_i_10_n_0\
    );
\ram[45][11]_i_11\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => timing_sel_imm(1),
      I1 => timing_sel_imm(0),
      O => \ram[45][11]_i_11_n_0\
    );
\ram[45][11]_i_12\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000D291A52B18"
    )
        port map (
      I0 => \ram_reg[45][11]_i_3_n_1\,
      I1 => \ram[45][11]_i_6_n_0\,
      I2 => \ram_reg[45][11]_i_7_n_6\,
      I3 => \ram_reg[45][11]_i_7_n_5\,
      I4 => \ram_reg[45][11]_i_7_n_4\,
      I5 => \ram_reg[45][11]_i_8_n_3\,
      O => \ram[45][11]_i_12_n_0\
    );
\ram[45][11]_i_13\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000C6A40058B463"
    )
        port map (
      I0 => \ram_reg[45][11]_i_3_n_1\,
      I1 => \ram[45][11]_i_6_n_0\,
      I2 => \ram_reg[45][11]_i_7_n_6\,
      I3 => \ram_reg[45][11]_i_7_n_4\,
      I4 => \ram_reg[45][11]_i_8_n_3\,
      I5 => \ram_reg[45][11]_i_7_n_5\,
      O => \ram[45][11]_i_13_n_0\
    );
\ram[45][11]_i_14\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => timing_sel_imm(1),
      I1 => timing_sel_imm(0),
      O => \ram[45][11]_i_14_n_0\
    );
\ram[45][11]_i_15\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => timing_sel_imm(1),
      I1 => timing_sel_imm(0),
      O => \ram[45][11]_i_15_n_0\
    );
\ram[45][11]_i_16\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => timing_sel_imm(0),
      I1 => timing_sel_imm(1),
      O => \ram[45][11]_i_16_n_0\
    );
\ram[45][11]_i_17\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => timing_sel_imm(1),
      I1 => timing_sel_imm(0),
      O => \ram[45][11]_i_17_n_0\
    );
\ram[45][11]_i_18\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => timing_sel_imm(0),
      I1 => timing_sel_imm(1),
      O => \ram[45][11]_i_18_n_0\
    );
\ram[45][11]_i_19\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => timing_sel_imm(1),
      I1 => timing_sel_imm(0),
      O => \ram[45][11]_i_19_n_0\
    );
\ram[45][11]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0063004A0052A531"
    )
        port map (
      I0 => \ram_reg[45][11]_i_3_n_1\,
      I1 => \ram[45][11]_i_6_n_0\,
      I2 => \ram_reg[45][11]_i_7_n_6\,
      I3 => \ram_reg[45][11]_i_8_n_3\,
      I4 => \ram_reg[45][11]_i_7_n_5\,
      I5 => \ram_reg[45][11]_i_7_n_4\,
      O => \ram[45][11]_i_2_n_0\
    );
\ram[45][11]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000018D20061918C"
    )
        port map (
      I0 => \ram_reg[45][11]_i_3_n_1\,
      I1 => \ram[45][11]_i_6_n_0\,
      I2 => \ram_reg[45][11]_i_7_n_6\,
      I3 => \ram_reg[45][11]_i_7_n_5\,
      I4 => \ram_reg[45][11]_i_8_n_3\,
      I5 => \ram_reg[45][11]_i_7_n_4\,
      O => \ram[45][11]_i_4_n_0\
    );
\ram[45][11]_i_6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => timing_sel_imm(0),
      I1 => timing_sel_imm(1),
      O => \ram[45][11]_i_6_n_0\
    );
\ram[45][11]_i_9\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => timing_sel_imm(1),
      I1 => timing_sel_imm(0),
      O => \ram[45][11]_i_9_n_0\
    );
\ram[45][12]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FB08"
    )
        port map (
      I0 => \ram[45][12]_i_2_n_0\,
      I1 => timing_sel_imm(0),
      I2 => timing_sel_imm(1),
      I3 => \ram[45][12]_i_3_n_0\,
      O => p_21_in(12)
    );
\ram[45][12]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \ram[44][12]_i_3_n_0\,
      I1 => \ram_reg[45][11]_i_3_n_6\,
      I2 => \ram[45][12]_i_4_n_0\,
      O => \ram[45][12]_i_2_n_0\
    );
\ram[45][12]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \ram[45][12]_i_5_n_0\,
      I1 => \ram_reg[45][11]_i_3_n_6\,
      I2 => \ram[45][4]_i_2_n_0\,
      O => \ram[45][12]_i_3_n_0\
    );
\ram[45][12]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000102000500400"
    )
        port map (
      I0 => \ram_reg[45][11]_i_3_n_1\,
      I1 => \ram[45][11]_i_6_n_0\,
      I2 => \ram_reg[45][11]_i_7_n_6\,
      I3 => \ram_reg[45][11]_i_7_n_4\,
      I4 => \ram_reg[45][11]_i_8_n_3\,
      I5 => \ram_reg[45][11]_i_7_n_5\,
      O => \ram[45][12]_i_4_n_0\
    );
\ram[45][12]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00A4000800011400"
    )
        port map (
      I0 => \ram_reg[45][11]_i_3_n_1\,
      I1 => \ram[45][11]_i_6_n_0\,
      I2 => \ram_reg[45][11]_i_7_n_6\,
      I3 => \ram_reg[45][11]_i_8_n_3\,
      I4 => \ram_reg[45][11]_i_7_n_4\,
      I5 => \ram_reg[45][11]_i_7_n_5\,
      O => \ram[45][12]_i_5_n_0\
    );
\ram[45][15]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FB08"
    )
        port map (
      I0 => \ram[45][15]_i_2_n_0\,
      I1 => timing_sel_imm(0),
      I2 => timing_sel_imm(1),
      I3 => \ram[45][15]_i_3_n_0\,
      O => p_21_in(15)
    );
\ram[45][15]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \ram[44][15]_i_3_n_0\,
      I1 => \ram_reg[45][11]_i_3_n_6\,
      I2 => \ram[45][15]_i_4_n_0\,
      I3 => \ram_reg[45][11]_i_3_n_1\,
      I4 => \ram[45][15]_i_5_n_0\,
      O => \ram[45][15]_i_2_n_0\
    );
\ram[45][15]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \ram[45][15]_i_6_n_0\,
      I1 => \ram_reg[45][11]_i_3_n_6\,
      I2 => \ram[45][7]_i_2_n_0\,
      O => \ram[45][15]_i_3_n_0\
    );
\ram[45][15]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"002D00F000F00FDD"
    )
        port map (
      I0 => timing_sel_imm(0),
      I1 => timing_sel_imm(1),
      I2 => \ram_reg[45][11]_i_7_n_6\,
      I3 => \ram_reg[45][11]_i_8_n_3\,
      I4 => \ram_reg[45][11]_i_7_n_5\,
      I5 => \ram_reg[45][11]_i_7_n_4\,
      O => \ram[45][15]_i_4_n_0\
    );
\ram[45][15]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000220200F0D22D"
    )
        port map (
      I0 => timing_sel_imm(0),
      I1 => timing_sel_imm(1),
      I2 => \ram_reg[45][11]_i_7_n_6\,
      I3 => \ram_reg[45][11]_i_7_n_4\,
      I4 => \ram_reg[45][11]_i_8_n_3\,
      I5 => \ram_reg[45][11]_i_7_n_5\,
      O => \ram[45][15]_i_5_n_0\
    );
\ram[45][15]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000004691A52B18"
    )
        port map (
      I0 => \ram_reg[45][11]_i_3_n_1\,
      I1 => \ram[45][11]_i_6_n_0\,
      I2 => \ram_reg[45][11]_i_7_n_6\,
      I3 => \ram_reg[45][11]_i_7_n_5\,
      I4 => \ram_reg[45][11]_i_7_n_4\,
      I5 => \ram_reg[45][11]_i_8_n_3\,
      O => \ram[45][15]_i_6_n_0\
    );
\ram[45][4]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFB8FF0000B800"
    )
        port map (
      I0 => \ram[45][4]_i_2_n_0\,
      I1 => \ram_reg[45][11]_i_3_n_6\,
      I2 => \ram[45][4]_i_3_n_0\,
      I3 => timing_sel_imm(0),
      I4 => timing_sel_imm(1),
      I5 => \ram[45][12]_i_2_n_0\,
      O => p_21_in(4)
    );
\ram[45][4]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00040A0000100480"
    )
        port map (
      I0 => \ram_reg[45][11]_i_3_n_1\,
      I1 => \ram[45][11]_i_6_n_0\,
      I2 => \ram_reg[45][11]_i_7_n_4\,
      I3 => \ram_reg[45][11]_i_8_n_3\,
      I4 => \ram_reg[45][11]_i_7_n_5\,
      I5 => \ram_reg[45][11]_i_7_n_6\,
      O => \ram[45][4]_i_2_n_0\
    );
\ram[45][4]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000481000290200"
    )
        port map (
      I0 => \ram_reg[45][11]_i_3_n_1\,
      I1 => \ram[45][11]_i_6_n_0\,
      I2 => \ram_reg[45][11]_i_7_n_6\,
      I3 => \ram_reg[45][11]_i_7_n_4\,
      I4 => \ram_reg[45][11]_i_8_n_3\,
      I5 => \ram_reg[45][11]_i_7_n_5\,
      O => \ram[45][4]_i_3_n_0\
    );
\ram[45][7]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFB8FF0000B800"
    )
        port map (
      I0 => \ram[45][7]_i_2_n_0\,
      I1 => \ram_reg[45][11]_i_3_n_6\,
      I2 => \ram[45][7]_i_3_n_0\,
      I3 => timing_sel_imm(0),
      I4 => timing_sel_imm(1),
      I5 => \ram[45][15]_i_2_n_0\,
      O => p_21_in(7)
    );
\ram[45][7]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"008C00480069B1C6"
    )
        port map (
      I0 => \ram_reg[45][11]_i_3_n_1\,
      I1 => \ram[45][11]_i_6_n_0\,
      I2 => \ram_reg[45][11]_i_7_n_6\,
      I3 => \ram_reg[45][11]_i_8_n_3\,
      I4 => \ram_reg[45][11]_i_7_n_4\,
      I5 => \ram_reg[45][11]_i_7_n_5\,
      O => \ram[45][7]_i_2_n_0\
    );
\ram[45][7]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0023004A00568D31"
    )
        port map (
      I0 => \ram_reg[45][11]_i_3_n_1\,
      I1 => \ram[45][11]_i_6_n_0\,
      I2 => \ram_reg[45][11]_i_7_n_6\,
      I3 => \ram_reg[45][11]_i_8_n_3\,
      I4 => \ram_reg[45][11]_i_7_n_5\,
      I5 => \ram_reg[45][11]_i_7_n_4\,
      O => \ram[45][7]_i_3_n_0\
    );
\ram[45][8]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFB8FF0000B800"
    )
        port map (
      I0 => \ram[45][8]_i_2_n_0\,
      I1 => \ram_reg[45][11]_i_3_n_6\,
      I2 => \ram[45][8]_i_3_n_0\,
      I3 => timing_sel_imm(0),
      I4 => timing_sel_imm(1),
      I5 => \ram_reg[45][8]_i_4_n_0\,
      O => p_21_in(8)
    );
\ram[45][8]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000082000240210"
    )
        port map (
      I0 => \ram_reg[45][11]_i_3_n_1\,
      I1 => \ram_reg[45][11]_i_7_n_5\,
      I2 => \ram_reg[45][11]_i_8_n_3\,
      I3 => \ram_reg[45][11]_i_7_n_4\,
      I4 => \ram_reg[45][11]_i_7_n_6\,
      I5 => \ram[45][11]_i_6_n_0\,
      O => \ram[45][8]_i_2_n_0\
    );
\ram[45][8]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000004202108000"
    )
        port map (
      I0 => \ram_reg[45][11]_i_3_n_1\,
      I1 => \ram[45][11]_i_6_n_0\,
      I2 => \ram_reg[45][11]_i_7_n_6\,
      I3 => \ram_reg[45][11]_i_7_n_5\,
      I4 => \ram_reg[45][11]_i_7_n_4\,
      I5 => \ram_reg[45][11]_i_8_n_3\,
      O => \ram[45][8]_i_3_n_0\
    );
\ram[45][8]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0008A00000044180"
    )
        port map (
      I0 => \ram_reg[45][11]_i_3_n_1\,
      I1 => \ram[45][11]_i_6_n_0\,
      I2 => \ram_reg[45][11]_i_7_n_5\,
      I3 => \ram_reg[45][11]_i_7_n_4\,
      I4 => \ram_reg[45][11]_i_8_n_3\,
      I5 => \ram_reg[45][11]_i_7_n_6\,
      O => \ram[45][8]_i_5_n_0\
    );
\ram[45][8]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000400522000"
    )
        port map (
      I0 => \ram_reg[45][11]_i_3_n_1\,
      I1 => \ram[45][11]_i_6_n_0\,
      I2 => \ram_reg[45][11]_i_7_n_6\,
      I3 => \ram_reg[45][11]_i_7_n_5\,
      I4 => \ram_reg[45][11]_i_8_n_3\,
      I5 => \ram_reg[45][11]_i_7_n_4\,
      O => \ram[45][8]_i_6_n_0\
    );
\ram_addr[0]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => current_state(2),
      I1 => ram_addr(0),
      O => \ram_addr[0]_i_1_n_0\
    );
\ram_addr[1]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"6F"
    )
        port map (
      I0 => ram_addr(1),
      I1 => ram_addr(0),
      I2 => current_state(2),
      O => \ram_addr[1]_i_1_n_0\
    );
\ram_addr[2]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6AFF"
    )
        port map (
      I0 => ram_addr(2),
      I1 => ram_addr(1),
      I2 => ram_addr(0),
      I3 => current_state(2),
      O => \ram_addr[2]_i_1_n_0\
    );
\ram_addr[3]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2AAAFFFF80000000"
    )
        port map (
      I0 => current_state(2),
      I1 => ram_addr(2),
      I2 => ram_addr(0),
      I3 => ram_addr(1),
      I4 => \ram_addr[4]_i_2_n_0\,
      I5 => ram_addr(3),
      O => \ram_addr[3]_i_1_n_0\
    );
\ram_addr[4]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0004"
    )
        port map (
      I0 => current_state(2),
      I1 => current_state(0),
      I2 => current_state(3),
      I3 => current_state(1),
      O => \ram_addr[4]_i_1_n_0\
    );
\ram_addr[4]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"40444004"
    )
        port map (
      I0 => current_state(3),
      I1 => current_state(0),
      I2 => current_state(1),
      I3 => current_state(2),
      I4 => \ram_addr_reg[0]_0\,
      O => \ram_addr[4]_i_2_n_0\
    );
\ram_addr[4]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"6AAAAAAAFFFFFFFF"
    )
        port map (
      I0 => ram_addr(4),
      I1 => ram_addr(3),
      I2 => ram_addr(1),
      I3 => ram_addr(0),
      I4 => ram_addr(2),
      I5 => current_state(2),
      O => \ram_addr[4]_i_3_n_0\
    );
\ram_addr[5]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"2AFF8000"
    )
        port map (
      I0 => current_state(2),
      I1 => ram_addr(4),
      I2 => \ram_addr[5]_i_2_n_0\,
      I3 => \ram_addr[4]_i_2_n_0\,
      I4 => ram_addr(5),
      O => \ram_addr[5]_i_1_n_0\
    );
\ram_addr[5]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8000"
    )
        port map (
      I0 => ram_addr(3),
      I1 => ram_addr(1),
      I2 => ram_addr(0),
      I3 => ram_addr(2),
      O => \ram_addr[5]_i_2_n_0\
    );
\ram_addr_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => \ram_addr[4]_i_2_n_0\,
      D => \ram_addr[0]_i_1_n_0\,
      Q => ram_addr(0),
      R => \ram_addr[4]_i_1_n_0\
    );
\ram_addr_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => \ram_addr[4]_i_2_n_0\,
      D => \ram_addr[1]_i_1_n_0\,
      Q => ram_addr(1),
      R => \ram_addr[4]_i_1_n_0\
    );
\ram_addr_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => \ram_addr[4]_i_2_n_0\,
      D => \ram_addr[2]_i_1_n_0\,
      Q => ram_addr(2),
      R => \ram_addr[4]_i_1_n_0\
    );
\ram_addr_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => '1',
      D => \ram_addr[3]_i_1_n_0\,
      Q => ram_addr(3),
      R => '0'
    );
\ram_addr_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => \ram_addr[4]_i_2_n_0\,
      D => \ram_addr[4]_i_3_n_0\,
      Q => ram_addr(4),
      R => \ram_addr[4]_i_1_n_0\
    );
\ram_addr_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => '1',
      D => \ram_addr[5]_i_1_n_0\,
      Q => ram_addr(5),
      R => '0'
    );
\ram_do[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00E2FFFF00E20000"
    )
        port map (
      I0 => \ram_do[0]_i_2_n_0\,
      I1 => ram_addr(3),
      I2 => \ram_do[0]_i_3_n_0\,
      I3 => ram_addr(4),
      I4 => ram_addr(5),
      I5 => \ram_do[0]_i_4_n_0\,
      O => ram(0)
    );
\ram_do[0]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A000A000CFFFC000"
    )
        port map (
      I0 => \ram_reg[39]_6\(0),
      I1 => \ram_reg[38]_7\(0),
      I2 => ram_addr(1),
      I3 => ram_addr(2),
      I4 => \ram_reg[40]_5\(7),
      I5 => ram_addr(0),
      O => \ram_do[0]_i_2_n_0\
    );
\ram_do[0]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000F8C83808"
    )
        port map (
      I0 => \ram_reg[41]_4\(0),
      I1 => ram_addr(0),
      I2 => ram_addr(1),
      I3 => \ram_reg[42]_3\(0),
      I4 => \ram_reg[43]_2\(0),
      I5 => ram_addr(2),
      O => \ram_do[0]_i_3_n_0\
    );
\ram_do[0]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BBB8BBB88888888B"
    )
        port map (
      I0 => \ram_do[0]_i_5_n_0\,
      I1 => ram_addr(4),
      I2 => ram_addr(3),
      I3 => ram_addr(2),
      I4 => ram_addr(1),
      I5 => ram_addr(0),
      O => \ram_do[0]_i_4_n_0\
    );
\ram_do[0]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B888BBBB88BB8888"
    )
        port map (
      I0 => \ram_do[0]_i_6_n_0\,
      I1 => ram_addr(3),
      I2 => \ram_reg[23]_11\(37),
      I3 => ram_addr(0),
      I4 => ram_addr(2),
      I5 => ram_addr(1),
      O => \ram_do[0]_i_5_n_0\
    );
\ram_do[0]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0033B8880000B888"
    )
        port map (
      I0 => \ram_reg[40]_5\(7),
      I1 => ram_addr(2),
      I2 => \ram_reg[26]_9\(0),
      I3 => ram_addr(1),
      I4 => ram_addr(0),
      I5 => \ram_reg[25]_10\(8),
      O => \ram_do[0]_i_6_n_0\
    );
\ram_do[10]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"30BB3088"
    )
        port map (
      I0 => \ram_do_reg[10]_i_2_n_0\,
      I1 => ram_addr(5),
      I2 => \ram_do[10]_i_3_n_0\,
      I3 => ram_addr(4),
      I4 => \ram_do[10]_i_4_n_0\,
      O => ram(10)
    );
\ram_do[10]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"3033008800003300"
    )
        port map (
      I0 => \ram_reg[25]_10\(10),
      I1 => ram_addr(3),
      I2 => \ram_reg[23]_11\(37),
      I3 => ram_addr(2),
      I4 => ram_addr(1),
      I5 => ram_addr(0),
      O => \ram_do[10]_i_3_n_0\
    );
\ram_do[10]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"01"
    )
        port map (
      I0 => ram_addr(0),
      I1 => ram_addr(2),
      I2 => ram_addr(3),
      O => \ram_do[10]_i_4_n_0\
    );
\ram_do[10]_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"A0800080"
    )
        port map (
      I0 => ram_addr(2),
      I1 => \ram_reg[37]_8\(10),
      I2 => ram_addr(0),
      I3 => ram_addr(1),
      I4 => \ram_reg[39]_6\(10),
      O => \ram_do[10]_i_5_n_0\
    );
\ram_do[10]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000F4A45404"
    )
        port map (
      I0 => ram_addr(0),
      I1 => \ram_reg[40]_5\(10),
      I2 => ram_addr(1),
      I3 => \ram_reg[42]_3\(10),
      I4 => \ram_reg[43]_2\(10),
      I5 => ram_addr(2),
      O => \ram_do[10]_i_6_n_0\
    );
\ram_do[11]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00E2FFFF00E20000"
    )
        port map (
      I0 => \ram_do[11]_i_2_n_0\,
      I1 => ram_addr(3),
      I2 => \ram_do[11]_i_3_n_0\,
      I3 => ram_addr(4),
      I4 => ram_addr(5),
      I5 => \ram_do[11]_i_4_n_0\,
      O => ram(11)
    );
\ram_do[11]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0080"
    )
        port map (
      I0 => ram_addr(2),
      I1 => \ram_reg[40]_5\(13),
      I2 => ram_addr(0),
      I3 => ram_addr(1),
      O => \ram_do[11]_i_2_n_0\
    );
\ram_do[11]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00E2FFFF00E20000"
    )
        port map (
      I0 => \ram_reg[44]_1\(11),
      I1 => ram_addr(0),
      I2 => \ram_reg[45]_0\(11),
      I3 => ram_addr(1),
      I4 => ram_addr(2),
      I5 => \ram_do[11]_i_5_n_0\,
      O => \ram_do[11]_i_3_n_0\
    );
\ram_do[11]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000008CCC00C3"
    )
        port map (
      I0 => \ram_reg[23]_11\(37),
      I1 => ram_addr(4),
      I2 => ram_addr(2),
      I3 => ram_addr(1),
      I4 => ram_addr(0),
      I5 => ram_addr(3),
      O => \ram_do[11]_i_4_n_0\
    );
\ram_do[11]_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"A0A0CFC0"
    )
        port map (
      I0 => \ram_reg[43]_2\(11),
      I1 => \ram_reg[42]_3\(11),
      I2 => ram_addr(1),
      I3 => \ram_reg[40]_5\(11),
      I4 => ram_addr(0),
      O => \ram_do[11]_i_5_n_0\
    );
\ram_do[12]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00E2FFFF00E20000"
    )
        port map (
      I0 => \ram_do[12]_i_2_n_0\,
      I1 => ram_addr(3),
      I2 => \ram_do[12]_i_3_n_0\,
      I3 => ram_addr(4),
      I4 => ram_addr(5),
      I5 => \ram_do[12]_i_4_n_0\,
      O => ram(12)
    );
\ram_do[12]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0080"
    )
        port map (
      I0 => ram_addr(2),
      I1 => ram_addr(0),
      I2 => \ram_reg[40]_5\(14),
      I3 => ram_addr(1),
      O => \ram_do[12]_i_2_n_0\
    );
\ram_do[12]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00E2FFFF00E20000"
    )
        port map (
      I0 => \ram_reg[44]_1\(12),
      I1 => ram_addr(0),
      I2 => \ram_reg[45]_0\(12),
      I3 => ram_addr(1),
      I4 => ram_addr(2),
      I5 => \ram_do[12]_i_5_n_0\,
      O => \ram_do[12]_i_3_n_0\
    );
\ram_do[12]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"083C0C0C0C000C03"
    )
        port map (
      I0 => \ram_reg[23]_11\(37),
      I1 => ram_addr(4),
      I2 => ram_addr(3),
      I3 => ram_addr(0),
      I4 => ram_addr(1),
      I5 => ram_addr(2),
      O => \ram_do[12]_i_4_n_0\
    );
\ram_do[12]_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"A0A0CFC0"
    )
        port map (
      I0 => \ram_reg[43]_2\(12),
      I1 => \ram_reg[42]_3\(12),
      I2 => ram_addr(1),
      I3 => \ram_reg[40]_5\(12),
      I4 => ram_addr(0),
      O => \ram_do[12]_i_5_n_0\
    );
\ram_do[13]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00E2FFFF00E20000"
    )
        port map (
      I0 => \ram_do[13]_i_2_n_0\,
      I1 => ram_addr(3),
      I2 => \ram_do[13]_i_3_n_0\,
      I3 => ram_addr(4),
      I4 => ram_addr(5),
      I5 => \ram_do[13]_i_4_n_0\,
      O => ram(13)
    );
\ram_do[13]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0A800080"
    )
        port map (
      I0 => ram_addr(2),
      I1 => \ram_reg[37]_8\(13),
      I2 => ram_addr(0),
      I3 => ram_addr(1),
      I4 => \ram_reg[38]_7\(13),
      O => \ram_do[13]_i_2_n_0\
    );
\ram_do[13]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000F4A45404"
    )
        port map (
      I0 => ram_addr(0),
      I1 => \ram_reg[40]_5\(13),
      I2 => ram_addr(1),
      I3 => \ram_reg[42]_3\(13),
      I4 => \ram_reg[43]_2\(13),
      I5 => ram_addr(2),
      O => \ram_do[13]_i_3_n_0\
    );
\ram_do[13]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0830000C0C000003"
    )
        port map (
      I0 => \ram_reg[23]_11\(37),
      I1 => ram_addr(4),
      I2 => ram_addr(3),
      I3 => ram_addr(0),
      I4 => ram_addr(1),
      I5 => ram_addr(2),
      O => \ram_do[13]_i_4_n_0\
    );
\ram_do[14]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"08FF0800"
    )
        port map (
      I0 => \ram_do[14]_i_2_n_0\,
      I1 => ram_addr(3),
      I2 => ram_addr(4),
      I3 => ram_addr(5),
      I4 => \ram_do[14]_i_3_n_0\,
      O => ram(14)
    );
\ram_do[14]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000F4A45404"
    )
        port map (
      I0 => ram_addr(0),
      I1 => \ram_reg[40]_5\(14),
      I2 => ram_addr(1),
      I3 => \ram_reg[42]_3\(14),
      I4 => \ram_reg[43]_2\(14),
      I5 => ram_addr(2),
      O => \ram_do[14]_i_2_n_0\
    );
\ram_do[14]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000008C0C00C3"
    )
        port map (
      I0 => \ram_reg[23]_11\(37),
      I1 => ram_addr(4),
      I2 => ram_addr(2),
      I3 => ram_addr(1),
      I4 => ram_addr(0),
      I5 => ram_addr(3),
      O => \ram_do[14]_i_3_n_0\
    );
\ram_do[15]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2F20"
    )
        port map (
      I0 => \ram_do[15]_i_2_n_0\,
      I1 => ram_addr(4),
      I2 => ram_addr(5),
      I3 => \ram_do[15]_i_3_n_0\,
      O => ram(15)
    );
\ram_do[15]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000A80800000000"
    )
        port map (
      I0 => ram_addr(3),
      I1 => \ram_reg[44]_1\(15),
      I2 => ram_addr(0),
      I3 => \ram_reg[45]_0\(15),
      I4 => ram_addr(1),
      I5 => ram_addr(2),
      O => \ram_do[15]_i_2_n_0\
    );
\ram_do[15]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000080C00003"
    )
        port map (
      I0 => \ram_reg[23]_11\(37),
      I1 => ram_addr(4),
      I2 => ram_addr(2),
      I3 => ram_addr(1),
      I4 => ram_addr(0),
      I5 => ram_addr(3),
      O => \ram_do[15]_i_3_n_0\
    );
\ram_do[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00E2FFFF00E20000"
    )
        port map (
      I0 => \ram_do[1]_i_2_n_0\,
      I1 => ram_addr(3),
      I2 => \ram_do[1]_i_3_n_0\,
      I3 => ram_addr(4),
      I4 => ram_addr(5),
      I5 => \ram_do[1]_i_4_n_0\,
      O => ram(1)
    );
\ram_do[1]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"8A800000"
    )
        port map (
      I0 => ram_addr(2),
      I1 => \ram_reg[39]_6\(8),
      I2 => ram_addr(0),
      I3 => \ram_reg[38]_7\(1),
      I4 => ram_addr(1),
      O => \ram_do[1]_i_2_n_0\
    );
\ram_do[1]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000F8C83808"
    )
        port map (
      I0 => \ram_reg[41]_4\(1),
      I1 => ram_addr(0),
      I2 => ram_addr(1),
      I3 => \ram_reg[42]_3\(1),
      I4 => \ram_reg[43]_2\(1),
      I5 => ram_addr(2),
      O => \ram_do[1]_i_3_n_0\
    );
\ram_do[1]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A0A0A0A0C0C0C0CF"
    )
        port map (
      I0 => \ram_do[1]_i_5_n_0\,
      I1 => \ram_do[4]_i_7_n_0\,
      I2 => ram_addr(4),
      I3 => ram_addr(0),
      I4 => ram_addr(2),
      I5 => ram_addr(3),
      O => \ram_do[1]_i_4_n_0\
    );
\ram_do[1]_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00003808"
    )
        port map (
      I0 => \ram_reg[25]_10\(10),
      I1 => ram_addr(0),
      I2 => ram_addr(1),
      I3 => \ram_reg[26]_9\(1),
      I4 => ram_addr(2),
      O => \ram_do[1]_i_5_n_0\
    );
\ram_do[23]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0830000008000000"
    )
        port map (
      I0 => \ram_do[23]_i_2_n_0\,
      I1 => ram_addr(5),
      I2 => ram_addr(4),
      I3 => ram_addr(3),
      I4 => ram_addr(2),
      I5 => \ram_do[23]_i_3_n_0\,
      O => ram(23)
    );
\ram_do[23]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"04"
    )
        port map (
      I0 => ram_addr(0),
      I1 => \ram_reg[44]_1\(38),
      I2 => ram_addr(1),
      O => \ram_do[23]_i_2_n_0\
    );
\ram_do[23]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => ram_addr(0),
      I1 => ram_addr(1),
      O => \ram_do[23]_i_3_n_0\
    );
\ram_do[27]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A0008000000F0FC0"
    )
        port map (
      I0 => \ram_reg[44]_1\(38),
      I1 => ram_addr(1),
      I2 => ram_addr(4),
      I3 => ram_addr(3),
      I4 => ram_addr(2),
      I5 => ram_addr(0),
      O => \ram_do[27]_i_2_n_0\
    );
\ram_do[27]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000040"
    )
        port map (
      I0 => ram_addr(2),
      I1 => \ram_reg[44]_1\(38),
      I2 => ram_addr(0),
      I3 => ram_addr(1),
      I4 => ram_addr(4),
      O => \ram_do[27]_i_3_n_0\
    );
\ram_do[28]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8833BB3FB833B30C"
    )
        port map (
      I0 => \ram_reg[44]_1\(38),
      I1 => ram_addr(4),
      I2 => ram_addr(0),
      I3 => ram_addr(3),
      I4 => ram_addr(2),
      I5 => ram_addr(1),
      O => \ram_do[28]_i_2_n_0\
    );
\ram_do[28]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000000020822A"
    )
        port map (
      I0 => \ram_reg[44]_1\(38),
      I1 => ram_addr(1),
      I2 => ram_addr(0),
      I3 => ram_addr(2),
      I4 => ram_addr(3),
      I5 => ram_addr(4),
      O => \ram_do[28]_i_3_n_0\
    );
\ram_do[29]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A030800000CF0FC0"
    )
        port map (
      I0 => \ram_reg[44]_1\(38),
      I1 => ram_addr(1),
      I2 => ram_addr(4),
      I3 => ram_addr(3),
      I4 => ram_addr(2),
      I5 => ram_addr(0),
      O => \ram_do[29]_i_2_n_0\
    );
\ram_do[29]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000E80040"
    )
        port map (
      I0 => ram_addr(2),
      I1 => \ram_reg[44]_1\(38),
      I2 => ram_addr(0),
      I3 => ram_addr(1),
      I4 => ram_addr(3),
      I5 => ram_addr(4),
      O => \ram_do[29]_i_3_n_0\
    );
\ram_do[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00E2FFFF00E20000"
    )
        port map (
      I0 => \ram_do[2]_i_2_n_0\,
      I1 => ram_addr(3),
      I2 => \ram_do[2]_i_3_n_0\,
      I3 => ram_addr(4),
      I4 => ram_addr(5),
      I5 => \ram_do[2]_i_4_n_0\,
      O => ram(2)
    );
\ram_do[2]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"8A800000"
    )
        port map (
      I0 => ram_addr(2),
      I1 => \ram_reg[39]_6\(8),
      I2 => ram_addr(0),
      I3 => \ram_reg[38]_7\(2),
      I4 => ram_addr(1),
      O => \ram_do[2]_i_2_n_0\
    );
\ram_do[2]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000F8C83808"
    )
        port map (
      I0 => \ram_reg[41]_4\(2),
      I1 => ram_addr(0),
      I2 => ram_addr(1),
      I3 => \ram_reg[42]_3\(2),
      I4 => \ram_reg[43]_2\(2),
      I5 => ram_addr(2),
      O => \ram_do[2]_i_3_n_0\
    );
\ram_do[2]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A0A0A0A0C0C0C0CF"
    )
        port map (
      I0 => \ram_do[2]_i_5_n_0\,
      I1 => \ram_do[4]_i_7_n_0\,
      I2 => ram_addr(4),
      I3 => ram_addr(2),
      I4 => \ram_do[38]_i_3_n_0\,
      I5 => ram_addr(3),
      O => \ram_do[2]_i_4_n_0\
    );
\ram_do[2]_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00003808"
    )
        port map (
      I0 => \ram_reg[25]_10\(8),
      I1 => ram_addr(0),
      I2 => ram_addr(1),
      I3 => \ram_reg[26]_9\(2),
      I4 => ram_addr(2),
      O => \ram_do[2]_i_5_n_0\
    );
\ram_do[30]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B80C800033F333C0"
    )
        port map (
      I0 => \ram_reg[44]_1\(38),
      I1 => ram_addr(4),
      I2 => ram_addr(1),
      I3 => ram_addr(3),
      I4 => ram_addr(2),
      I5 => ram_addr(0),
      O => \ram_do[30]_i_2_n_0\
    );
\ram_do[30]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000E82888"
    )
        port map (
      I0 => \ram_reg[44]_1\(38),
      I1 => ram_addr(0),
      I2 => ram_addr(2),
      I3 => ram_addr(1),
      I4 => ram_addr(3),
      I5 => ram_addr(4),
      O => \ram_do[30]_i_3_n_0\
    );
\ram_do[31]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B08C333C800F3FB0"
    )
        port map (
      I0 => \ram_reg[44]_1\(38),
      I1 => ram_addr(4),
      I2 => ram_addr(3),
      I3 => ram_addr(2),
      I4 => ram_addr(0),
      I5 => ram_addr(1),
      O => \ram_do[31]_i_2_n_0\
    );
\ram_do[31]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000000A0A2888"
    )
        port map (
      I0 => \ram_reg[44]_1\(38),
      I1 => ram_addr(0),
      I2 => ram_addr(2),
      I3 => ram_addr(1),
      I4 => ram_addr(3),
      I5 => ram_addr(4),
      O => \ram_do[31]_i_3_n_0\
    );
\ram_do[32]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"808C3F30800F33B0"
    )
        port map (
      I0 => \ram_reg[44]_1\(38),
      I1 => ram_addr(4),
      I2 => ram_addr(3),
      I3 => ram_addr(2),
      I4 => ram_addr(0),
      I5 => ram_addr(1),
      O => \ram_do[32]_i_2_n_0\
    );
\ram_do[32]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000002C20888"
    )
        port map (
      I0 => \ram_reg[44]_1\(38),
      I1 => ram_addr(0),
      I2 => ram_addr(2),
      I3 => ram_addr(1),
      I4 => ram_addr(3),
      I5 => ram_addr(4),
      O => \ram_do[32]_i_3_n_0\
    );
\ram_do[33]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B3B33C00BC803F30"
    )
        port map (
      I0 => \ram_reg[44]_1\(38),
      I1 => ram_addr(4),
      I2 => ram_addr(3),
      I3 => ram_addr(2),
      I4 => ram_addr(1),
      I5 => ram_addr(0),
      O => \ram_do[33]_i_2_n_0\
    );
\ram_do[33]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000382028A8"
    )
        port map (
      I0 => \ram_reg[44]_1\(38),
      I1 => ram_addr(1),
      I2 => ram_addr(2),
      I3 => ram_addr(0),
      I4 => ram_addr(3),
      I5 => ram_addr(4),
      O => \ram_do[33]_i_3_n_0\
    );
\ram_do[34]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B3308F0C8F00B03C"
    )
        port map (
      I0 => \ram_reg[44]_1\(38),
      I1 => ram_addr(4),
      I2 => ram_addr(3),
      I3 => ram_addr(2),
      I4 => ram_addr(1),
      I5 => ram_addr(0),
      O => \ram_do[34]_i_2_n_0\
    );
\ram_do[34]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000038280828"
    )
        port map (
      I0 => \ram_reg[44]_1\(38),
      I1 => ram_addr(1),
      I2 => ram_addr(3),
      I3 => ram_addr(0),
      I4 => ram_addr(2),
      I5 => ram_addr(4),
      O => \ram_do[34]_i_3_n_0\
    );
\ram_do[35]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8888888BBBBBBBBB"
    )
        port map (
      I0 => \ram_do[35]_i_4_n_0\,
      I1 => ram_addr(4),
      I2 => ram_addr(2),
      I3 => ram_addr(1),
      I4 => ram_addr(0),
      I5 => ram_addr(3),
      O => \ram_do[35]_i_2_n_0\
    );
\ram_do[35]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000007E280000"
    )
        port map (
      I0 => ram_addr(2),
      I1 => ram_addr(1),
      I2 => ram_addr(0),
      I3 => \ram_reg[44]_1\(38),
      I4 => ram_addr(3),
      I5 => ram_addr(4),
      O => \ram_do[35]_i_3_n_0\
    );
\ram_do[35]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BB8BBBBBBBBB8888"
    )
        port map (
      I0 => \ram_reg[44]_1\(38),
      I1 => ram_addr(3),
      I2 => ram_addr(0),
      I3 => \ram_reg[23]_11\(37),
      I4 => ram_addr(2),
      I5 => ram_addr(1),
      O => \ram_do[35]_i_4_n_0\
    );
\ram_do[36]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"44422662"
    )
        port map (
      I0 => ram_addr(4),
      I1 => ram_addr(3),
      I2 => ram_addr(0),
      I3 => ram_addr(1),
      I4 => ram_addr(2),
      O => \ram_do[36]_i_2_n_0\
    );
\ram_do[36]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000CC4"
    )
        port map (
      I0 => ram_addr(1),
      I1 => \ram_reg[44]_1\(38),
      I2 => ram_addr(2),
      I3 => ram_addr(3),
      I4 => ram_addr(4),
      O => \ram_do[36]_i_3_n_0\
    );
\ram_do[37]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000080000003"
    )
        port map (
      I0 => \ram_reg[23]_11\(37),
      I1 => ram_addr(4),
      I2 => ram_addr(2),
      I3 => ram_addr(1),
      I4 => ram_addr(0),
      I5 => ram_addr(3),
      O => \ram_do[37]_i_2_n_0\
    );
\ram_do[37]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00002000"
    )
        port map (
      I0 => ram_addr(2),
      I1 => ram_addr(0),
      I2 => ram_addr(1),
      I3 => ram_addr(3),
      I4 => ram_addr(4),
      O => \ram_do[37]_i_3_n_0\
    );
\ram_do[38]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0830000008000000"
    )
        port map (
      I0 => \ram_do[38]_i_2_n_0\,
      I1 => ram_addr(5),
      I2 => ram_addr(4),
      I3 => ram_addr(3),
      I4 => ram_addr(2),
      I5 => \ram_do[38]_i_3_n_0\,
      O => ram(38)
    );
\ram_do[38]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"0E"
    )
        port map (
      I0 => \ram_reg[44]_1\(38),
      I1 => ram_addr(0),
      I2 => ram_addr(1),
      O => \ram_do[38]_i_2_n_0\
    );
\ram_do[38]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => ram_addr(1),
      I1 => ram_addr(0),
      O => \ram_do[38]_i_3_n_0\
    );
\ram_do[3]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"30BB3088"
    )
        port map (
      I0 => \ram_do_reg[3]_i_2_n_0\,
      I1 => ram_addr(5),
      I2 => \ram_do[3]_i_3_n_0\,
      I3 => ram_addr(4),
      I4 => \ram_do[9]_i_4_n_0\,
      O => ram(3)
    );
\ram_do[3]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"300000000033BB33"
    )
        port map (
      I0 => \ram_reg[26]_9\(5),
      I1 => ram_addr(3),
      I2 => \ram_reg[23]_11\(37),
      I3 => ram_addr(1),
      I4 => ram_addr(2),
      I5 => ram_addr(0),
      O => \ram_do[3]_i_3_n_0\
    );
\ram_do[3]_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"8A800000"
    )
        port map (
      I0 => ram_addr(2),
      I1 => \ram_reg[39]_6\(9),
      I2 => ram_addr(0),
      I3 => \ram_reg[38]_7\(3),
      I4 => ram_addr(1),
      O => \ram_do[3]_i_4_n_0\
    );
\ram_do[3]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000F8C83808"
    )
        port map (
      I0 => \ram_reg[41]_4\(3),
      I1 => ram_addr(0),
      I2 => ram_addr(1),
      I3 => \ram_reg[42]_3\(3),
      I4 => \ram_reg[43]_2\(3),
      I5 => ram_addr(2),
      O => \ram_do[3]_i_5_n_0\
    );
\ram_do[4]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00E2FFFF00E20000"
    )
        port map (
      I0 => \ram_do[4]_i_2_n_0\,
      I1 => ram_addr(3),
      I2 => \ram_do[4]_i_3_n_0\,
      I3 => ram_addr(4),
      I4 => ram_addr(5),
      I5 => \ram_do[4]_i_4_n_0\,
      O => ram(4)
    );
\ram_do[4]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"8A800000"
    )
        port map (
      I0 => ram_addr(2),
      I1 => \ram_reg[39]_6\(10),
      I2 => ram_addr(0),
      I3 => \ram_reg[38]_7\(4),
      I4 => ram_addr(1),
      O => \ram_do[4]_i_2_n_0\
    );
\ram_do[4]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"08FF0800"
    )
        port map (
      I0 => \ram_reg[45]_0\(4),
      I1 => ram_addr(0),
      I2 => ram_addr(1),
      I3 => ram_addr(2),
      I4 => \ram_do[4]_i_5_n_0\,
      O => \ram_do[4]_i_3_n_0\
    );
\ram_do[4]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A0A0A0A0C0C0C0CF"
    )
        port map (
      I0 => \ram_do[4]_i_6_n_0\,
      I1 => \ram_do[4]_i_7_n_0\,
      I2 => ram_addr(4),
      I3 => ram_addr(0),
      I4 => ram_addr(2),
      I5 => ram_addr(3),
      O => \ram_do[4]_i_4_n_0\
    );
\ram_do[4]_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AFC0A0C0"
    )
        port map (
      I0 => \ram_reg[43]_2\(4),
      I1 => \ram_reg[42]_3\(4),
      I2 => ram_addr(1),
      I3 => ram_addr(0),
      I4 => \ram_reg[41]_4\(4),
      O => \ram_do[4]_i_5_n_0\
    );
\ram_do[4]_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00003808"
    )
        port map (
      I0 => \ram_reg[25]_10\(10),
      I1 => ram_addr(0),
      I2 => ram_addr(1),
      I3 => \ram_reg[26]_9\(5),
      I4 => ram_addr(2),
      O => \ram_do[4]_i_6_n_0\
    );
\ram_do[4]_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8030"
    )
        port map (
      I0 => \ram_reg[23]_11\(37),
      I1 => ram_addr(2),
      I2 => ram_addr(1),
      I3 => ram_addr(0),
      O => \ram_do[4]_i_7_n_0\
    );
\ram_do[5]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"30BB3088"
    )
        port map (
      I0 => \ram_do_reg[5]_i_2_n_0\,
      I1 => ram_addr(5),
      I2 => \ram_do[5]_i_3_n_0\,
      I3 => ram_addr(4),
      I4 => \ram_do[9]_i_4_n_0\,
      O => ram(5)
    );
\ram_do[5]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"3000000000BB3300"
    )
        port map (
      I0 => \ram_reg[26]_9\(5),
      I1 => ram_addr(3),
      I2 => \ram_reg[23]_11\(37),
      I3 => ram_addr(2),
      I4 => ram_addr(1),
      I5 => ram_addr(0),
      O => \ram_do[5]_i_3_n_0\
    );
\ram_do[5]_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2000"
    )
        port map (
      I0 => ram_addr(2),
      I1 => ram_addr(0),
      I2 => \ram_reg[38]_7\(5),
      I3 => ram_addr(1),
      O => \ram_do[5]_i_4_n_0\
    );
\ram_do[5]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000F8C83808"
    )
        port map (
      I0 => \ram_reg[41]_4\(5),
      I1 => ram_addr(0),
      I2 => ram_addr(1),
      I3 => \ram_reg[42]_3\(5),
      I4 => \ram_reg[43]_2\(5),
      I5 => ram_addr(2),
      O => \ram_do[5]_i_5_n_0\
    );
\ram_do[6]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00E2FFFF00E20000"
    )
        port map (
      I0 => \ram_do[6]_i_2_n_0\,
      I1 => ram_addr(3),
      I2 => \ram_do[6]_i_3_n_0\,
      I3 => ram_addr(4),
      I4 => ram_addr(5),
      I5 => \ram_do[6]_i_4_n_0\,
      O => ram(6)
    );
\ram_do[6]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8FFFFFFB8000000"
    )
        port map (
      I0 => \ram_reg[39]_6\(6),
      I1 => ram_addr(0),
      I2 => \ram_reg[38]_7\(6),
      I3 => ram_addr(1),
      I4 => ram_addr(2),
      I5 => \ram_reg[40]_5\(7),
      O => \ram_do[6]_i_2_n_0\
    );
\ram_do[6]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000F8C83808"
    )
        port map (
      I0 => \ram_reg[41]_4\(6),
      I1 => ram_addr(0),
      I2 => ram_addr(1),
      I3 => \ram_reg[42]_3\(6),
      I4 => \ram_reg[43]_2\(6),
      I5 => ram_addr(2),
      O => \ram_do[6]_i_3_n_0\
    );
\ram_do[6]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BBBBBBB8BBBBB8BB"
    )
        port map (
      I0 => \ram_do[6]_i_5_n_0\,
      I1 => ram_addr(4),
      I2 => ram_addr(3),
      I3 => ram_addr(0),
      I4 => ram_addr(1),
      I5 => ram_addr(2),
      O => \ram_do[6]_i_4_n_0\
    );
\ram_do[6]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B08888B0808888B0"
    )
        port map (
      I0 => \ram_reg[40]_5\(7),
      I1 => ram_addr(3),
      I2 => ram_addr(2),
      I3 => ram_addr(0),
      I4 => ram_addr(1),
      I5 => \ram_reg[23]_11\(37),
      O => \ram_do[6]_i_5_n_0\
    );
\ram_do[7]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00E2FFFF00E20000"
    )
        port map (
      I0 => \ram_do[7]_i_2_n_0\,
      I1 => ram_addr(3),
      I2 => \ram_do[7]_i_3_n_0\,
      I3 => ram_addr(4),
      I4 => ram_addr(5),
      I5 => \ram_do[7]_i_4_n_0\,
      O => ram(7)
    );
\ram_do[7]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"8A800000"
    )
        port map (
      I0 => ram_addr(2),
      I1 => \ram_reg[39]_6\(7),
      I2 => ram_addr(0),
      I3 => \ram_reg[38]_7\(13),
      I4 => ram_addr(1),
      O => \ram_do[7]_i_2_n_0\
    );
\ram_do[7]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"08FF0800"
    )
        port map (
      I0 => \ram_reg[45]_0\(7),
      I1 => ram_addr(0),
      I2 => ram_addr(1),
      I3 => ram_addr(2),
      I4 => \ram_do[7]_i_5_n_0\,
      O => \ram_do[7]_i_3_n_0\
    );
\ram_do[7]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"88888888888BBB8B"
    )
        port map (
      I0 => \ram_do[7]_i_6_n_0\,
      I1 => ram_addr(4),
      I2 => ram_addr(1),
      I3 => ram_addr(0),
      I4 => ram_addr(2),
      I5 => ram_addr(3),
      O => \ram_do[7]_i_4_n_0\
    );
\ram_do[7]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \ram_reg[43]_2\(7),
      I1 => \ram_reg[42]_3\(7),
      I2 => ram_addr(1),
      I3 => \ram_reg[41]_4\(7),
      I4 => ram_addr(0),
      I5 => \ram_reg[40]_5\(7),
      O => \ram_do[7]_i_5_n_0\
    );
\ram_do[7]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"3088008800333388"
    )
        port map (
      I0 => \ram_reg[25]_10\(10),
      I1 => ram_addr(3),
      I2 => \ram_reg[23]_11\(37),
      I3 => ram_addr(2),
      I4 => ram_addr(0),
      I5 => ram_addr(1),
      O => \ram_do[7]_i_6_n_0\
    );
\ram_do[8]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"30BB3088"
    )
        port map (
      I0 => \ram_do[8]_i_2_n_0\,
      I1 => ram_addr(5),
      I2 => \ram_do[8]_i_3_n_0\,
      I3 => ram_addr(4),
      I4 => \ram_do[9]_i_4_n_0\,
      O => ram(8)
    );
\ram_do[8]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B888888888888888"
    )
        port map (
      I0 => \ram_do[8]_i_4_n_0\,
      I1 => ram_addr(3),
      I2 => ram_addr(2),
      I3 => ram_addr(0),
      I4 => \ram_reg[39]_6\(8),
      I5 => ram_addr(1),
      O => \ram_do[8]_i_2_n_0\
    );
\ram_do[8]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"3038003830303030"
    )
        port map (
      I0 => \ram_reg[25]_10\(8),
      I1 => ram_addr(3),
      I2 => ram_addr(2),
      I3 => ram_addr(1),
      I4 => \ram_reg[23]_11\(37),
      I5 => ram_addr(0),
      O => \ram_do[8]_i_3_n_0\
    );
\ram_do[8]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00E2FFFF00E20000"
    )
        port map (
      I0 => \ram_reg[44]_1\(8),
      I1 => ram_addr(0),
      I2 => \ram_reg[45]_0\(8),
      I3 => ram_addr(1),
      I4 => ram_addr(2),
      I5 => \ram_do[8]_i_5_n_0\,
      O => \ram_do[8]_i_4_n_0\
    );
\ram_do[8]_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AFC0A0C0"
    )
        port map (
      I0 => \ram_reg[43]_2\(8),
      I1 => \ram_reg[42]_3\(8),
      I2 => ram_addr(1),
      I3 => ram_addr(0),
      I4 => \ram_reg[41]_4\(8),
      O => \ram_do[8]_i_5_n_0\
    );
\ram_do[9]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0030BBBB00308888"
    )
        port map (
      I0 => \ram_do[9]_i_2_n_0\,
      I1 => ram_addr(5),
      I2 => \ram_do[9]_i_3_n_0\,
      I3 => ram_addr(3),
      I4 => ram_addr(4),
      I5 => \ram_do[9]_i_4_n_0\,
      O => ram(9)
    );
\ram_do[9]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B888888888888888"
    )
        port map (
      I0 => \ram_do[9]_i_5_n_0\,
      I1 => ram_addr(3),
      I2 => ram_addr(2),
      I3 => ram_addr(0),
      I4 => \ram_reg[39]_6\(9),
      I5 => ram_addr(1),
      O => \ram_do[9]_i_2_n_0\
    );
\ram_do[9]_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"803F"
    )
        port map (
      I0 => \ram_reg[23]_11\(37),
      I1 => ram_addr(1),
      I2 => ram_addr(2),
      I3 => ram_addr(0),
      O => \ram_do[9]_i_3_n_0\
    );
\ram_do[9]_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0001"
    )
        port map (
      I0 => ram_addr(2),
      I1 => ram_addr(1),
      I2 => ram_addr(0),
      I3 => ram_addr(3),
      O => \ram_do[9]_i_4_n_0\
    );
\ram_do[9]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000F8C83808"
    )
        port map (
      I0 => \ram_reg[41]_4\(9),
      I1 => ram_addr(0),
      I2 => ram_addr(1),
      I3 => \ram_reg[42]_3\(9),
      I4 => \ram_reg[43]_2\(9),
      I5 => ram_addr(2),
      O => \ram_do[9]_i_5_n_0\
    );
\ram_do_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => '1',
      D => ram(0),
      Q => ram_do(0),
      R => '0'
    );
\ram_do_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => '1',
      D => ram(10),
      Q => ram_do(10),
      R => '0'
    );
\ram_do_reg[10]_i_2\: unisim.vcomponents.MUXF7
     port map (
      I0 => \ram_do[10]_i_5_n_0\,
      I1 => \ram_do[10]_i_6_n_0\,
      O => \ram_do_reg[10]_i_2_n_0\,
      S => ram_addr(3)
    );
\ram_do_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => '1',
      D => ram(11),
      Q => ram_do(11),
      R => '0'
    );
\ram_do_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => '1',
      D => ram(12),
      Q => ram_do(12),
      R => '0'
    );
\ram_do_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => '1',
      D => ram(13),
      Q => ram_do(13),
      R => '0'
    );
\ram_do_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => '1',
      D => ram(14),
      Q => ram_do(14),
      R => '0'
    );
\ram_do_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => '1',
      D => ram(15),
      Q => ram_do(15),
      R => '0'
    );
\ram_do_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => '1',
      D => ram(1),
      Q => ram_do(1),
      R => '0'
    );
\ram_do_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => '1',
      D => ram(23),
      Q => ram_do(23),
      R => '0'
    );
\ram_do_reg[27]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => '1',
      D => ram(27),
      Q => ram_do(27),
      R => '0'
    );
\ram_do_reg[27]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \ram_do[27]_i_2_n_0\,
      I1 => \ram_do[27]_i_3_n_0\,
      O => ram(27),
      S => ram_addr(5)
    );
\ram_do_reg[28]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => '1',
      D => ram(28),
      Q => ram_do(28),
      R => '0'
    );
\ram_do_reg[28]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \ram_do[28]_i_2_n_0\,
      I1 => \ram_do[28]_i_3_n_0\,
      O => ram(28),
      S => ram_addr(5)
    );
\ram_do_reg[29]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => '1',
      D => ram(29),
      Q => ram_do(29),
      R => '0'
    );
\ram_do_reg[29]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \ram_do[29]_i_2_n_0\,
      I1 => \ram_do[29]_i_3_n_0\,
      O => ram(29),
      S => ram_addr(5)
    );
\ram_do_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => '1',
      D => ram(2),
      Q => ram_do(2),
      R => '0'
    );
\ram_do_reg[30]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => '1',
      D => ram(30),
      Q => ram_do(30),
      R => '0'
    );
\ram_do_reg[30]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \ram_do[30]_i_2_n_0\,
      I1 => \ram_do[30]_i_3_n_0\,
      O => ram(30),
      S => ram_addr(5)
    );
\ram_do_reg[31]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => '1',
      D => ram(31),
      Q => ram_do(31),
      R => '0'
    );
\ram_do_reg[31]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \ram_do[31]_i_2_n_0\,
      I1 => \ram_do[31]_i_3_n_0\,
      O => ram(31),
      S => ram_addr(5)
    );
\ram_do_reg[32]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => '1',
      D => ram(32),
      Q => ram_do(32),
      R => '0'
    );
\ram_do_reg[32]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \ram_do[32]_i_2_n_0\,
      I1 => \ram_do[32]_i_3_n_0\,
      O => ram(32),
      S => ram_addr(5)
    );
\ram_do_reg[33]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => '1',
      D => ram(33),
      Q => ram_do(33),
      R => '0'
    );
\ram_do_reg[33]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \ram_do[33]_i_2_n_0\,
      I1 => \ram_do[33]_i_3_n_0\,
      O => ram(33),
      S => ram_addr(5)
    );
\ram_do_reg[34]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => '1',
      D => ram(34),
      Q => ram_do(34),
      R => '0'
    );
\ram_do_reg[34]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \ram_do[34]_i_2_n_0\,
      I1 => \ram_do[34]_i_3_n_0\,
      O => ram(34),
      S => ram_addr(5)
    );
\ram_do_reg[35]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => '1',
      D => ram(35),
      Q => ram_do(35),
      R => '0'
    );
\ram_do_reg[35]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \ram_do[35]_i_2_n_0\,
      I1 => \ram_do[35]_i_3_n_0\,
      O => ram(35),
      S => ram_addr(5)
    );
\ram_do_reg[36]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => '1',
      D => ram(36),
      Q => ram_do(36),
      R => '0'
    );
\ram_do_reg[36]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \ram_do[36]_i_2_n_0\,
      I1 => \ram_do[36]_i_3_n_0\,
      O => ram(36),
      S => ram_addr(5)
    );
\ram_do_reg[37]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => '1',
      D => ram(37),
      Q => ram_do(37),
      R => '0'
    );
\ram_do_reg[37]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \ram_do[37]_i_2_n_0\,
      I1 => \ram_do[37]_i_3_n_0\,
      O => ram(37),
      S => ram_addr(5)
    );
\ram_do_reg[38]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => '1',
      D => ram(38),
      Q => ram_do(38),
      R => '0'
    );
\ram_do_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => '1',
      D => ram(3),
      Q => ram_do(3),
      R => '0'
    );
\ram_do_reg[3]_i_2\: unisim.vcomponents.MUXF7
     port map (
      I0 => \ram_do[3]_i_4_n_0\,
      I1 => \ram_do[3]_i_5_n_0\,
      O => \ram_do_reg[3]_i_2_n_0\,
      S => ram_addr(3)
    );
\ram_do_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => '1',
      D => ram(4),
      Q => ram_do(4),
      R => '0'
    );
\ram_do_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => '1',
      D => ram(5),
      Q => ram_do(5),
      R => '0'
    );
\ram_do_reg[5]_i_2\: unisim.vcomponents.MUXF7
     port map (
      I0 => \ram_do[5]_i_4_n_0\,
      I1 => \ram_do[5]_i_5_n_0\,
      O => \ram_do_reg[5]_i_2_n_0\,
      S => ram_addr(3)
    );
\ram_do_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => '1',
      D => ram(6),
      Q => ram_do(6),
      R => '0'
    );
\ram_do_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => '1',
      D => ram(7),
      Q => ram_do(7),
      R => '0'
    );
\ram_do_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => '1',
      D => ram(8),
      Q => ram_do(8),
      R => '0'
    );
\ram_do_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => '1',
      D => ram(9),
      Q => ram_do(9),
      R => '0'
    );
\ram_reg[23][37]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => '1',
      D => \ram[23][37]_i_1_n_0\,
      Q => \ram_reg[23]_11\(37),
      R => '0'
    );
\ram_reg[25][10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => \ram[25][10]_i_1_n_0\,
      Q => \ram_reg[25]_10\(10),
      R => '0'
    );
\ram_reg[25][8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => \ram[25][8]_i_1_n_0\,
      Q => \ram_reg[25]_10\(8),
      R => '0'
    );
\ram_reg[26][0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => \ram_reg[26][5]_i_1_n_7\,
      Q => \ram_reg[26]_9\(0),
      R => '0'
    );
\ram_reg[26][1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => \ram_reg[26][5]_i_1_n_6\,
      Q => \ram_reg[26]_9\(1),
      R => '0'
    );
\ram_reg[26][2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => \ram_reg[26][5]_i_1_n_5\,
      Q => \ram_reg[26]_9\(2),
      R => '0'
    );
\ram_reg[26][5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => \ram_reg[26][5]_i_1_n_4\,
      Q => \ram_reg[26]_9\(5),
      R => '0'
    );
\ram_reg[26][5]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \NLW_ram_reg[26][5]_i_1_CO_UNCONNECTED\(3),
      CO(2) => \ram_reg[26][5]_i_1_n_1\,
      CO(1) => \ram_reg[26][5]_i_1_n_2\,
      CO(0) => \ram_reg[26][5]_i_1_n_3\,
      CYINIT => '1',
      DI(3) => '0',
      DI(2) => \ram[26][5]_i_2_n_0\,
      DI(1) => '1',
      DI(0) => \ram[26][5]_i_3_n_0\,
      O(3) => \ram_reg[26][5]_i_1_n_4\,
      O(2) => \ram_reg[26][5]_i_1_n_5\,
      O(1) => \ram_reg[26][5]_i_1_n_6\,
      O(0) => \ram_reg[26][5]_i_1_n_7\,
      S(3) => '1',
      S(2) => \ram[26][5]_i_4_n_0\,
      S(1) => \ram[26][5]_i_5_n_0\,
      S(0) => \ram[26][5]_i_6_n_0\
    );
\ram_reg[37][10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => \ram[37][10]_i_1_n_0\,
      Q => \ram_reg[37]_8\(10),
      R => '0'
    );
\ram_reg[37][13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => '1',
      Q => \ram_reg[37]_8\(13),
      R => '0'
    );
\ram_reg[38][0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => \ram_reg[38][0]_i_1_n_7\,
      Q => \ram_reg[38]_7\(0),
      R => '0'
    );
\ram_reg[38][0]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \ram_reg[38][0]_i_1_n_0\,
      CO(2) => \ram_reg[38][0]_i_1_n_1\,
      CO(1) => \ram_reg[38][0]_i_1_n_2\,
      CO(0) => \ram_reg[38][0]_i_1_n_3\,
      CYINIT => '1',
      DI(3) => '0',
      DI(2) => \ram[38][0]_i_2_n_0\,
      DI(1) => \ram[38][0]_i_3_n_0\,
      DI(0) => \ram[38][0]_i_4_n_0\,
      O(3) => \ram_reg[38][0]_i_1_n_4\,
      O(2) => \ram_reg[38][0]_i_1_n_5\,
      O(1) => \ram_reg[38][0]_i_1_n_6\,
      O(0) => \ram_reg[38][0]_i_1_n_7\,
      S(3) => '1',
      S(2) => \ram[38][0]_i_5_n_0\,
      S(1 downto 0) => B"00"
    );
\ram_reg[38][13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => s2_clkfbout_mult(5),
      Q => \ram_reg[38]_7\(13),
      R => '0'
    );
\ram_reg[38][1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => \ram_reg[38][0]_i_1_n_6\,
      Q => \ram_reg[38]_7\(1),
      R => '0'
    );
\ram_reg[38][2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => \ram_reg[38][0]_i_1_n_5\,
      Q => \ram_reg[38]_7\(2),
      R => '0'
    );
\ram_reg[38][3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => \ram_reg[38][0]_i_1_n_4\,
      Q => \ram_reg[38]_7\(3),
      R => '0'
    );
\ram_reg[38][4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => \ram_reg[38][5]_i_1_n_7\,
      Q => \ram_reg[38]_7\(4),
      R => '0'
    );
\ram_reg[38][5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => \ram_reg[38][5]_i_1_n_6\,
      Q => \ram_reg[38]_7\(5),
      R => '0'
    );
\ram_reg[38][5]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \ram_reg[38][0]_i_1_n_0\,
      CO(3 downto 1) => \NLW_ram_reg[38][5]_i_1_CO_UNCONNECTED\(3 downto 1),
      CO(0) => \ram_reg[38][5]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 2) => \NLW_ram_reg[38][5]_i_1_O_UNCONNECTED\(3 downto 2),
      O(1) => \ram_reg[38][5]_i_1_n_6\,
      O(0) => \ram_reg[38][5]_i_1_n_7\,
      S(3 downto 0) => B"0011"
    );
\ram_reg[38][6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => \ram[38][6]_i_1_n_0\,
      Q => \ram_reg[38]_7\(6),
      R => '0'
    );
\ram_reg[39][0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => \ram[39][0]_i_1_n_0\,
      Q => \ram_reg[39]_6\(0),
      R => '0'
    );
\ram_reg[39][10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => \ram[39][10]_i_1_n_0\,
      Q => \ram_reg[39]_6\(10),
      R => '0'
    );
\ram_reg[39][6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => \ram[39][6]_i_1_n_0\,
      Q => \ram_reg[39]_6\(6),
      R => '0'
    );
\ram_reg[39][7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => \ram[39][7]_i_1_n_0\,
      Q => \ram_reg[39]_6\(7),
      R => '0'
    );
\ram_reg[39][8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => \ram[39][8]_i_1_n_0\,
      Q => \ram_reg[39]_6\(8),
      R => '0'
    );
\ram_reg[39][9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => \ram[39][9]_i_1_n_0\,
      Q => \ram_reg[39]_6\(9),
      R => '0'
    );
\ram_reg[40][10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => p_1_out(10),
      Q => \ram_reg[40]_5\(10),
      R => '0'
    );
\ram_reg[40][11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => '1',
      D => \ram[40][11]_i_1_n_0\,
      Q => \ram_reg[40]_5\(11),
      R => '0'
    );
\ram_reg[40][12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => \ram[40][12]_i_1_n_0\,
      Q => \ram_reg[40]_5\(12),
      R => '0'
    );
\ram_reg[40][12]_i_19\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \ram_reg[40][12]_i_19_n_0\,
      CO(2) => \ram_reg[40][12]_i_19_n_1\,
      CO(1) => \ram_reg[40][12]_i_19_n_2\,
      CO(0) => \ram_reg[40][12]_i_19_n_3\,
      CYINIT => '0',
      DI(3) => \ram[40][12]_i_25_n_0\,
      DI(2) => '0',
      DI(1) => \ram[40][12]_i_26_n_0\,
      DI(0) => '0',
      O(3 downto 0) => \NLW_ram_reg[40][12]_i_19_O_UNCONNECTED\(3 downto 0),
      S(3) => \ram[40][12]_i_27_n_0\,
      S(2) => \ram[40][12]_i_28_n_0\,
      S(1 downto 0) => B"11"
    );
\ram_reg[40][12]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \ram_reg[40][12]_i_4_n_0\,
      CO(3) => \ram_reg[40][12]_i_2_n_0\,
      CO(2) => \NLW_ram_reg[40][12]_i_2_CO_UNCONNECTED\(2),
      CO(1) => \ram_reg[40][12]_i_2_n_2\,
      CO(0) => \ram_reg[40][12]_i_2_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \ram[40][12]_i_5_n_0\,
      DI(0) => '0',
      O(3) => \NLW_ram_reg[40][12]_i_2_O_UNCONNECTED\(3),
      O(2) => \ram_reg[40][12]_i_2_n_5\,
      O(1) => \ram_reg[40][12]_i_2_n_6\,
      O(0) => \ram_reg[40][12]_i_2_n_7\,
      S(3) => '1',
      S(2) => \ram[40][12]_i_6_n_0\,
      S(1) => \ram[40][12]_i_7_n_0\,
      S(0) => \ram[40][12]_i_8_n_0\
    );
\ram_reg[40][12]_i_3\: unisim.vcomponents.CARRY4
     port map (
      CI => \ram_reg[40][12]_i_9_n_0\,
      CO(3 downto 2) => \NLW_ram_reg[40][12]_i_3_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \ram_reg[40][12]_i_3_n_2\,
      CO(0) => \ram_reg[40][12]_i_3_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \ram_reg[40][12]_i_2_n_5\,
      DI(0) => \ram[40][12]_i_10_n_0\,
      O(3 downto 0) => \NLW_ram_reg[40][12]_i_3_O_UNCONNECTED\(3 downto 0),
      S(3 downto 2) => B"00",
      S(1) => \ram[40][12]_i_11_n_0\,
      S(0) => \ram[40][12]_i_12_n_0\
    );
\ram_reg[40][12]_i_4\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \ram_reg[40][12]_i_4_n_0\,
      CO(2) => \ram_reg[40][12]_i_4_n_1\,
      CO(1) => \ram_reg[40][12]_i_4_n_2\,
      CO(0) => \ram_reg[40][12]_i_4_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \ram[40][12]_i_13_n_0\,
      DI(0) => \ram[40][12]_i_14_n_0\,
      O(3) => \ram_reg[40][12]_i_4_n_4\,
      O(2) => \ram_reg[40][12]_i_4_n_5\,
      O(1) => \ram_reg[40][12]_i_4_n_6\,
      O(0) => \ram_reg[40][12]_i_4_n_7\,
      S(3) => \ram[40][12]_i_15_n_0\,
      S(2) => \ram[40][12]_i_16_n_0\,
      S(1) => \ram[40][12]_i_17_n_0\,
      S(0) => \ram[40][12]_i_18_n_0\
    );
\ram_reg[40][12]_i_9\: unisim.vcomponents.CARRY4
     port map (
      CI => \ram_reg[40][12]_i_19_n_0\,
      CO(3) => \ram_reg[40][12]_i_9_n_0\,
      CO(2) => \ram_reg[40][12]_i_9_n_1\,
      CO(1) => \ram_reg[40][12]_i_9_n_2\,
      CO(0) => \ram_reg[40][12]_i_9_n_3\,
      CYINIT => '0',
      DI(3) => \ram_reg[40][12]_i_2_n_7\,
      DI(2) => \ram_reg[40][12]_i_4_n_4\,
      DI(1) => \ram_reg[40][12]_i_4_n_5\,
      DI(0) => \ram[40][12]_i_20_n_0\,
      O(3 downto 0) => \NLW_ram_reg[40][12]_i_9_O_UNCONNECTED\(3 downto 0),
      S(3) => \ram[40][12]_i_21_n_0\,
      S(2) => \ram[40][12]_i_22_n_0\,
      S(1) => \ram[40][12]_i_23_n_0\,
      S(0) => \ram[40][12]_i_24_n_0\
    );
\ram_reg[40][13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => \ram[40][13]_i_1_n_0\,
      Q => \ram_reg[40]_5\(13),
      R => '0'
    );
\ram_reg[40][14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => \ram[38][6]_i_1_n_0\,
      Q => \ram_reg[40]_5\(14),
      R => '0'
    );
\ram_reg[40][7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => '1',
      Q => \ram_reg[40]_5\(7),
      R => '0'
    );
\ram_reg[41][0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => p_17_in(0),
      Q => \ram_reg[41]_4\(0),
      R => '0'
    );
\ram_reg[41][1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => p_17_in(1),
      Q => \ram_reg[41]_4\(1),
      R => '0'
    );
\ram_reg[41][2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => p_17_in(2),
      Q => \ram_reg[41]_4\(2),
      R => '0'
    );
\ram_reg[41][3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => p_17_in(3),
      Q => \ram_reg[41]_4\(3),
      R => '0'
    );
\ram_reg[41][4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => p_17_in(4),
      Q => \ram_reg[41]_4\(4),
      R => '0'
    );
\ram_reg[41][5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => p_17_in(5),
      Q => \ram_reg[41]_4\(5),
      R => '0'
    );
\ram_reg[41][6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => p_17_in(6),
      Q => \ram_reg[41]_4\(6),
      R => '0'
    );
\ram_reg[41][7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => p_17_in(7),
      Q => \ram_reg[41]_4\(7),
      R => '0'
    );
\ram_reg[41][8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => p_17_in(8),
      Q => \ram_reg[41]_4\(8),
      R => '0'
    );
\ram_reg[41][9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => p_17_in(9),
      Q => \ram_reg[41]_4\(9),
      R => '0'
    );
\ram_reg[42][0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => p_18_in(0),
      Q => \ram_reg[42]_3\(0),
      R => '0'
    );
\ram_reg[42][10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => p_18_in(10),
      Q => \ram_reg[42]_3\(10),
      R => '0'
    );
\ram_reg[42][11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => p_18_in(11),
      Q => \ram_reg[42]_3\(11),
      R => '0'
    );
\ram_reg[42][12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => p_18_in(12),
      Q => \ram_reg[42]_3\(12),
      R => '0'
    );
\ram_reg[42][13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => p_18_in(13),
      Q => \ram_reg[42]_3\(13),
      R => '0'
    );
\ram_reg[42][14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => p_18_in(14),
      Q => \ram_reg[42]_3\(14),
      R => '0'
    );
\ram_reg[42][1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => p_18_in(1),
      Q => \ram_reg[42]_3\(1),
      R => '0'
    );
\ram_reg[42][2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => p_18_in(2),
      Q => \ram_reg[42]_3\(2),
      R => '0'
    );
\ram_reg[42][3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => p_18_in(3),
      Q => \ram_reg[42]_3\(3),
      R => '0'
    );
\ram_reg[42][4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => p_18_in(4),
      Q => \ram_reg[42]_3\(4),
      R => '0'
    );
\ram_reg[42][5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => p_18_in(5),
      Q => \ram_reg[42]_3\(5),
      R => '0'
    );
\ram_reg[42][6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => p_18_in(6),
      Q => \ram_reg[42]_3\(6),
      R => '0'
    );
\ram_reg[42][7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => p_18_in(7),
      Q => \ram_reg[42]_3\(7),
      R => '0'
    );
\ram_reg[42][8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => p_18_in(8),
      Q => \ram_reg[42]_3\(8),
      R => '0'
    );
\ram_reg[42][8]_i_2\: unisim.vcomponents.MUXF7
     port map (
      I0 => \ram[42][8]_i_5_n_0\,
      I1 => \ram[42][8]_i_6_n_0\,
      O => \ram_reg[42][8]_i_2_n_0\,
      S => \ram_reg[43][14]_i_3_n_6\
    );
\ram_reg[42][9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => p_18_in(9),
      Q => \ram_reg[42]_3\(9),
      R => '0'
    );
\ram_reg[42][9]_i_2\: unisim.vcomponents.MUXF7
     port map (
      I0 => \ram[42][9]_i_5_n_0\,
      I1 => \ram[42][9]_i_6_n_0\,
      O => \ram_reg[42][9]_i_2_n_0\,
      S => \ram_reg[43][14]_i_3_n_6\
    );
\ram_reg[43][0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => p_19_in(0),
      Q => \ram_reg[43]_2\(0),
      R => '0'
    );
\ram_reg[43][0]_i_2\: unisim.vcomponents.MUXF7
     port map (
      I0 => \ram[43][0]_i_4_n_0\,
      I1 => \ram[43][0]_i_5_n_0\,
      O => \ram_reg[43][0]_i_2_n_0\,
      S => \ram_reg[43][14]_i_3_n_6\
    );
\ram_reg[43][10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => p_19_in(10),
      Q => \ram_reg[43]_2\(10),
      R => '0'
    );
\ram_reg[43][11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => p_19_in(11),
      Q => \ram_reg[43]_2\(11),
      R => '0'
    );
\ram_reg[43][12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => p_19_in(12),
      Q => \ram_reg[43]_2\(12),
      R => '0'
    );
\ram_reg[43][13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => p_19_in(13),
      Q => \ram_reg[43]_2\(13),
      R => '0'
    );
\ram_reg[43][14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => p_19_in(14),
      Q => \ram_reg[43]_2\(14),
      R => '0'
    );
\ram_reg[43][14]_i_3\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \NLW_ram_reg[43][14]_i_3_CO_UNCONNECTED\(3),
      CO(2) => \ram_reg[43][14]_i_3_n_1\,
      CO(1) => \NLW_ram_reg[43][14]_i_3_CO_UNCONNECTED\(1),
      CO(0) => \ram_reg[43][14]_i_3_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \ram[43][14]_i_9_n_0\,
      DI(0) => '0',
      O(3 downto 2) => \NLW_ram_reg[43][14]_i_3_O_UNCONNECTED\(3 downto 2),
      O(1) => \ram_reg[43][14]_i_3_n_6\,
      O(0) => \ram_reg[43][14]_i_3_n_7\,
      S(3 downto 2) => B"01",
      S(1) => \ram[43][14]_i_10_n_0\,
      S(0) => \ram[43][14]_i_11_n_0\
    );
\ram_reg[43][14]_i_7\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \ram_reg[43][14]_i_7_n_0\,
      CO(2) => \ram_reg[43][14]_i_7_n_1\,
      CO(1) => \ram_reg[43][14]_i_7_n_2\,
      CO(0) => \ram_reg[43][14]_i_7_n_3\,
      CYINIT => \ram[45][11]_i_14_n_0\,
      DI(3 downto 2) => B"00",
      DI(1) => \ram[43][14]_i_12_n_0\,
      DI(0) => \ram[43][14]_i_13_n_0\,
      O(3) => \ram_reg[43][14]_i_7_n_4\,
      O(2) => \ram_reg[43][14]_i_7_n_5\,
      O(1) => \ram_reg[43][14]_i_7_n_6\,
      O(0) => \ram_reg[43][14]_i_7_n_7\,
      S(3) => \ram[43][14]_i_14_n_0\,
      S(2) => \ram[43][14]_i_15_n_0\,
      S(1) => \ram[43][14]_i_16_n_0\,
      S(0) => '1'
    );
\ram_reg[43][14]_i_8\: unisim.vcomponents.CARRY4
     port map (
      CI => \ram_reg[43][14]_i_7_n_0\,
      CO(3 downto 1) => \NLW_ram_reg[43][14]_i_8_CO_UNCONNECTED\(3 downto 1),
      CO(0) => \ram_reg[43][14]_i_8_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => \NLW_ram_reg[43][14]_i_8_O_UNCONNECTED\(3 downto 0),
      S(3 downto 0) => B"0001"
    );
\ram_reg[43][1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => p_19_in(1),
      Q => \ram_reg[43]_2\(1),
      R => '0'
    );
\ram_reg[43][1]_i_2\: unisim.vcomponents.MUXF7
     port map (
      I0 => \ram[43][1]_i_5_n_0\,
      I1 => \ram[43][1]_i_6_n_0\,
      O => \ram_reg[43][1]_i_2_n_0\,
      S => \ram_reg[43][14]_i_3_n_6\
    );
\ram_reg[43][2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => p_19_in(2),
      Q => \ram_reg[43]_2\(2),
      R => '0'
    );
\ram_reg[43][2]_i_2\: unisim.vcomponents.MUXF7
     port map (
      I0 => \ram[43][2]_i_5_n_0\,
      I1 => \ram[43][2]_i_6_n_0\,
      O => \ram_reg[43][2]_i_2_n_0\,
      S => \ram_reg[43][14]_i_3_n_6\
    );
\ram_reg[43][3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => p_19_in(3),
      Q => \ram_reg[43]_2\(3),
      R => '0'
    );
\ram_reg[43][3]_i_2\: unisim.vcomponents.MUXF7
     port map (
      I0 => \ram[43][3]_i_5_n_0\,
      I1 => \ram[43][3]_i_6_n_0\,
      O => \ram_reg[43][3]_i_2_n_0\,
      S => \ram_reg[43][14]_i_3_n_6\
    );
\ram_reg[43][4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => p_19_in(4),
      Q => \ram_reg[43]_2\(4),
      R => '0'
    );
\ram_reg[43][4]_i_2\: unisim.vcomponents.MUXF7
     port map (
      I0 => \ram[43][4]_i_5_n_0\,
      I1 => \ram[43][4]_i_6_n_0\,
      O => \ram_reg[43][4]_i_2_n_0\,
      S => \ram_reg[43][14]_i_3_n_6\
    );
\ram_reg[43][5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => p_19_in(5),
      Q => \ram_reg[43]_2\(5),
      R => '0'
    );
\ram_reg[43][5]_i_2\: unisim.vcomponents.MUXF7
     port map (
      I0 => \ram[43][5]_i_5_n_0\,
      I1 => \ram[43][5]_i_6_n_0\,
      O => \ram_reg[43][5]_i_2_n_0\,
      S => \ram_reg[43][14]_i_3_n_6\
    );
\ram_reg[43][6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => p_19_in(6),
      Q => \ram_reg[43]_2\(6),
      R => '0'
    );
\ram_reg[43][7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => p_19_in(7),
      Q => \ram_reg[43]_2\(7),
      R => '0'
    );
\ram_reg[43][8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => p_19_in(8),
      Q => \ram_reg[43]_2\(8),
      R => '0'
    );
\ram_reg[43][9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => p_19_in(9),
      Q => \ram_reg[43]_2\(9),
      R => '0'
    );
\ram_reg[44][11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => p_20_in(11),
      Q => \ram_reg[44]_1\(11),
      R => '0'
    );
\ram_reg[44][12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => p_20_in(12),
      Q => \ram_reg[44]_1\(12),
      R => '0'
    );
\ram_reg[44][15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => p_20_in(15),
      Q => \ram_reg[44]_1\(15),
      R => '0'
    );
\ram_reg[44][38]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => '1',
      D => \ram[44][38]_i_1_n_0\,
      Q => \ram_reg[44]_1\(38),
      R => '0'
    );
\ram_reg[44][8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => p_20_in(8),
      Q => \ram_reg[44]_1\(8),
      R => '0'
    );
\ram_reg[45][11]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => p_21_in(11),
      Q => \ram_reg[45]_0\(11),
      R => '0'
    );
\ram_reg[45][11]_i_3\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \NLW_ram_reg[45][11]_i_3_CO_UNCONNECTED\(3),
      CO(2) => \ram_reg[45][11]_i_3_n_1\,
      CO(1) => \NLW_ram_reg[45][11]_i_3_CO_UNCONNECTED\(1),
      CO(0) => \ram_reg[45][11]_i_3_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \ram[45][11]_i_9_n_0\,
      DI(0) => '0',
      O(3 downto 2) => \NLW_ram_reg[45][11]_i_3_O_UNCONNECTED\(3 downto 2),
      O(1) => \ram_reg[45][11]_i_3_n_6\,
      O(0) => \NLW_ram_reg[45][11]_i_3_O_UNCONNECTED\(0),
      S(3 downto 2) => B"01",
      S(1) => \ram[45][11]_i_10_n_0\,
      S(0) => \ram[45][11]_i_11_n_0\
    );
\ram_reg[45][11]_i_5\: unisim.vcomponents.MUXF7
     port map (
      I0 => \ram[45][11]_i_12_n_0\,
      I1 => \ram[45][11]_i_13_n_0\,
      O => \ram_reg[45][11]_i_5_n_0\,
      S => \ram_reg[45][11]_i_3_n_6\
    );
\ram_reg[45][11]_i_7\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \ram_reg[45][11]_i_7_n_0\,
      CO(2) => \ram_reg[45][11]_i_7_n_1\,
      CO(1) => \ram_reg[45][11]_i_7_n_2\,
      CO(0) => \ram_reg[45][11]_i_7_n_3\,
      CYINIT => \ram[45][11]_i_14_n_0\,
      DI(3 downto 2) => B"00",
      DI(1) => \ram[45][11]_i_15_n_0\,
      DI(0) => \ram[45][11]_i_16_n_0\,
      O(3) => \ram_reg[45][11]_i_7_n_4\,
      O(2) => \ram_reg[45][11]_i_7_n_5\,
      O(1) => \ram_reg[45][11]_i_7_n_6\,
      O(0) => \NLW_ram_reg[45][11]_i_7_O_UNCONNECTED\(0),
      S(3) => \ram[45][11]_i_17_n_0\,
      S(2) => \ram[45][11]_i_18_n_0\,
      S(1) => \ram[45][11]_i_19_n_0\,
      S(0) => '1'
    );
\ram_reg[45][11]_i_8\: unisim.vcomponents.CARRY4
     port map (
      CI => \ram_reg[45][11]_i_7_n_0\,
      CO(3 downto 1) => \NLW_ram_reg[45][11]_i_8_CO_UNCONNECTED\(3 downto 1),
      CO(0) => \ram_reg[45][11]_i_8_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => \NLW_ram_reg[45][11]_i_8_O_UNCONNECTED\(3 downto 0),
      S(3 downto 0) => B"0001"
    );
\ram_reg[45][12]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => p_21_in(12),
      Q => \ram_reg[45]_0\(12),
      R => '0'
    );
\ram_reg[45][15]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => p_21_in(15),
      Q => \ram_reg[45]_0\(15),
      R => '0'
    );
\ram_reg[45][4]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => p_21_in(4),
      Q => \ram_reg[45]_0\(4),
      R => '0'
    );
\ram_reg[45][7]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => p_21_in(7),
      Q => \ram_reg[45]_0\(7),
      R => '0'
    );
\ram_reg[45][8]\: unisim.vcomponents.FDRE
     port map (
      C => CLK,
      CE => \ram_reg[26][0]_0\,
      D => p_21_in(8),
      Q => \ram_reg[45]_0\(8),
      R => '0'
    );
\ram_reg[45][8]_i_4\: unisim.vcomponents.MUXF7
     port map (
      I0 => \ram[45][8]_i_5_n_0\,
      I1 => \ram[45][8]_i_6_n_0\,
      O => \ram_reg[45][8]_i_4_n_0\,
      S => \ram_reg[45][11]_i_3_n_6\
    );
\state_count[0]_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => state_count(0),
      O => \state_count[0]_i_1_n_0\
    );
\state_count[1]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => state_count(0),
      I1 => state_count(1),
      O => \state_count[1]_i_1_n_0\
    );
\state_count[2]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E1"
    )
        port map (
      I0 => state_count(1),
      I1 => state_count(0),
      I2 => state_count(2),
      O => \state_count[2]_i_1_n_0\
    );
\state_count[3]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAA8FFFF00020000"
    )
        port map (
      I0 => current_state(3),
      I1 => state_count(1),
      I2 => state_count(0),
      I3 => state_count(2),
      I4 => \state_count[4]_i_2_n_0\,
      I5 => state_count(3),
      O => \state_count[3]_i_1_n_0\
    );
\state_count[4]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0010"
    )
        port map (
      I0 => current_state(2),
      I1 => current_state(0),
      I2 => current_state(1),
      I3 => current_state(3),
      O => \state_count[4]_i_1_n_0\
    );
\state_count[4]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0006"
    )
        port map (
      I0 => current_state(3),
      I1 => current_state(1),
      I2 => current_state(0),
      I3 => current_state(2),
      O => \state_count[4]_i_2_n_0\
    );
\state_count[4]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFE0001"
    )
        port map (
      I0 => state_count(3),
      I1 => state_count(1),
      I2 => state_count(0),
      I3 => state_count(2),
      I4 => state_count(4),
      O => \state_count[4]_i_3_n_0\
    );
\state_count_reg[0]\: unisim.vcomponents.FDSE
    generic map(
      INIT => '1'
    )
        port map (
      C => CLK,
      CE => \state_count[4]_i_2_n_0\,
      D => \state_count[0]_i_1_n_0\,
      Q => state_count(0),
      S => \state_count[4]_i_1_n_0\
    );
\state_count_reg[1]\: unisim.vcomponents.FDSE
    generic map(
      INIT => '1'
    )
        port map (
      C => CLK,
      CE => \state_count[4]_i_2_n_0\,
      D => \state_count[1]_i_1_n_0\,
      Q => state_count(1),
      S => \state_count[4]_i_1_n_0\
    );
\state_count_reg[2]\: unisim.vcomponents.FDSE
    generic map(
      INIT => '1'
    )
        port map (
      C => CLK,
      CE => \state_count[4]_i_2_n_0\,
      D => \state_count[2]_i_1_n_0\,
      Q => state_count(2),
      S => \state_count[4]_i_1_n_0\
    );
\state_count_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => '1',
      D => \state_count[3]_i_1_n_0\,
      Q => state_count(3),
      R => '0'
    );
\state_count_reg[4]\: unisim.vcomponents.FDSE
    generic map(
      INIT => '1'
    )
        port map (
      C => CLK,
      CE => \state_count[4]_i_2_n_0\,
      D => \state_count[4]_i_3_n_0\,
      Q => state_count(4),
      S => \state_count[4]_i_1_n_0\
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity system_pattern_multi_0_0_pckgen_triple is
  port (
    locked : out STD_LOGIC;
    PCK : out STD_LOGIC;
    SerialClk : out STD_LOGIC;
    reconfig_done : out STD_LOGIC;
    timing_sel_imm : in STD_LOGIC_VECTOR ( 1 downto 0 );
    CLK : in STD_LOGIC;
    reconfig_req : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of system_pattern_multi_0_0_pckgen_triple : entity is "pckgen_triple";
end system_pattern_multi_0_0_pckgen_triple;

architecture STRUCTURE of system_pattern_multi_0_0_pckgen_triple is
  signal CLKFBIN : STD_LOGIC;
  signal CLKFBOUT : STD_LOGIC;
  signal \FSM_sequential_state[1]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_sequential_state[2]_i_1_n_0\ : STD_LOGIC;
  signal MMCM_RECONFIG_n_25 : STD_LOGIC;
  signal drp_daddr : STD_LOGIC_VECTOR ( 6 downto 0 );
  signal drp_den : STD_LOGIC;
  signal drp_di : STD_LOGIC_VECTOR ( 15 downto 0 );
  signal drp_do : STD_LOGIC_VECTOR ( 15 downto 0 );
  signal drp_drdy : STD_LOGIC;
  signal drp_dwe : STD_LOGIC;
  signal iPCK : STD_LOGIC;
  signal iSerialClk : STD_LOGIC;
  signal load_pulse : STD_LOGIC;
  signal load_pulse_reg_n_0 : STD_LOGIC;
  signal \^locked\ : STD_LOGIC;
  signal mmcm_drp_inst_n_16 : STD_LOGIC;
  signal mmcm_rst : STD_LOGIC;
  signal reconfig_done_i_1_n_0 : STD_LOGIC;
  signal sen_pulse : STD_LOGIC;
  signal sen_pulse_reg_n_0 : STD_LOGIC;
  signal state : STD_LOGIC_VECTOR ( 2 downto 0 );
  signal NLW_MMCM_RECONFIG_CLKFBOUTB_UNCONNECTED : STD_LOGIC;
  signal NLW_MMCM_RECONFIG_CLKFBSTOPPED_UNCONNECTED : STD_LOGIC;
  signal NLW_MMCM_RECONFIG_CLKINSTOPPED_UNCONNECTED : STD_LOGIC;
  signal NLW_MMCM_RECONFIG_CLKOUT0B_UNCONNECTED : STD_LOGIC;
  signal NLW_MMCM_RECONFIG_CLKOUT1B_UNCONNECTED : STD_LOGIC;
  signal NLW_MMCM_RECONFIG_CLKOUT2_UNCONNECTED : STD_LOGIC;
  signal NLW_MMCM_RECONFIG_CLKOUT2B_UNCONNECTED : STD_LOGIC;
  signal NLW_MMCM_RECONFIG_CLKOUT3_UNCONNECTED : STD_LOGIC;
  signal NLW_MMCM_RECONFIG_CLKOUT3B_UNCONNECTED : STD_LOGIC;
  signal NLW_MMCM_RECONFIG_CLKOUT4_UNCONNECTED : STD_LOGIC;
  signal NLW_MMCM_RECONFIG_CLKOUT5_UNCONNECTED : STD_LOGIC;
  signal NLW_MMCM_RECONFIG_CLKOUT6_UNCONNECTED : STD_LOGIC;
  signal NLW_MMCM_RECONFIG_PSDONE_UNCONNECTED : STD_LOGIC;
  attribute BOX_TYPE : string;
  attribute BOX_TYPE of BUFG_5X : label is "PRIMITIVE";
  attribute BOX_TYPE of BUFG_FB : label is "PRIMITIVE";
  attribute BOX_TYPE of BUFG_PCK : label is "PRIMITIVE";
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \FSM_sequential_state[1]_i_1\ : label is "soft_lutpair20";
  attribute SOFT_HLUTNM of \FSM_sequential_state[2]_i_1\ : label is "soft_lutpair20";
  attribute FSM_ENCODED_STATES : string;
  attribute FSM_ENCODED_STATES of \FSM_sequential_state_reg[0]\ : label is "S_BOOT_WAIT:000,S_IDLE:001,S_LOAD:010,S_SEN:011,S_WAIT_SRDY:100,S_DONE:101,";
  attribute FSM_ENCODED_STATES of \FSM_sequential_state_reg[1]\ : label is "S_BOOT_WAIT:000,S_IDLE:001,S_LOAD:010,S_SEN:011,S_WAIT_SRDY:100,S_DONE:101,";
  attribute FSM_ENCODED_STATES of \FSM_sequential_state_reg[2]\ : label is "S_BOOT_WAIT:000,S_IDLE:001,S_LOAD:010,S_SEN:011,S_WAIT_SRDY:100,S_DONE:101,";
  attribute BOX_TYPE of MMCM_RECONFIG : label is "PRIMITIVE";
  attribute SOFT_HLUTNM of reconfig_done_i_1 : label is "soft_lutpair21";
  attribute SOFT_HLUTNM of sen_pulse_i_1 : label is "soft_lutpair21";
begin
  locked <= \^locked\;
BUFG_5X: unisim.vcomponents.BUFG
     port map (
      I => iSerialClk,
      O => SerialClk
    );
BUFG_FB: unisim.vcomponents.BUFG
     port map (
      I => CLKFBOUT,
      O => CLKFBIN
    );
BUFG_PCK: unisim.vcomponents.BUFG
     port map (
      I => iPCK,
      O => PCK
    );
\FSM_sequential_state[1]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"98AA"
    )
        port map (
      I0 => state(1),
      I1 => state(2),
      I2 => reconfig_req,
      I3 => state(0),
      O => \FSM_sequential_state[1]_i_1_n_0\
    );
\FSM_sequential_state[2]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"AC"
    )
        port map (
      I0 => state(1),
      I1 => state(2),
      I2 => state(0),
      O => \FSM_sequential_state[2]_i_1_n_0\
    );
\FSM_sequential_state_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => '1',
      D => mmcm_drp_inst_n_16,
      Q => state(0),
      R => '0'
    );
\FSM_sequential_state_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => '1',
      D => \FSM_sequential_state[1]_i_1_n_0\,
      Q => state(1),
      R => '0'
    );
\FSM_sequential_state_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => '1',
      D => \FSM_sequential_state[2]_i_1_n_0\,
      Q => state(2),
      R => '0'
    );
MMCM_RECONFIG: unisim.vcomponents.MMCME2_ADV
    generic map(
      BANDWIDTH => "OPTIMIZED",
      CLKFBOUT_MULT_F => 17.625000,
      CLKFBOUT_PHASE => 0.000000,
      CLKFBOUT_USE_FINE_PS => false,
      CLKIN1_PERIOD => 10.000000,
      CLKIN2_PERIOD => 0.000000,
      CLKOUT0_DIVIDE_F => 35.000000,
      CLKOUT0_DUTY_CYCLE => 0.500000,
      CLKOUT0_PHASE => 0.000000,
      CLKOUT0_USE_FINE_PS => false,
      CLKOUT1_DIVIDE => 7,
      CLKOUT1_DUTY_CYCLE => 0.500000,
      CLKOUT1_PHASE => 0.000000,
      CLKOUT1_USE_FINE_PS => false,
      CLKOUT2_DIVIDE => 1,
      CLKOUT2_DUTY_CYCLE => 0.500000,
      CLKOUT2_PHASE => 0.000000,
      CLKOUT2_USE_FINE_PS => false,
      CLKOUT3_DIVIDE => 1,
      CLKOUT3_DUTY_CYCLE => 0.500000,
      CLKOUT3_PHASE => 0.000000,
      CLKOUT3_USE_FINE_PS => false,
      CLKOUT4_CASCADE => false,
      CLKOUT4_DIVIDE => 1,
      CLKOUT4_DUTY_CYCLE => 0.500000,
      CLKOUT4_PHASE => 0.000000,
      CLKOUT4_USE_FINE_PS => false,
      CLKOUT5_DIVIDE => 1,
      CLKOUT5_DUTY_CYCLE => 0.500000,
      CLKOUT5_PHASE => 0.000000,
      CLKOUT5_USE_FINE_PS => false,
      CLKOUT6_DIVIDE => 1,
      CLKOUT6_DUTY_CYCLE => 0.500000,
      CLKOUT6_PHASE => 0.000000,
      CLKOUT6_USE_FINE_PS => false,
      COMPENSATION => "ZHOLD",
      DIVCLK_DIVIDE => 2,
      IS_CLKINSEL_INVERTED => '0',
      IS_PSEN_INVERTED => '0',
      IS_PSINCDEC_INVERTED => '0',
      IS_PWRDWN_INVERTED => '0',
      IS_RST_INVERTED => '0',
      REF_JITTER1 => 0.010000,
      REF_JITTER2 => 0.010000,
      SS_EN => "FALSE",
      SS_MODE => "CENTER_HIGH",
      SS_MOD_PERIOD => 10000,
      STARTUP_WAIT => false
    )
        port map (
      CLKFBIN => CLKFBIN,
      CLKFBOUT => CLKFBOUT,
      CLKFBOUTB => NLW_MMCM_RECONFIG_CLKFBOUTB_UNCONNECTED,
      CLKFBSTOPPED => NLW_MMCM_RECONFIG_CLKFBSTOPPED_UNCONNECTED,
      CLKIN1 => CLK,
      CLKIN2 => '0',
      CLKINSEL => '1',
      CLKINSTOPPED => NLW_MMCM_RECONFIG_CLKINSTOPPED_UNCONNECTED,
      CLKOUT0 => iPCK,
      CLKOUT0B => NLW_MMCM_RECONFIG_CLKOUT0B_UNCONNECTED,
      CLKOUT1 => iSerialClk,
      CLKOUT1B => NLW_MMCM_RECONFIG_CLKOUT1B_UNCONNECTED,
      CLKOUT2 => NLW_MMCM_RECONFIG_CLKOUT2_UNCONNECTED,
      CLKOUT2B => NLW_MMCM_RECONFIG_CLKOUT2B_UNCONNECTED,
      CLKOUT3 => NLW_MMCM_RECONFIG_CLKOUT3_UNCONNECTED,
      CLKOUT3B => NLW_MMCM_RECONFIG_CLKOUT3B_UNCONNECTED,
      CLKOUT4 => NLW_MMCM_RECONFIG_CLKOUT4_UNCONNECTED,
      CLKOUT5 => NLW_MMCM_RECONFIG_CLKOUT5_UNCONNECTED,
      CLKOUT6 => NLW_MMCM_RECONFIG_CLKOUT6_UNCONNECTED,
      DADDR(6 downto 0) => drp_daddr(6 downto 0),
      DCLK => CLK,
      DEN => drp_den,
      DI(15 downto 0) => drp_di(15 downto 0),
      DO(15 downto 9) => drp_do(15 downto 9),
      DO(8) => MMCM_RECONFIG_n_25,
      DO(7 downto 0) => drp_do(7 downto 0),
      DRDY => drp_drdy,
      DWE => drp_dwe,
      LOCKED => \^locked\,
      PSCLK => '0',
      PSDONE => NLW_MMCM_RECONFIG_PSDONE_UNCONNECTED,
      PSEN => '0',
      PSINCDEC => '0',
      PWRDWN => '0',
      RST => mmcm_rst
    );
load_pulse_i_1: unisim.vcomponents.LUT3
    generic map(
      INIT => X"02"
    )
        port map (
      I0 => state(1),
      I1 => state(2),
      I2 => state(0),
      O => load_pulse
    );
load_pulse_reg: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => '1',
      D => load_pulse,
      Q => load_pulse_reg_n_0,
      R => '0'
    );
mmcm_drp_inst: entity work.system_pattern_multi_0_0_mmcm_drp
     port map (
      CLK => CLK,
      DADDR(6 downto 0) => drp_daddr(6 downto 0),
      DEN => drp_den,
      DI(15 downto 0) => drp_di(15 downto 0),
      DO(14 downto 8) => drp_do(15 downto 9),
      DO(7 downto 0) => drp_do(7 downto 0),
      DWE => drp_dwe,
      \FSM_sequential_state_reg[1]\ => mmcm_drp_inst_n_16,
      drp_drdy => drp_drdy,
      locked => \^locked\,
      mmcm_rst => mmcm_rst,
      \ram_addr_reg[0]_0\ => sen_pulse_reg_n_0,
      \ram_reg[26][0]_0\ => load_pulse_reg_n_0,
      reconfig_req => reconfig_req,
      state(2 downto 0) => state(2 downto 0),
      timing_sel_imm(1 downto 0) => timing_sel_imm(1 downto 0)
    );
reconfig_done_i_1: unisim.vcomponents.LUT3
    generic map(
      INIT => X"40"
    )
        port map (
      I0 => state(1),
      I1 => state(0),
      I2 => state(2),
      O => reconfig_done_i_1_n_0
    );
reconfig_done_reg: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => '1',
      D => reconfig_done_i_1_n_0,
      Q => reconfig_done,
      R => '0'
    );
sen_pulse_i_1: unisim.vcomponents.LUT3
    generic map(
      INIT => X"40"
    )
        port map (
      I0 => state(2),
      I1 => state(0),
      I2 => state(1),
      O => sen_pulse
    );
sen_pulse_reg: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => '1',
      D => sen_pulse,
      Q => sen_pulse_reg_n_0,
      R => '0'
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity system_pattern_multi_0_0_syncgen_multi is
  port (
    p_1_in : out STD_LOGIC_VECTOR ( 10 downto 0 );
    A : out STD_LOGIC_VECTOR ( 10 downto 0 );
    SR : out STD_LOGIC_VECTOR ( 0 to 0 );
    RST_0 : out STD_LOGIC;
    D : out STD_LOGIC_VECTOR ( 7 downto 0 );
    \pattern_sel[3]\ : out STD_LOGIC_VECTOR ( 7 downto 0 );
    \pattern_sel[3]_0\ : out STD_LOGIC_VECTOR ( 7 downto 0 );
    locked : out STD_LOGIC;
    PCK : out STD_LOGIC;
    SerialClk : out STD_LOGIC;
    reconfig_done : out STD_LOGIC;
    VGA_HS : out STD_LOGIC;
    VGA_VS : out STD_LOGIC;
    timing_sel_imm : in STD_LOGIC_VECTOR ( 1 downto 0 );
    zp_sum : in STD_LOGIC;
    timing_sel : in STD_LOGIC_VECTOR ( 1 downto 0 );
    \VGA_R_reg[4]_i_5_0\ : in STD_LOGIC;
    O : in STD_LOGIC_VECTOR ( 2 downto 0 );
    CO : in STD_LOGIC_VECTOR ( 0 to 0 );
    \VGA_R_reg[5]_i_35_0\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \VGA_R_reg[5]_i_35_1\ : in STD_LOGIC_VECTOR ( 1 downto 0 );
    pattern_sel : in STD_LOGIC_VECTOR ( 3 downto 0 );
    \VGA_B_reg[7]\ : in STD_LOGIC;
    zp_sum0 : in STD_LOGIC_VECTOR ( 2 downto 0 );
    \VGA_R_reg[7]_i_4_0\ : in STD_LOGIC;
    RST : in STD_LOGIC;
    \VGA_R_reg[7]_i_231_0\ : in STD_LOGIC;
    zp_sum0_0 : in STD_LOGIC_VECTOR ( 0 to 0 );
    \VGA_R_reg[7]_i_16_0\ : in STD_LOGIC;
    \VGA_R_reg[7]_i_16_1\ : in STD_LOGIC;
    \VGA_B_reg[0]\ : in STD_LOGIC;
    data2 : in STD_LOGIC_VECTOR ( 7 downto 0 );
    \VGA_B_reg[1]\ : in STD_LOGIC;
    \VGA_B_reg[2]\ : in STD_LOGIC;
    \VGA_R_reg[5]_i_31_0\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \VGA_R_reg[5]_i_11_0\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \VGA_R_reg[5]_i_31_1\ : in STD_LOGIC;
    \VGA_R_reg[5]_i_31_2\ : in STD_LOGIC;
    \VGA_R_reg[5]_i_31_3\ : in STD_LOGIC_VECTOR ( 2 downto 0 );
    \VGA_R_reg[5]_i_14_0\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \VGA_R_reg[5]_i_14_1\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \VGA_R_reg[5]_i_14_2\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \VGA_R_reg[5]_i_14_3\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \VGA_R_reg[5]_i_14_4\ : in STD_LOGIC;
    data6 : in STD_LOGIC_VECTOR ( 7 downto 0 );
    \VGA_R_reg[6]\ : in STD_LOGIC;
    \VGA_R_reg[6]_0\ : in STD_LOGIC;
    P : in STD_LOGIC_VECTOR ( 4 downto 0 );
    \VGA_R_reg[5]\ : in STD_LOGIC;
    \VGA_R_reg[7]_i_236_0\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    DI : in STD_LOGIC_VECTOR ( 0 to 0 );
    \VGA_R_reg[7]_i_99_0\ : in STD_LOGIC_VECTOR ( 2 downto 0 );
    S : in STD_LOGIC_VECTOR ( 2 downto 0 );
    \VGA_R_reg[7]_i_99_1\ : in STD_LOGIC_VECTOR ( 1 downto 0 );
    \VGA_R_reg[7]_i_99_2\ : in STD_LOGIC_VECTOR ( 3 downto 0 );
    \VGA_R[7]_i_330_0\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \VGA_R[7]_i_330_1\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \VGA_R[7]_i_343_0\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \VGA_R_reg[7]_i_70_0\ : in STD_LOGIC_VECTOR ( 2 downto 0 );
    \VGA_R_reg[7]_i_74_0\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    CLK : in STD_LOGIC;
    reconfig_req : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of system_pattern_multi_0_0_syncgen_multi : entity is "syncgen_multi";
end system_pattern_multi_0_0_syncgen_multi;

architecture STRUCTURE of system_pattern_multi_0_0_syncgen_multi is
  signal \^a\ : STD_LOGIC_VECTOR ( 10 downto 0 );
  signal FCNT : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal \FCNT[7]_i_1_n_0\ : STD_LOGIC;
  signal \FCNT[7]_i_3_n_0\ : STD_LOGIC;
  signal HCNT : STD_LOGIC_VECTOR ( 10 downto 0 );
  signal \HCNT[10]_i_1_n_0\ : STD_LOGIC;
  signal \HCNT[10]_i_3_n_0\ : STD_LOGIC;
  signal \^pck\ : STD_LOGIC;
  signal VCNT : STD_LOGIC_VECTOR ( 10 downto 0 );
  signal VCNT0 : STD_LOGIC;
  signal \VCNT[10]_i_10_n_0\ : STD_LOGIC;
  signal \VCNT[10]_i_11_n_0\ : STD_LOGIC;
  signal \VCNT[10]_i_12_n_0\ : STD_LOGIC;
  signal \VCNT[10]_i_13_n_0\ : STD_LOGIC;
  signal \VCNT[10]_i_1_n_0\ : STD_LOGIC;
  signal \VCNT[10]_i_5_n_0\ : STD_LOGIC;
  signal \VCNT[10]_i_6_n_0\ : STD_LOGIC;
  signal \VCNT[10]_i_7_n_0\ : STD_LOGIC;
  signal \VCNT[10]_i_8_n_0\ : STD_LOGIC;
  signal \VCNT[10]_i_9_n_0\ : STD_LOGIC;
  signal \VCNT_reg[10]_i_2_n_1\ : STD_LOGIC;
  signal \VCNT_reg[10]_i_2_n_2\ : STD_LOGIC;
  signal \VCNT_reg[10]_i_2_n_3\ : STD_LOGIC;
  signal \VCNT_reg[10]_i_4_n_1\ : STD_LOGIC;
  signal \VCNT_reg[10]_i_4_n_2\ : STD_LOGIC;
  signal \VCNT_reg[10]_i_4_n_3\ : STD_LOGIC;
  signal \VGA_B[4]_i_2_n_0\ : STD_LOGIC;
  signal \VGA_B[5]_i_2_n_0\ : STD_LOGIC;
  signal \VGA_B[6]_i_2_n_0\ : STD_LOGIC;
  signal \VGA_B[7]_i_10_n_0\ : STD_LOGIC;
  signal \VGA_B[7]_i_11_n_0\ : STD_LOGIC;
  signal \VGA_B[7]_i_12_n_0\ : STD_LOGIC;
  signal \VGA_B[7]_i_14_n_0\ : STD_LOGIC;
  signal \VGA_B[7]_i_15_n_0\ : STD_LOGIC;
  signal \VGA_B[7]_i_16_n_0\ : STD_LOGIC;
  signal \VGA_B[7]_i_17_n_0\ : STD_LOGIC;
  signal \VGA_B[7]_i_18_n_0\ : STD_LOGIC;
  signal \VGA_B[7]_i_19_n_0\ : STD_LOGIC;
  signal \VGA_B[7]_i_20_n_0\ : STD_LOGIC;
  signal \VGA_B[7]_i_21_n_0\ : STD_LOGIC;
  signal \VGA_B[7]_i_22_n_0\ : STD_LOGIC;
  signal \VGA_B[7]_i_23_n_0\ : STD_LOGIC;
  signal \VGA_B[7]_i_24_n_0\ : STD_LOGIC;
  signal \VGA_B[7]_i_25_n_0\ : STD_LOGIC;
  signal \VGA_B[7]_i_26_n_0\ : STD_LOGIC;
  signal \VGA_B[7]_i_27_n_0\ : STD_LOGIC;
  signal \VGA_B[7]_i_29_n_0\ : STD_LOGIC;
  signal \VGA_B[7]_i_2_n_0\ : STD_LOGIC;
  signal \VGA_B[7]_i_31_n_0\ : STD_LOGIC;
  signal \VGA_B[7]_i_33_n_0\ : STD_LOGIC;
  signal \VGA_B[7]_i_3_n_0\ : STD_LOGIC;
  signal \VGA_B[7]_i_4_n_0\ : STD_LOGIC;
  signal \VGA_B[7]_i_5_n_0\ : STD_LOGIC;
  signal \VGA_B[7]_i_9_n_0\ : STD_LOGIC;
  signal \VGA_B_reg[7]_i_13_n_0\ : STD_LOGIC;
  signal \VGA_B_reg[7]_i_13_n_1\ : STD_LOGIC;
  signal \VGA_B_reg[7]_i_13_n_2\ : STD_LOGIC;
  signal \VGA_B_reg[7]_i_13_n_3\ : STD_LOGIC;
  signal \VGA_B_reg[7]_i_28_n_7\ : STD_LOGIC;
  signal \VGA_B_reg[7]_i_30_n_7\ : STD_LOGIC;
  signal \VGA_B_reg[7]_i_32_n_7\ : STD_LOGIC;
  signal \VGA_B_reg[7]_i_6_n_0\ : STD_LOGIC;
  signal \VGA_B_reg[7]_i_6_n_1\ : STD_LOGIC;
  signal \VGA_B_reg[7]_i_6_n_2\ : STD_LOGIC;
  signal \VGA_B_reg[7]_i_6_n_3\ : STD_LOGIC;
  signal \VGA_B_reg[7]_i_7_n_1\ : STD_LOGIC;
  signal \VGA_B_reg[7]_i_7_n_2\ : STD_LOGIC;
  signal \VGA_B_reg[7]_i_7_n_3\ : STD_LOGIC;
  signal \VGA_B_reg[7]_i_8_n_0\ : STD_LOGIC;
  signal \VGA_B_reg[7]_i_8_n_1\ : STD_LOGIC;
  signal \VGA_B_reg[7]_i_8_n_2\ : STD_LOGIC;
  signal \VGA_B_reg[7]_i_8_n_3\ : STD_LOGIC;
  signal \VGA_G[6]_i_2_n_0\ : STD_LOGIC;
  signal \VGA_G[7]_i_10_n_0\ : STD_LOGIC;
  signal \VGA_G[7]_i_11_n_0\ : STD_LOGIC;
  signal \VGA_G[7]_i_12_n_0\ : STD_LOGIC;
  signal \VGA_G[7]_i_13_n_0\ : STD_LOGIC;
  signal \VGA_G[7]_i_14_n_0\ : STD_LOGIC;
  signal \VGA_G[7]_i_15_n_0\ : STD_LOGIC;
  signal \VGA_G[7]_i_16_n_0\ : STD_LOGIC;
  signal \VGA_G[7]_i_17_n_0\ : STD_LOGIC;
  signal \VGA_G[7]_i_18_n_0\ : STD_LOGIC;
  signal \VGA_G[7]_i_19_n_0\ : STD_LOGIC;
  signal \VGA_G[7]_i_20_n_0\ : STD_LOGIC;
  signal \VGA_G[7]_i_21_n_0\ : STD_LOGIC;
  signal \VGA_G[7]_i_2_n_0\ : STD_LOGIC;
  signal \VGA_G[7]_i_3_n_0\ : STD_LOGIC;
  signal \VGA_G[7]_i_4_n_0\ : STD_LOGIC;
  signal \VGA_G[7]_i_5_n_0\ : STD_LOGIC;
  signal \VGA_G[7]_i_9_n_0\ : STD_LOGIC;
  signal \VGA_G_reg[7]_i_6_n_0\ : STD_LOGIC;
  signal \VGA_G_reg[7]_i_6_n_1\ : STD_LOGIC;
  signal \VGA_G_reg[7]_i_6_n_2\ : STD_LOGIC;
  signal \VGA_G_reg[7]_i_6_n_3\ : STD_LOGIC;
  signal \VGA_G_reg[7]_i_6_n_5\ : STD_LOGIC;
  signal \VGA_G_reg[7]_i_6_n_6\ : STD_LOGIC;
  signal \VGA_G_reg[7]_i_6_n_7\ : STD_LOGIC;
  signal \VGA_G_reg[7]_i_7_n_1\ : STD_LOGIC;
  signal \VGA_G_reg[7]_i_7_n_2\ : STD_LOGIC;
  signal \VGA_G_reg[7]_i_7_n_3\ : STD_LOGIC;
  signal \VGA_G_reg[7]_i_7_n_5\ : STD_LOGIC;
  signal \VGA_G_reg[7]_i_7_n_6\ : STD_LOGIC;
  signal \VGA_G_reg[7]_i_7_n_7\ : STD_LOGIC;
  signal \VGA_G_reg[7]_i_8_n_0\ : STD_LOGIC;
  signal \VGA_G_reg[7]_i_8_n_1\ : STD_LOGIC;
  signal \VGA_G_reg[7]_i_8_n_2\ : STD_LOGIC;
  signal \VGA_G_reg[7]_i_8_n_3\ : STD_LOGIC;
  signal \VGA_G_reg[7]_i_8_n_4\ : STD_LOGIC;
  signal \VGA_G_reg[7]_i_8_n_5\ : STD_LOGIC;
  signal \VGA_G_reg[7]_i_8_n_6\ : STD_LOGIC;
  signal \VGA_G_reg[7]_i_8_n_7\ : STD_LOGIC;
  signal \^vga_hs\ : STD_LOGIC;
  signal VGA_HS0 : STD_LOGIC;
  signal VGA_HS1 : STD_LOGIC;
  signal VGA_HS_i_10_n_0 : STD_LOGIC;
  signal VGA_HS_i_11_n_0 : STD_LOGIC;
  signal VGA_HS_i_12_n_0 : STD_LOGIC;
  signal VGA_HS_i_1_n_0 : STD_LOGIC;
  signal VGA_HS_i_2_n_0 : STD_LOGIC;
  signal VGA_HS_i_5_n_0 : STD_LOGIC;
  signal VGA_HS_i_6_n_0 : STD_LOGIC;
  signal VGA_HS_i_7_n_0 : STD_LOGIC;
  signal VGA_HS_i_8_n_0 : STD_LOGIC;
  signal VGA_HS_i_9_n_0 : STD_LOGIC;
  signal VGA_HS_reg_i_3_n_1 : STD_LOGIC;
  signal VGA_HS_reg_i_3_n_2 : STD_LOGIC;
  signal VGA_HS_reg_i_3_n_3 : STD_LOGIC;
  signal VGA_HS_reg_i_4_n_1 : STD_LOGIC;
  signal VGA_HS_reg_i_4_n_2 : STD_LOGIC;
  signal VGA_HS_reg_i_4_n_3 : STD_LOGIC;
  signal \VGA_R[0]_i_3_n_0\ : STD_LOGIC;
  signal \VGA_R[0]_i_4_n_0\ : STD_LOGIC;
  signal \VGA_R[1]_i_3_n_0\ : STD_LOGIC;
  signal \VGA_R[1]_i_4_n_0\ : STD_LOGIC;
  signal \VGA_R[2]_i_3_n_0\ : STD_LOGIC;
  signal \VGA_R[2]_i_4_n_0\ : STD_LOGIC;
  signal \VGA_R[3]_i_2_n_0\ : STD_LOGIC;
  signal \VGA_R[3]_i_3_n_0\ : STD_LOGIC;
  signal \VGA_R[3]_i_4_n_0\ : STD_LOGIC;
  signal \VGA_R[3]_i_5_n_0\ : STD_LOGIC;
  signal \VGA_R[4]_i_10_n_0\ : STD_LOGIC;
  signal \VGA_R[4]_i_11_n_0\ : STD_LOGIC;
  signal \VGA_R[4]_i_22_n_0\ : STD_LOGIC;
  signal \VGA_R[4]_i_23_n_0\ : STD_LOGIC;
  signal \VGA_R[4]_i_24_n_0\ : STD_LOGIC;
  signal \VGA_R[4]_i_25_n_0\ : STD_LOGIC;
  signal \VGA_R[4]_i_26_n_0\ : STD_LOGIC;
  signal \VGA_R[4]_i_27_n_0\ : STD_LOGIC;
  signal \VGA_R[4]_i_28_n_0\ : STD_LOGIC;
  signal \VGA_R[4]_i_29_n_0\ : STD_LOGIC;
  signal \VGA_R[4]_i_2_n_0\ : STD_LOGIC;
  signal \VGA_R[4]_i_3_n_0\ : STD_LOGIC;
  signal \VGA_R[4]_i_4_n_0\ : STD_LOGIC;
  signal \VGA_R[4]_i_9_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_15_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_16_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_17_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_19_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_20_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_2_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_32_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_33_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_34_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_36_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_37_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_38_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_39_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_3_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_41_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_42_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_43_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_44_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_45_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_46_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_47_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_48_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_49_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_4_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_50_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_51_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_52_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_53_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_54_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_55_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_56_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_57_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_58_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_59_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_6_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_70_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_71_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_72_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_73_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_74_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_75_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_76_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_77_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_80_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_81_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_82_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_83_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_84_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_85_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_86_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_87_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_88_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_89_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_90_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_91_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_92_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_93_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_94_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_95_n_0\ : STD_LOGIC;
  signal \VGA_R[6]_i_2_n_0\ : STD_LOGIC;
  signal \VGA_R[6]_i_3_n_0\ : STD_LOGIC;
  signal \VGA_R[6]_i_4_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_103_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_104_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_106_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_107_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_108_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_10_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_123_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_124_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_125_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_126_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_128_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_12_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_132_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_133_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_134_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_135_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_138_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_139_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_13_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_140_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_141_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_144_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_145_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_146_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_147_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_149_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_14_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_150_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_151_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_152_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_153_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_154_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_155_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_156_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_159_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_15_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_160_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_161_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_162_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_164_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_165_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_166_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_167_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_168_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_169_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_170_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_171_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_172_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_173_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_174_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_175_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_17_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_18_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_193_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_194_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_195_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_196_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_197_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_198_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_199_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_19_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_200_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_201_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_202_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_20_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_212_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_213_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_214_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_215_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_217_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_218_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_219_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_220_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_222_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_223_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_224_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_225_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_227_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_228_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_229_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_22_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_230_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_232_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_233_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_234_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_235_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_237_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_238_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_239_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_23_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_240_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_24_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_250_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_251_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_252_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_253_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_254_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_255_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_256_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_257_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_258_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_259_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_260_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_261_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_262_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_263_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_264_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_265_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_266_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_267_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_268_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_269_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_26_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_27_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_287_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_288_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_289_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_28_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_290_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_291_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_292_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_293_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_294_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_295_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_296_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_297_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_298_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_299_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_300_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_301_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_302_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_303_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_304_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_305_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_306_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_307_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_308_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_318_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_31_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_320_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_321_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_322_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_323_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_324_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_325_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_326_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_327_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_328_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_329_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_32_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_330_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_331_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_332_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_333_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_334_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_335_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_336_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_337_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_338_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_339_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_340_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_341_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_342_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_343_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_344_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_345_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_346_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_347_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_348_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_349_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_350_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_351_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_352_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_353_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_354_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_355_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_356_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_357_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_358_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_359_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_35_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_360_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_361_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_362_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_363_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_364_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_36_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_37_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_393_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_394_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_395_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_396_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_397_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_398_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_399_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_400_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_401_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_402_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_403_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_404_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_405_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_406_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_407_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_408_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_409_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_410_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_411_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_412_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_413_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_414_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_415_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_416_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_417_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_418_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_41_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_422_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_428_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_429_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_42_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_430_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_431_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_432_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_433_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_434_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_43_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_44_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_451_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_452_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_453_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_454_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_45_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_46_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_476_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_47_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_48_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_499_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_49_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_500_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_502_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_503_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_504_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_505_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_506_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_507_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_508_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_509_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_50_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_510_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_511_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_51_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_52_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_53_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_54_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_556_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_557_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_558_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_559_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_55_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_560_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_56_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_57_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_58_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_59_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_61_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_62_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_63_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_64_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_65_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_66_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_67_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_6_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_7_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_88_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_89_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_8_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_90_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_91_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_9_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[4]_i_5_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[4]_i_5_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[4]_i_8_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[4]_i_8_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[4]_i_8_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[4]_i_8_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_11_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_11_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_12_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_12_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_13_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_13_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_14_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_14_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_14_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_14_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_18_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_18_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_18_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_18_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_31_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_31_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_31_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_31_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_35_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_35_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_35_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_35_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_40_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_40_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_40_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_40_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_7_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_8_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_8_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_100_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_100_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_100_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_100_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_100_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_100_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_100_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_102_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_102_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_102_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_102_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_105_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_105_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_105_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_105_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_116_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_116_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_116_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_117_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_117_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_117_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_118_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_118_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_118_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_11_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_11_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_11_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_11_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_121_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_121_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_121_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_121_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_121_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_121_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_121_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_121_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_122_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_122_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_122_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_122_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_122_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_122_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_122_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_122_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_130_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_130_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_130_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_130_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_130_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_130_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_130_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_130_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_136_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_136_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_136_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_136_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_136_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_136_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_136_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_136_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_137_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_137_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_137_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_137_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_137_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_137_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_137_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_137_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_142_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_142_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_142_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_142_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_142_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_142_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_142_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_142_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_143_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_143_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_143_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_143_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_143_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_143_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_143_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_143_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_148_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_148_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_148_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_148_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_148_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_148_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_148_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_148_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_157_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_157_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_157_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_157_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_157_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_157_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_157_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_157_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_158_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_158_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_158_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_158_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_158_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_158_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_158_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_158_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_163_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_163_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_163_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_163_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_163_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_163_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_163_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_163_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_16_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_16_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_16_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_16_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_211_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_211_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_211_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_211_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_211_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_211_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_211_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_211_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_216_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_216_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_216_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_216_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_216_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_216_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_216_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_216_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_21_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_21_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_21_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_21_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_221_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_221_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_221_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_221_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_221_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_221_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_221_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_221_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_226_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_226_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_226_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_226_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_226_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_226_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_226_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_226_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_231_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_231_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_231_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_231_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_231_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_231_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_231_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_231_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_236_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_236_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_236_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_236_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_236_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_236_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_236_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_236_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_317_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_317_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_317_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_317_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_317_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_317_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_317_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_317_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_33_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_33_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_33_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_33_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_33_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_33_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_33_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_38_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_39_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_3_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_448_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_449_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_450_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_450_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_450_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_450_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_450_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_450_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_450_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_450_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_455_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_456_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_456_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_456_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_457_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_458_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_459_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_4_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_501_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_501_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_501_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_501_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_5_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_68_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_68_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_68_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_68_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_68_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_68_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_69_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_70_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_70_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_70_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_70_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_70_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_70_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_71_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_71_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_71_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_71_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_71_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_71_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_72_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_72_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_72_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_72_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_72_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_72_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_73_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_73_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_73_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_73_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_73_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_73_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_74_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_74_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_74_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_74_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_74_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_74_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_75_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_75_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_75_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_75_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_75_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_75_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_76_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_76_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_76_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_76_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_76_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_76_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_77_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_77_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_77_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_77_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_77_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_77_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_78_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_78_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_78_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_78_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_78_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_78_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_86_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_86_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_86_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_86_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_86_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_86_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_86_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_86_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_87_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_87_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_87_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_87_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_87_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_87_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_87_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_87_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_94_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_94_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_94_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_94_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_94_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_94_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_94_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_95_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_95_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_95_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_95_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_95_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_95_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_95_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_96_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_96_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_96_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_96_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_96_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_96_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_96_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_97_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_97_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_97_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_97_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_97_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_97_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_97_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_98_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_98_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_98_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_98_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_98_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_98_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_98_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_99_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_99_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_99_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_99_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_99_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_99_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_99_n_7\ : STD_LOGIC;
  signal \^vga_vs\ : STD_LOGIC;
  signal VGA_VS0 : STD_LOGIC;
  signal VGA_VS1 : STD_LOGIC;
  signal VGA_VS_i_10_n_0 : STD_LOGIC;
  signal VGA_VS_i_11_n_0 : STD_LOGIC;
  signal VGA_VS_i_1_n_0 : STD_LOGIC;
  signal VGA_VS_i_4_n_0 : STD_LOGIC;
  signal VGA_VS_i_5_n_0 : STD_LOGIC;
  signal VGA_VS_i_6_n_0 : STD_LOGIC;
  signal VGA_VS_i_7_n_0 : STD_LOGIC;
  signal VGA_VS_i_8_n_0 : STD_LOGIC;
  signal VGA_VS_i_9_n_0 : STD_LOGIC;
  signal VGA_VS_reg_i_2_n_1 : STD_LOGIC;
  signal VGA_VS_reg_i_2_n_2 : STD_LOGIC;
  signal VGA_VS_reg_i_2_n_3 : STD_LOGIC;
  signal VGA_VS_reg_i_3_n_1 : STD_LOGIC;
  signal VGA_VS_reg_i_3_n_2 : STD_LOGIC;
  signal VGA_VS_reg_i_3_n_3 : STD_LOGIC;
  signal disp_enable0 : STD_LOGIC;
  signal disp_enable1 : STD_LOGIC;
  signal disp_enable10_in : STD_LOGIC;
  signal hcntend : STD_LOGIC;
  signal p_0_in : STD_LOGIC_VECTOR ( 10 downto 1 );
  signal \p_0_in__0\ : STD_LOGIC_VECTOR ( 10 downto 0 );
  signal \p_0_in__1\ : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal \^p_1_in\ : STD_LOGIC_VECTOR ( 10 downto 0 );
  signal pattern_b11_in : STD_LOGIC;
  signal \pattern_b1__0_i_10_n_0\ : STD_LOGIC;
  signal \pattern_b1__0_i_11_n_0\ : STD_LOGIC;
  signal \pattern_b1__0_i_12_n_0\ : STD_LOGIC;
  signal \pattern_b1__0_i_1_n_2\ : STD_LOGIC;
  signal \pattern_b1__0_i_1_n_3\ : STD_LOGIC;
  signal \pattern_b1__0_i_2_n_0\ : STD_LOGIC;
  signal \pattern_b1__0_i_2_n_1\ : STD_LOGIC;
  signal \pattern_b1__0_i_2_n_2\ : STD_LOGIC;
  signal \pattern_b1__0_i_2_n_3\ : STD_LOGIC;
  signal \pattern_b1__0_i_3_n_0\ : STD_LOGIC;
  signal \pattern_b1__0_i_3_n_1\ : STD_LOGIC;
  signal \pattern_b1__0_i_3_n_2\ : STD_LOGIC;
  signal \pattern_b1__0_i_3_n_3\ : STD_LOGIC;
  signal \pattern_b1__0_i_4_n_0\ : STD_LOGIC;
  signal \pattern_b1__0_i_5_n_0\ : STD_LOGIC;
  signal \pattern_b1__0_i_6_n_0\ : STD_LOGIC;
  signal \pattern_b1__0_i_7_n_0\ : STD_LOGIC;
  signal \pattern_b1__0_i_8_n_0\ : STD_LOGIC;
  signal \pattern_b1__0_i_9_n_0\ : STD_LOGIC;
  signal \pattern_b1__1\ : STD_LOGIC;
  signal pattern_b1_i_10_n_0 : STD_LOGIC;
  signal pattern_b1_i_11_n_0 : STD_LOGIC;
  signal pattern_b1_i_12_n_0 : STD_LOGIC;
  signal pattern_b1_i_13_n_0 : STD_LOGIC;
  signal pattern_b1_i_14_n_0 : STD_LOGIC;
  signal pattern_b1_i_15_n_0 : STD_LOGIC;
  signal pattern_b1_i_16_n_0 : STD_LOGIC;
  signal pattern_b1_i_19_n_0 : STD_LOGIC;
  signal pattern_b1_i_1_n_3 : STD_LOGIC;
  signal pattern_b1_i_20_n_0 : STD_LOGIC;
  signal pattern_b1_i_21_n_0 : STD_LOGIC;
  signal pattern_b1_i_22_n_0 : STD_LOGIC;
  signal pattern_b1_i_2_n_0 : STD_LOGIC;
  signal pattern_b1_i_2_n_1 : STD_LOGIC;
  signal pattern_b1_i_2_n_2 : STD_LOGIC;
  signal pattern_b1_i_2_n_3 : STD_LOGIC;
  signal pattern_b1_i_3_n_0 : STD_LOGIC;
  signal pattern_b1_i_3_n_1 : STD_LOGIC;
  signal pattern_b1_i_3_n_2 : STD_LOGIC;
  signal pattern_b1_i_3_n_3 : STD_LOGIC;
  signal pattern_b1_i_4_n_0 : STD_LOGIC;
  signal pattern_b1_i_5_n_0 : STD_LOGIC;
  signal pattern_b1_i_6_n_0 : STD_LOGIC;
  signal pattern_b1_i_7_n_0 : STD_LOGIC;
  signal pattern_b1_i_8_n_0 : STD_LOGIC;
  signal pattern_b1_i_9_n_0 : STD_LOGIC;
  signal pattern_b20_out : STD_LOGIC;
  signal \pattern_b3__4\ : STD_LOGIC;
  signal sel0 : STD_LOGIC_VECTOR ( 32 downto 0 );
  signal \NLW_VCNT_reg[10]_i_2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VCNT_reg[10]_i_4_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_B_reg[7]_i_13_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_B_reg[7]_i_28_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_B_reg[7]_i_28_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_VGA_B_reg[7]_i_30_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_B_reg[7]_i_30_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_VGA_B_reg[7]_i_32_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_B_reg[7]_i_32_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_VGA_B_reg[7]_i_6_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_B_reg[7]_i_7_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_B_reg[7]_i_8_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_G_reg[7]_i_6_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_VGA_G_reg[7]_i_7_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal NLW_VGA_HS_reg_i_3_O_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal NLW_VGA_HS_reg_i_4_O_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[4]_i_5_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_VGA_R_reg[4]_i_5_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[4]_i_8_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[5]_i_11_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_VGA_R_reg[5]_i_11_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[5]_i_12_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_VGA_R_reg[5]_i_12_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[5]_i_13_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_VGA_R_reg[5]_i_13_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[5]_i_14_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[5]_i_18_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[5]_i_31_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[5]_i_35_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[5]_i_40_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[5]_i_7_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_VGA_R_reg[5]_i_7_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[5]_i_8_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_VGA_R_reg[5]_i_8_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[7]_i_100_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_VGA_R_reg[7]_i_102_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[7]_i_105_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[7]_i_11_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[7]_i_116_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[7]_i_117_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[7]_i_118_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[7]_i_16_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[7]_i_21_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[7]_i_3_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_VGA_R_reg[7]_i_3_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[7]_i_33_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_VGA_R_reg[7]_i_38_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_VGA_R_reg[7]_i_38_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[7]_i_39_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_VGA_R_reg[7]_i_39_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[7]_i_4_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_VGA_R_reg[7]_i_4_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[7]_i_448_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[7]_i_448_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_VGA_R_reg[7]_i_449_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[7]_i_449_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_VGA_R_reg[7]_i_455_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[7]_i_455_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_VGA_R_reg[7]_i_456_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_VGA_R_reg[7]_i_456_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_VGA_R_reg[7]_i_457_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[7]_i_457_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_VGA_R_reg[7]_i_458_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[7]_i_458_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_VGA_R_reg[7]_i_459_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[7]_i_459_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_VGA_R_reg[7]_i_5_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_VGA_R_reg[7]_i_5_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[7]_i_501_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[7]_i_68_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_VGA_R_reg[7]_i_69_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_VGA_R_reg[7]_i_69_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[7]_i_70_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_VGA_R_reg[7]_i_71_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_VGA_R_reg[7]_i_72_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_VGA_R_reg[7]_i_73_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_VGA_R_reg[7]_i_74_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_VGA_R_reg[7]_i_75_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_VGA_R_reg[7]_i_76_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_VGA_R_reg[7]_i_77_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_VGA_R_reg[7]_i_78_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_VGA_R_reg[7]_i_94_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_VGA_R_reg[7]_i_95_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_VGA_R_reg[7]_i_96_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_VGA_R_reg[7]_i_97_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_VGA_R_reg[7]_i_98_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_VGA_R_reg[7]_i_99_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal NLW_VGA_VS_reg_i_2_O_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal NLW_VGA_VS_reg_i_3_O_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_pattern_b1__0_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_pattern_b1__0_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal NLW_pattern_b1_i_1_CO_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal NLW_pattern_b1_i_1_O_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 2 );
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \FCNT[0]_i_1\ : label is "soft_lutpair39";
  attribute SOFT_HLUTNM of \FCNT[1]_i_1\ : label is "soft_lutpair39";
  attribute SOFT_HLUTNM of \FCNT[2]_i_1\ : label is "soft_lutpair28";
  attribute SOFT_HLUTNM of \FCNT[3]_i_1\ : label is "soft_lutpair22";
  attribute SOFT_HLUTNM of \FCNT[4]_i_1\ : label is "soft_lutpair28";
  attribute SOFT_HLUTNM of \FCNT[6]_i_1\ : label is "soft_lutpair32";
  attribute SOFT_HLUTNM of \HCNT[1]_i_1\ : label is "soft_lutpair36";
  attribute SOFT_HLUTNM of \HCNT[2]_i_1\ : label is "soft_lutpair36";
  attribute SOFT_HLUTNM of \HCNT[3]_i_1\ : label is "soft_lutpair25";
  attribute SOFT_HLUTNM of \HCNT[4]_i_1\ : label is "soft_lutpair25";
  attribute SOFT_HLUTNM of \HCNT[6]_i_1\ : label is "soft_lutpair35";
  attribute SOFT_HLUTNM of \HCNT[7]_i_1\ : label is "soft_lutpair35";
  attribute SOFT_HLUTNM of \HCNT[8]_i_1\ : label is "soft_lutpair24";
  attribute SOFT_HLUTNM of \HCNT[9]_i_1\ : label is "soft_lutpair24";
  attribute SOFT_HLUTNM of \VCNT[1]_i_1\ : label is "soft_lutpair38";
  attribute SOFT_HLUTNM of \VCNT[2]_i_1\ : label is "soft_lutpair38";
  attribute SOFT_HLUTNM of \VCNT[3]_i_1\ : label is "soft_lutpair27";
  attribute SOFT_HLUTNM of \VCNT[4]_i_1\ : label is "soft_lutpair27";
  attribute SOFT_HLUTNM of \VCNT[6]_i_1\ : label is "soft_lutpair37";
  attribute SOFT_HLUTNM of \VCNT[7]_i_1\ : label is "soft_lutpair37";
  attribute SOFT_HLUTNM of \VCNT[8]_i_1\ : label is "soft_lutpair26";
  attribute SOFT_HLUTNM of \VCNT[9]_i_1\ : label is "soft_lutpair26";
  attribute SOFT_HLUTNM of \VGA_B[7]_i_5\ : label is "soft_lutpair33";
  attribute SOFT_HLUTNM of VGA_DE_i_1 : label is "soft_lutpair30";
  attribute SOFT_HLUTNM of \VGA_G[7]_i_5\ : label is "soft_lutpair33";
  attribute SOFT_HLUTNM of VGA_HS_i_2 : label is "soft_lutpair31";
  attribute SOFT_HLUTNM of \VGA_R[7]_i_1\ : label is "soft_lutpair30";
  attribute SOFT_HLUTNM of \VGA_R[7]_i_428\ : label is "soft_lutpair22";
  attribute SOFT_HLUTNM of \VGA_R[7]_i_429\ : label is "soft_lutpair29";
  attribute SOFT_HLUTNM of \VGA_R[7]_i_43\ : label is "soft_lutpair32";
  attribute SOFT_HLUTNM of \VGA_R[7]_i_430\ : label is "soft_lutpair34";
  attribute SOFT_HLUTNM of \VGA_R[7]_i_431\ : label is "soft_lutpair34";
  attribute SOFT_HLUTNM of \VGA_R[7]_i_432\ : label is "soft_lutpair31";
  attribute SOFT_HLUTNM of \VGA_R[7]_i_433\ : label is "soft_lutpair29";
  attribute SOFT_HLUTNM of \VGA_R[7]_i_434\ : label is "soft_lutpair23";
  attribute SOFT_HLUTNM of \VGA_R[7]_i_476\ : label is "soft_lutpair23";
  attribute COMPARATOR_THRESHOLD : integer;
  attribute COMPARATOR_THRESHOLD of \VGA_R_reg[4]_i_5\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \VGA_R_reg[4]_i_8\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \VGA_R_reg[5]_i_11\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \VGA_R_reg[5]_i_12\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \VGA_R_reg[5]_i_13\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \VGA_R_reg[5]_i_14\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \VGA_R_reg[5]_i_18\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \VGA_R_reg[5]_i_31\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \VGA_R_reg[5]_i_35\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \VGA_R_reg[5]_i_40\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \VGA_R_reg[5]_i_7\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \VGA_R_reg[5]_i_8\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \VGA_R_reg[7]_i_102\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \VGA_R_reg[7]_i_105\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \VGA_R_reg[7]_i_11\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \VGA_R_reg[7]_i_16\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \VGA_R_reg[7]_i_21\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \VGA_R_reg[7]_i_3\ : label is 11;
  attribute ADDER_THRESHOLD : integer;
  attribute ADDER_THRESHOLD of \VGA_R_reg[7]_i_317\ : label is 35;
  attribute COMPARATOR_THRESHOLD of \VGA_R_reg[7]_i_38\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \VGA_R_reg[7]_i_39\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \VGA_R_reg[7]_i_4\ : label is 11;
  attribute ADDER_THRESHOLD of \VGA_R_reg[7]_i_450\ : label is 35;
  attribute ADDER_THRESHOLD of \VGA_R_reg[7]_i_456\ : label is 35;
  attribute COMPARATOR_THRESHOLD of \VGA_R_reg[7]_i_5\ : label is 11;
  attribute ADDER_THRESHOLD of \VGA_R_reg[7]_i_501\ : label is 35;
  attribute ADDER_THRESHOLD of \pattern_b1__0_i_1\ : label is 35;
  attribute ADDER_THRESHOLD of \pattern_b1__0_i_2\ : label is 35;
  attribute ADDER_THRESHOLD of \pattern_b1__0_i_3\ : label is 35;
  attribute ADDER_THRESHOLD of pattern_b1_i_1 : label is 35;
  attribute ADDER_THRESHOLD of pattern_b1_i_2 : label is 35;
  attribute ADDER_THRESHOLD of pattern_b1_i_3 : label is 35;
begin
  A(10 downto 0) <= \^a\(10 downto 0);
  PCK <= \^pck\;
  VGA_HS <= \^vga_hs\;
  VGA_VS <= \^vga_vs\;
  p_1_in(10 downto 0) <= \^p_1_in\(10 downto 0);
\FCNT[0]_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => FCNT(0),
      O => \p_0_in__1\(0)
    );
\FCNT[1]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => FCNT(0),
      I1 => FCNT(1),
      O => \p_0_in__1\(1)
    );
\FCNT[2]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"78"
    )
        port map (
      I0 => FCNT(0),
      I1 => FCNT(1),
      I2 => FCNT(2),
      O => \p_0_in__1\(2)
    );
\FCNT[3]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7F80"
    )
        port map (
      I0 => FCNT(1),
      I1 => FCNT(0),
      I2 => FCNT(2),
      I3 => FCNT(3),
      O => \p_0_in__1\(3)
    );
\FCNT[4]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"7FFF8000"
    )
        port map (
      I0 => FCNT(2),
      I1 => FCNT(0),
      I2 => FCNT(1),
      I3 => FCNT(3),
      I4 => FCNT(4),
      O => \p_0_in__1\(4)
    );
\FCNT[5]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7FFFFFFF80000000"
    )
        port map (
      I0 => FCNT(3),
      I1 => FCNT(1),
      I2 => FCNT(0),
      I3 => FCNT(2),
      I4 => FCNT(4),
      I5 => FCNT(5),
      O => \p_0_in__1\(5)
    );
\FCNT[6]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \FCNT[7]_i_3_n_0\,
      I1 => FCNT(6),
      O => \p_0_in__1\(6)
    );
\FCNT[7]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => hcntend,
      I1 => VCNT0,
      O => \FCNT[7]_i_1_n_0\
    );
\FCNT[7]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"78"
    )
        port map (
      I0 => \FCNT[7]_i_3_n_0\,
      I1 => FCNT(6),
      I2 => FCNT(7),
      O => \p_0_in__1\(7)
    );
\FCNT[7]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8000000000000000"
    )
        port map (
      I0 => FCNT(5),
      I1 => FCNT(3),
      I2 => FCNT(1),
      I3 => FCNT(0),
      I4 => FCNT(2),
      I5 => FCNT(4),
      O => \FCNT[7]_i_3_n_0\
    );
\FCNT_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => \^pck\,
      CE => \FCNT[7]_i_1_n_0\,
      D => \p_0_in__1\(0),
      Q => FCNT(0),
      R => RST
    );
\FCNT_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => \^pck\,
      CE => \FCNT[7]_i_1_n_0\,
      D => \p_0_in__1\(1),
      Q => FCNT(1),
      R => RST
    );
\FCNT_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => \^pck\,
      CE => \FCNT[7]_i_1_n_0\,
      D => \p_0_in__1\(2),
      Q => FCNT(2),
      R => RST
    );
\FCNT_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => \^pck\,
      CE => \FCNT[7]_i_1_n_0\,
      D => \p_0_in__1\(3),
      Q => FCNT(3),
      R => RST
    );
\FCNT_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => \^pck\,
      CE => \FCNT[7]_i_1_n_0\,
      D => \p_0_in__1\(4),
      Q => FCNT(4),
      R => RST
    );
\FCNT_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => \^pck\,
      CE => \FCNT[7]_i_1_n_0\,
      D => \p_0_in__1\(5),
      Q => FCNT(5),
      R => RST
    );
\FCNT_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => \^pck\,
      CE => \FCNT[7]_i_1_n_0\,
      D => \p_0_in__1\(6),
      Q => FCNT(6),
      R => RST
    );
\FCNT_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => \^pck\,
      CE => \FCNT[7]_i_1_n_0\,
      D => \p_0_in__1\(7),
      Q => FCNT(7),
      R => RST
    );
\HCNT[0]_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => HCNT(0),
      O => \^p_1_in\(0)
    );
\HCNT[10]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => RST,
      I1 => hcntend,
      O => \HCNT[10]_i_1_n_0\
    );
\HCNT[10]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7FFFFFFF80000000"
    )
        port map (
      I0 => HCNT(8),
      I1 => HCNT(6),
      I2 => \HCNT[10]_i_3_n_0\,
      I3 => HCNT(7),
      I4 => HCNT(9),
      I5 => HCNT(10),
      O => p_0_in(10)
    );
\HCNT[10]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8000000000000000"
    )
        port map (
      I0 => HCNT(5),
      I1 => HCNT(3),
      I2 => HCNT(1),
      I3 => HCNT(0),
      I4 => HCNT(2),
      I5 => HCNT(4),
      O => \HCNT[10]_i_3_n_0\
    );
\HCNT[1]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => HCNT(0),
      I1 => HCNT(1),
      O => p_0_in(1)
    );
\HCNT[2]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"78"
    )
        port map (
      I0 => HCNT(0),
      I1 => HCNT(1),
      I2 => HCNT(2),
      O => p_0_in(2)
    );
\HCNT[3]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7F80"
    )
        port map (
      I0 => HCNT(1),
      I1 => HCNT(0),
      I2 => HCNT(2),
      I3 => HCNT(3),
      O => p_0_in(3)
    );
\HCNT[4]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"7FFF8000"
    )
        port map (
      I0 => HCNT(2),
      I1 => HCNT(0),
      I2 => HCNT(1),
      I3 => HCNT(3),
      I4 => HCNT(4),
      O => p_0_in(4)
    );
\HCNT[5]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7FFFFFFF80000000"
    )
        port map (
      I0 => HCNT(3),
      I1 => HCNT(1),
      I2 => HCNT(0),
      I3 => HCNT(2),
      I4 => HCNT(4),
      I5 => HCNT(5),
      O => p_0_in(5)
    );
\HCNT[6]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \HCNT[10]_i_3_n_0\,
      I1 => HCNT(6),
      O => p_0_in(6)
    );
\HCNT[7]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"78"
    )
        port map (
      I0 => \HCNT[10]_i_3_n_0\,
      I1 => HCNT(6),
      I2 => HCNT(7),
      O => p_0_in(7)
    );
\HCNT[8]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7F80"
    )
        port map (
      I0 => HCNT(6),
      I1 => \HCNT[10]_i_3_n_0\,
      I2 => HCNT(7),
      I3 => HCNT(8),
      O => p_0_in(8)
    );
\HCNT[9]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"7FFF8000"
    )
        port map (
      I0 => HCNT(7),
      I1 => \HCNT[10]_i_3_n_0\,
      I2 => HCNT(6),
      I3 => HCNT(8),
      I4 => HCNT(9),
      O => p_0_in(9)
    );
\HCNT_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => \^pck\,
      CE => '1',
      D => \^p_1_in\(0),
      Q => HCNT(0),
      R => \HCNT[10]_i_1_n_0\
    );
\HCNT_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => \^pck\,
      CE => '1',
      D => p_0_in(10),
      Q => HCNT(10),
      R => \HCNT[10]_i_1_n_0\
    );
\HCNT_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => \^pck\,
      CE => '1',
      D => p_0_in(1),
      Q => HCNT(1),
      R => \HCNT[10]_i_1_n_0\
    );
\HCNT_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => \^pck\,
      CE => '1',
      D => p_0_in(2),
      Q => HCNT(2),
      R => \HCNT[10]_i_1_n_0\
    );
\HCNT_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => \^pck\,
      CE => '1',
      D => p_0_in(3),
      Q => HCNT(3),
      R => \HCNT[10]_i_1_n_0\
    );
\HCNT_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => \^pck\,
      CE => '1',
      D => p_0_in(4),
      Q => HCNT(4),
      R => \HCNT[10]_i_1_n_0\
    );
\HCNT_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => \^pck\,
      CE => '1',
      D => p_0_in(5),
      Q => HCNT(5),
      R => \HCNT[10]_i_1_n_0\
    );
\HCNT_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => \^pck\,
      CE => '1',
      D => p_0_in(6),
      Q => HCNT(6),
      R => \HCNT[10]_i_1_n_0\
    );
\HCNT_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => \^pck\,
      CE => '1',
      D => p_0_in(7),
      Q => HCNT(7),
      R => \HCNT[10]_i_1_n_0\
    );
\HCNT_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => \^pck\,
      CE => '1',
      D => p_0_in(8),
      Q => HCNT(8),
      R => \HCNT[10]_i_1_n_0\
    );
\HCNT_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => \^pck\,
      CE => '1',
      D => p_0_in(9),
      Q => HCNT(9),
      R => \HCNT[10]_i_1_n_0\
    );
\VCNT[0]_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => VCNT(0),
      O => \p_0_in__0\(0)
    );
\VCNT[10]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"EA"
    )
        port map (
      I0 => RST,
      I1 => VCNT0,
      I2 => hcntend,
      O => \VCNT[10]_i_1_n_0\
    );
\VCNT[10]_i_10\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => VCNT(9),
      I1 => VCNT(10),
      O => \VCNT[10]_i_10_n_0\
    );
\VCNT[10]_i_11\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00201101"
    )
        port map (
      I0 => VCNT(6),
      I1 => VCNT(8),
      I2 => timing_sel(1),
      I3 => timing_sel(0),
      I4 => VCNT(7),
      O => \VCNT[10]_i_11_n_0\
    );
\VCNT[10]_i_12\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00202202"
    )
        port map (
      I0 => VCNT(3),
      I1 => VCNT(4),
      I2 => timing_sel(1),
      I3 => timing_sel(0),
      I4 => VCNT(5),
      O => \VCNT[10]_i_12_n_0\
    );
\VCNT[10]_i_13\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00650000"
    )
        port map (
      I0 => VCNT(0),
      I1 => timing_sel(0),
      I2 => timing_sel(1),
      I3 => VCNT(1),
      I4 => VCNT(2),
      O => \VCNT[10]_i_13_n_0\
    );
\VCNT[10]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7FFFFFFF80000000"
    )
        port map (
      I0 => VCNT(8),
      I1 => VCNT(6),
      I2 => \VCNT[10]_i_9_n_0\,
      I3 => VCNT(7),
      I4 => VCNT(9),
      I5 => VCNT(10),
      O => \p_0_in__0\(10)
    );
\VCNT[10]_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2822"
    )
        port map (
      I0 => HCNT(9),
      I1 => HCNT(10),
      I2 => timing_sel(0),
      I3 => timing_sel(1),
      O => \VCNT[10]_i_5_n_0\
    );
\VCNT[10]_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00004920"
    )
        port map (
      I0 => HCNT(6),
      I1 => timing_sel(0),
      I2 => timing_sel(1),
      I3 => HCNT(8),
      I4 => HCNT(7),
      O => \VCNT[10]_i_6_n_0\
    );
\VCNT[10]_i_7\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"04A20000"
    )
        port map (
      I0 => HCNT(3),
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      I3 => HCNT(5),
      I4 => HCNT(4),
      O => \VCNT[10]_i_7_n_0\
    );
\VCNT[10]_i_8\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"82000028"
    )
        port map (
      I0 => HCNT(0),
      I1 => timing_sel(0),
      I2 => timing_sel(1),
      I3 => HCNT(2),
      I4 => HCNT(1),
      O => \VCNT[10]_i_8_n_0\
    );
\VCNT[10]_i_9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8000000000000000"
    )
        port map (
      I0 => VCNT(5),
      I1 => VCNT(3),
      I2 => VCNT(1),
      I3 => VCNT(0),
      I4 => VCNT(2),
      I5 => VCNT(4),
      O => \VCNT[10]_i_9_n_0\
    );
\VCNT[1]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => VCNT(0),
      I1 => VCNT(1),
      O => \p_0_in__0\(1)
    );
\VCNT[2]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"78"
    )
        port map (
      I0 => VCNT(0),
      I1 => VCNT(1),
      I2 => VCNT(2),
      O => \p_0_in__0\(2)
    );
\VCNT[3]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7F80"
    )
        port map (
      I0 => VCNT(1),
      I1 => VCNT(0),
      I2 => VCNT(2),
      I3 => VCNT(3),
      O => \p_0_in__0\(3)
    );
\VCNT[4]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"7FFF8000"
    )
        port map (
      I0 => VCNT(2),
      I1 => VCNT(0),
      I2 => VCNT(1),
      I3 => VCNT(3),
      I4 => VCNT(4),
      O => \p_0_in__0\(4)
    );
\VCNT[5]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7FFFFFFF80000000"
    )
        port map (
      I0 => VCNT(3),
      I1 => VCNT(1),
      I2 => VCNT(0),
      I3 => VCNT(2),
      I4 => VCNT(4),
      I5 => VCNT(5),
      O => \p_0_in__0\(5)
    );
\VCNT[6]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VCNT[10]_i_9_n_0\,
      I1 => VCNT(6),
      O => \p_0_in__0\(6)
    );
\VCNT[7]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"78"
    )
        port map (
      I0 => \VCNT[10]_i_9_n_0\,
      I1 => VCNT(6),
      I2 => VCNT(7),
      O => \p_0_in__0\(7)
    );
\VCNT[8]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7F80"
    )
        port map (
      I0 => VCNT(6),
      I1 => \VCNT[10]_i_9_n_0\,
      I2 => VCNT(7),
      I3 => VCNT(8),
      O => \p_0_in__0\(8)
    );
\VCNT[9]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"7FFF8000"
    )
        port map (
      I0 => VCNT(7),
      I1 => \VCNT[10]_i_9_n_0\,
      I2 => VCNT(6),
      I3 => VCNT(8),
      I4 => VCNT(9),
      O => \p_0_in__0\(9)
    );
\VCNT_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => \^pck\,
      CE => hcntend,
      D => \p_0_in__0\(0),
      Q => VCNT(0),
      R => \VCNT[10]_i_1_n_0\
    );
\VCNT_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => \^pck\,
      CE => hcntend,
      D => \p_0_in__0\(10),
      Q => VCNT(10),
      R => \VCNT[10]_i_1_n_0\
    );
\VCNT_reg[10]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => hcntend,
      CO(2) => \VCNT_reg[10]_i_2_n_1\,
      CO(1) => \VCNT_reg[10]_i_2_n_2\,
      CO(0) => \VCNT_reg[10]_i_2_n_3\,
      CYINIT => '1',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => \NLW_VCNT_reg[10]_i_2_O_UNCONNECTED\(3 downto 0),
      S(3) => \VCNT[10]_i_5_n_0\,
      S(2) => \VCNT[10]_i_6_n_0\,
      S(1) => \VCNT[10]_i_7_n_0\,
      S(0) => \VCNT[10]_i_8_n_0\
    );
\VCNT_reg[10]_i_4\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => VCNT0,
      CO(2) => \VCNT_reg[10]_i_4_n_1\,
      CO(1) => \VCNT_reg[10]_i_4_n_2\,
      CO(0) => \VCNT_reg[10]_i_4_n_3\,
      CYINIT => '1',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => \NLW_VCNT_reg[10]_i_4_O_UNCONNECTED\(3 downto 0),
      S(3) => \VCNT[10]_i_10_n_0\,
      S(2) => \VCNT[10]_i_11_n_0\,
      S(1) => \VCNT[10]_i_12_n_0\,
      S(0) => \VCNT[10]_i_13_n_0\
    );
\VCNT_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => \^pck\,
      CE => hcntend,
      D => \p_0_in__0\(1),
      Q => VCNT(1),
      R => \VCNT[10]_i_1_n_0\
    );
\VCNT_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => \^pck\,
      CE => hcntend,
      D => \p_0_in__0\(2),
      Q => VCNT(2),
      R => \VCNT[10]_i_1_n_0\
    );
\VCNT_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => \^pck\,
      CE => hcntend,
      D => \p_0_in__0\(3),
      Q => VCNT(3),
      R => \VCNT[10]_i_1_n_0\
    );
\VCNT_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => \^pck\,
      CE => hcntend,
      D => \p_0_in__0\(4),
      Q => VCNT(4),
      R => \VCNT[10]_i_1_n_0\
    );
\VCNT_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => \^pck\,
      CE => hcntend,
      D => \p_0_in__0\(5),
      Q => VCNT(5),
      R => \VCNT[10]_i_1_n_0\
    );
\VCNT_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => \^pck\,
      CE => hcntend,
      D => \p_0_in__0\(6),
      Q => VCNT(6),
      R => \VCNT[10]_i_1_n_0\
    );
\VCNT_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => \^pck\,
      CE => hcntend,
      D => \p_0_in__0\(7),
      Q => VCNT(7),
      R => \VCNT[10]_i_1_n_0\
    );
\VCNT_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => \^pck\,
      CE => hcntend,
      D => \p_0_in__0\(8),
      Q => VCNT(8),
      R => \VCNT[10]_i_1_n_0\
    );
\VCNT_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => \^pck\,
      CE => hcntend,
      D => \p_0_in__0\(9),
      Q => VCNT(9),
      R => \VCNT[10]_i_1_n_0\
    );
\VGA_B[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BABBBABBBABBAAAA"
    )
        port map (
      I0 => \VGA_B_reg[0]\,
      I1 => pattern_sel(3),
      I2 => \VGA_B[7]_i_4_n_0\,
      I3 => \VGA_R[0]_i_3_n_0\,
      I4 => \VGA_R[0]_i_4_n_0\,
      I5 => \VGA_B[7]_i_3_n_0\,
      O => D(0)
    );
\VGA_B[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BABBBABBBABBAAAA"
    )
        port map (
      I0 => \VGA_B_reg[1]\,
      I1 => pattern_sel(3),
      I2 => \VGA_B[7]_i_4_n_0\,
      I3 => \VGA_R[1]_i_3_n_0\,
      I4 => \VGA_R[1]_i_4_n_0\,
      I5 => \VGA_B[7]_i_3_n_0\,
      O => D(1)
    );
\VGA_B[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BABBBABBBABBAAAA"
    )
        port map (
      I0 => \VGA_B_reg[2]\,
      I1 => pattern_sel(3),
      I2 => \VGA_B[7]_i_4_n_0\,
      I3 => \VGA_R[2]_i_3_n_0\,
      I4 => \VGA_R[2]_i_4_n_0\,
      I5 => \VGA_B[7]_i_3_n_0\,
      O => D(2)
    );
\VGA_B[3]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BABBBABBBABBAAAA"
    )
        port map (
      I0 => \VGA_R[3]_i_2_n_0\,
      I1 => pattern_sel(3),
      I2 => \VGA_B[7]_i_4_n_0\,
      I3 => \VGA_R[3]_i_3_n_0\,
      I4 => \VGA_R[3]_i_4_n_0\,
      I5 => \VGA_B[7]_i_3_n_0\,
      O => D(3)
    );
\VGA_B[4]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BBB88888BBB8BBB8"
    )
        port map (
      I0 => \VGA_B[4]_i_2_n_0\,
      I1 => pattern_sel(3),
      I2 => \VGA_B[7]_i_3_n_0\,
      I3 => \VGA_R[4]_i_4_n_0\,
      I4 => \VGA_B[7]_i_4_n_0\,
      I5 => \VGA_R[4]_i_3_n_0\,
      O => D(4)
    );
\VGA_B[4]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"08080808A8A8A808"
    )
        port map (
      I0 => \VGA_R_reg[6]\,
      I1 => P(1),
      I2 => \VGA_R_reg[6]_0\,
      I3 => \VGA_R_reg[4]_i_5_n_2\,
      I4 => \VGA_R_reg[5]_i_8_n_2\,
      I5 => sel0(32),
      O => \VGA_B[4]_i_2_n_0\
    );
\VGA_B[5]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BBB88888BBB8BBB8"
    )
        port map (
      I0 => \VGA_B[5]_i_2_n_0\,
      I1 => pattern_sel(3),
      I2 => \VGA_B[7]_i_3_n_0\,
      I3 => \VGA_R[5]_i_4_n_0\,
      I4 => \VGA_B[7]_i_4_n_0\,
      I5 => \VGA_R[5]_i_3_n_0\,
      O => D(5)
    );
\VGA_B[5]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"08080808A8A8A808"
    )
        port map (
      I0 => \VGA_R_reg[6]\,
      I1 => P(2),
      I2 => \VGA_R_reg[6]_0\,
      I3 => \VGA_R_reg[5]_i_8_n_2\,
      I4 => \VGA_R[5]_i_6_n_0\,
      I5 => sel0(32),
      O => \VGA_B[5]_i_2_n_0\
    );
\VGA_B[6]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BBB88888BBB8BBB8"
    )
        port map (
      I0 => \VGA_B[6]_i_2_n_0\,
      I1 => pattern_sel(3),
      I2 => \VGA_B[7]_i_3_n_0\,
      I3 => \VGA_R[6]_i_3_n_0\,
      I4 => \VGA_B[7]_i_4_n_0\,
      I5 => \VGA_R[6]_i_4_n_0\,
      O => D(6)
    );
\VGA_B[6]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"222222A200000080"
    )
        port map (
      I0 => \VGA_R_reg[6]\,
      I1 => \VGA_R_reg[6]_0\,
      I2 => \VGA_R[7]_i_27_n_0\,
      I3 => \VGA_R[7]_i_28_n_0\,
      I4 => \VGA_B[7]_i_5_n_0\,
      I5 => P(3),
      O => \VGA_B[6]_i_2_n_0\
    );
\VGA_B[7]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BBB88888BBB8BBB8"
    )
        port map (
      I0 => \VGA_B[7]_i_2_n_0\,
      I1 => pattern_sel(3),
      I2 => \VGA_B[7]_i_3_n_0\,
      I3 => \VGA_R[7]_i_7_n_0\,
      I4 => \VGA_B[7]_i_4_n_0\,
      I5 => \VGA_R[7]_i_9_n_0\,
      O => D(7)
    );
\VGA_B[7]_i_10\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_33_n_0\,
      I1 => zp_sum,
      I2 => \VGA_R_reg[7]_i_33_n_6\,
      O => \VGA_B[7]_i_10_n_0\
    );
\VGA_B[7]_i_11\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => zp_sum,
      I1 => \VGA_R_reg[7]_i_33_n_0\,
      I2 => \VGA_R_reg[7]_i_33_n_7\,
      O => \VGA_B[7]_i_11_n_0\
    );
\VGA_B[7]_i_12\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_33_n_0\,
      I1 => zp_sum,
      I2 => \VGA_R_reg[7]_i_86_n_4\,
      O => \VGA_B[7]_i_12_n_0\
    );
\VGA_B[7]_i_14\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => sel0(1),
      I1 => \VGA_R_reg[7]_i_68_n_5\,
      O => \VGA_B[7]_i_14_n_0\
    );
\VGA_B[7]_i_15\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => sel0(1),
      I1 => zp_sum,
      I2 => \VGA_R_reg[7]_i_68_n_6\,
      O => \VGA_B[7]_i_15_n_0\
    );
\VGA_B[7]_i_16\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => zp_sum,
      I1 => sel0(1),
      I2 => \VGA_R_reg[7]_i_68_n_7\,
      O => \VGA_B[7]_i_16_n_0\
    );
\VGA_B[7]_i_17\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => sel0(1),
      I1 => zp_sum,
      I2 => \VGA_R_reg[7]_i_121_n_4\,
      O => \VGA_B[7]_i_17_n_0\
    );
\VGA_B[7]_i_18\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \^p_1_in\(1),
      O => \VGA_B[7]_i_18_n_0\
    );
\VGA_B[7]_i_19\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => zp_sum,
      I1 => \VGA_R_reg[7]_i_33_n_0\,
      I2 => \VGA_R_reg[7]_i_86_n_5\,
      O => \VGA_B[7]_i_19_n_0\
    );
\VGA_B[7]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"222222A200000080"
    )
        port map (
      I0 => \VGA_R_reg[6]\,
      I1 => \VGA_R_reg[6]_0\,
      I2 => \VGA_R[7]_i_27_n_0\,
      I3 => \VGA_R[7]_i_28_n_0\,
      I4 => \VGA_B[7]_i_5_n_0\,
      I5 => P(4),
      O => \VGA_B[7]_i_2_n_0\
    );
\VGA_B[7]_i_20\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"659A"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_33_n_0\,
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      I3 => \VGA_R_reg[7]_i_86_n_6\,
      O => \VGA_B[7]_i_20_n_0\
    );
\VGA_B[7]_i_21\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_33_n_0\,
      I1 => \VGA_R_reg[7]_i_86_n_7\,
      O => \VGA_B[7]_i_21_n_0\
    );
\VGA_B[7]_i_22\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6966"
    )
        port map (
      I0 => \^p_1_in\(1),
      I1 => \VGA_R_reg[7]_i_33_n_0\,
      I2 => timing_sel(1),
      I3 => timing_sel(0),
      O => \VGA_B[7]_i_22_n_0\
    );
\VGA_B[7]_i_23\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \VGA_B_reg[7]_i_28_n_7\,
      O => \VGA_B[7]_i_23_n_0\
    );
\VGA_B[7]_i_24\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => zp_sum,
      I1 => sel0(1),
      I2 => \VGA_R_reg[7]_i_121_n_5\,
      O => \VGA_B[7]_i_24_n_0\
    );
\VGA_B[7]_i_25\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"659A"
    )
        port map (
      I0 => sel0(1),
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      I3 => \VGA_R_reg[7]_i_121_n_6\,
      O => \VGA_B[7]_i_25_n_0\
    );
\VGA_B[7]_i_26\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => sel0(1),
      I1 => \VGA_R_reg[7]_i_121_n_7\,
      O => \VGA_B[7]_i_26_n_0\
    );
\VGA_B[7]_i_27\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"659A"
    )
        port map (
      I0 => sel0(1),
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      I3 => \VGA_B_reg[7]_i_28_n_7\,
      O => \VGA_B[7]_i_27_n_0\
    );
\VGA_B[7]_i_29\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_B_reg[7]_i_30_n_7\,
      I1 => sel0(3),
      O => \VGA_B[7]_i_29_n_0\
    );
\VGA_B[7]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000155555555"
    )
        port map (
      I0 => pattern_sel(1),
      I1 => \VGA_B_reg[7]_i_6_n_0\,
      I2 => \VGA_B_reg[7]\,
      I3 => \VGA_R[7]_i_35_n_0\,
      I4 => \VGA_R[7]_i_36_n_0\,
      I5 => \VGA_R[7]_i_37_n_0\,
      O => \VGA_B[7]_i_3_n_0\
    );
\VGA_B[7]_i_31\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_B_reg[7]_i_32_n_7\,
      I1 => sel0(4),
      O => \VGA_B[7]_i_31_n_0\
    );
\VGA_B[7]_i_33\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_450_n_7\,
      I1 => sel0(5),
      O => \VGA_B[7]_i_33_n_0\
    );
\VGA_B[7]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000FFAB000000AB"
    )
        port map (
      I0 => \VGA_R[7]_i_41_n_0\,
      I1 => \VGA_R[7]_i_42_n_0\,
      I2 => \VGA_R[7]_i_31_n_0\,
      I3 => pattern_sel(0),
      I4 => pattern_sel(1),
      I5 => FCNT(6),
      O => \VGA_B[7]_i_4_n_0\
    );
\VGA_B[7]_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FEFF"
    )
        port map (
      I0 => sel0(0),
      I1 => sel0(12),
      I2 => sel0(11),
      I3 => sel0(32),
      O => \VGA_B[7]_i_5_n_0\
    );
\VGA_B[7]_i_9\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_33_n_0\,
      I1 => \VGA_R_reg[7]_i_33_n_5\,
      O => \VGA_B[7]_i_9_n_0\
    );
\VGA_B_reg[7]_i_13\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_B_reg[7]_i_13_n_0\,
      CO(2) => \VGA_B_reg[7]_i_13_n_1\,
      CO(1) => \VGA_B_reg[7]_i_13_n_2\,
      CO(0) => \VGA_B_reg[7]_i_13_n_3\,
      CYINIT => sel0(1),
      DI(3) => \VGA_R_reg[7]_i_121_n_5\,
      DI(2) => \VGA_R_reg[7]_i_121_n_6\,
      DI(1) => sel0(1),
      DI(0) => \VGA_B[7]_i_23_n_0\,
      O(3 downto 0) => \NLW_VGA_B_reg[7]_i_13_O_UNCONNECTED\(3 downto 0),
      S(3) => \VGA_B[7]_i_24_n_0\,
      S(2) => \VGA_B[7]_i_25_n_0\,
      S(1) => \VGA_B[7]_i_26_n_0\,
      S(0) => \VGA_B[7]_i_27_n_0\
    );
\VGA_B_reg[7]_i_28\: unisim.vcomponents.CARRY4
     port map (
      CI => sel0(3),
      CO(3 downto 0) => \NLW_VGA_B_reg[7]_i_28_CO_UNCONNECTED\(3 downto 0),
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 1) => \NLW_VGA_B_reg[7]_i_28_O_UNCONNECTED\(3 downto 1),
      O(0) => \VGA_B_reg[7]_i_28_n_7\,
      S(3 downto 1) => B"000",
      S(0) => \VGA_B[7]_i_29_n_0\
    );
\VGA_B_reg[7]_i_30\: unisim.vcomponents.CARRY4
     port map (
      CI => sel0(4),
      CO(3 downto 0) => \NLW_VGA_B_reg[7]_i_30_CO_UNCONNECTED\(3 downto 0),
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 1) => \NLW_VGA_B_reg[7]_i_30_O_UNCONNECTED\(3 downto 1),
      O(0) => \VGA_B_reg[7]_i_30_n_7\,
      S(3 downto 1) => B"000",
      S(0) => \VGA_B[7]_i_31_n_0\
    );
\VGA_B_reg[7]_i_32\: unisim.vcomponents.CARRY4
     port map (
      CI => sel0(5),
      CO(3 downto 0) => \NLW_VGA_B_reg[7]_i_32_CO_UNCONNECTED\(3 downto 0),
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 1) => \NLW_VGA_B_reg[7]_i_32_O_UNCONNECTED\(3 downto 1),
      O(0) => \VGA_B_reg[7]_i_32_n_7\,
      S(3 downto 1) => B"000",
      S(0) => \VGA_B[7]_i_33_n_0\
    );
\VGA_B_reg[7]_i_6\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_B_reg[7]_i_8_n_0\,
      CO(3) => \VGA_B_reg[7]_i_6_n_0\,
      CO(2) => \VGA_B_reg[7]_i_6_n_1\,
      CO(1) => \VGA_B_reg[7]_i_6_n_2\,
      CO(0) => \VGA_B_reg[7]_i_6_n_3\,
      CYINIT => '0',
      DI(3) => \VGA_R_reg[7]_i_33_n_0\,
      DI(2) => \VGA_R_reg[7]_i_33_n_6\,
      DI(1) => \VGA_R_reg[7]_i_33_n_7\,
      DI(0) => \VGA_R_reg[7]_i_86_n_4\,
      O(3 downto 0) => \NLW_VGA_B_reg[7]_i_6_O_UNCONNECTED\(3 downto 0),
      S(3) => \VGA_B[7]_i_9_n_0\,
      S(2) => \VGA_B[7]_i_10_n_0\,
      S(1) => \VGA_B[7]_i_11_n_0\,
      S(0) => \VGA_B[7]_i_12_n_0\
    );
\VGA_B_reg[7]_i_7\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_B_reg[7]_i_13_n_0\,
      CO(3) => sel0(0),
      CO(2) => \VGA_B_reg[7]_i_7_n_1\,
      CO(1) => \VGA_B_reg[7]_i_7_n_2\,
      CO(0) => \VGA_B_reg[7]_i_7_n_3\,
      CYINIT => '0',
      DI(3) => sel0(1),
      DI(2) => \VGA_R_reg[7]_i_68_n_6\,
      DI(1) => \VGA_R_reg[7]_i_68_n_7\,
      DI(0) => \VGA_R_reg[7]_i_121_n_4\,
      O(3 downto 0) => \NLW_VGA_B_reg[7]_i_7_O_UNCONNECTED\(3 downto 0),
      S(3) => \VGA_B[7]_i_14_n_0\,
      S(2) => \VGA_B[7]_i_15_n_0\,
      S(1) => \VGA_B[7]_i_16_n_0\,
      S(0) => \VGA_B[7]_i_17_n_0\
    );
\VGA_B_reg[7]_i_8\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_B_reg[7]_i_8_n_0\,
      CO(2) => \VGA_B_reg[7]_i_8_n_1\,
      CO(1) => \VGA_B_reg[7]_i_8_n_2\,
      CO(0) => \VGA_B_reg[7]_i_8_n_3\,
      CYINIT => \VGA_R_reg[7]_i_33_n_0\,
      DI(3) => \VGA_R_reg[7]_i_86_n_5\,
      DI(2) => \VGA_R_reg[7]_i_86_n_6\,
      DI(1) => \VGA_R_reg[7]_i_33_n_0\,
      DI(0) => \VGA_B[7]_i_18_n_0\,
      O(3 downto 0) => \NLW_VGA_B_reg[7]_i_8_O_UNCONNECTED\(3 downto 0),
      S(3) => \VGA_B[7]_i_19_n_0\,
      S(2) => \VGA_B[7]_i_20_n_0\,
      S(1) => \VGA_B[7]_i_21_n_0\,
      S(0) => \VGA_B[7]_i_22_n_0\
    );
VGA_DE_i_1: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0080"
    )
        port map (
      I0 => disp_enable10_in,
      I1 => disp_enable1,
      I2 => disp_enable0,
      I3 => RST,
      O => RST_0
    );
\VGA_G[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BABBBABBBABBAAAA"
    )
        port map (
      I0 => \VGA_B_reg[0]\,
      I1 => pattern_sel(3),
      I2 => \VGA_G[7]_i_4_n_0\,
      I3 => \VGA_R[0]_i_3_n_0\,
      I4 => \VGA_R[0]_i_4_n_0\,
      I5 => \VGA_G[7]_i_3_n_0\,
      O => \pattern_sel[3]\(0)
    );
\VGA_G[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BABBBABBBABBAAAA"
    )
        port map (
      I0 => \VGA_B_reg[1]\,
      I1 => pattern_sel(3),
      I2 => \VGA_G[7]_i_4_n_0\,
      I3 => \VGA_R[1]_i_3_n_0\,
      I4 => \VGA_R[1]_i_4_n_0\,
      I5 => \VGA_G[7]_i_3_n_0\,
      O => \pattern_sel[3]\(1)
    );
\VGA_G[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BABBBABBBABBAAAA"
    )
        port map (
      I0 => \VGA_B_reg[2]\,
      I1 => pattern_sel(3),
      I2 => \VGA_G[7]_i_4_n_0\,
      I3 => \VGA_R[2]_i_3_n_0\,
      I4 => \VGA_R[2]_i_4_n_0\,
      I5 => \VGA_G[7]_i_3_n_0\,
      O => \pattern_sel[3]\(2)
    );
\VGA_G[3]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BABBBABBBABBAAAA"
    )
        port map (
      I0 => \VGA_R[3]_i_2_n_0\,
      I1 => pattern_sel(3),
      I2 => \VGA_G[7]_i_4_n_0\,
      I3 => \VGA_R[3]_i_3_n_0\,
      I4 => \VGA_R[3]_i_4_n_0\,
      I5 => \VGA_G[7]_i_3_n_0\,
      O => \pattern_sel[3]\(3)
    );
\VGA_G[4]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BABBBABBBABBAAAA"
    )
        port map (
      I0 => \VGA_R[4]_i_2_n_0\,
      I1 => pattern_sel(3),
      I2 => \VGA_G[7]_i_4_n_0\,
      I3 => \VGA_R[4]_i_3_n_0\,
      I4 => \VGA_R[4]_i_4_n_0\,
      I5 => \VGA_G[7]_i_3_n_0\,
      O => \pattern_sel[3]\(4)
    );
\VGA_G[5]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BABBBABBBABBAAAA"
    )
        port map (
      I0 => \VGA_R[5]_i_2_n_0\,
      I1 => pattern_sel(3),
      I2 => \VGA_G[7]_i_4_n_0\,
      I3 => \VGA_R[5]_i_3_n_0\,
      I4 => \VGA_R[5]_i_4_n_0\,
      I5 => \VGA_G[7]_i_3_n_0\,
      O => \pattern_sel[3]\(5)
    );
\VGA_G[6]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BBB88888BBB8BBB8"
    )
        port map (
      I0 => \VGA_G[6]_i_2_n_0\,
      I1 => pattern_sel(3),
      I2 => \VGA_G[7]_i_3_n_0\,
      I3 => \VGA_R[6]_i_3_n_0\,
      I4 => \VGA_G[7]_i_4_n_0\,
      I5 => \VGA_R[6]_i_4_n_0\,
      O => \pattern_sel[3]\(6)
    );
\VGA_G[6]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"222222A200000080"
    )
        port map (
      I0 => \VGA_R_reg[6]\,
      I1 => \VGA_R_reg[6]_0\,
      I2 => \VGA_R[7]_i_27_n_0\,
      I3 => \VGA_R[7]_i_28_n_0\,
      I4 => \VGA_G[7]_i_5_n_0\,
      I5 => P(3),
      O => \VGA_G[6]_i_2_n_0\
    );
\VGA_G[7]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BBB88888BBB8BBB8"
    )
        port map (
      I0 => \VGA_G[7]_i_2_n_0\,
      I1 => pattern_sel(3),
      I2 => \VGA_G[7]_i_3_n_0\,
      I3 => \VGA_R[7]_i_7_n_0\,
      I4 => \VGA_G[7]_i_4_n_0\,
      I5 => \VGA_R[7]_i_9_n_0\,
      O => \pattern_sel[3]\(7)
    );
\VGA_G[7]_i_10\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_94_n_0\,
      I1 => zp_sum,
      I2 => \VGA_R_reg[7]_i_94_n_6\,
      O => \VGA_G[7]_i_10_n_0\
    );
\VGA_G[7]_i_11\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => zp_sum,
      I1 => \VGA_R_reg[7]_i_94_n_0\,
      I2 => \VGA_R_reg[7]_i_94_n_7\,
      O => \VGA_G[7]_i_11_n_0\
    );
\VGA_G[7]_i_12\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_94_n_0\,
      I1 => zp_sum,
      I2 => \VGA_G_reg[7]_i_8_n_4\,
      O => \VGA_G[7]_i_12_n_0\
    );
\VGA_G[7]_i_13\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => sel0(3),
      I1 => \VGA_R_reg[7]_i_75_n_5\,
      O => \VGA_G[7]_i_13_n_0\
    );
\VGA_G[7]_i_14\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => sel0(3),
      I1 => zp_sum,
      I2 => \VGA_R_reg[7]_i_75_n_6\,
      O => \VGA_G[7]_i_14_n_0\
    );
\VGA_G[7]_i_15\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => zp_sum,
      I1 => sel0(3),
      I2 => \VGA_R_reg[7]_i_75_n_7\,
      O => \VGA_G[7]_i_15_n_0\
    );
\VGA_G[7]_i_16\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => sel0(3),
      I1 => zp_sum,
      I2 => \VGA_R_reg[7]_i_157_n_4\,
      O => \VGA_G[7]_i_16_n_0\
    );
\VGA_G[7]_i_17\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \^p_1_in\(4),
      O => \VGA_G[7]_i_17_n_0\
    );
\VGA_G[7]_i_18\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => zp_sum,
      I1 => \VGA_R_reg[7]_i_95_n_0\,
      I2 => \VGA_R_reg[7]_i_211_n_5\,
      O => \VGA_G[7]_i_18_n_0\
    );
\VGA_G[7]_i_19\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"659A"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_95_n_0\,
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      I3 => \VGA_R_reg[7]_i_211_n_6\,
      O => \VGA_G[7]_i_19_n_0\
    );
\VGA_G[7]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"222222A200000080"
    )
        port map (
      I0 => \VGA_R_reg[6]\,
      I1 => \VGA_R_reg[6]_0\,
      I2 => \VGA_R[7]_i_27_n_0\,
      I3 => \VGA_R[7]_i_28_n_0\,
      I4 => \VGA_G[7]_i_5_n_0\,
      I5 => P(4),
      O => \VGA_G[7]_i_2_n_0\
    );
\VGA_G[7]_i_20\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_95_n_0\,
      I1 => \VGA_R_reg[7]_i_211_n_7\,
      O => \VGA_G[7]_i_20_n_0\
    );
\VGA_G[7]_i_21\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6966"
    )
        port map (
      I0 => \^p_1_in\(4),
      I1 => \VGA_R_reg[7]_i_95_n_0\,
      I2 => timing_sel(1),
      I3 => timing_sel(0),
      O => \VGA_G[7]_i_21_n_0\
    );
\VGA_G[7]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000155555555"
    )
        port map (
      I0 => pattern_sel(1),
      I1 => \VGA_G_reg[7]_i_6_n_0\,
      I2 => \VGA_B_reg[7]\,
      I3 => \VGA_R[7]_i_35_n_0\,
      I4 => \VGA_R[7]_i_36_n_0\,
      I5 => \VGA_R[7]_i_37_n_0\,
      O => \VGA_G[7]_i_3_n_0\
    );
\VGA_G[7]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000FFAB000000AB"
    )
        port map (
      I0 => \VGA_R[7]_i_41_n_0\,
      I1 => \VGA_R[7]_i_42_n_0\,
      I2 => \VGA_R[7]_i_31_n_0\,
      I3 => pattern_sel(0),
      I4 => pattern_sel(1),
      I5 => FCNT(5),
      O => \VGA_G[7]_i_4_n_0\
    );
\VGA_G[7]_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FEFF"
    )
        port map (
      I0 => sel0(2),
      I1 => sel0(12),
      I2 => sel0(11),
      I3 => sel0(32),
      O => \VGA_G[7]_i_5_n_0\
    );
\VGA_G[7]_i_9\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_94_n_0\,
      I1 => \VGA_R_reg[7]_i_94_n_5\,
      O => \VGA_G[7]_i_9_n_0\
    );
\VGA_G_reg[7]_i_6\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_87_n_0\,
      CO(3) => \VGA_G_reg[7]_i_6_n_0\,
      CO(2) => \VGA_G_reg[7]_i_6_n_1\,
      CO(1) => \VGA_G_reg[7]_i_6_n_2\,
      CO(0) => \VGA_G_reg[7]_i_6_n_3\,
      CYINIT => '0',
      DI(3) => \VGA_R_reg[7]_i_94_n_0\,
      DI(2) => \VGA_R_reg[7]_i_94_n_6\,
      DI(1) => \VGA_R_reg[7]_i_94_n_7\,
      DI(0) => \VGA_G_reg[7]_i_8_n_4\,
      O(3) => \NLW_VGA_G_reg[7]_i_6_O_UNCONNECTED\(3),
      O(2) => \VGA_G_reg[7]_i_6_n_5\,
      O(1) => \VGA_G_reg[7]_i_6_n_6\,
      O(0) => \VGA_G_reg[7]_i_6_n_7\,
      S(3) => \VGA_G[7]_i_9_n_0\,
      S(2) => \VGA_G[7]_i_10_n_0\,
      S(1) => \VGA_G[7]_i_11_n_0\,
      S(0) => \VGA_G[7]_i_12_n_0\
    );
\VGA_G_reg[7]_i_7\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_122_n_0\,
      CO(3) => sel0(2),
      CO(2) => \VGA_G_reg[7]_i_7_n_1\,
      CO(1) => \VGA_G_reg[7]_i_7_n_2\,
      CO(0) => \VGA_G_reg[7]_i_7_n_3\,
      CYINIT => '0',
      DI(3) => sel0(3),
      DI(2) => \VGA_R_reg[7]_i_75_n_6\,
      DI(1) => \VGA_R_reg[7]_i_75_n_7\,
      DI(0) => \VGA_R_reg[7]_i_157_n_4\,
      O(3) => \NLW_VGA_G_reg[7]_i_7_O_UNCONNECTED\(3),
      O(2) => \VGA_G_reg[7]_i_7_n_5\,
      O(1) => \VGA_G_reg[7]_i_7_n_6\,
      O(0) => \VGA_G_reg[7]_i_7_n_7\,
      S(3) => \VGA_G[7]_i_13_n_0\,
      S(2) => \VGA_G[7]_i_14_n_0\,
      S(1) => \VGA_G[7]_i_15_n_0\,
      S(0) => \VGA_G[7]_i_16_n_0\
    );
\VGA_G_reg[7]_i_8\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_G_reg[7]_i_8_n_0\,
      CO(2) => \VGA_G_reg[7]_i_8_n_1\,
      CO(1) => \VGA_G_reg[7]_i_8_n_2\,
      CO(0) => \VGA_G_reg[7]_i_8_n_3\,
      CYINIT => \VGA_R_reg[7]_i_95_n_0\,
      DI(3) => \VGA_R_reg[7]_i_211_n_5\,
      DI(2) => \VGA_R_reg[7]_i_211_n_6\,
      DI(1) => \VGA_R_reg[7]_i_95_n_0\,
      DI(0) => \VGA_G[7]_i_17_n_0\,
      O(3) => \VGA_G_reg[7]_i_8_n_4\,
      O(2) => \VGA_G_reg[7]_i_8_n_5\,
      O(1) => \VGA_G_reg[7]_i_8_n_6\,
      O(0) => \VGA_G_reg[7]_i_8_n_7\,
      S(3) => \VGA_G[7]_i_18_n_0\,
      S(2) => \VGA_G[7]_i_19_n_0\,
      S(1) => \VGA_G[7]_i_20_n_0\,
      S(0) => \VGA_G[7]_i_21_n_0\
    );
VGA_HS_i_1: unisim.vcomponents.LUT5
    generic map(
      INIT => X"66576654"
    )
        port map (
      I0 => VGA_HS_i_2_n_0,
      I1 => RST,
      I2 => VGA_HS0,
      I3 => VGA_HS1,
      I4 => \^vga_hs\,
      O => VGA_HS_i_1_n_0
    );
VGA_HS_i_10: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000065"
    )
        port map (
      I0 => HCNT(6),
      I1 => timing_sel(0),
      I2 => timing_sel(1),
      I3 => HCNT(8),
      I4 => HCNT(7),
      O => VGA_HS_i_10_n_0
    );
VGA_HS_i_11: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00202202"
    )
        port map (
      I0 => HCNT(3),
      I1 => HCNT(4),
      I2 => timing_sel(1),
      I3 => timing_sel(0),
      I4 => HCNT(5),
      O => VGA_HS_i_11_n_0
    );
VGA_HS_i_12: unisim.vcomponents.LUT5
    generic map(
      INIT => X"88080080"
    )
        port map (
      I0 => HCNT(0),
      I1 => HCNT(2),
      I2 => timing_sel(1),
      I3 => timing_sel(0),
      I4 => HCNT(1),
      O => VGA_HS_i_12_n_0
    );
VGA_HS_i_2: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => timing_sel(1),
      I1 => timing_sel(0),
      O => VGA_HS_i_2_n_0
    );
VGA_HS_i_5: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => HCNT(9),
      I1 => HCNT(10),
      O => VGA_HS_i_5_n_0
    );
VGA_HS_i_6: unisim.vcomponents.LUT5
    generic map(
      INIT => X"01002022"
    )
        port map (
      I0 => HCNT(6),
      I1 => HCNT(8),
      I2 => timing_sel(0),
      I3 => timing_sel(1),
      I4 => HCNT(7),
      O => VGA_HS_i_6_n_0
    );
VGA_HS_i_7: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00048220"
    )
        port map (
      I0 => HCNT(3),
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      I3 => HCNT(5),
      I4 => HCNT(4),
      O => VGA_HS_i_7_n_0
    );
VGA_HS_i_8: unisim.vcomponents.LUT5
    generic map(
      INIT => X"82002800"
    )
        port map (
      I0 => HCNT(0),
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      I3 => HCNT(2),
      I4 => HCNT(1),
      O => VGA_HS_i_8_n_0
    );
VGA_HS_i_9: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => HCNT(9),
      I1 => HCNT(10),
      O => VGA_HS_i_9_n_0
    );
VGA_HS_reg: unisim.vcomponents.FDRE
     port map (
      C => \^pck\,
      CE => '1',
      D => VGA_HS_i_1_n_0,
      Q => \^vga_hs\,
      R => '0'
    );
VGA_HS_reg_i_3: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => VGA_HS0,
      CO(2) => VGA_HS_reg_i_3_n_1,
      CO(1) => VGA_HS_reg_i_3_n_2,
      CO(0) => VGA_HS_reg_i_3_n_3,
      CYINIT => '1',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => NLW_VGA_HS_reg_i_3_O_UNCONNECTED(3 downto 0),
      S(3) => VGA_HS_i_5_n_0,
      S(2) => VGA_HS_i_6_n_0,
      S(1) => VGA_HS_i_7_n_0,
      S(0) => VGA_HS_i_8_n_0
    );
VGA_HS_reg_i_4: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => VGA_HS1,
      CO(2) => VGA_HS_reg_i_4_n_1,
      CO(1) => VGA_HS_reg_i_4_n_2,
      CO(0) => VGA_HS_reg_i_4_n_3,
      CYINIT => '1',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => NLW_VGA_HS_reg_i_4_O_UNCONNECTED(3 downto 0),
      S(3) => VGA_HS_i_9_n_0,
      S(2) => VGA_HS_i_10_n_0,
      S(1) => VGA_HS_i_11_n_0,
      S(0) => VGA_HS_i_12_n_0
    );
\VGA_R[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"ABBBABBBABBBAAAA"
    )
        port map (
      I0 => \VGA_B_reg[0]\,
      I1 => pattern_sel(3),
      I2 => \VGA_R[0]_i_3_n_0\,
      I3 => \VGA_R[7]_i_10_n_0\,
      I4 => \VGA_R[7]_i_8_n_0\,
      I5 => \VGA_R[0]_i_4_n_0\,
      O => \pattern_sel[3]_0\(0)
    );
\VGA_R[0]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2AAA22222AAAAAAA"
    )
        port map (
      I0 => pattern_sel(2),
      I1 => pattern_sel(1),
      I2 => \VGA_R_reg[7]_i_38_n_3\,
      I3 => pattern_b11_in,
      I4 => pattern_sel(0),
      I5 => data6(0),
      O => \VGA_R[0]_i_3_n_0\
    );
\VGA_R[0]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFAFEEEEAAAAAAAA"
    )
        port map (
      I0 => pattern_sel(2),
      I1 => data2(0),
      I2 => \VGA_R[7]_i_31_n_0\,
      I3 => \VGA_R[7]_i_32_n_0\,
      I4 => pattern_sel(0),
      I5 => pattern_sel(1),
      O => \VGA_R[0]_i_4_n_0\
    );
\VGA_R[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"ABBBABBBABBBAAAA"
    )
        port map (
      I0 => \VGA_B_reg[1]\,
      I1 => pattern_sel(3),
      I2 => \VGA_R[1]_i_3_n_0\,
      I3 => \VGA_R[7]_i_10_n_0\,
      I4 => \VGA_R[7]_i_8_n_0\,
      I5 => \VGA_R[1]_i_4_n_0\,
      O => \pattern_sel[3]_0\(1)
    );
\VGA_R[1]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2AAA22222AAAAAAA"
    )
        port map (
      I0 => pattern_sel(2),
      I1 => pattern_sel(1),
      I2 => \VGA_R_reg[7]_i_38_n_3\,
      I3 => pattern_b11_in,
      I4 => pattern_sel(0),
      I5 => data6(1),
      O => \VGA_R[1]_i_3_n_0\
    );
\VGA_R[1]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFAFEEEEAAAAAAAA"
    )
        port map (
      I0 => pattern_sel(2),
      I1 => data2(1),
      I2 => \VGA_R[7]_i_31_n_0\,
      I3 => \VGA_R[7]_i_32_n_0\,
      I4 => pattern_sel(0),
      I5 => pattern_sel(1),
      O => \VGA_R[1]_i_4_n_0\
    );
\VGA_R[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"ABBBABBBABBBAAAA"
    )
        port map (
      I0 => \VGA_B_reg[2]\,
      I1 => pattern_sel(3),
      I2 => \VGA_R[2]_i_3_n_0\,
      I3 => \VGA_R[7]_i_10_n_0\,
      I4 => \VGA_R[7]_i_8_n_0\,
      I5 => \VGA_R[2]_i_4_n_0\,
      O => \pattern_sel[3]_0\(2)
    );
\VGA_R[2]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2AAA22222AAAAAAA"
    )
        port map (
      I0 => pattern_sel(2),
      I1 => pattern_sel(1),
      I2 => \VGA_R_reg[7]_i_38_n_3\,
      I3 => pattern_b11_in,
      I4 => pattern_sel(0),
      I5 => data6(2),
      O => \VGA_R[2]_i_3_n_0\
    );
\VGA_R[2]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFAFEEEEAAAAAAAA"
    )
        port map (
      I0 => pattern_sel(2),
      I1 => data2(2),
      I2 => \VGA_R[7]_i_31_n_0\,
      I3 => \VGA_R[7]_i_32_n_0\,
      I4 => pattern_sel(0),
      I5 => pattern_sel(1),
      O => \VGA_R[2]_i_4_n_0\
    );
\VGA_R[3]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"ABBBABBBABBBAAAA"
    )
        port map (
      I0 => \VGA_R[3]_i_2_n_0\,
      I1 => pattern_sel(3),
      I2 => \VGA_R[3]_i_3_n_0\,
      I3 => \VGA_R[7]_i_10_n_0\,
      I4 => \VGA_R[7]_i_8_n_0\,
      I5 => \VGA_R[3]_i_4_n_0\,
      O => \pattern_sel[3]_0\(3)
    );
\VGA_R[3]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000008A00000080"
    )
        port map (
      I0 => pattern_sel(3),
      I1 => P(0),
      I2 => pattern_sel(0),
      I3 => pattern_sel(1),
      I4 => pattern_sel(2),
      I5 => \VGA_R[3]_i_5_n_0\,
      O => \VGA_R[3]_i_2_n_0\
    );
\VGA_R[3]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2AAA22222AAAAAAA"
    )
        port map (
      I0 => pattern_sel(2),
      I1 => pattern_sel(1),
      I2 => \VGA_R_reg[7]_i_38_n_3\,
      I3 => pattern_b11_in,
      I4 => pattern_sel(0),
      I5 => data6(3),
      O => \VGA_R[3]_i_3_n_0\
    );
\VGA_R[3]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFAFEEEEAAAAAAAA"
    )
        port map (
      I0 => pattern_sel(2),
      I1 => data2(3),
      I2 => \VGA_R[7]_i_31_n_0\,
      I3 => \VGA_R[7]_i_32_n_0\,
      I4 => pattern_sel(0),
      I5 => pattern_sel(1),
      O => \VGA_R[3]_i_4_n_0\
    );
\VGA_R[3]_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000010"
    )
        port map (
      I0 => \VGA_R_reg[5]_i_8_n_2\,
      I1 => sel0(32),
      I2 => \VGA_R_reg[5]_i_13_n_2\,
      I3 => \VGA_R_reg[4]_i_5_n_2\,
      I4 => \VGA_R_reg[5]_i_11_n_2\,
      O => \VGA_R[3]_i_5_n_0\
    );
\VGA_R[4]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"ABBBABBBABBBAAAA"
    )
        port map (
      I0 => \VGA_R[4]_i_2_n_0\,
      I1 => pattern_sel(3),
      I2 => \VGA_R[4]_i_3_n_0\,
      I3 => \VGA_R[7]_i_10_n_0\,
      I4 => \VGA_R[7]_i_8_n_0\,
      I5 => \VGA_R[4]_i_4_n_0\,
      O => \pattern_sel[3]_0\(4)
    );
\VGA_R[4]_i_10\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^p_1_in\(10),
      O => \VGA_R[4]_i_10_n_0\
    );
\VGA_R[4]_i_11\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"41"
    )
        port map (
      I0 => \^p_1_in\(9),
      I1 => \VGA_R_reg[4]_i_5_0\,
      I2 => \^p_1_in\(8),
      O => \VGA_R[4]_i_11_n_0\
    );
\VGA_R[4]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"080808080808A808"
    )
        port map (
      I0 => \VGA_R_reg[5]\,
      I1 => P(1),
      I2 => \VGA_R_reg[6]_0\,
      I3 => \VGA_R_reg[4]_i_5_n_2\,
      I4 => sel0(32),
      I5 => \VGA_R_reg[5]_i_8_n_2\,
      O => \VGA_R[4]_i_2_n_0\
    );
\VGA_R[4]_i_22\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"002FFFFF"
    )
        port map (
      I0 => timing_sel(0),
      I1 => timing_sel(1),
      I2 => \VGA_R_reg[4]_i_5_0\,
      I3 => \^p_1_in\(6),
      I4 => \^p_1_in\(7),
      O => \VGA_R[4]_i_22_n_0\
    );
\VGA_R[4]_i_23\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"5104515D"
    )
        port map (
      I0 => \^p_1_in\(5),
      I1 => timing_sel(0),
      I2 => timing_sel(1),
      I3 => \VGA_R_reg[4]_i_5_0\,
      I4 => \^p_1_in\(4),
      O => \VGA_R[4]_i_23_n_0\
    );
\VGA_R[4]_i_24\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0000AAEF"
    )
        port map (
      I0 => \VGA_R_reg[4]_i_5_0\,
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      I3 => \^p_1_in\(2),
      I4 => \^p_1_in\(3),
      O => \VGA_R[4]_i_24_n_0\
    );
\VGA_R[4]_i_25\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"33332202"
    )
        port map (
      I0 => HCNT(0),
      I1 => \^p_1_in\(1),
      I2 => timing_sel(0),
      I3 => timing_sel(1),
      I4 => \VGA_R_reg[4]_i_5_0\,
      O => \VGA_R[4]_i_25_n_0\
    );
\VGA_R[4]_i_26\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"08AAA200"
    )
        port map (
      I0 => \^p_1_in\(7),
      I1 => timing_sel(0),
      I2 => timing_sel(1),
      I3 => \VGA_R_reg[4]_i_5_0\,
      I4 => \^p_1_in\(6),
      O => \VGA_R[4]_i_26_n_0\
    );
\VGA_R[4]_i_27\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"12118488"
    )
        port map (
      I0 => \^p_1_in\(5),
      I1 => \VGA_R_reg[4]_i_5_0\,
      I2 => timing_sel(1),
      I3 => timing_sel(0),
      I4 => \^p_1_in\(4),
      O => \VGA_R[4]_i_27_n_0\
    );
\VGA_R[4]_i_28\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0051AA04"
    )
        port map (
      I0 => \^p_1_in\(3),
      I1 => timing_sel(0),
      I2 => timing_sel(1),
      I3 => \VGA_R_reg[4]_i_5_0\,
      I4 => \^p_1_in\(2),
      O => \VGA_R[4]_i_28_n_0\
    );
\VGA_R[4]_i_29\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AA040051"
    )
        port map (
      I0 => \^p_1_in\(1),
      I1 => timing_sel(0),
      I2 => timing_sel(1),
      I3 => \VGA_R_reg[4]_i_5_0\,
      I4 => HCNT(0),
      O => \VGA_R[4]_i_29_n_0\
    );
\VGA_R[4]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2AAA22222AAAAAAA"
    )
        port map (
      I0 => pattern_sel(2),
      I1 => pattern_sel(1),
      I2 => \VGA_R_reg[7]_i_38_n_3\,
      I3 => pattern_b11_in,
      I4 => pattern_sel(0),
      I5 => data6(4),
      O => \VGA_R[4]_i_3_n_0\
    );
\VGA_R[4]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFAFEEEEAAAAAAAA"
    )
        port map (
      I0 => pattern_sel(2),
      I1 => data2(4),
      I2 => \VGA_R[7]_i_31_n_0\,
      I3 => \VGA_R[7]_i_32_n_0\,
      I4 => pattern_sel(0),
      I5 => pattern_sel(1),
      O => \VGA_R[4]_i_4_n_0\
    );
\VGA_R[4]_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"04"
    )
        port map (
      I0 => \^p_1_in\(9),
      I1 => \VGA_R_reg[4]_i_5_0\,
      I2 => \^p_1_in\(8),
      O => \VGA_R[4]_i_9_n_0\
    );
\VGA_R[5]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"ABBBABBBABBBAAAA"
    )
        port map (
      I0 => \VGA_R[5]_i_2_n_0\,
      I1 => pattern_sel(3),
      I2 => \VGA_R[5]_i_3_n_0\,
      I3 => \VGA_R[7]_i_10_n_0\,
      I4 => \VGA_R[7]_i_8_n_0\,
      I5 => \VGA_R[5]_i_4_n_0\,
      O => \pattern_sel[3]_0\(5)
    );
\VGA_R[5]_i_15\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^a\(9),
      I1 => \^a\(8),
      O => \VGA_R[5]_i_15_n_0\
    );
\VGA_R[5]_i_16\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^a\(10),
      O => \VGA_R[5]_i_16_n_0\
    );
\VGA_R[5]_i_17\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"4"
    )
        port map (
      I0 => \^a\(9),
      I1 => \^a\(8),
      O => \VGA_R[5]_i_17_n_0\
    );
\VGA_R[5]_i_19\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^p_1_in\(10),
      O => \VGA_R[5]_i_19_n_0\
    );
\VGA_R[5]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"080808080808A808"
    )
        port map (
      I0 => \VGA_R_reg[5]\,
      I1 => P(2),
      I2 => \VGA_R_reg[6]_0\,
      I3 => \VGA_R[5]_i_6_n_0\,
      I4 => sel0(32),
      I5 => \VGA_R_reg[5]_i_8_n_2\,
      O => \VGA_R[5]_i_2_n_0\
    );
\VGA_R[5]_i_20\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^p_1_in\(8),
      I1 => \^p_1_in\(9),
      O => \VGA_R[5]_i_20_n_0\
    );
\VGA_R[5]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2AAA22222AAAAAAA"
    )
        port map (
      I0 => pattern_sel(2),
      I1 => pattern_sel(1),
      I2 => \VGA_R_reg[7]_i_38_n_3\,
      I3 => pattern_b11_in,
      I4 => pattern_sel(0),
      I5 => data6(5),
      O => \VGA_R[5]_i_3_n_0\
    );
\VGA_R[5]_i_32\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"002B"
    )
        port map (
      I0 => \VGA_R_reg[5]_i_31_0\(0),
      I1 => \VGA_R_reg[5]_i_11_0\(0),
      I2 => \^p_1_in\(8),
      I3 => \^p_1_in\(9),
      O => \VGA_R[5]_i_32_n_0\
    );
\VGA_R[5]_i_33\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^p_1_in\(10),
      O => \VGA_R[5]_i_33_n_0\
    );
\VGA_R[5]_i_34\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"4118"
    )
        port map (
      I0 => \^p_1_in\(9),
      I1 => \VGA_R_reg[5]_i_31_0\(0),
      I2 => \VGA_R_reg[5]_i_11_0\(0),
      I3 => \^p_1_in\(8),
      O => \VGA_R[5]_i_34_n_0\
    );
\VGA_R[5]_i_36\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \VGA_R_reg[4]_i_5_0\,
      I1 => \^p_1_in\(10),
      O => \VGA_R[5]_i_36_n_0\
    );
\VGA_R[5]_i_37\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^p_1_in\(9),
      I1 => \VGA_R_reg[4]_i_5_0\,
      O => \VGA_R[5]_i_37_n_0\
    );
\VGA_R[5]_i_38\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^p_1_in\(10),
      I1 => \VGA_R_reg[4]_i_5_0\,
      O => \VGA_R[5]_i_38_n_0\
    );
\VGA_R[5]_i_39\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"14"
    )
        port map (
      I0 => \^p_1_in\(8),
      I1 => \VGA_R_reg[4]_i_5_0\,
      I2 => \^p_1_in\(9),
      O => \VGA_R[5]_i_39_n_0\
    );
\VGA_R[5]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFAFEEEEAAAAAAAA"
    )
        port map (
      I0 => pattern_sel(2),
      I1 => data2(5),
      I2 => \VGA_R[7]_i_31_n_0\,
      I3 => \VGA_R[7]_i_32_n_0\,
      I4 => pattern_sel(0),
      I5 => pattern_sel(1),
      O => \VGA_R[5]_i_4_n_0\
    );
\VGA_R[5]_i_41\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"71"
    )
        port map (
      I0 => \^p_1_in\(8),
      I1 => \^p_1_in\(9),
      I2 => \VGA_R_reg[4]_i_5_0\,
      O => \VGA_R[5]_i_41_n_0\
    );
\VGA_R[5]_i_42\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^p_1_in\(10),
      O => \VGA_R[5]_i_42_n_0\
    );
\VGA_R[5]_i_43\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"90"
    )
        port map (
      I0 => \VGA_R_reg[4]_i_5_0\,
      I1 => \^p_1_in\(9),
      I2 => \^p_1_in\(8),
      O => \VGA_R[5]_i_43_n_0\
    );
\VGA_R[5]_i_44\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"55550000FFFF5540"
    )
        port map (
      I0 => \^a\(7),
      I1 => \VGA_R_reg[5]_i_14_4\,
      I2 => \VGA_R_reg[5]_i_14_2\(0),
      I3 => \VGA_R_reg[5]_i_14_3\(0),
      I4 => \VGA_R_reg[4]_i_5_0\,
      I5 => \^a\(6),
      O => \VGA_R[5]_i_44_n_0\
    );
\VGA_R[5]_i_45\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"554000155555003F"
    )
        port map (
      I0 => \^a\(5),
      I1 => \VGA_R_reg[5]_i_14_4\,
      I2 => \VGA_R_reg[5]_i_14_2\(0),
      I3 => \VGA_R_reg[5]_i_14_3\(0),
      I4 => \VGA_R_reg[4]_i_5_0\,
      I5 => \^a\(4),
      O => \VGA_R[5]_i_45_n_0\
    );
\VGA_R[5]_i_46\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"01114333"
    )
        port map (
      I0 => \^a\(3),
      I1 => \VGA_R_reg[5]_i_14_3\(0),
      I2 => \VGA_R_reg[5]_i_14_4\,
      I3 => \VGA_R_reg[5]_i_14_2\(0),
      I4 => \^a\(2),
      O => \VGA_R[5]_i_46_n_0\
    );
\VGA_R[5]_i_47\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"45441011CFCC5555"
    )
        port map (
      I0 => \^a\(1),
      I1 => \VGA_R_reg[5]_i_14_0\(0),
      I2 => \VGA_R_reg[4]_i_5_0\,
      I3 => \VGA_R_reg[5]_i_14_1\(0),
      I4 => \VGA_R_reg[5]_i_14_2\(0),
      I5 => \^a\(0),
      O => \VGA_R[5]_i_47_n_0\
    );
\VGA_R[5]_i_48\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A5A4A4A400010101"
    )
        port map (
      I0 => \^a\(7),
      I1 => \VGA_R_reg[5]_i_14_3\(0),
      I2 => \VGA_R_reg[4]_i_5_0\,
      I3 => \VGA_R_reg[5]_i_14_4\,
      I4 => \VGA_R_reg[5]_i_14_2\(0),
      I5 => \^a\(6),
      O => \VGA_R[5]_i_48_n_0\
    );
\VGA_R[5]_i_49\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0006060699909090"
    )
        port map (
      I0 => \VGA_R_reg[4]_i_5_0\,
      I1 => \^a\(5),
      I2 => \VGA_R_reg[5]_i_14_3\(0),
      I3 => \VGA_R_reg[5]_i_14_4\,
      I4 => \VGA_R_reg[5]_i_14_2\(0),
      I5 => \^a\(4),
      O => \VGA_R[5]_i_49_n_0\
    );
\VGA_R[5]_i_50\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"42221444"
    )
        port map (
      I0 => \^a\(3),
      I1 => \VGA_R_reg[5]_i_14_3\(0),
      I2 => \VGA_R_reg[5]_i_14_4\,
      I3 => \VGA_R_reg[5]_i_14_2\(0),
      I4 => \^a\(2),
      O => \VGA_R[5]_i_50_n_0\
    );
\VGA_R[5]_i_51\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9099909006000606"
    )
        port map (
      I0 => \VGA_R_reg[5]_i_14_2\(0),
      I1 => \^a\(1),
      I2 => \VGA_R_reg[5]_i_14_0\(0),
      I3 => \VGA_R_reg[4]_i_5_0\,
      I4 => \VGA_R_reg[5]_i_14_1\(0),
      I5 => \^a\(0),
      O => \VGA_R[5]_i_51_n_0\
    );
\VGA_R[5]_i_52\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"4D"
    )
        port map (
      I0 => \^p_1_in\(7),
      I1 => \VGA_R_reg[4]_i_5_0\,
      I2 => \^p_1_in\(6),
      O => \VGA_R[5]_i_52_n_0\
    );
\VGA_R[5]_i_53\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"15115755"
    )
        port map (
      I0 => \^p_1_in\(5),
      I1 => \VGA_R_reg[4]_i_5_0\,
      I2 => timing_sel(1),
      I3 => timing_sel(0),
      I4 => \^p_1_in\(4),
      O => \VGA_R[5]_i_53_n_0\
    );
\VGA_R[5]_i_54\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"15"
    )
        port map (
      I0 => \^p_1_in\(3),
      I1 => \VGA_R_reg[4]_i_5_0\,
      I2 => \^p_1_in\(2),
      O => \VGA_R[5]_i_54_n_0\
    );
\VGA_R[5]_i_55\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0000FB51"
    )
        port map (
      I0 => \VGA_R_reg[4]_i_5_0\,
      I1 => timing_sel(0),
      I2 => timing_sel(1),
      I3 => HCNT(0),
      I4 => \^p_1_in\(1),
      O => \VGA_R[5]_i_55_n_0\
    );
\VGA_R[5]_i_56\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"82"
    )
        port map (
      I0 => \^p_1_in\(6),
      I1 => \VGA_R_reg[4]_i_5_0\,
      I2 => \^p_1_in\(7),
      O => \VGA_R[5]_i_56_n_0\
    );
\VGA_R[5]_i_57\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"42442822"
    )
        port map (
      I0 => \^p_1_in\(5),
      I1 => \VGA_R_reg[4]_i_5_0\,
      I2 => timing_sel(1),
      I3 => timing_sel(0),
      I4 => \^p_1_in\(4),
      O => \VGA_R[5]_i_57_n_0\
    );
\VGA_R[5]_i_58\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"42"
    )
        port map (
      I0 => \^p_1_in\(3),
      I1 => \VGA_R_reg[4]_i_5_0\,
      I2 => \^p_1_in\(2),
      O => \VGA_R[5]_i_58_n_0\
    );
\VGA_R[5]_i_59\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"22124444"
    )
        port map (
      I0 => \^p_1_in\(1),
      I1 => \VGA_R_reg[4]_i_5_0\,
      I2 => timing_sel(0),
      I3 => timing_sel(1),
      I4 => HCNT(0),
      O => \VGA_R[5]_i_59_n_0\
    );
\VGA_R[5]_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0001"
    )
        port map (
      I0 => \VGA_R_reg[5]_i_11_n_2\,
      I1 => \VGA_R_reg[4]_i_5_n_2\,
      I2 => \VGA_R_reg[5]_i_12_n_2\,
      I3 => \VGA_R_reg[5]_i_13_n_2\,
      O => \VGA_R[5]_i_6_n_0\
    );
\VGA_R[5]_i_70\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"40544050"
    )
        port map (
      I0 => \^p_1_in\(7),
      I1 => \VGA_R_reg[5]_i_31_3\(2),
      I2 => \VGA_R_reg[5]_i_31_0\(0),
      I3 => \^p_1_in\(6),
      I4 => \VGA_R_reg[5]_i_31_3\(1),
      O => \VGA_R[5]_i_70_n_0\
    );
\VGA_R[5]_i_71\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"1005511051177551"
    )
        port map (
      I0 => \^p_1_in\(5),
      I1 => \VGA_R_reg[7]_i_231_0\,
      I2 => \VGA_R_reg[5]_i_31_3\(1),
      I3 => \VGA_R_reg[5]_i_31_0\(0),
      I4 => \VGA_R_reg[5]_i_31_3\(2),
      I5 => \^p_1_in\(4),
      O => \VGA_R[5]_i_71_n_0\
    );
\VGA_R[5]_i_72\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"555440007DD55001"
    )
        port map (
      I0 => \^p_1_in\(3),
      I1 => \VGA_R_reg[5]_i_31_3\(0),
      I2 => \VGA_R_reg[5]_i_31_2\,
      I3 => \VGA_R_reg[7]_i_231_0\,
      I4 => \VGA_R_reg[5]_i_31_1\,
      I5 => \^p_1_in\(2),
      O => \VGA_R[5]_i_72_n_0\
    );
\VGA_R[5]_i_73\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"200000003BB22CCE"
    )
        port map (
      I0 => HCNT(0),
      I1 => \VGA_R_reg[5]_i_31_3\(0),
      I2 => \VGA_R_reg[5]_i_31_2\,
      I3 => \VGA_R_reg[7]_i_231_0\,
      I4 => \VGA_R_reg[5]_i_31_1\,
      I5 => \^p_1_in\(1),
      O => \VGA_R[5]_i_73_n_0\
    );
\VGA_R[5]_i_74\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0540A015"
    )
        port map (
      I0 => \^p_1_in\(7),
      I1 => \VGA_R_reg[5]_i_31_3\(1),
      I2 => \VGA_R_reg[5]_i_31_3\(2),
      I3 => \VGA_R_reg[5]_i_31_0\(0),
      I4 => \^p_1_in\(6),
      O => \VGA_R[5]_i_74_n_0\
    );
\VGA_R[5]_i_75\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"4124124124824824"
    )
        port map (
      I0 => \^p_1_in\(5),
      I1 => \VGA_R_reg[7]_i_231_0\,
      I2 => \VGA_R_reg[5]_i_31_0\(0),
      I3 => \VGA_R_reg[5]_i_31_3\(2),
      I4 => \VGA_R_reg[5]_i_31_3\(1),
      I5 => \^p_1_in\(4),
      O => \VGA_R[5]_i_75_n_0\
    );
\VGA_R[5]_i_76\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"08809005A1190990"
    )
        port map (
      I0 => \^p_1_in\(3),
      I1 => \VGA_R_reg[5]_i_31_1\,
      I2 => \VGA_R_reg[7]_i_231_0\,
      I3 => \VGA_R_reg[5]_i_31_2\,
      I4 => \VGA_R_reg[5]_i_31_3\(0),
      I5 => \^p_1_in\(2),
      O => \VGA_R[5]_i_76_n_0\
    );
\VGA_R[5]_i_77\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5226099004409005"
    )
        port map (
      I0 => \^p_1_in\(1),
      I1 => \VGA_R_reg[5]_i_31_1\,
      I2 => \VGA_R_reg[7]_i_231_0\,
      I3 => \VGA_R_reg[5]_i_31_2\,
      I4 => \VGA_R_reg[5]_i_31_3\(0),
      I5 => HCNT(0),
      O => \VGA_R[5]_i_77_n_0\
    );
\VGA_R[5]_i_80\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"40544044"
    )
        port map (
      I0 => \^p_1_in\(7),
      I1 => \VGA_R_reg[5]_i_35_0\(0),
      I2 => \VGA_R_reg[5]_i_35_1\(1),
      I3 => \^p_1_in\(6),
      I4 => \VGA_R_reg[5]_i_35_1\(0),
      O => \VGA_R[5]_i_80_n_0\
    );
\VGA_R[5]_i_81\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"002400B6"
    )
        port map (
      I0 => \VGA_R_reg[5]_i_35_0\(0),
      I1 => \VGA_R_reg[5]_i_35_1\(1),
      I2 => \VGA_R_reg[5]_i_35_1\(0),
      I3 => \^p_1_in\(5),
      I4 => \^p_1_in\(4),
      O => \VGA_R[5]_i_81_n_0\
    );
\VGA_R[5]_i_82\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"1051051050750750"
    )
        port map (
      I0 => \^p_1_in\(3),
      I1 => \VGA_R_reg[7]_i_231_0\,
      I2 => \VGA_R_reg[5]_i_35_1\(0),
      I3 => \VGA_R_reg[5]_i_35_1\(1),
      I4 => \VGA_R_reg[5]_i_35_0\(0),
      I5 => \^p_1_in\(2),
      O => \VGA_R[5]_i_82_n_0\
    );
\VGA_R[5]_i_83\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000097E91681"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_231_0\,
      I1 => \VGA_R_reg[5]_i_35_1\(0),
      I2 => \VGA_R_reg[5]_i_35_0\(0),
      I3 => \VGA_R_reg[5]_i_35_1\(1),
      I4 => HCNT(0),
      I5 => \^p_1_in\(1),
      O => \VGA_R[5]_i_83_n_0\
    );
\VGA_R[5]_i_84\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0540A015"
    )
        port map (
      I0 => \^p_1_in\(7),
      I1 => \VGA_R_reg[5]_i_35_1\(0),
      I2 => \VGA_R_reg[5]_i_35_1\(1),
      I3 => \VGA_R_reg[5]_i_35_0\(0),
      I4 => \^p_1_in\(6),
      O => \VGA_R[5]_i_84_n_0\
    );
\VGA_R[5]_i_85\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"41041861"
    )
        port map (
      I0 => \^p_1_in\(5),
      I1 => \VGA_R_reg[5]_i_35_0\(0),
      I2 => \VGA_R_reg[5]_i_35_1\(1),
      I3 => \VGA_R_reg[5]_i_35_1\(0),
      I4 => \^p_1_in\(4),
      O => \VGA_R[5]_i_85_n_0\
    );
\VGA_R[5]_i_86\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0410492492491041"
    )
        port map (
      I0 => \^p_1_in\(2),
      I1 => \VGA_R_reg[5]_i_35_0\(0),
      I2 => \VGA_R_reg[5]_i_35_1\(1),
      I3 => \VGA_R_reg[5]_i_35_1\(0),
      I4 => \VGA_R_reg[7]_i_231_0\,
      I5 => \^p_1_in\(3),
      O => \VGA_R[5]_i_86_n_0\
    );
\VGA_R[5]_i_87\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"1668811640011440"
    )
        port map (
      I0 => \^p_1_in\(1),
      I1 => \VGA_R_reg[7]_i_231_0\,
      I2 => \VGA_R_reg[5]_i_35_1\(0),
      I3 => \VGA_R_reg[5]_i_35_0\(0),
      I4 => \VGA_R_reg[5]_i_35_1\(1),
      I5 => HCNT(0),
      O => \VGA_R[5]_i_87_n_0\
    );
\VGA_R[5]_i_88\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00045DFF"
    )
        port map (
      I0 => \^p_1_in\(6),
      I1 => timing_sel(0),
      I2 => timing_sel(1),
      I3 => \VGA_R_reg[4]_i_5_0\,
      I4 => \^p_1_in\(7),
      O => \VGA_R[5]_i_88_n_0\
    );
\VGA_R[5]_i_89\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"15"
    )
        port map (
      I0 => \^p_1_in\(5),
      I1 => \VGA_R_reg[4]_i_5_0\,
      I2 => \^p_1_in\(4),
      O => \VGA_R[5]_i_89_n_0\
    );
\VGA_R[5]_i_90\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"11115055"
    )
        port map (
      I0 => \^p_1_in\(3),
      I1 => \^p_1_in\(2),
      I2 => timing_sel(1),
      I3 => timing_sel(0),
      I4 => \VGA_R_reg[4]_i_5_0\,
      O => \VGA_R[5]_i_90_n_0\
    );
\VGA_R[5]_i_91\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0000FB51"
    )
        port map (
      I0 => \VGA_R_reg[4]_i_5_0\,
      I1 => timing_sel(0),
      I2 => timing_sel(1),
      I3 => HCNT(0),
      I4 => \^p_1_in\(1),
      O => \VGA_R[5]_i_91_n_0\
    );
\VGA_R[5]_i_92\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"42442822"
    )
        port map (
      I0 => \^p_1_in\(7),
      I1 => \VGA_R_reg[4]_i_5_0\,
      I2 => timing_sel(1),
      I3 => timing_sel(0),
      I4 => \^p_1_in\(6),
      O => \VGA_R[5]_i_92_n_0\
    );
\VGA_R[5]_i_93\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"42"
    )
        port map (
      I0 => \^p_1_in\(5),
      I1 => \VGA_R_reg[4]_i_5_0\,
      I2 => \^p_1_in\(4),
      O => \VGA_R[5]_i_93_n_0\
    );
\VGA_R[5]_i_94\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0051AA04"
    )
        port map (
      I0 => \^p_1_in\(2),
      I1 => timing_sel(0),
      I2 => timing_sel(1),
      I3 => \VGA_R_reg[4]_i_5_0\,
      I4 => \^p_1_in\(3),
      O => \VGA_R[5]_i_94_n_0\
    );
\VGA_R[5]_i_95\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"22124444"
    )
        port map (
      I0 => \^p_1_in\(1),
      I1 => \VGA_R_reg[4]_i_5_0\,
      I2 => timing_sel(0),
      I3 => timing_sel(1),
      I4 => HCNT(0),
      O => \VGA_R[5]_i_95_n_0\
    );
\VGA_R[6]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8888BBB8BBB8BBB8"
    )
        port map (
      I0 => \VGA_R[6]_i_2_n_0\,
      I1 => pattern_sel(3),
      I2 => \VGA_R[6]_i_3_n_0\,
      I3 => \VGA_R[7]_i_8_n_0\,
      I4 => \VGA_R[6]_i_4_n_0\,
      I5 => \VGA_R[7]_i_10_n_0\,
      O => \pattern_sel[3]_0\(6)
    );
\VGA_R[6]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0A0A8A0A00008000"
    )
        port map (
      I0 => \VGA_R_reg[6]\,
      I1 => \VGA_R[7]_i_26_n_0\,
      I2 => \VGA_R_reg[6]_0\,
      I3 => \VGA_R[7]_i_27_n_0\,
      I4 => \VGA_R[7]_i_28_n_0\,
      I5 => P(3),
      O => \VGA_R[6]_i_2_n_0\
    );
\VGA_R[6]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFAFEEEEAAAAAAAA"
    )
        port map (
      I0 => pattern_sel(2),
      I1 => data2(6),
      I2 => \VGA_R[7]_i_31_n_0\,
      I3 => \VGA_R[7]_i_32_n_0\,
      I4 => pattern_sel(0),
      I5 => pattern_sel(1),
      O => \VGA_R[6]_i_3_n_0\
    );
\VGA_R[6]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2AAA22222AAAAAAA"
    )
        port map (
      I0 => pattern_sel(2),
      I1 => pattern_sel(1),
      I2 => \VGA_R_reg[7]_i_38_n_3\,
      I3 => pattern_b11_in,
      I4 => pattern_sel(0),
      I5 => data6(6),
      O => \VGA_R[6]_i_4_n_0\
    );
\VGA_R[7]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"BFFF"
    )
        port map (
      I0 => RST,
      I1 => disp_enable0,
      I2 => disp_enable1,
      I3 => disp_enable10_in,
      O => SR(0)
    );
\VGA_R[7]_i_10\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000EFEFEFEE"
    )
        port map (
      I0 => pattern_sel(0),
      I1 => pattern_sel(1),
      I2 => \VGA_R[7]_i_41_n_0\,
      I3 => \VGA_R[7]_i_42_n_0\,
      I4 => \VGA_R[7]_i_31_n_0\,
      I5 => \VGA_R[7]_i_43_n_0\,
      O => \VGA_R[7]_i_10_n_0\
    );
\VGA_R[7]_i_103\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"02000000"
    )
        port map (
      I0 => \VGA_R[7]_i_258_n_0\,
      I1 => \VGA_R[7]_i_259_n_0\,
      I2 => \^p_1_in\(10),
      I3 => \VGA_R[7]_i_260_n_0\,
      I4 => \VGA_R[7]_i_261_n_0\,
      O => \VGA_R[7]_i_103_n_0\
    );
\VGA_R[7]_i_104\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"2D0F0F0F"
    )
        port map (
      I0 => \VGA_R[7]_i_258_n_0\,
      I1 => \VGA_R[7]_i_259_n_0\,
      I2 => \^p_1_in\(10),
      I3 => \VGA_R[7]_i_260_n_0\,
      I4 => \VGA_R[7]_i_261_n_0\,
      O => \VGA_R[7]_i_104_n_0\
    );
\VGA_R[7]_i_106\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"22B2"
    )
        port map (
      I0 => \^p_1_in\(9),
      I1 => \VGA_R[7]_i_260_n_0\,
      I2 => \^p_1_in\(8),
      I3 => \VGA_R[7]_i_261_n_0\,
      O => \VGA_R[7]_i_106_n_0\
    );
\VGA_R[7]_i_107\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^p_1_in\(10),
      O => \VGA_R[7]_i_107_n_0\
    );
\VGA_R[7]_i_108\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \VGA_R[7]_i_260_n_0\,
      I1 => \^p_1_in\(9),
      I2 => \VGA_R[7]_i_261_n_0\,
      I3 => \^p_1_in\(8),
      O => \VGA_R[7]_i_108_n_0\
    );
\VGA_R[7]_i_12\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => VGA_HS_i_2_n_0,
      I1 => HCNT(10),
      O => \VGA_R[7]_i_12_n_0\
    );
\VGA_R[7]_i_123\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => sel0(2),
      I1 => \VGA_G_reg[7]_i_7_n_5\,
      O => \VGA_R[7]_i_123_n_0\
    );
\VGA_R[7]_i_124\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => sel0(2),
      I1 => zp_sum,
      I2 => \VGA_G_reg[7]_i_7_n_6\,
      O => \VGA_R[7]_i_124_n_0\
    );
\VGA_R[7]_i_125\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => zp_sum,
      I1 => sel0(2),
      I2 => \VGA_G_reg[7]_i_7_n_7\,
      O => \VGA_R[7]_i_125_n_0\
    );
\VGA_R[7]_i_126\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => sel0(2),
      I1 => zp_sum,
      I2 => \VGA_R_reg[7]_i_122_n_4\,
      O => \VGA_R[7]_i_126_n_0\
    );
\VGA_R[7]_i_128\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_317_n_4\,
      I1 => sel0(12),
      O => \VGA_R[7]_i_128_n_0\
    );
\VGA_R[7]_i_13\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"1F"
    )
        port map (
      I0 => VGA_HS_i_2_n_0,
      I1 => HCNT(8),
      I2 => HCNT(9),
      O => \VGA_R[7]_i_13_n_0\
    );
\VGA_R[7]_i_132\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => sel0(12),
      I1 => \VGA_R_reg[7]_i_70_0\(2),
      O => \VGA_R[7]_i_132_n_0\
    );
\VGA_R[7]_i_133\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => sel0(12),
      I1 => zp_sum,
      I2 => \VGA_R_reg[7]_i_70_0\(1),
      O => \VGA_R[7]_i_133_n_0\
    );
\VGA_R[7]_i_134\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => zp_sum,
      I1 => sel0(12),
      I2 => \VGA_R_reg[7]_i_70_0\(0),
      O => \VGA_R[7]_i_134_n_0\
    );
\VGA_R[7]_i_135\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"65"
    )
        port map (
      I0 => sel0(12),
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      O => \VGA_R[7]_i_135_n_0\
    );
\VGA_R[7]_i_138\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => sel0(7),
      I1 => \VGA_R_reg[7]_i_78_n_5\,
      O => \VGA_R[7]_i_138_n_0\
    );
\VGA_R[7]_i_139\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => sel0(7),
      I1 => zp_sum,
      I2 => \VGA_R_reg[7]_i_78_n_6\,
      O => \VGA_R[7]_i_139_n_0\
    );
\VGA_R[7]_i_14\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => HCNT(10),
      I1 => VGA_HS_i_2_n_0,
      O => \VGA_R[7]_i_14_n_0\
    );
\VGA_R[7]_i_140\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => zp_sum,
      I1 => sel0(7),
      I2 => \VGA_R_reg[7]_i_78_n_7\,
      O => \VGA_R[7]_i_140_n_0\
    );
\VGA_R[7]_i_141\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => sel0(7),
      I1 => zp_sum,
      I2 => \VGA_R_reg[7]_i_137_n_4\,
      O => \VGA_R[7]_i_141_n_0\
    );
\VGA_R[7]_i_144\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => sel0(10),
      I1 => \VGA_R_reg[7]_i_74_n_5\,
      O => \VGA_R[7]_i_144_n_0\
    );
\VGA_R[7]_i_145\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => sel0(10),
      I1 => zp_sum,
      I2 => \VGA_R_reg[7]_i_74_n_6\,
      O => \VGA_R[7]_i_145_n_0\
    );
\VGA_R[7]_i_146\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => zp_sum,
      I1 => sel0(10),
      I2 => \VGA_R_reg[7]_i_74_n_7\,
      O => \VGA_R[7]_i_146_n_0\
    );
\VGA_R[7]_i_147\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => sel0(10),
      I1 => zp_sum,
      I2 => \VGA_R_reg[7]_i_143_n_4\,
      O => \VGA_R[7]_i_147_n_0\
    );
\VGA_R[7]_i_149\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => sel0(9),
      I1 => \VGA_R_reg[7]_i_72_n_5\,
      O => \VGA_R[7]_i_149_n_0\
    );
\VGA_R[7]_i_15\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"28"
    )
        port map (
      I0 => HCNT(9),
      I1 => VGA_HS_i_2_n_0,
      I2 => HCNT(8),
      O => \VGA_R[7]_i_15_n_0\
    );
\VGA_R[7]_i_150\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => sel0(9),
      I1 => zp_sum,
      I2 => \VGA_R_reg[7]_i_72_n_6\,
      O => \VGA_R[7]_i_150_n_0\
    );
\VGA_R[7]_i_151\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => zp_sum,
      I1 => sel0(9),
      I2 => \VGA_R_reg[7]_i_72_n_7\,
      O => \VGA_R[7]_i_151_n_0\
    );
\VGA_R[7]_i_152\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => sel0(9),
      I1 => zp_sum,
      I2 => \VGA_R_reg[7]_i_142_n_4\,
      O => \VGA_R[7]_i_152_n_0\
    );
\VGA_R[7]_i_153\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => sel0(11),
      I1 => \VGA_R_reg[7]_i_70_n_5\,
      O => \VGA_R[7]_i_153_n_0\
    );
\VGA_R[7]_i_154\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => sel0(11),
      I1 => zp_sum,
      I2 => \VGA_R_reg[7]_i_70_n_6\,
      O => \VGA_R[7]_i_154_n_0\
    );
\VGA_R[7]_i_155\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => zp_sum,
      I1 => sel0(11),
      I2 => \VGA_R_reg[7]_i_70_n_7\,
      O => \VGA_R[7]_i_155_n_0\
    );
\VGA_R[7]_i_156\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => sel0(11),
      I1 => zp_sum,
      I2 => \VGA_R_reg[7]_i_130_n_4\,
      O => \VGA_R[7]_i_156_n_0\
    );
\VGA_R[7]_i_159\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => sel0(4),
      I1 => \VGA_R_reg[7]_i_76_n_5\,
      O => \VGA_R[7]_i_159_n_0\
    );
\VGA_R[7]_i_160\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => sel0(4),
      I1 => zp_sum,
      I2 => \VGA_R_reg[7]_i_76_n_6\,
      O => \VGA_R[7]_i_160_n_0\
    );
\VGA_R[7]_i_161\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => zp_sum,
      I1 => sel0(4),
      I2 => \VGA_R_reg[7]_i_76_n_7\,
      O => \VGA_R[7]_i_161_n_0\
    );
\VGA_R[7]_i_162\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => sel0(4),
      I1 => zp_sum,
      I2 => \VGA_R_reg[7]_i_158_n_4\,
      O => \VGA_R[7]_i_162_n_0\
    );
\VGA_R[7]_i_164\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => sel0(5),
      I1 => \VGA_R_reg[7]_i_77_n_5\,
      O => \VGA_R[7]_i_164_n_0\
    );
\VGA_R[7]_i_165\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => sel0(5),
      I1 => zp_sum,
      I2 => \VGA_R_reg[7]_i_77_n_6\,
      O => \VGA_R[7]_i_165_n_0\
    );
\VGA_R[7]_i_166\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => zp_sum,
      I1 => sel0(5),
      I2 => \VGA_R_reg[7]_i_77_n_7\,
      O => \VGA_R[7]_i_166_n_0\
    );
\VGA_R[7]_i_167\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => sel0(5),
      I1 => zp_sum,
      I2 => \VGA_R_reg[7]_i_163_n_4\,
      O => \VGA_R[7]_i_167_n_0\
    );
\VGA_R[7]_i_168\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => sel0(6),
      I1 => \VGA_R_reg[7]_i_71_n_5\,
      O => \VGA_R[7]_i_168_n_0\
    );
\VGA_R[7]_i_169\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => sel0(6),
      I1 => zp_sum,
      I2 => \VGA_R_reg[7]_i_71_n_6\,
      O => \VGA_R[7]_i_169_n_0\
    );
\VGA_R[7]_i_17\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FB00"
    )
        port map (
      I0 => zp_sum0(2),
      I1 => \VGA_R_reg[7]_i_4_0\,
      I2 => CO(0),
      I3 => HCNT(10),
      O => \VGA_R[7]_i_17_n_0\
    );
\VGA_R[7]_i_170\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => zp_sum,
      I1 => sel0(6),
      I2 => \VGA_R_reg[7]_i_71_n_7\,
      O => \VGA_R[7]_i_170_n_0\
    );
\VGA_R[7]_i_171\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => sel0(6),
      I1 => zp_sum,
      I2 => \VGA_R_reg[7]_i_136_n_4\,
      O => \VGA_R[7]_i_171_n_0\
    );
\VGA_R[7]_i_172\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => sel0(8),
      I1 => \VGA_R_reg[7]_i_73_n_5\,
      O => \VGA_R[7]_i_172_n_0\
    );
\VGA_R[7]_i_173\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => sel0(8),
      I1 => zp_sum,
      I2 => \VGA_R_reg[7]_i_73_n_6\,
      O => \VGA_R[7]_i_173_n_0\
    );
\VGA_R[7]_i_174\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => zp_sum,
      I1 => sel0(8),
      I2 => \VGA_R_reg[7]_i_73_n_7\,
      O => \VGA_R[7]_i_174_n_0\
    );
\VGA_R[7]_i_175\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => sel0(8),
      I1 => zp_sum,
      I2 => \VGA_R_reg[7]_i_148_n_4\,
      O => \VGA_R[7]_i_175_n_0\
    );
\VGA_R[7]_i_18\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"CECEE0CE"
    )
        port map (
      I0 => HCNT(8),
      I1 => HCNT(9),
      I2 => CO(0),
      I3 => \VGA_R_reg[7]_i_4_0\,
      I4 => zp_sum0(2),
      O => \VGA_R[7]_i_18_n_0\
    );
\VGA_R[7]_i_19\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"04FB"
    )
        port map (
      I0 => zp_sum0(2),
      I1 => \VGA_R_reg[7]_i_4_0\,
      I2 => CO(0),
      I3 => HCNT(10),
      O => \VGA_R[7]_i_19_n_0\
    );
\VGA_R[7]_i_193\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \^p_1_in\(2),
      O => \VGA_R[7]_i_193_n_0\
    );
\VGA_R[7]_i_194\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => zp_sum,
      I1 => \VGA_G_reg[7]_i_6_n_0\,
      I2 => \VGA_R_reg[7]_i_87_n_5\,
      O => \VGA_R[7]_i_194_n_0\
    );
\VGA_R[7]_i_195\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"659A"
    )
        port map (
      I0 => \VGA_G_reg[7]_i_6_n_0\,
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      I3 => \VGA_R_reg[7]_i_87_n_6\,
      O => \VGA_R[7]_i_195_n_0\
    );
\VGA_R[7]_i_196\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_G_reg[7]_i_6_n_0\,
      I1 => \VGA_R_reg[7]_i_87_n_7\,
      O => \VGA_R[7]_i_196_n_0\
    );
\VGA_R[7]_i_197\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6966"
    )
        port map (
      I0 => \^p_1_in\(2),
      I1 => \VGA_G_reg[7]_i_6_n_0\,
      I2 => timing_sel(1),
      I3 => timing_sel(0),
      O => \VGA_R[7]_i_197_n_0\
    );
\VGA_R[7]_i_198\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \^p_1_in\(3),
      O => \VGA_R[7]_i_198_n_0\
    );
\VGA_R[7]_i_199\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => zp_sum,
      I1 => \VGA_R_reg[7]_i_94_n_0\,
      I2 => \VGA_G_reg[7]_i_8_n_5\,
      O => \VGA_R[7]_i_199_n_0\
    );
\VGA_R[7]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8888BBB8BBB8BBB8"
    )
        port map (
      I0 => \VGA_R[7]_i_6_n_0\,
      I1 => pattern_sel(3),
      I2 => \VGA_R[7]_i_7_n_0\,
      I3 => \VGA_R[7]_i_8_n_0\,
      I4 => \VGA_R[7]_i_9_n_0\,
      I5 => \VGA_R[7]_i_10_n_0\,
      O => \pattern_sel[3]_0\(7)
    );
\VGA_R[7]_i_20\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"42441411"
    )
        port map (
      I0 => HCNT(9),
      I1 => CO(0),
      I2 => zp_sum0(2),
      I3 => \VGA_R_reg[7]_i_4_0\,
      I4 => HCNT(8),
      O => \VGA_R[7]_i_20_n_0\
    );
\VGA_R[7]_i_200\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"659A"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_94_n_0\,
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      I3 => \VGA_G_reg[7]_i_8_n_6\,
      O => \VGA_R[7]_i_200_n_0\
    );
\VGA_R[7]_i_201\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_94_n_0\,
      I1 => \VGA_G_reg[7]_i_8_n_7\,
      O => \VGA_R[7]_i_201_n_0\
    );
\VGA_R[7]_i_202\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6966"
    )
        port map (
      I0 => \^p_1_in\(3),
      I1 => \VGA_R_reg[7]_i_94_n_0\,
      I2 => timing_sel(1),
      I3 => timing_sel(0),
      O => \VGA_R[7]_i_202_n_0\
    );
\VGA_R[7]_i_212\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_95_n_0\,
      I1 => \VGA_R_reg[7]_i_95_n_5\,
      O => \VGA_R[7]_i_212_n_0\
    );
\VGA_R[7]_i_213\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_95_n_0\,
      I1 => zp_sum,
      I2 => \VGA_R_reg[7]_i_95_n_6\,
      O => \VGA_R[7]_i_213_n_0\
    );
\VGA_R[7]_i_214\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => zp_sum,
      I1 => \VGA_R_reg[7]_i_95_n_0\,
      I2 => \VGA_R_reg[7]_i_95_n_7\,
      O => \VGA_R[7]_i_214_n_0\
    );
\VGA_R[7]_i_215\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_95_n_0\,
      I1 => zp_sum,
      I2 => \VGA_R_reg[7]_i_211_n_4\,
      O => \VGA_R[7]_i_215_n_0\
    );
\VGA_R[7]_i_217\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_96_n_0\,
      I1 => \VGA_R_reg[7]_i_96_n_5\,
      O => \VGA_R[7]_i_217_n_0\
    );
\VGA_R[7]_i_218\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_96_n_0\,
      I1 => zp_sum,
      I2 => \VGA_R_reg[7]_i_96_n_6\,
      O => \VGA_R[7]_i_218_n_0\
    );
\VGA_R[7]_i_219\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => zp_sum,
      I1 => \VGA_R_reg[7]_i_96_n_0\,
      I2 => \VGA_R_reg[7]_i_96_n_7\,
      O => \VGA_R[7]_i_219_n_0\
    );
\VGA_R[7]_i_22\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => VCNT(9),
      I1 => VCNT(8),
      O => \VGA_R[7]_i_22_n_0\
    );
\VGA_R[7]_i_220\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_96_n_0\,
      I1 => zp_sum,
      I2 => \VGA_R_reg[7]_i_216_n_4\,
      O => \VGA_R[7]_i_220_n_0\
    );
\VGA_R[7]_i_222\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_97_n_0\,
      I1 => \VGA_R_reg[7]_i_97_n_5\,
      O => \VGA_R[7]_i_222_n_0\
    );
\VGA_R[7]_i_223\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_97_n_0\,
      I1 => zp_sum,
      I2 => \VGA_R_reg[7]_i_97_n_6\,
      O => \VGA_R[7]_i_223_n_0\
    );
\VGA_R[7]_i_224\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => zp_sum,
      I1 => \VGA_R_reg[7]_i_97_n_0\,
      I2 => \VGA_R_reg[7]_i_97_n_7\,
      O => \VGA_R[7]_i_224_n_0\
    );
\VGA_R[7]_i_225\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_97_n_0\,
      I1 => zp_sum,
      I2 => \VGA_R_reg[7]_i_221_n_4\,
      O => \VGA_R[7]_i_225_n_0\
    );
\VGA_R[7]_i_227\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_98_n_0\,
      I1 => \VGA_R_reg[7]_i_98_n_5\,
      O => \VGA_R[7]_i_227_n_0\
    );
\VGA_R[7]_i_228\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_98_n_0\,
      I1 => zp_sum,
      I2 => \VGA_R_reg[7]_i_98_n_6\,
      O => \VGA_R[7]_i_228_n_0\
    );
\VGA_R[7]_i_229\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => zp_sum,
      I1 => \VGA_R_reg[7]_i_98_n_0\,
      I2 => \VGA_R_reg[7]_i_98_n_7\,
      O => \VGA_R[7]_i_229_n_0\
    );
\VGA_R[7]_i_23\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => VCNT(10),
      O => \VGA_R[7]_i_23_n_0\
    );
\VGA_R[7]_i_230\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_98_n_0\,
      I1 => zp_sum,
      I2 => \VGA_R_reg[7]_i_226_n_4\,
      O => \VGA_R[7]_i_230_n_0\
    );
\VGA_R[7]_i_232\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_99_n_0\,
      I1 => \VGA_R_reg[7]_i_99_n_5\,
      O => \VGA_R[7]_i_232_n_0\
    );
\VGA_R[7]_i_233\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_99_n_0\,
      I1 => zp_sum,
      I2 => \VGA_R_reg[7]_i_99_n_6\,
      O => \VGA_R[7]_i_233_n_0\
    );
\VGA_R[7]_i_234\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => zp_sum,
      I1 => \VGA_R_reg[7]_i_99_n_0\,
      I2 => \VGA_R_reg[7]_i_99_n_7\,
      O => \VGA_R[7]_i_234_n_0\
    );
\VGA_R[7]_i_235\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_99_n_0\,
      I1 => zp_sum,
      I2 => \VGA_R_reg[7]_i_231_n_4\,
      O => \VGA_R[7]_i_235_n_0\
    );
\VGA_R[7]_i_237\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_100_n_0\,
      I1 => \VGA_R_reg[7]_i_100_n_5\,
      O => \VGA_R[7]_i_237_n_0\
    );
\VGA_R[7]_i_238\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_100_n_0\,
      I1 => zp_sum,
      I2 => \VGA_R_reg[7]_i_100_n_6\,
      O => \VGA_R[7]_i_238_n_0\
    );
\VGA_R[7]_i_239\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => zp_sum,
      I1 => \VGA_R_reg[7]_i_100_n_0\,
      I2 => \VGA_R_reg[7]_i_100_n_7\,
      O => \VGA_R[7]_i_239_n_0\
    );
\VGA_R[7]_i_24\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => VCNT(8),
      I1 => VCNT(9),
      O => \VGA_R[7]_i_24_n_0\
    );
\VGA_R[7]_i_240\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_100_n_0\,
      I1 => zp_sum,
      I2 => \VGA_R_reg[7]_i_236_n_4\,
      O => \VGA_R[7]_i_240_n_0\
    );
\VGA_R[7]_i_250\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0D020F00DD0F2F02"
    )
        port map (
      I0 => \VGA_R[7]_i_258_n_0\,
      I1 => \VGA_R[7]_i_259_n_0\,
      I2 => \^p_1_in\(9),
      I3 => \VGA_R[7]_i_260_n_0\,
      I4 => \VGA_R[7]_i_261_n_0\,
      I5 => \^p_1_in\(8),
      O => \VGA_R[7]_i_250_n_0\
    );
\VGA_R[7]_i_251\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"045145D3"
    )
        port map (
      I0 => \^p_1_in\(7),
      I1 => \VGA_R[7]_i_428_n_0\,
      I2 => \VGA_R[7]_i_429_n_0\,
      I3 => \VGA_R[7]_i_259_n_0\,
      I4 => \^p_1_in\(6),
      O => \VGA_R[7]_i_251_n_0\
    );
\VGA_R[7]_i_252\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"1111411171114777"
    )
        port map (
      I0 => \^p_1_in\(5),
      I1 => \VGA_R[7]_i_430_n_0\,
      I2 => FCNT(1),
      I3 => FCNT(0),
      I4 => \VGA_R[7]_i_431_n_0\,
      I5 => \^p_1_in\(4),
      O => \VGA_R[7]_i_252_n_0\
    );
\VGA_R[7]_i_253\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"105B"
    )
        port map (
      I0 => FCNT(0),
      I1 => \^p_1_in\(2),
      I2 => FCNT(1),
      I3 => \^p_1_in\(3),
      O => \VGA_R[7]_i_253_n_0\
    );
\VGA_R[7]_i_254\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"D00D20020220D00D"
    )
        port map (
      I0 => \VGA_R[7]_i_258_n_0\,
      I1 => \VGA_R[7]_i_259_n_0\,
      I2 => \VGA_R[7]_i_260_n_0\,
      I3 => \^p_1_in\(9),
      I4 => \VGA_R[7]_i_261_n_0\,
      I5 => \^p_1_in\(8),
      O => \VGA_R[7]_i_254_n_0\
    );
\VGA_R[7]_i_255\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"60060690"
    )
        port map (
      I0 => \VGA_R[7]_i_259_n_0\,
      I1 => \^p_1_in\(7),
      I2 => \VGA_R[7]_i_428_n_0\,
      I3 => \VGA_R[7]_i_429_n_0\,
      I4 => \^p_1_in\(6),
      O => \VGA_R[7]_i_255_n_0\
    );
\VGA_R[7]_i_256\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"6000066606669000"
    )
        port map (
      I0 => \VGA_R[7]_i_430_n_0\,
      I1 => \^p_1_in\(5),
      I2 => FCNT(1),
      I3 => FCNT(0),
      I4 => \VGA_R[7]_i_431_n_0\,
      I5 => \^p_1_in\(4),
      O => \VGA_R[7]_i_256_n_0\
    );
\VGA_R[7]_i_257\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0690"
    )
        port map (
      I0 => \^p_1_in\(3),
      I1 => FCNT(1),
      I2 => \^p_1_in\(2),
      I3 => FCNT(0),
      O => \VGA_R[7]_i_257_n_0\
    );
\VGA_R[7]_i_258\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0800008000000000"
    )
        port map (
      I0 => FCNT(1),
      I1 => FCNT(0),
      I2 => \VGA_R[7]_i_432_n_0\,
      I3 => FCNT(2),
      I4 => FCNT(3),
      I5 => FCNT(4),
      O => \VGA_R[7]_i_258_n_0\
    );
\VGA_R[7]_i_259\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00F50000FB3BFFFF"
    )
        port map (
      I0 => \VGA_R[7]_i_433_n_0\,
      I1 => FCNT(6),
      I2 => \VGA_R_reg[7]_i_231_0\,
      I3 => VGA_HS_i_2_n_0,
      I4 => FCNT(7),
      I5 => FCNT(5),
      O => \VGA_R[7]_i_259_n_0\
    );
\VGA_R[7]_i_26\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0100"
    )
        port map (
      I0 => sel0(1),
      I1 => sel0(12),
      I2 => sel0(11),
      I3 => sel0(32),
      O => \VGA_R[7]_i_26_n_0\
    );
\VGA_R[7]_i_260\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"4044404440444444"
    )
        port map (
      I0 => \VGA_R[7]_i_432_n_0\,
      I1 => FCNT(7),
      I2 => VGA_HS_i_2_n_0,
      I3 => \VGA_R_reg[7]_i_231_0\,
      I4 => FCNT(5),
      I5 => FCNT(6),
      O => \VGA_R[7]_i_260_n_0\
    );
\VGA_R[7]_i_261\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAA2AA88AA80AA"
    )
        port map (
      I0 => FCNT(6),
      I1 => \VGA_R_reg[7]_i_231_0\,
      I2 => VGA_HS_i_2_n_0,
      I3 => FCNT(7),
      I4 => FCNT(5),
      I5 => \VGA_R[7]_i_434_n_0\,
      O => \VGA_R[7]_i_261_n_0\
    );
\VGA_R[7]_i_262\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"E888"
    )
        port map (
      I0 => \^p_1_in\(7),
      I1 => \VGA_R[7]_i_259_n_0\,
      I2 => \VGA_R[7]_i_429_n_0\,
      I3 => \^p_1_in\(6),
      O => \VGA_R[7]_i_262_n_0\
    );
\VGA_R[7]_i_263\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"A2CB208A"
    )
        port map (
      I0 => \^p_1_in\(5),
      I1 => FCNT(2),
      I2 => \VGA_R[7]_i_432_n_0\,
      I3 => FCNT(3),
      I4 => \^p_1_in\(4),
      O => \VGA_R[7]_i_263_n_0\
    );
\VGA_R[7]_i_264\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"22B2"
    )
        port map (
      I0 => \^p_1_in\(3),
      I1 => FCNT(1),
      I2 => \^p_1_in\(2),
      I3 => FCNT(0),
      O => \VGA_R[7]_i_264_n_0\
    );
\VGA_R[7]_i_265\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => \^p_1_in\(1),
      I1 => HCNT(0),
      O => \VGA_R[7]_i_265_n_0\
    );
\VGA_R[7]_i_266\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0660"
    )
        port map (
      I0 => \VGA_R[7]_i_259_n_0\,
      I1 => \^p_1_in\(7),
      I2 => \VGA_R[7]_i_429_n_0\,
      I3 => \^p_1_in\(6),
      O => \VGA_R[7]_i_266_n_0\
    );
\VGA_R[7]_i_267\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"06909009"
    )
        port map (
      I0 => FCNT(3),
      I1 => \^p_1_in\(5),
      I2 => FCNT(2),
      I3 => \VGA_R[7]_i_432_n_0\,
      I4 => \^p_1_in\(4),
      O => \VGA_R[7]_i_267_n_0\
    );
\VGA_R[7]_i_268\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => FCNT(1),
      I1 => \^p_1_in\(3),
      I2 => FCNT(0),
      I3 => \^p_1_in\(2),
      O => \VGA_R[7]_i_268_n_0\
    );
\VGA_R[7]_i_269\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => HCNT(0),
      I1 => \^p_1_in\(1),
      O => \VGA_R[7]_i_269_n_0\
    );
\VGA_R[7]_i_27\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0001"
    )
        port map (
      I0 => sel0(6),
      I1 => sel0(9),
      I2 => sel0(8),
      I3 => sel0(10),
      O => \VGA_R[7]_i_27_n_0\
    );
\VGA_R[7]_i_28\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => sel0(3),
      I1 => sel0(4),
      I2 => sel0(5),
      I3 => sel0(7),
      O => \VGA_R[7]_i_28_n_0\
    );
\VGA_R[7]_i_287\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"18"
    )
        port map (
      I0 => \^p_1_in\(10),
      I1 => zp_sum,
      I2 => \^p_1_in\(9),
      O => \VGA_R[7]_i_287_n_0\
    );
\VGA_R[7]_i_288\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000082888282"
    )
        port map (
      I0 => \^p_1_in\(6),
      I1 => \^p_1_in\(7),
      I2 => zp_sum,
      I3 => timing_sel(1),
      I4 => timing_sel(0),
      I5 => \^p_1_in\(8),
      O => \VGA_R[7]_i_288_n_0\
    );
\VGA_R[7]_i_289\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"88080020"
    )
        port map (
      I0 => \^p_1_in\(3),
      I1 => \^p_1_in\(4),
      I2 => timing_sel(0),
      I3 => timing_sel(1),
      I4 => \^p_1_in\(5),
      O => \VGA_R[7]_i_289_n_0\
    );
\VGA_R[7]_i_290\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"40"
    )
        port map (
      I0 => HCNT(0),
      I1 => \^p_1_in\(1),
      I2 => \^p_1_in\(2),
      O => \VGA_R[7]_i_290_n_0\
    );
\VGA_R[7]_i_291\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"41"
    )
        port map (
      I0 => \^a\(10),
      I1 => \VGA_R_reg[4]_i_5_0\,
      I2 => \^a\(9),
      O => \VGA_R[7]_i_291_n_0\
    );
\VGA_R[7]_i_292\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0880"
    )
        port map (
      I0 => \^a\(6),
      I1 => \^a\(7),
      I2 => \^a\(8),
      I3 => \VGA_R_reg[4]_i_5_0\,
      O => \VGA_R[7]_i_292_n_0\
    );
\VGA_R[7]_i_293\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0028"
    )
        port map (
      I0 => \^a\(3),
      I1 => \^a\(4),
      I2 => \VGA_R_reg[4]_i_5_0\,
      I3 => \^a\(5),
      O => \VGA_R[7]_i_293_n_0\
    );
\VGA_R[7]_i_294\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"80"
    )
        port map (
      I0 => \^a\(0),
      I1 => \^a\(1),
      I2 => \^a\(2),
      O => \VGA_R[7]_i_294_n_0\
    );
\VGA_R[7]_i_295\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => VCNT(9),
      I1 => VCNT(10),
      O => \VGA_R[7]_i_295_n_0\
    );
\VGA_R[7]_i_296\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"01"
    )
        port map (
      I0 => VCNT(7),
      I1 => VCNT(6),
      I2 => VCNT(8),
      O => \VGA_R[7]_i_296_n_0\
    );
\VGA_R[7]_i_297\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0280"
    )
        port map (
      I0 => VCNT(3),
      I1 => \VGA_R_reg[4]_i_5_0\,
      I2 => VCNT(4),
      I3 => VCNT(5),
      O => \VGA_R[7]_i_297_n_0\
    );
\VGA_R[7]_i_298\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0280"
    )
        port map (
      I0 => VCNT(2),
      I1 => VCNT(1),
      I2 => \VGA_R_reg[4]_i_5_0\,
      I3 => VCNT(0),
      O => \VGA_R[7]_i_298_n_0\
    );
\VGA_R[7]_i_299\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_448_n_7\,
      O => \VGA_R[7]_i_299_n_0\
    );
\VGA_R[7]_i_300\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => zp_sum,
      I1 => sel0(2),
      I2 => \VGA_R_reg[7]_i_122_n_5\,
      O => \VGA_R[7]_i_300_n_0\
    );
\VGA_R[7]_i_301\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"659A"
    )
        port map (
      I0 => sel0(2),
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      I3 => \VGA_R_reg[7]_i_122_n_6\,
      O => \VGA_R[7]_i_301_n_0\
    );
\VGA_R[7]_i_302\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => sel0(2),
      I1 => \VGA_R_reg[7]_i_122_n_7\,
      O => \VGA_R[7]_i_302_n_0\
    );
\VGA_R[7]_i_303\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => sel0(2),
      I1 => \VGA_R_reg[7]_i_231_0\,
      I2 => \VGA_R_reg[7]_i_448_n_7\,
      O => \VGA_R[7]_i_303_n_0\
    );
\VGA_R[7]_i_304\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_449_n_7\,
      O => \VGA_R[7]_i_304_n_0\
    );
\VGA_R[7]_i_305\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => zp_sum,
      I1 => sel0(3),
      I2 => \VGA_R_reg[7]_i_157_n_5\,
      O => \VGA_R[7]_i_305_n_0\
    );
\VGA_R[7]_i_306\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"659A"
    )
        port map (
      I0 => sel0(3),
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      I3 => \VGA_R_reg[7]_i_157_n_6\,
      O => \VGA_R[7]_i_306_n_0\
    );
\VGA_R[7]_i_307\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => sel0(3),
      I1 => \VGA_R_reg[7]_i_157_n_7\,
      O => \VGA_R[7]_i_307_n_0\
    );
\VGA_R[7]_i_308\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => sel0(3),
      I1 => \VGA_R_reg[7]_i_231_0\,
      I2 => \VGA_R_reg[7]_i_449_n_7\,
      O => \VGA_R[7]_i_308_n_0\
    );
\VGA_R[7]_i_31\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFEFFFF"
    )
        port map (
      I0 => \^p_1_in\(4),
      I1 => \^p_1_in\(5),
      I2 => \^p_1_in\(2),
      I3 => \^p_1_in\(3),
      I4 => HCNT(0),
      I5 => \^p_1_in\(1),
      O => \VGA_R[7]_i_31_n_0\
    );
\VGA_R[7]_i_318\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => sel0(12),
      I1 => zp_sum,
      O => \VGA_R[7]_i_318_n_0\
    );
\VGA_R[7]_i_32\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000001"
    )
        port map (
      I0 => \^a\(0),
      I1 => \^a\(1),
      I2 => \^a\(5),
      I3 => \^a\(3),
      I4 => \^a\(2),
      I5 => \^a\(4),
      O => \VGA_R[7]_i_32_n_0\
    );
\VGA_R[7]_i_320\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D2"
    )
        port map (
      I0 => timing_sel(0),
      I1 => timing_sel(1),
      I2 => sel0(12),
      O => \VGA_R[7]_i_320_n_0\
    );
\VGA_R[7]_i_321\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => sel0(12),
      I1 => zp_sum,
      O => \VGA_R[7]_i_321_n_0\
    );
\VGA_R[7]_i_322\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => sel0(12),
      O => \VGA_R[7]_i_322_n_0\
    );
\VGA_R[7]_i_323\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"A6"
    )
        port map (
      I0 => sel0(12),
      I1 => timing_sel(0),
      I2 => timing_sel(1),
      O => \VGA_R[7]_i_323_n_0\
    );
\VGA_R[7]_i_324\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D2"
    )
        port map (
      I0 => timing_sel(0),
      I1 => timing_sel(1),
      I2 => sel0(12),
      O => \VGA_R[7]_i_324_n_0\
    );
\VGA_R[7]_i_325\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_455_n_7\,
      O => \VGA_R[7]_i_325_n_0\
    );
\VGA_R[7]_i_326\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => zp_sum,
      I1 => sel0(7),
      I2 => \VGA_R_reg[7]_i_137_n_5\,
      O => \VGA_R[7]_i_326_n_0\
    );
\VGA_R[7]_i_327\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"659A"
    )
        port map (
      I0 => sel0(7),
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      I3 => \VGA_R_reg[7]_i_137_n_6\,
      O => \VGA_R[7]_i_327_n_0\
    );
\VGA_R[7]_i_328\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => sel0(7),
      I1 => \VGA_R_reg[7]_i_137_n_7\,
      O => \VGA_R[7]_i_328_n_0\
    );
\VGA_R[7]_i_329\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => sel0(7),
      I1 => \VGA_R_reg[7]_i_231_0\,
      I2 => \VGA_R_reg[7]_i_455_n_7\,
      O => \VGA_R[7]_i_329_n_0\
    );
\VGA_R[7]_i_330\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_69_n_6\,
      O => \VGA_R[7]_i_330_n_0\
    );
\VGA_R[7]_i_331\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => zp_sum,
      I1 => sel0(8),
      I2 => \VGA_R_reg[7]_i_148_n_5\,
      O => \VGA_R[7]_i_331_n_0\
    );
\VGA_R[7]_i_332\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"659A"
    )
        port map (
      I0 => sel0(8),
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      I3 => \VGA_R_reg[7]_i_148_n_6\,
      O => \VGA_R[7]_i_332_n_0\
    );
\VGA_R[7]_i_333\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => sel0(8),
      I1 => \VGA_R_reg[7]_i_148_n_7\,
      O => \VGA_R[7]_i_333_n_0\
    );
\VGA_R[7]_i_334\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => sel0(8),
      I1 => \VGA_R_reg[7]_i_231_0\,
      I2 => \VGA_R_reg[7]_i_69_n_6\,
      O => \VGA_R[7]_i_334_n_0\
    );
\VGA_R[7]_i_335\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_456_n_6\,
      O => \VGA_R[7]_i_335_n_0\
    );
\VGA_R[7]_i_336\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => zp_sum,
      I1 => sel0(10),
      I2 => \VGA_R_reg[7]_i_143_n_5\,
      O => \VGA_R[7]_i_336_n_0\
    );
\VGA_R[7]_i_337\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"659A"
    )
        port map (
      I0 => sel0(10),
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      I3 => \VGA_R_reg[7]_i_143_n_6\,
      O => \VGA_R[7]_i_337_n_0\
    );
\VGA_R[7]_i_338\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => sel0(10),
      I1 => \VGA_R_reg[7]_i_143_n_7\,
      O => \VGA_R[7]_i_338_n_0\
    );
\VGA_R[7]_i_339\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"659A"
    )
        port map (
      I0 => sel0(10),
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      I3 => \VGA_R_reg[7]_i_456_n_6\,
      O => \VGA_R[7]_i_339_n_0\
    );
\VGA_R[7]_i_340\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D2"
    )
        port map (
      I0 => timing_sel(0),
      I1 => timing_sel(1),
      I2 => sel0(11),
      O => \VGA_R[7]_i_340_n_0\
    );
\VGA_R[7]_i_341\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => zp_sum,
      I1 => sel0(11),
      I2 => \VGA_R_reg[7]_i_130_n_5\,
      O => \VGA_R[7]_i_341_n_0\
    );
\VGA_R[7]_i_342\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"659A"
    )
        port map (
      I0 => sel0(11),
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      I3 => \VGA_R_reg[7]_i_130_n_6\,
      O => \VGA_R[7]_i_342_n_0\
    );
\VGA_R[7]_i_343\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => sel0(11),
      I1 => \VGA_R_reg[7]_i_130_n_7\,
      O => \VGA_R[7]_i_343_n_0\
    );
\VGA_R[7]_i_344\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D2"
    )
        port map (
      I0 => timing_sel(0),
      I1 => timing_sel(1),
      I2 => sel0(11),
      O => \VGA_R[7]_i_344_n_0\
    );
\VGA_R[7]_i_345\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_456_n_7\,
      O => \VGA_R[7]_i_345_n_0\
    );
\VGA_R[7]_i_346\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => zp_sum,
      I1 => sel0(9),
      I2 => \VGA_R_reg[7]_i_142_n_5\,
      O => \VGA_R[7]_i_346_n_0\
    );
\VGA_R[7]_i_347\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"659A"
    )
        port map (
      I0 => sel0(9),
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      I3 => \VGA_R_reg[7]_i_142_n_6\,
      O => \VGA_R[7]_i_347_n_0\
    );
\VGA_R[7]_i_348\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => sel0(9),
      I1 => \VGA_R_reg[7]_i_142_n_7\,
      O => \VGA_R[7]_i_348_n_0\
    );
\VGA_R[7]_i_349\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => sel0(9),
      I1 => \VGA_R_reg[7]_i_231_0\,
      I2 => \VGA_R_reg[7]_i_456_n_7\,
      O => \VGA_R[7]_i_349_n_0\
    );
\VGA_R[7]_i_35\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_94_n_0\,
      I1 => \VGA_R_reg[7]_i_95_n_0\,
      I2 => \VGA_R_reg[7]_i_96_n_0\,
      I3 => \VGA_R_reg[7]_i_97_n_0\,
      O => \VGA_R[7]_i_35_n_0\
    );
\VGA_R[7]_i_350\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_457_n_7\,
      O => \VGA_R[7]_i_350_n_0\
    );
\VGA_R[7]_i_351\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => zp_sum,
      I1 => sel0(4),
      I2 => \VGA_R_reg[7]_i_158_n_5\,
      O => \VGA_R[7]_i_351_n_0\
    );
\VGA_R[7]_i_352\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"659A"
    )
        port map (
      I0 => sel0(4),
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      I3 => \VGA_R_reg[7]_i_158_n_6\,
      O => \VGA_R[7]_i_352_n_0\
    );
\VGA_R[7]_i_353\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => sel0(4),
      I1 => \VGA_R_reg[7]_i_158_n_7\,
      O => \VGA_R[7]_i_353_n_0\
    );
\VGA_R[7]_i_354\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => sel0(4),
      I1 => \VGA_R_reg[7]_i_231_0\,
      I2 => \VGA_R_reg[7]_i_457_n_7\,
      O => \VGA_R[7]_i_354_n_0\
    );
\VGA_R[7]_i_355\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_458_n_7\,
      O => \VGA_R[7]_i_355_n_0\
    );
\VGA_R[7]_i_356\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => zp_sum,
      I1 => sel0(5),
      I2 => \VGA_R_reg[7]_i_163_n_5\,
      O => \VGA_R[7]_i_356_n_0\
    );
\VGA_R[7]_i_357\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"659A"
    )
        port map (
      I0 => sel0(5),
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      I3 => \VGA_R_reg[7]_i_163_n_6\,
      O => \VGA_R[7]_i_357_n_0\
    );
\VGA_R[7]_i_358\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => sel0(5),
      I1 => \VGA_R_reg[7]_i_163_n_7\,
      O => \VGA_R[7]_i_358_n_0\
    );
\VGA_R[7]_i_359\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => sel0(5),
      I1 => \VGA_R_reg[7]_i_231_0\,
      I2 => \VGA_R_reg[7]_i_458_n_7\,
      O => \VGA_R[7]_i_359_n_0\
    );
\VGA_R[7]_i_36\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_98_n_0\,
      I1 => \VGA_R_reg[7]_i_99_n_0\,
      I2 => \VGA_R_reg[7]_i_100_n_0\,
      I3 => \VGA_R_reg[7]_i_236_0\(0),
      O => \VGA_R[7]_i_36_n_0\
    );
\VGA_R[7]_i_360\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_459_n_7\,
      O => \VGA_R[7]_i_360_n_0\
    );
\VGA_R[7]_i_361\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => zp_sum,
      I1 => sel0(6),
      I2 => \VGA_R_reg[7]_i_136_n_5\,
      O => \VGA_R[7]_i_361_n_0\
    );
\VGA_R[7]_i_362\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"659A"
    )
        port map (
      I0 => sel0(6),
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      I3 => \VGA_R_reg[7]_i_136_n_6\,
      O => \VGA_R[7]_i_362_n_0\
    );
\VGA_R[7]_i_363\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => sel0(6),
      I1 => \VGA_R_reg[7]_i_136_n_7\,
      O => \VGA_R[7]_i_363_n_0\
    );
\VGA_R[7]_i_364\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => sel0(6),
      I1 => \VGA_R_reg[7]_i_231_0\,
      I2 => \VGA_R_reg[7]_i_459_n_7\,
      O => \VGA_R[7]_i_364_n_0\
    );
\VGA_R[7]_i_37\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D7"
    )
        port map (
      I0 => pattern_sel(0),
      I1 => \^a\(5),
      I2 => \^p_1_in\(5),
      O => \VGA_R[7]_i_37_n_0\
    );
\VGA_R[7]_i_393\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \^p_1_in\(5),
      O => \VGA_R[7]_i_393_n_0\
    );
\VGA_R[7]_i_394\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => zp_sum,
      I1 => \VGA_R_reg[7]_i_96_n_0\,
      I2 => \VGA_R_reg[7]_i_216_n_5\,
      O => \VGA_R[7]_i_394_n_0\
    );
\VGA_R[7]_i_395\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"659A"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_96_n_0\,
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      I3 => \VGA_R_reg[7]_i_216_n_6\,
      O => \VGA_R[7]_i_395_n_0\
    );
\VGA_R[7]_i_396\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_96_n_0\,
      I1 => \VGA_R_reg[7]_i_216_n_7\,
      O => \VGA_R[7]_i_396_n_0\
    );
\VGA_R[7]_i_397\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6966"
    )
        port map (
      I0 => \^p_1_in\(5),
      I1 => \VGA_R_reg[7]_i_96_n_0\,
      I2 => timing_sel(1),
      I3 => timing_sel(0),
      O => \VGA_R[7]_i_397_n_0\
    );
\VGA_R[7]_i_398\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \^p_1_in\(6),
      O => \VGA_R[7]_i_398_n_0\
    );
\VGA_R[7]_i_399\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => zp_sum,
      I1 => \VGA_R_reg[7]_i_97_n_0\,
      I2 => \VGA_R_reg[7]_i_221_n_5\,
      O => \VGA_R[7]_i_399_n_0\
    );
\VGA_R[7]_i_400\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"659A"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_97_n_0\,
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      I3 => \VGA_R_reg[7]_i_221_n_6\,
      O => \VGA_R[7]_i_400_n_0\
    );
\VGA_R[7]_i_401\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_97_n_0\,
      I1 => \VGA_R_reg[7]_i_221_n_7\,
      O => \VGA_R[7]_i_401_n_0\
    );
\VGA_R[7]_i_402\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6966"
    )
        port map (
      I0 => \^p_1_in\(6),
      I1 => \VGA_R_reg[7]_i_97_n_0\,
      I2 => timing_sel(1),
      I3 => timing_sel(0),
      O => \VGA_R[7]_i_402_n_0\
    );
\VGA_R[7]_i_403\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \^p_1_in\(7),
      O => \VGA_R[7]_i_403_n_0\
    );
\VGA_R[7]_i_404\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => zp_sum,
      I1 => \VGA_R_reg[7]_i_98_n_0\,
      I2 => \VGA_R_reg[7]_i_226_n_5\,
      O => \VGA_R[7]_i_404_n_0\
    );
\VGA_R[7]_i_405\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"659A"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_98_n_0\,
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      I3 => \VGA_R_reg[7]_i_226_n_6\,
      O => \VGA_R[7]_i_405_n_0\
    );
\VGA_R[7]_i_406\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_98_n_0\,
      I1 => \VGA_R_reg[7]_i_226_n_7\,
      O => \VGA_R[7]_i_406_n_0\
    );
\VGA_R[7]_i_407\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6966"
    )
        port map (
      I0 => \^p_1_in\(7),
      I1 => \VGA_R_reg[7]_i_98_n_0\,
      I2 => timing_sel(1),
      I3 => timing_sel(0),
      O => \VGA_R[7]_i_407_n_0\
    );
\VGA_R[7]_i_408\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \^p_1_in\(8),
      O => \VGA_R[7]_i_408_n_0\
    );
\VGA_R[7]_i_409\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => zp_sum,
      I1 => \VGA_R_reg[7]_i_99_n_0\,
      I2 => \VGA_R_reg[7]_i_231_n_5\,
      O => \VGA_R[7]_i_409_n_0\
    );
\VGA_R[7]_i_41\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"FE"
    )
        port map (
      I0 => \pattern_b3__4\,
      I1 => \pattern_b1__1\,
      I2 => pattern_b20_out,
      O => \VGA_R[7]_i_41_n_0\
    );
\VGA_R[7]_i_410\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"659A"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_99_n_0\,
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      I3 => \VGA_R_reg[7]_i_231_n_6\,
      O => \VGA_R[7]_i_410_n_0\
    );
\VGA_R[7]_i_411\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_99_n_0\,
      I1 => \VGA_R_reg[7]_i_231_n_7\,
      O => \VGA_R[7]_i_411_n_0\
    );
\VGA_R[7]_i_412\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6966"
    )
        port map (
      I0 => \^p_1_in\(8),
      I1 => \VGA_R_reg[7]_i_99_n_0\,
      I2 => timing_sel(1),
      I3 => timing_sel(0),
      O => \VGA_R[7]_i_412_n_0\
    );
\VGA_R[7]_i_413\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \^p_1_in\(9),
      O => \VGA_R[7]_i_413_n_0\
    );
\VGA_R[7]_i_414\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => zp_sum,
      I1 => \VGA_R_reg[7]_i_100_n_0\,
      I2 => \VGA_R_reg[7]_i_236_n_5\,
      O => \VGA_R[7]_i_414_n_0\
    );
\VGA_R[7]_i_415\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"659A"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_100_n_0\,
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      I3 => \VGA_R_reg[7]_i_236_n_6\,
      O => \VGA_R[7]_i_415_n_0\
    );
\VGA_R[7]_i_416\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_100_n_0\,
      I1 => \VGA_R_reg[7]_i_236_n_7\,
      O => \VGA_R[7]_i_416_n_0\
    );
\VGA_R[7]_i_417\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_100_n_0\,
      I1 => \VGA_R_reg[7]_i_231_0\,
      I2 => \^p_1_in\(9),
      O => \VGA_R[7]_i_417_n_0\
    );
\VGA_R[7]_i_418\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \^p_1_in\(10),
      O => \VGA_R[7]_i_418_n_0\
    );
\VGA_R[7]_i_42\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFFE"
    )
        port map (
      I0 => \^p_1_in\(9),
      I1 => \^p_1_in\(8),
      I2 => \^p_1_in\(6),
      I3 => \^p_1_in\(10),
      I4 => \^p_1_in\(7),
      O => \VGA_R[7]_i_42_n_0\
    );
\VGA_R[7]_i_422\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"659A"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_236_0\(0),
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      I3 => \^p_1_in\(10),
      O => \VGA_R[7]_i_422_n_0\
    );
\VGA_R[7]_i_428\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00800800"
    )
        port map (
      I0 => FCNT(0),
      I1 => FCNT(1),
      I2 => FCNT(2),
      I3 => \VGA_R[7]_i_432_n_0\,
      I4 => FCNT(3),
      O => \VGA_R[7]_i_428_n_0\
    );
\VGA_R[7]_i_429\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"A955"
    )
        port map (
      I0 => FCNT(4),
      I1 => FCNT(3),
      I2 => FCNT(2),
      I3 => \VGA_R[7]_i_432_n_0\,
      O => \VGA_R[7]_i_429_n_0\
    );
\VGA_R[7]_i_43\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"4004"
    )
        port map (
      I0 => pattern_sel(1),
      I1 => pattern_sel(0),
      I2 => FCNT(5),
      I3 => FCNT(6),
      O => \VGA_R[7]_i_43_n_0\
    );
\VGA_R[7]_i_430\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"59"
    )
        port map (
      I0 => FCNT(3),
      I1 => \VGA_R[7]_i_432_n_0\,
      I2 => FCNT(2),
      O => \VGA_R[7]_i_430_n_0\
    );
\VGA_R[7]_i_431\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => FCNT(2),
      I1 => \VGA_R[7]_i_432_n_0\,
      O => \VGA_R[7]_i_431_n_0\
    );
\VGA_R[7]_i_432\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0400"
    )
        port map (
      I0 => \VGA_R[7]_i_476_n_0\,
      I1 => FCNT(7),
      I2 => timing_sel(1),
      I3 => timing_sel(0),
      O => \VGA_R[7]_i_432_n_0\
    );
\VGA_R[7]_i_433\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"1F"
    )
        port map (
      I0 => FCNT(2),
      I1 => FCNT(3),
      I2 => FCNT(4),
      O => \VGA_R[7]_i_433_n_0\
    );
\VGA_R[7]_i_434\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8880"
    )
        port map (
      I0 => FCNT(5),
      I1 => FCNT(4),
      I2 => FCNT(3),
      I3 => FCNT(2),
      O => \VGA_R[7]_i_434_n_0\
    );
\VGA_R[7]_i_44\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00005504"
    )
        port map (
      I0 => HCNT(7),
      I1 => timing_sel(0),
      I2 => timing_sel(1),
      I3 => VGA_HS_i_2_n_0,
      I4 => HCNT(6),
      O => \VGA_R[7]_i_44_n_0\
    );
\VGA_R[7]_i_45\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"4D"
    )
        port map (
      I0 => HCNT(5),
      I1 => VGA_HS_i_2_n_0,
      I2 => HCNT(4),
      O => \VGA_R[7]_i_45_n_0\
    );
\VGA_R[7]_i_451\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^p_1_in\(8),
      O => \VGA_R[7]_i_451_n_0\
    );
\VGA_R[7]_i_452\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^p_1_in\(7),
      I1 => \^p_1_in\(10),
      O => \VGA_R[7]_i_452_n_0\
    );
\VGA_R[7]_i_453\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^p_1_in\(6),
      I1 => \^p_1_in\(9),
      O => \VGA_R[7]_i_453_n_0\
    );
\VGA_R[7]_i_454\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^p_1_in\(5),
      I1 => \^p_1_in\(8),
      O => \VGA_R[7]_i_454_n_0\
    );
\VGA_R[7]_i_46\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"105510DF"
    )
        port map (
      I0 => HCNT(3),
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      I3 => VGA_HS_i_2_n_0,
      I4 => HCNT(2),
      O => \VGA_R[7]_i_46_n_0\
    );
\VGA_R[7]_i_47\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"10117577"
    )
        port map (
      I0 => HCNT(1),
      I1 => VGA_HS_i_2_n_0,
      I2 => timing_sel(1),
      I3 => timing_sel(0),
      I4 => HCNT(0),
      O => \VGA_R[7]_i_47_n_0\
    );
\VGA_R[7]_i_476\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"01555555"
    )
        port map (
      I0 => FCNT(6),
      I1 => FCNT(2),
      I2 => FCNT(3),
      I3 => FCNT(4),
      I4 => FCNT(5),
      O => \VGA_R[7]_i_476_n_0\
    );
\VGA_R[7]_i_48\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"55040051"
    )
        port map (
      I0 => HCNT(7),
      I1 => timing_sel(0),
      I2 => timing_sel(1),
      I3 => VGA_HS_i_2_n_0,
      I4 => HCNT(6),
      O => \VGA_R[7]_i_48_n_0\
    );
\VGA_R[7]_i_49\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"82"
    )
        port map (
      I0 => HCNT(4),
      I1 => VGA_HS_i_2_n_0,
      I2 => HCNT(5),
      O => \VGA_R[7]_i_49_n_0\
    );
\VGA_R[7]_i_499\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_450_n_6\,
      I1 => sel0(6),
      O => \VGA_R[7]_i_499_n_0\
    );
\VGA_R[7]_i_50\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00A25908"
    )
        port map (
      I0 => HCNT(3),
      I1 => timing_sel(0),
      I2 => timing_sel(1),
      I3 => VGA_HS_i_2_n_0,
      I4 => HCNT(2),
      O => \VGA_R[7]_i_50_n_0\
    );
\VGA_R[7]_i_500\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_450_n_5\,
      I1 => sel0(7),
      O => \VGA_R[7]_i_500_n_0\
    );
\VGA_R[7]_i_502\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^p_1_in\(4),
      I1 => \^p_1_in\(7),
      O => \VGA_R[7]_i_502_n_0\
    );
\VGA_R[7]_i_503\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^p_1_in\(3),
      I1 => \^p_1_in\(6),
      O => \VGA_R[7]_i_503_n_0\
    );
\VGA_R[7]_i_504\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^p_1_in\(2),
      I1 => \^p_1_in\(5),
      O => \VGA_R[7]_i_504_n_0\
    );
\VGA_R[7]_i_505\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \^p_1_in\(1),
      I1 => \^p_1_in\(4),
      O => \VGA_R[7]_i_505_n_0\
    );
\VGA_R[7]_i_506\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_317_n_5\,
      I1 => sel0(11),
      O => \VGA_R[7]_i_506_n_0\
    );
\VGA_R[7]_i_507\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^p_1_in\(10),
      O => \VGA_R[7]_i_507_n_0\
    );
\VGA_R[7]_i_508\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^p_1_in\(9),
      O => \VGA_R[7]_i_508_n_0\
    );
\VGA_R[7]_i_509\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_450_n_4\,
      I1 => sel0(8),
      O => \VGA_R[7]_i_509_n_0\
    );
\VGA_R[7]_i_51\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00A2AA08"
    )
        port map (
      I0 => HCNT(0),
      I1 => timing_sel(0),
      I2 => timing_sel(1),
      I3 => VGA_HS_i_2_n_0,
      I4 => HCNT(1),
      O => \VGA_R[7]_i_51_n_0\
    );
\VGA_R[7]_i_510\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_317_n_7\,
      I1 => sel0(9),
      O => \VGA_R[7]_i_510_n_0\
    );
\VGA_R[7]_i_511\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_317_n_6\,
      I1 => sel0(10),
      O => \VGA_R[7]_i_511_n_0\
    );
\VGA_R[7]_i_52\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"8AE308A2"
    )
        port map (
      I0 => HCNT(7),
      I1 => \VGA_R_reg[7]_i_16_1\,
      I2 => zp_sum0(1),
      I3 => zp_sum0(2),
      I4 => HCNT(6),
      O => \VGA_R[7]_i_52_n_0\
    );
\VGA_R[7]_i_53\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"8AE308A2"
    )
        port map (
      I0 => HCNT(5),
      I1 => \VGA_R_reg[7]_i_16_0\,
      I2 => zp_sum0_0(0),
      I3 => zp_sum0(0),
      I4 => HCNT(4),
      O => \VGA_R[7]_i_53_n_0\
    );
\VGA_R[7]_i_54\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"2ABC02A8"
    )
        port map (
      I0 => HCNT(3),
      I1 => O(0),
      I2 => O(1),
      I3 => O(2),
      I4 => HCNT(2),
      O => \VGA_R[7]_i_54_n_0\
    );
\VGA_R[7]_i_55\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => HCNT(1),
      I1 => O(0),
      O => \VGA_R[7]_i_55_n_0\
    );
\VGA_R[7]_i_556\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => HCNT(0),
      O => \VGA_R[7]_i_556_n_0\
    );
\VGA_R[7]_i_557\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => HCNT(0),
      I1 => \^p_1_in\(3),
      O => \VGA_R[7]_i_557_n_0\
    );
\VGA_R[7]_i_558\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^p_1_in\(2),
      O => \VGA_R[7]_i_558_n_0\
    );
\VGA_R[7]_i_559\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^p_1_in\(1),
      O => \VGA_R[7]_i_559_n_0\
    );
\VGA_R[7]_i_56\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"06909009"
    )
        port map (
      I0 => zp_sum0(2),
      I1 => HCNT(7),
      I2 => zp_sum0(1),
      I3 => \VGA_R_reg[7]_i_16_1\,
      I4 => HCNT(6),
      O => \VGA_R[7]_i_56_n_0\
    );
\VGA_R[7]_i_560\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => HCNT(0),
      O => \VGA_R[7]_i_560_n_0\
    );
\VGA_R[7]_i_57\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"06909009"
    )
        port map (
      I0 => zp_sum0(0),
      I1 => HCNT(5),
      I2 => zp_sum0_0(0),
      I3 => \VGA_R_reg[7]_i_16_0\,
      I4 => HCNT(4),
      O => \VGA_R[7]_i_57_n_0\
    );
\VGA_R[7]_i_58\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"90060990"
    )
        port map (
      I0 => O(2),
      I1 => HCNT(3),
      I2 => O(0),
      I3 => O(1),
      I4 => HCNT(2),
      O => \VGA_R[7]_i_58_n_0\
    );
\VGA_R[7]_i_59\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"60"
    )
        port map (
      I0 => O(0),
      I1 => HCNT(1),
      I2 => HCNT(0),
      O => \VGA_R[7]_i_59_n_0\
    );
\VGA_R[7]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2222E22200000000"
    )
        port map (
      I0 => P(4),
      I1 => \VGA_R_reg[6]_0\,
      I2 => \VGA_R[7]_i_26_n_0\,
      I3 => \VGA_R[7]_i_27_n_0\,
      I4 => \VGA_R[7]_i_28_n_0\,
      I5 => \VGA_R_reg[6]\,
      O => \VGA_R[7]_i_6_n_0\
    );
\VGA_R[7]_i_61\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => VCNT(7),
      I1 => VCNT(6),
      O => \VGA_R[7]_i_61_n_0\
    );
\VGA_R[7]_i_62\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"A8"
    )
        port map (
      I0 => VCNT(5),
      I1 => VGA_HS_i_2_n_0,
      I2 => VCNT(4),
      O => \VGA_R[7]_i_62_n_0\
    );
\VGA_R[7]_i_63\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8A"
    )
        port map (
      I0 => VCNT(1),
      I1 => VCNT(0),
      I2 => VGA_HS_i_2_n_0,
      O => \VGA_R[7]_i_63_n_0\
    );
\VGA_R[7]_i_64\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => VCNT(6),
      I1 => VCNT(7),
      O => \VGA_R[7]_i_64_n_0\
    );
\VGA_R[7]_i_65\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"42"
    )
        port map (
      I0 => VCNT(5),
      I1 => VCNT(4),
      I2 => VGA_HS_i_2_n_0,
      O => \VGA_R[7]_i_65_n_0\
    );
\VGA_R[7]_i_66\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => VCNT(2),
      I1 => VCNT(3),
      O => \VGA_R[7]_i_66_n_0\
    );
\VGA_R[7]_i_67\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"42"
    )
        port map (
      I0 => VCNT(0),
      I1 => VGA_HS_i_2_n_0,
      I2 => VCNT(1),
      O => \VGA_R[7]_i_67_n_0\
    );
\VGA_R[7]_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFAFEEEEAAAAAAAA"
    )
        port map (
      I0 => pattern_sel(2),
      I1 => data2(7),
      I2 => \VGA_R[7]_i_31_n_0\,
      I3 => \VGA_R[7]_i_32_n_0\,
      I4 => pattern_sel(0),
      I5 => pattern_sel(1),
      O => \VGA_R[7]_i_7_n_0\
    );
\VGA_R[7]_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000155555555"
    )
        port map (
      I0 => pattern_sel(1),
      I1 => \VGA_R_reg[7]_i_33_n_0\,
      I2 => \VGA_B_reg[7]\,
      I3 => \VGA_R[7]_i_35_n_0\,
      I4 => \VGA_R[7]_i_36_n_0\,
      I5 => \VGA_R[7]_i_37_n_0\,
      O => \VGA_R[7]_i_8_n_0\
    );
\VGA_R[7]_i_88\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_G_reg[7]_i_6_n_0\,
      I1 => \VGA_G_reg[7]_i_6_n_5\,
      O => \VGA_R[7]_i_88_n_0\
    );
\VGA_R[7]_i_89\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \VGA_G_reg[7]_i_6_n_0\,
      I1 => zp_sum,
      I2 => \VGA_G_reg[7]_i_6_n_6\,
      O => \VGA_R[7]_i_89_n_0\
    );
\VGA_R[7]_i_9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2AAA22222AAAAAAA"
    )
        port map (
      I0 => pattern_sel(2),
      I1 => pattern_sel(1),
      I2 => \VGA_R_reg[7]_i_38_n_3\,
      I3 => pattern_b11_in,
      I4 => pattern_sel(0),
      I5 => data6(7),
      O => \VGA_R[7]_i_9_n_0\
    );
\VGA_R[7]_i_90\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => zp_sum,
      I1 => \VGA_G_reg[7]_i_6_n_0\,
      I2 => \VGA_G_reg[7]_i_6_n_7\,
      O => \VGA_R[7]_i_90_n_0\
    );
\VGA_R[7]_i_91\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \VGA_G_reg[7]_i_6_n_0\,
      I1 => zp_sum,
      I2 => \VGA_R_reg[7]_i_87_n_4\,
      O => \VGA_R[7]_i_91_n_0\
    );
\VGA_R_reg[4]_i_5\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[4]_i_8_n_0\,
      CO(3 downto 2) => \NLW_VGA_R_reg[4]_i_5_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \VGA_R_reg[4]_i_5_n_2\,
      CO(0) => \VGA_R_reg[4]_i_5_n_3\,
      CYINIT => '0',
      DI(3 downto 1) => B"000",
      DI(0) => \VGA_R[4]_i_9_n_0\,
      O(3 downto 0) => \NLW_VGA_R_reg[4]_i_5_O_UNCONNECTED\(3 downto 0),
      S(3 downto 2) => B"00",
      S(1) => \VGA_R[4]_i_10_n_0\,
      S(0) => \VGA_R[4]_i_11_n_0\
    );
\VGA_R_reg[4]_i_8\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[4]_i_8_n_0\,
      CO(2) => \VGA_R_reg[4]_i_8_n_1\,
      CO(1) => \VGA_R_reg[4]_i_8_n_2\,
      CO(0) => \VGA_R_reg[4]_i_8_n_3\,
      CYINIT => '0',
      DI(3) => \VGA_R[4]_i_22_n_0\,
      DI(2) => \VGA_R[4]_i_23_n_0\,
      DI(1) => \VGA_R[4]_i_24_n_0\,
      DI(0) => \VGA_R[4]_i_25_n_0\,
      O(3 downto 0) => \NLW_VGA_R_reg[4]_i_8_O_UNCONNECTED\(3 downto 0),
      S(3) => \VGA_R[4]_i_26_n_0\,
      S(2) => \VGA_R[4]_i_27_n_0\,
      S(1) => \VGA_R[4]_i_28_n_0\,
      S(0) => \VGA_R[4]_i_29_n_0\
    );
\VGA_R_reg[5]_i_11\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[5]_i_31_n_0\,
      CO(3 downto 2) => \NLW_VGA_R_reg[5]_i_11_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \VGA_R_reg[5]_i_11_n_2\,
      CO(0) => \VGA_R_reg[5]_i_11_n_3\,
      CYINIT => '0',
      DI(3 downto 1) => B"000",
      DI(0) => \VGA_R[5]_i_32_n_0\,
      O(3 downto 0) => \NLW_VGA_R_reg[5]_i_11_O_UNCONNECTED\(3 downto 0),
      S(3 downto 2) => B"00",
      S(1) => \VGA_R[5]_i_33_n_0\,
      S(0) => \VGA_R[5]_i_34_n_0\
    );
\VGA_R_reg[5]_i_12\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[5]_i_35_n_0\,
      CO(3 downto 2) => \NLW_VGA_R_reg[5]_i_12_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \VGA_R_reg[5]_i_12_n_2\,
      CO(0) => \VGA_R_reg[5]_i_12_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \VGA_R[5]_i_36_n_0\,
      DI(0) => \VGA_R[5]_i_37_n_0\,
      O(3 downto 0) => \NLW_VGA_R_reg[5]_i_12_O_UNCONNECTED\(3 downto 0),
      S(3 downto 2) => B"00",
      S(1) => \VGA_R[5]_i_38_n_0\,
      S(0) => \VGA_R[5]_i_39_n_0\
    );
\VGA_R_reg[5]_i_13\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[5]_i_40_n_0\,
      CO(3 downto 2) => \NLW_VGA_R_reg[5]_i_13_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \VGA_R_reg[5]_i_13_n_2\,
      CO(0) => \VGA_R_reg[5]_i_13_n_3\,
      CYINIT => '0',
      DI(3 downto 1) => B"000",
      DI(0) => \VGA_R[5]_i_41_n_0\,
      O(3 downto 0) => \NLW_VGA_R_reg[5]_i_13_O_UNCONNECTED\(3 downto 0),
      S(3 downto 2) => B"00",
      S(1) => \VGA_R[5]_i_42_n_0\,
      S(0) => \VGA_R[5]_i_43_n_0\
    );
\VGA_R_reg[5]_i_14\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[5]_i_14_n_0\,
      CO(2) => \VGA_R_reg[5]_i_14_n_1\,
      CO(1) => \VGA_R_reg[5]_i_14_n_2\,
      CO(0) => \VGA_R_reg[5]_i_14_n_3\,
      CYINIT => '0',
      DI(3) => \VGA_R[5]_i_44_n_0\,
      DI(2) => \VGA_R[5]_i_45_n_0\,
      DI(1) => \VGA_R[5]_i_46_n_0\,
      DI(0) => \VGA_R[5]_i_47_n_0\,
      O(3 downto 0) => \NLW_VGA_R_reg[5]_i_14_O_UNCONNECTED\(3 downto 0),
      S(3) => \VGA_R[5]_i_48_n_0\,
      S(2) => \VGA_R[5]_i_49_n_0\,
      S(1) => \VGA_R[5]_i_50_n_0\,
      S(0) => \VGA_R[5]_i_51_n_0\
    );
\VGA_R_reg[5]_i_18\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[5]_i_18_n_0\,
      CO(2) => \VGA_R_reg[5]_i_18_n_1\,
      CO(1) => \VGA_R_reg[5]_i_18_n_2\,
      CO(0) => \VGA_R_reg[5]_i_18_n_3\,
      CYINIT => '0',
      DI(3) => \VGA_R[5]_i_52_n_0\,
      DI(2) => \VGA_R[5]_i_53_n_0\,
      DI(1) => \VGA_R[5]_i_54_n_0\,
      DI(0) => \VGA_R[5]_i_55_n_0\,
      O(3 downto 0) => \NLW_VGA_R_reg[5]_i_18_O_UNCONNECTED\(3 downto 0),
      S(3) => \VGA_R[5]_i_56_n_0\,
      S(2) => \VGA_R[5]_i_57_n_0\,
      S(1) => \VGA_R[5]_i_58_n_0\,
      S(0) => \VGA_R[5]_i_59_n_0\
    );
\VGA_R_reg[5]_i_31\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[5]_i_31_n_0\,
      CO(2) => \VGA_R_reg[5]_i_31_n_1\,
      CO(1) => \VGA_R_reg[5]_i_31_n_2\,
      CO(0) => \VGA_R_reg[5]_i_31_n_3\,
      CYINIT => '0',
      DI(3) => \VGA_R[5]_i_70_n_0\,
      DI(2) => \VGA_R[5]_i_71_n_0\,
      DI(1) => \VGA_R[5]_i_72_n_0\,
      DI(0) => \VGA_R[5]_i_73_n_0\,
      O(3 downto 0) => \NLW_VGA_R_reg[5]_i_31_O_UNCONNECTED\(3 downto 0),
      S(3) => \VGA_R[5]_i_74_n_0\,
      S(2) => \VGA_R[5]_i_75_n_0\,
      S(1) => \VGA_R[5]_i_76_n_0\,
      S(0) => \VGA_R[5]_i_77_n_0\
    );
\VGA_R_reg[5]_i_35\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[5]_i_35_n_0\,
      CO(2) => \VGA_R_reg[5]_i_35_n_1\,
      CO(1) => \VGA_R_reg[5]_i_35_n_2\,
      CO(0) => \VGA_R_reg[5]_i_35_n_3\,
      CYINIT => '0',
      DI(3) => \VGA_R[5]_i_80_n_0\,
      DI(2) => \VGA_R[5]_i_81_n_0\,
      DI(1) => \VGA_R[5]_i_82_n_0\,
      DI(0) => \VGA_R[5]_i_83_n_0\,
      O(3 downto 0) => \NLW_VGA_R_reg[5]_i_35_O_UNCONNECTED\(3 downto 0),
      S(3) => \VGA_R[5]_i_84_n_0\,
      S(2) => \VGA_R[5]_i_85_n_0\,
      S(1) => \VGA_R[5]_i_86_n_0\,
      S(0) => \VGA_R[5]_i_87_n_0\
    );
\VGA_R_reg[5]_i_40\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[5]_i_40_n_0\,
      CO(2) => \VGA_R_reg[5]_i_40_n_1\,
      CO(1) => \VGA_R_reg[5]_i_40_n_2\,
      CO(0) => \VGA_R_reg[5]_i_40_n_3\,
      CYINIT => '0',
      DI(3) => \VGA_R[5]_i_88_n_0\,
      DI(2) => \VGA_R[5]_i_89_n_0\,
      DI(1) => \VGA_R[5]_i_90_n_0\,
      DI(0) => \VGA_R[5]_i_91_n_0\,
      O(3 downto 0) => \NLW_VGA_R_reg[5]_i_40_O_UNCONNECTED\(3 downto 0),
      S(3) => \VGA_R[5]_i_92_n_0\,
      S(2) => \VGA_R[5]_i_93_n_0\,
      S(1) => \VGA_R[5]_i_94_n_0\,
      S(0) => \VGA_R[5]_i_95_n_0\
    );
\VGA_R_reg[5]_i_7\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[5]_i_14_n_0\,
      CO(3 downto 2) => \NLW_VGA_R_reg[5]_i_7_CO_UNCONNECTED\(3 downto 2),
      CO(1) => sel0(32),
      CO(0) => \VGA_R_reg[5]_i_7_n_3\,
      CYINIT => '0',
      DI(3 downto 1) => B"000",
      DI(0) => \VGA_R[5]_i_15_n_0\,
      O(3 downto 0) => \NLW_VGA_R_reg[5]_i_7_O_UNCONNECTED\(3 downto 0),
      S(3 downto 2) => B"00",
      S(1) => \VGA_R[5]_i_16_n_0\,
      S(0) => \VGA_R[5]_i_17_n_0\
    );
\VGA_R_reg[5]_i_8\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[5]_i_18_n_0\,
      CO(3 downto 2) => \NLW_VGA_R_reg[5]_i_8_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \VGA_R_reg[5]_i_8_n_2\,
      CO(0) => \VGA_R_reg[5]_i_8_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => \NLW_VGA_R_reg[5]_i_8_O_UNCONNECTED\(3 downto 0),
      S(3 downto 2) => B"00",
      S(1) => \VGA_R[5]_i_19_n_0\,
      S(0) => \VGA_R[5]_i_20_n_0\
    );
\VGA_R_reg[7]_i_100\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_236_n_0\,
      CO(3) => \VGA_R_reg[7]_i_100_n_0\,
      CO(2) => \VGA_R_reg[7]_i_100_n_1\,
      CO(1) => \VGA_R_reg[7]_i_100_n_2\,
      CO(0) => \VGA_R_reg[7]_i_100_n_3\,
      CYINIT => '0',
      DI(3) => \VGA_R_reg[7]_i_236_0\(0),
      DI(2 downto 1) => \VGA_R_reg[7]_i_99_1\(1 downto 0),
      DI(0) => \VGA_R_reg[7]_i_99_0\(2),
      O(3) => \NLW_VGA_R_reg[7]_i_100_O_UNCONNECTED\(3),
      O(2) => \VGA_R_reg[7]_i_100_n_5\,
      O(1) => \VGA_R_reg[7]_i_100_n_6\,
      O(0) => \VGA_R_reg[7]_i_100_n_7\,
      S(3 downto 0) => \VGA_R_reg[7]_i_99_2\(3 downto 0)
    );
\VGA_R_reg[7]_i_102\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[7]_i_102_n_0\,
      CO(2) => \VGA_R_reg[7]_i_102_n_1\,
      CO(1) => \VGA_R_reg[7]_i_102_n_2\,
      CO(0) => \VGA_R_reg[7]_i_102_n_3\,
      CYINIT => '0',
      DI(3) => \VGA_R[7]_i_250_n_0\,
      DI(2) => \VGA_R[7]_i_251_n_0\,
      DI(1) => \VGA_R[7]_i_252_n_0\,
      DI(0) => \VGA_R[7]_i_253_n_0\,
      O(3 downto 0) => \NLW_VGA_R_reg[7]_i_102_O_UNCONNECTED\(3 downto 0),
      S(3) => \VGA_R[7]_i_254_n_0\,
      S(2) => \VGA_R[7]_i_255_n_0\,
      S(1) => \VGA_R[7]_i_256_n_0\,
      S(0) => \VGA_R[7]_i_257_n_0\
    );
\VGA_R_reg[7]_i_105\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[7]_i_105_n_0\,
      CO(2) => \VGA_R_reg[7]_i_105_n_1\,
      CO(1) => \VGA_R_reg[7]_i_105_n_2\,
      CO(0) => \VGA_R_reg[7]_i_105_n_3\,
      CYINIT => '1',
      DI(3) => \VGA_R[7]_i_262_n_0\,
      DI(2) => \VGA_R[7]_i_263_n_0\,
      DI(1) => \VGA_R[7]_i_264_n_0\,
      DI(0) => \VGA_R[7]_i_265_n_0\,
      O(3 downto 0) => \NLW_VGA_R_reg[7]_i_105_O_UNCONNECTED\(3 downto 0),
      S(3) => \VGA_R[7]_i_266_n_0\,
      S(2) => \VGA_R[7]_i_267_n_0\,
      S(1) => \VGA_R[7]_i_268_n_0\,
      S(0) => \VGA_R[7]_i_269_n_0\
    );
\VGA_R_reg[7]_i_11\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[7]_i_11_n_0\,
      CO(2) => \VGA_R_reg[7]_i_11_n_1\,
      CO(1) => \VGA_R_reg[7]_i_11_n_2\,
      CO(0) => \VGA_R_reg[7]_i_11_n_3\,
      CYINIT => '0',
      DI(3) => \VGA_R[7]_i_44_n_0\,
      DI(2) => \VGA_R[7]_i_45_n_0\,
      DI(1) => \VGA_R[7]_i_46_n_0\,
      DI(0) => \VGA_R[7]_i_47_n_0\,
      O(3 downto 0) => \NLW_VGA_R_reg[7]_i_11_O_UNCONNECTED\(3 downto 0),
      S(3) => \VGA_R[7]_i_48_n_0\,
      S(2) => \VGA_R[7]_i_49_n_0\,
      S(1) => \VGA_R[7]_i_50_n_0\,
      S(0) => \VGA_R[7]_i_51_n_0\
    );
\VGA_R_reg[7]_i_116\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \pattern_b3__4\,
      CO(2) => \VGA_R_reg[7]_i_116_n_1\,
      CO(1) => \VGA_R_reg[7]_i_116_n_2\,
      CO(0) => \VGA_R_reg[7]_i_116_n_3\,
      CYINIT => '1',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => \NLW_VGA_R_reg[7]_i_116_O_UNCONNECTED\(3 downto 0),
      S(3) => \VGA_R[7]_i_287_n_0\,
      S(2) => \VGA_R[7]_i_288_n_0\,
      S(1) => \VGA_R[7]_i_289_n_0\,
      S(0) => \VGA_R[7]_i_290_n_0\
    );
\VGA_R_reg[7]_i_117\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \pattern_b1__1\,
      CO(2) => \VGA_R_reg[7]_i_117_n_1\,
      CO(1) => \VGA_R_reg[7]_i_117_n_2\,
      CO(0) => \VGA_R_reg[7]_i_117_n_3\,
      CYINIT => '1',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => \NLW_VGA_R_reg[7]_i_117_O_UNCONNECTED\(3 downto 0),
      S(3) => \VGA_R[7]_i_291_n_0\,
      S(2) => \VGA_R[7]_i_292_n_0\,
      S(1) => \VGA_R[7]_i_293_n_0\,
      S(0) => \VGA_R[7]_i_294_n_0\
    );
\VGA_R_reg[7]_i_118\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => pattern_b20_out,
      CO(2) => \VGA_R_reg[7]_i_118_n_1\,
      CO(1) => \VGA_R_reg[7]_i_118_n_2\,
      CO(0) => \VGA_R_reg[7]_i_118_n_3\,
      CYINIT => '1',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => \NLW_VGA_R_reg[7]_i_118_O_UNCONNECTED\(3 downto 0),
      S(3) => \VGA_R[7]_i_295_n_0\,
      S(2) => \VGA_R[7]_i_296_n_0\,
      S(1) => \VGA_R[7]_i_297_n_0\,
      S(0) => \VGA_R[7]_i_298_n_0\
    );
\VGA_R_reg[7]_i_121\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[7]_i_121_n_0\,
      CO(2) => \VGA_R_reg[7]_i_121_n_1\,
      CO(1) => \VGA_R_reg[7]_i_121_n_2\,
      CO(0) => \VGA_R_reg[7]_i_121_n_3\,
      CYINIT => sel0(2),
      DI(3) => \VGA_R_reg[7]_i_122_n_5\,
      DI(2) => \VGA_R_reg[7]_i_122_n_6\,
      DI(1) => sel0(2),
      DI(0) => \VGA_R[7]_i_299_n_0\,
      O(3) => \VGA_R_reg[7]_i_121_n_4\,
      O(2) => \VGA_R_reg[7]_i_121_n_5\,
      O(1) => \VGA_R_reg[7]_i_121_n_6\,
      O(0) => \VGA_R_reg[7]_i_121_n_7\,
      S(3) => \VGA_R[7]_i_300_n_0\,
      S(2) => \VGA_R[7]_i_301_n_0\,
      S(1) => \VGA_R[7]_i_302_n_0\,
      S(0) => \VGA_R[7]_i_303_n_0\
    );
\VGA_R_reg[7]_i_122\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[7]_i_122_n_0\,
      CO(2) => \VGA_R_reg[7]_i_122_n_1\,
      CO(1) => \VGA_R_reg[7]_i_122_n_2\,
      CO(0) => \VGA_R_reg[7]_i_122_n_3\,
      CYINIT => sel0(3),
      DI(3) => \VGA_R_reg[7]_i_157_n_5\,
      DI(2) => \VGA_R_reg[7]_i_157_n_6\,
      DI(1) => sel0(3),
      DI(0) => \VGA_R[7]_i_304_n_0\,
      O(3) => \VGA_R_reg[7]_i_122_n_4\,
      O(2) => \VGA_R_reg[7]_i_122_n_5\,
      O(1) => \VGA_R_reg[7]_i_122_n_6\,
      O(0) => \VGA_R_reg[7]_i_122_n_7\,
      S(3) => \VGA_R[7]_i_305_n_0\,
      S(2) => \VGA_R[7]_i_306_n_0\,
      S(1) => \VGA_R[7]_i_307_n_0\,
      S(0) => \VGA_R[7]_i_308_n_0\
    );
\VGA_R_reg[7]_i_130\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[7]_i_130_n_0\,
      CO(2) => \VGA_R_reg[7]_i_130_n_1\,
      CO(1) => \VGA_R_reg[7]_i_130_n_2\,
      CO(0) => \VGA_R_reg[7]_i_130_n_3\,
      CYINIT => sel0(12),
      DI(3) => \VGA_R[7]_i_318_n_0\,
      DI(2) => \VGA_R[7]_i_343_0\(0),
      DI(1) => sel0(12),
      DI(0) => \VGA_R[7]_i_320_n_0\,
      O(3) => \VGA_R_reg[7]_i_130_n_4\,
      O(2) => \VGA_R_reg[7]_i_130_n_5\,
      O(1) => \VGA_R_reg[7]_i_130_n_6\,
      O(0) => \VGA_R_reg[7]_i_130_n_7\,
      S(3) => \VGA_R[7]_i_321_n_0\,
      S(2) => \VGA_R[7]_i_322_n_0\,
      S(1) => \VGA_R[7]_i_323_n_0\,
      S(0) => \VGA_R[7]_i_324_n_0\
    );
\VGA_R_reg[7]_i_136\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[7]_i_136_n_0\,
      CO(2) => \VGA_R_reg[7]_i_136_n_1\,
      CO(1) => \VGA_R_reg[7]_i_136_n_2\,
      CO(0) => \VGA_R_reg[7]_i_136_n_3\,
      CYINIT => sel0(7),
      DI(3) => \VGA_R_reg[7]_i_137_n_5\,
      DI(2) => \VGA_R_reg[7]_i_137_n_6\,
      DI(1) => sel0(7),
      DI(0) => \VGA_R[7]_i_325_n_0\,
      O(3) => \VGA_R_reg[7]_i_136_n_4\,
      O(2) => \VGA_R_reg[7]_i_136_n_5\,
      O(1) => \VGA_R_reg[7]_i_136_n_6\,
      O(0) => \VGA_R_reg[7]_i_136_n_7\,
      S(3) => \VGA_R[7]_i_326_n_0\,
      S(2) => \VGA_R[7]_i_327_n_0\,
      S(1) => \VGA_R[7]_i_328_n_0\,
      S(0) => \VGA_R[7]_i_329_n_0\
    );
\VGA_R_reg[7]_i_137\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[7]_i_137_n_0\,
      CO(2) => \VGA_R_reg[7]_i_137_n_1\,
      CO(1) => \VGA_R_reg[7]_i_137_n_2\,
      CO(0) => \VGA_R_reg[7]_i_137_n_3\,
      CYINIT => sel0(8),
      DI(3) => \VGA_R_reg[7]_i_148_n_5\,
      DI(2) => \VGA_R_reg[7]_i_148_n_6\,
      DI(1) => sel0(8),
      DI(0) => \VGA_R[7]_i_330_n_0\,
      O(3) => \VGA_R_reg[7]_i_137_n_4\,
      O(2) => \VGA_R_reg[7]_i_137_n_5\,
      O(1) => \VGA_R_reg[7]_i_137_n_6\,
      O(0) => \VGA_R_reg[7]_i_137_n_7\,
      S(3) => \VGA_R[7]_i_331_n_0\,
      S(2) => \VGA_R[7]_i_332_n_0\,
      S(1) => \VGA_R[7]_i_333_n_0\,
      S(0) => \VGA_R[7]_i_334_n_0\
    );
\VGA_R_reg[7]_i_142\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[7]_i_142_n_0\,
      CO(2) => \VGA_R_reg[7]_i_142_n_1\,
      CO(1) => \VGA_R_reg[7]_i_142_n_2\,
      CO(0) => \VGA_R_reg[7]_i_142_n_3\,
      CYINIT => sel0(10),
      DI(3) => \VGA_R_reg[7]_i_143_n_5\,
      DI(2) => \VGA_R_reg[7]_i_143_n_6\,
      DI(1) => sel0(10),
      DI(0) => \VGA_R[7]_i_335_n_0\,
      O(3) => \VGA_R_reg[7]_i_142_n_4\,
      O(2) => \VGA_R_reg[7]_i_142_n_5\,
      O(1) => \VGA_R_reg[7]_i_142_n_6\,
      O(0) => \VGA_R_reg[7]_i_142_n_7\,
      S(3) => \VGA_R[7]_i_336_n_0\,
      S(2) => \VGA_R[7]_i_337_n_0\,
      S(1) => \VGA_R[7]_i_338_n_0\,
      S(0) => \VGA_R[7]_i_339_n_0\
    );
\VGA_R_reg[7]_i_143\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[7]_i_143_n_0\,
      CO(2) => \VGA_R_reg[7]_i_143_n_1\,
      CO(1) => \VGA_R_reg[7]_i_143_n_2\,
      CO(0) => \VGA_R_reg[7]_i_143_n_3\,
      CYINIT => sel0(11),
      DI(3) => \VGA_R_reg[7]_i_130_n_5\,
      DI(2) => \VGA_R_reg[7]_i_130_n_6\,
      DI(1) => sel0(11),
      DI(0) => \VGA_R[7]_i_340_n_0\,
      O(3) => \VGA_R_reg[7]_i_143_n_4\,
      O(2) => \VGA_R_reg[7]_i_143_n_5\,
      O(1) => \VGA_R_reg[7]_i_143_n_6\,
      O(0) => \VGA_R_reg[7]_i_143_n_7\,
      S(3) => \VGA_R[7]_i_341_n_0\,
      S(2) => \VGA_R[7]_i_342_n_0\,
      S(1) => \VGA_R[7]_i_343_n_0\,
      S(0) => \VGA_R[7]_i_344_n_0\
    );
\VGA_R_reg[7]_i_148\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[7]_i_148_n_0\,
      CO(2) => \VGA_R_reg[7]_i_148_n_1\,
      CO(1) => \VGA_R_reg[7]_i_148_n_2\,
      CO(0) => \VGA_R_reg[7]_i_148_n_3\,
      CYINIT => sel0(9),
      DI(3) => \VGA_R_reg[7]_i_142_n_5\,
      DI(2) => \VGA_R_reg[7]_i_142_n_6\,
      DI(1) => sel0(9),
      DI(0) => \VGA_R[7]_i_345_n_0\,
      O(3) => \VGA_R_reg[7]_i_148_n_4\,
      O(2) => \VGA_R_reg[7]_i_148_n_5\,
      O(1) => \VGA_R_reg[7]_i_148_n_6\,
      O(0) => \VGA_R_reg[7]_i_148_n_7\,
      S(3) => \VGA_R[7]_i_346_n_0\,
      S(2) => \VGA_R[7]_i_347_n_0\,
      S(1) => \VGA_R[7]_i_348_n_0\,
      S(0) => \VGA_R[7]_i_349_n_0\
    );
\VGA_R_reg[7]_i_157\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[7]_i_157_n_0\,
      CO(2) => \VGA_R_reg[7]_i_157_n_1\,
      CO(1) => \VGA_R_reg[7]_i_157_n_2\,
      CO(0) => \VGA_R_reg[7]_i_157_n_3\,
      CYINIT => sel0(4),
      DI(3) => \VGA_R_reg[7]_i_158_n_5\,
      DI(2) => \VGA_R_reg[7]_i_158_n_6\,
      DI(1) => sel0(4),
      DI(0) => \VGA_R[7]_i_350_n_0\,
      O(3) => \VGA_R_reg[7]_i_157_n_4\,
      O(2) => \VGA_R_reg[7]_i_157_n_5\,
      O(1) => \VGA_R_reg[7]_i_157_n_6\,
      O(0) => \VGA_R_reg[7]_i_157_n_7\,
      S(3) => \VGA_R[7]_i_351_n_0\,
      S(2) => \VGA_R[7]_i_352_n_0\,
      S(1) => \VGA_R[7]_i_353_n_0\,
      S(0) => \VGA_R[7]_i_354_n_0\
    );
\VGA_R_reg[7]_i_158\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[7]_i_158_n_0\,
      CO(2) => \VGA_R_reg[7]_i_158_n_1\,
      CO(1) => \VGA_R_reg[7]_i_158_n_2\,
      CO(0) => \VGA_R_reg[7]_i_158_n_3\,
      CYINIT => sel0(5),
      DI(3) => \VGA_R_reg[7]_i_163_n_5\,
      DI(2) => \VGA_R_reg[7]_i_163_n_6\,
      DI(1) => sel0(5),
      DI(0) => \VGA_R[7]_i_355_n_0\,
      O(3) => \VGA_R_reg[7]_i_158_n_4\,
      O(2) => \VGA_R_reg[7]_i_158_n_5\,
      O(1) => \VGA_R_reg[7]_i_158_n_6\,
      O(0) => \VGA_R_reg[7]_i_158_n_7\,
      S(3) => \VGA_R[7]_i_356_n_0\,
      S(2) => \VGA_R[7]_i_357_n_0\,
      S(1) => \VGA_R[7]_i_358_n_0\,
      S(0) => \VGA_R[7]_i_359_n_0\
    );
\VGA_R_reg[7]_i_16\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[7]_i_16_n_0\,
      CO(2) => \VGA_R_reg[7]_i_16_n_1\,
      CO(1) => \VGA_R_reg[7]_i_16_n_2\,
      CO(0) => \VGA_R_reg[7]_i_16_n_3\,
      CYINIT => '1',
      DI(3) => \VGA_R[7]_i_52_n_0\,
      DI(2) => \VGA_R[7]_i_53_n_0\,
      DI(1) => \VGA_R[7]_i_54_n_0\,
      DI(0) => \VGA_R[7]_i_55_n_0\,
      O(3 downto 0) => \NLW_VGA_R_reg[7]_i_16_O_UNCONNECTED\(3 downto 0),
      S(3) => \VGA_R[7]_i_56_n_0\,
      S(2) => \VGA_R[7]_i_57_n_0\,
      S(1) => \VGA_R[7]_i_58_n_0\,
      S(0) => \VGA_R[7]_i_59_n_0\
    );
\VGA_R_reg[7]_i_163\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[7]_i_163_n_0\,
      CO(2) => \VGA_R_reg[7]_i_163_n_1\,
      CO(1) => \VGA_R_reg[7]_i_163_n_2\,
      CO(0) => \VGA_R_reg[7]_i_163_n_3\,
      CYINIT => sel0(6),
      DI(3) => \VGA_R_reg[7]_i_136_n_5\,
      DI(2) => \VGA_R_reg[7]_i_136_n_6\,
      DI(1) => sel0(6),
      DI(0) => \VGA_R[7]_i_360_n_0\,
      O(3) => \VGA_R_reg[7]_i_163_n_4\,
      O(2) => \VGA_R_reg[7]_i_163_n_5\,
      O(1) => \VGA_R_reg[7]_i_163_n_6\,
      O(0) => \VGA_R_reg[7]_i_163_n_7\,
      S(3) => \VGA_R[7]_i_361_n_0\,
      S(2) => \VGA_R[7]_i_362_n_0\,
      S(1) => \VGA_R[7]_i_363_n_0\,
      S(0) => \VGA_R[7]_i_364_n_0\
    );
\VGA_R_reg[7]_i_21\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[7]_i_21_n_0\,
      CO(2) => \VGA_R_reg[7]_i_21_n_1\,
      CO(1) => \VGA_R_reg[7]_i_21_n_2\,
      CO(0) => \VGA_R_reg[7]_i_21_n_3\,
      CYINIT => '1',
      DI(3) => \VGA_R[7]_i_61_n_0\,
      DI(2) => \VGA_R[7]_i_62_n_0\,
      DI(1) => '0',
      DI(0) => \VGA_R[7]_i_63_n_0\,
      O(3 downto 0) => \NLW_VGA_R_reg[7]_i_21_O_UNCONNECTED\(3 downto 0),
      S(3) => \VGA_R[7]_i_64_n_0\,
      S(2) => \VGA_R[7]_i_65_n_0\,
      S(1) => \VGA_R[7]_i_66_n_0\,
      S(0) => \VGA_R[7]_i_67_n_0\
    );
\VGA_R_reg[7]_i_211\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[7]_i_211_n_0\,
      CO(2) => \VGA_R_reg[7]_i_211_n_1\,
      CO(1) => \VGA_R_reg[7]_i_211_n_2\,
      CO(0) => \VGA_R_reg[7]_i_211_n_3\,
      CYINIT => \VGA_R_reg[7]_i_96_n_0\,
      DI(3) => \VGA_R_reg[7]_i_216_n_5\,
      DI(2) => \VGA_R_reg[7]_i_216_n_6\,
      DI(1) => \VGA_R_reg[7]_i_96_n_0\,
      DI(0) => \VGA_R[7]_i_393_n_0\,
      O(3) => \VGA_R_reg[7]_i_211_n_4\,
      O(2) => \VGA_R_reg[7]_i_211_n_5\,
      O(1) => \VGA_R_reg[7]_i_211_n_6\,
      O(0) => \VGA_R_reg[7]_i_211_n_7\,
      S(3) => \VGA_R[7]_i_394_n_0\,
      S(2) => \VGA_R[7]_i_395_n_0\,
      S(1) => \VGA_R[7]_i_396_n_0\,
      S(0) => \VGA_R[7]_i_397_n_0\
    );
\VGA_R_reg[7]_i_216\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[7]_i_216_n_0\,
      CO(2) => \VGA_R_reg[7]_i_216_n_1\,
      CO(1) => \VGA_R_reg[7]_i_216_n_2\,
      CO(0) => \VGA_R_reg[7]_i_216_n_3\,
      CYINIT => \VGA_R_reg[7]_i_97_n_0\,
      DI(3) => \VGA_R_reg[7]_i_221_n_5\,
      DI(2) => \VGA_R_reg[7]_i_221_n_6\,
      DI(1) => \VGA_R_reg[7]_i_97_n_0\,
      DI(0) => \VGA_R[7]_i_398_n_0\,
      O(3) => \VGA_R_reg[7]_i_216_n_4\,
      O(2) => \VGA_R_reg[7]_i_216_n_5\,
      O(1) => \VGA_R_reg[7]_i_216_n_6\,
      O(0) => \VGA_R_reg[7]_i_216_n_7\,
      S(3) => \VGA_R[7]_i_399_n_0\,
      S(2) => \VGA_R[7]_i_400_n_0\,
      S(1) => \VGA_R[7]_i_401_n_0\,
      S(0) => \VGA_R[7]_i_402_n_0\
    );
\VGA_R_reg[7]_i_221\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[7]_i_221_n_0\,
      CO(2) => \VGA_R_reg[7]_i_221_n_1\,
      CO(1) => \VGA_R_reg[7]_i_221_n_2\,
      CO(0) => \VGA_R_reg[7]_i_221_n_3\,
      CYINIT => \VGA_R_reg[7]_i_98_n_0\,
      DI(3) => \VGA_R_reg[7]_i_226_n_5\,
      DI(2) => \VGA_R_reg[7]_i_226_n_6\,
      DI(1) => \VGA_R_reg[7]_i_98_n_0\,
      DI(0) => \VGA_R[7]_i_403_n_0\,
      O(3) => \VGA_R_reg[7]_i_221_n_4\,
      O(2) => \VGA_R_reg[7]_i_221_n_5\,
      O(1) => \VGA_R_reg[7]_i_221_n_6\,
      O(0) => \VGA_R_reg[7]_i_221_n_7\,
      S(3) => \VGA_R[7]_i_404_n_0\,
      S(2) => \VGA_R[7]_i_405_n_0\,
      S(1) => \VGA_R[7]_i_406_n_0\,
      S(0) => \VGA_R[7]_i_407_n_0\
    );
\VGA_R_reg[7]_i_226\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[7]_i_226_n_0\,
      CO(2) => \VGA_R_reg[7]_i_226_n_1\,
      CO(1) => \VGA_R_reg[7]_i_226_n_2\,
      CO(0) => \VGA_R_reg[7]_i_226_n_3\,
      CYINIT => \VGA_R_reg[7]_i_99_n_0\,
      DI(3) => \VGA_R_reg[7]_i_231_n_5\,
      DI(2) => \VGA_R_reg[7]_i_231_n_6\,
      DI(1) => \VGA_R_reg[7]_i_99_n_0\,
      DI(0) => \VGA_R[7]_i_408_n_0\,
      O(3) => \VGA_R_reg[7]_i_226_n_4\,
      O(2) => \VGA_R_reg[7]_i_226_n_5\,
      O(1) => \VGA_R_reg[7]_i_226_n_6\,
      O(0) => \VGA_R_reg[7]_i_226_n_7\,
      S(3) => \VGA_R[7]_i_409_n_0\,
      S(2) => \VGA_R[7]_i_410_n_0\,
      S(1) => \VGA_R[7]_i_411_n_0\,
      S(0) => \VGA_R[7]_i_412_n_0\
    );
\VGA_R_reg[7]_i_231\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[7]_i_231_n_0\,
      CO(2) => \VGA_R_reg[7]_i_231_n_1\,
      CO(1) => \VGA_R_reg[7]_i_231_n_2\,
      CO(0) => \VGA_R_reg[7]_i_231_n_3\,
      CYINIT => \VGA_R_reg[7]_i_100_n_0\,
      DI(3) => \VGA_R_reg[7]_i_236_n_5\,
      DI(2) => \VGA_R_reg[7]_i_236_n_6\,
      DI(1) => \VGA_R_reg[7]_i_100_n_0\,
      DI(0) => \VGA_R[7]_i_413_n_0\,
      O(3) => \VGA_R_reg[7]_i_231_n_4\,
      O(2) => \VGA_R_reg[7]_i_231_n_5\,
      O(1) => \VGA_R_reg[7]_i_231_n_6\,
      O(0) => \VGA_R_reg[7]_i_231_n_7\,
      S(3) => \VGA_R[7]_i_414_n_0\,
      S(2) => \VGA_R[7]_i_415_n_0\,
      S(1) => \VGA_R[7]_i_416_n_0\,
      S(0) => \VGA_R[7]_i_417_n_0\
    );
\VGA_R_reg[7]_i_236\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[7]_i_236_n_0\,
      CO(2) => \VGA_R_reg[7]_i_236_n_1\,
      CO(1) => \VGA_R_reg[7]_i_236_n_2\,
      CO(0) => \VGA_R_reg[7]_i_236_n_3\,
      CYINIT => \VGA_R_reg[7]_i_236_0\(0),
      DI(3 downto 2) => \VGA_R_reg[7]_i_99_0\(1 downto 0),
      DI(1) => \VGA_R_reg[7]_i_236_0\(0),
      DI(0) => \VGA_R[7]_i_418_n_0\,
      O(3) => \VGA_R_reg[7]_i_236_n_4\,
      O(2) => \VGA_R_reg[7]_i_236_n_5\,
      O(1) => \VGA_R_reg[7]_i_236_n_6\,
      O(0) => \VGA_R_reg[7]_i_236_n_7\,
      S(3 downto 1) => S(2 downto 0),
      S(0) => \VGA_R[7]_i_422_n_0\
    );
\VGA_R_reg[7]_i_3\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_11_n_0\,
      CO(3 downto 2) => \NLW_VGA_R_reg[7]_i_3_CO_UNCONNECTED\(3 downto 2),
      CO(1) => disp_enable0,
      CO(0) => \VGA_R_reg[7]_i_3_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \VGA_R[7]_i_12_n_0\,
      DI(0) => \VGA_R[7]_i_13_n_0\,
      O(3 downto 0) => \NLW_VGA_R_reg[7]_i_3_O_UNCONNECTED\(3 downto 0),
      S(3 downto 2) => B"00",
      S(1) => \VGA_R[7]_i_14_n_0\,
      S(0) => \VGA_R[7]_i_15_n_0\
    );
\VGA_R_reg[7]_i_317\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_450_n_0\,
      CO(3) => \VGA_R_reg[7]_i_317_n_0\,
      CO(2) => \VGA_R_reg[7]_i_317_n_1\,
      CO(1) => \VGA_R_reg[7]_i_317_n_2\,
      CO(0) => \VGA_R_reg[7]_i_317_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => \^p_1_in\(8 downto 5),
      O(3) => \VGA_R_reg[7]_i_317_n_4\,
      O(2) => \VGA_R_reg[7]_i_317_n_5\,
      O(1) => \VGA_R_reg[7]_i_317_n_6\,
      O(0) => \VGA_R_reg[7]_i_317_n_7\,
      S(3) => \VGA_R[7]_i_451_n_0\,
      S(2) => \VGA_R[7]_i_452_n_0\,
      S(1) => \VGA_R[7]_i_453_n_0\,
      S(0) => \VGA_R[7]_i_454_n_0\
    );
\VGA_R_reg[7]_i_33\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_86_n_0\,
      CO(3) => \VGA_R_reg[7]_i_33_n_0\,
      CO(2) => \VGA_R_reg[7]_i_33_n_1\,
      CO(1) => \VGA_R_reg[7]_i_33_n_2\,
      CO(0) => \VGA_R_reg[7]_i_33_n_3\,
      CYINIT => '0',
      DI(3) => \VGA_G_reg[7]_i_6_n_0\,
      DI(2) => \VGA_G_reg[7]_i_6_n_6\,
      DI(1) => \VGA_G_reg[7]_i_6_n_7\,
      DI(0) => \VGA_R_reg[7]_i_87_n_4\,
      O(3) => \NLW_VGA_R_reg[7]_i_33_O_UNCONNECTED\(3),
      O(2) => \VGA_R_reg[7]_i_33_n_5\,
      O(1) => \VGA_R_reg[7]_i_33_n_6\,
      O(0) => \VGA_R_reg[7]_i_33_n_7\,
      S(3) => \VGA_R[7]_i_88_n_0\,
      S(2) => \VGA_R[7]_i_89_n_0\,
      S(1) => \VGA_R[7]_i_90_n_0\,
      S(0) => \VGA_R[7]_i_91_n_0\
    );
\VGA_R_reg[7]_i_38\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_102_n_0\,
      CO(3 downto 1) => \NLW_VGA_R_reg[7]_i_38_CO_UNCONNECTED\(3 downto 1),
      CO(0) => \VGA_R_reg[7]_i_38_n_3\,
      CYINIT => '0',
      DI(3 downto 1) => B"000",
      DI(0) => \VGA_R[7]_i_103_n_0\,
      O(3 downto 0) => \NLW_VGA_R_reg[7]_i_38_O_UNCONNECTED\(3 downto 0),
      S(3 downto 1) => B"000",
      S(0) => \VGA_R[7]_i_104_n_0\
    );
\VGA_R_reg[7]_i_39\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_105_n_0\,
      CO(3 downto 2) => \NLW_VGA_R_reg[7]_i_39_CO_UNCONNECTED\(3 downto 2),
      CO(1) => pattern_b11_in,
      CO(0) => \VGA_R_reg[7]_i_39_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \^p_1_in\(10),
      DI(0) => \VGA_R[7]_i_106_n_0\,
      O(3 downto 0) => \NLW_VGA_R_reg[7]_i_39_O_UNCONNECTED\(3 downto 0),
      S(3 downto 2) => B"00",
      S(1) => \VGA_R[7]_i_107_n_0\,
      S(0) => \VGA_R[7]_i_108_n_0\
    );
\VGA_R_reg[7]_i_4\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_16_n_0\,
      CO(3 downto 2) => \NLW_VGA_R_reg[7]_i_4_CO_UNCONNECTED\(3 downto 2),
      CO(1) => disp_enable1,
      CO(0) => \VGA_R_reg[7]_i_4_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \VGA_R[7]_i_17_n_0\,
      DI(0) => \VGA_R[7]_i_18_n_0\,
      O(3 downto 0) => \NLW_VGA_R_reg[7]_i_4_O_UNCONNECTED\(3 downto 0),
      S(3 downto 2) => B"00",
      S(1) => \VGA_R[7]_i_19_n_0\,
      S(0) => \VGA_R[7]_i_20_n_0\
    );
\VGA_R_reg[7]_i_448\: unisim.vcomponents.CARRY4
     port map (
      CI => sel0(6),
      CO(3 downto 0) => \NLW_VGA_R_reg[7]_i_448_CO_UNCONNECTED\(3 downto 0),
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 1) => \NLW_VGA_R_reg[7]_i_448_O_UNCONNECTED\(3 downto 1),
      O(0) => \VGA_R_reg[7]_i_448_n_7\,
      S(3 downto 1) => B"000",
      S(0) => \VGA_R[7]_i_499_n_0\
    );
\VGA_R_reg[7]_i_449\: unisim.vcomponents.CARRY4
     port map (
      CI => sel0(7),
      CO(3 downto 0) => \NLW_VGA_R_reg[7]_i_449_CO_UNCONNECTED\(3 downto 0),
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 1) => \NLW_VGA_R_reg[7]_i_449_O_UNCONNECTED\(3 downto 1),
      O(0) => \VGA_R_reg[7]_i_449_n_7\,
      S(3 downto 1) => B"000",
      S(0) => \VGA_R[7]_i_500_n_0\
    );
\VGA_R_reg[7]_i_450\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_501_n_0\,
      CO(3) => \VGA_R_reg[7]_i_450_n_0\,
      CO(2) => \VGA_R_reg[7]_i_450_n_1\,
      CO(1) => \VGA_R_reg[7]_i_450_n_2\,
      CO(0) => \VGA_R_reg[7]_i_450_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => \^p_1_in\(4 downto 1),
      O(3) => \VGA_R_reg[7]_i_450_n_4\,
      O(2) => \VGA_R_reg[7]_i_450_n_5\,
      O(1) => \VGA_R_reg[7]_i_450_n_6\,
      O(0) => \VGA_R_reg[7]_i_450_n_7\,
      S(3) => \VGA_R[7]_i_502_n_0\,
      S(2) => \VGA_R[7]_i_503_n_0\,
      S(1) => \VGA_R[7]_i_504_n_0\,
      S(0) => \VGA_R[7]_i_505_n_0\
    );
\VGA_R_reg[7]_i_455\: unisim.vcomponents.CARRY4
     port map (
      CI => sel0(11),
      CO(3 downto 0) => \NLW_VGA_R_reg[7]_i_455_CO_UNCONNECTED\(3 downto 0),
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 1) => \NLW_VGA_R_reg[7]_i_455_O_UNCONNECTED\(3 downto 1),
      O(0) => \VGA_R_reg[7]_i_455_n_7\,
      S(3 downto 1) => B"000",
      S(0) => \VGA_R[7]_i_506_n_0\
    );
\VGA_R_reg[7]_i_456\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_317_n_0\,
      CO(3 downto 1) => \NLW_VGA_R_reg[7]_i_456_CO_UNCONNECTED\(3 downto 1),
      CO(0) => \VGA_R_reg[7]_i_456_n_3\,
      CYINIT => '0',
      DI(3 downto 1) => B"000",
      DI(0) => \^p_1_in\(9),
      O(3 downto 2) => \NLW_VGA_R_reg[7]_i_456_O_UNCONNECTED\(3 downto 2),
      O(1) => \VGA_R_reg[7]_i_456_n_6\,
      O(0) => \VGA_R_reg[7]_i_456_n_7\,
      S(3 downto 2) => B"00",
      S(1) => \VGA_R[7]_i_507_n_0\,
      S(0) => \VGA_R[7]_i_508_n_0\
    );
\VGA_R_reg[7]_i_457\: unisim.vcomponents.CARRY4
     port map (
      CI => sel0(8),
      CO(3 downto 0) => \NLW_VGA_R_reg[7]_i_457_CO_UNCONNECTED\(3 downto 0),
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 1) => \NLW_VGA_R_reg[7]_i_457_O_UNCONNECTED\(3 downto 1),
      O(0) => \VGA_R_reg[7]_i_457_n_7\,
      S(3 downto 1) => B"000",
      S(0) => \VGA_R[7]_i_509_n_0\
    );
\VGA_R_reg[7]_i_458\: unisim.vcomponents.CARRY4
     port map (
      CI => sel0(9),
      CO(3 downto 0) => \NLW_VGA_R_reg[7]_i_458_CO_UNCONNECTED\(3 downto 0),
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 1) => \NLW_VGA_R_reg[7]_i_458_O_UNCONNECTED\(3 downto 1),
      O(0) => \VGA_R_reg[7]_i_458_n_7\,
      S(3 downto 1) => B"000",
      S(0) => \VGA_R[7]_i_510_n_0\
    );
\VGA_R_reg[7]_i_459\: unisim.vcomponents.CARRY4
     port map (
      CI => sel0(10),
      CO(3 downto 0) => \NLW_VGA_R_reg[7]_i_459_CO_UNCONNECTED\(3 downto 0),
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 1) => \NLW_VGA_R_reg[7]_i_459_O_UNCONNECTED\(3 downto 1),
      O(0) => \VGA_R_reg[7]_i_459_n_7\,
      S(3 downto 1) => B"000",
      S(0) => \VGA_R[7]_i_511_n_0\
    );
\VGA_R_reg[7]_i_5\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_21_n_0\,
      CO(3 downto 2) => \NLW_VGA_R_reg[7]_i_5_CO_UNCONNECTED\(3 downto 2),
      CO(1) => disp_enable10_in,
      CO(0) => \VGA_R_reg[7]_i_5_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => VCNT(10),
      DI(0) => \VGA_R[7]_i_22_n_0\,
      O(3 downto 0) => \NLW_VGA_R_reg[7]_i_5_O_UNCONNECTED\(3 downto 0),
      S(3 downto 2) => B"00",
      S(1) => \VGA_R[7]_i_23_n_0\,
      S(0) => \VGA_R[7]_i_24_n_0\
    );
\VGA_R_reg[7]_i_501\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[7]_i_501_n_0\,
      CO(2) => \VGA_R_reg[7]_i_501_n_1\,
      CO(1) => \VGA_R_reg[7]_i_501_n_2\,
      CO(0) => \VGA_R_reg[7]_i_501_n_3\,
      CYINIT => '0',
      DI(3) => \VGA_R[7]_i_556_n_0\,
      DI(2 downto 0) => B"001",
      O(3 downto 0) => \NLW_VGA_R_reg[7]_i_501_O_UNCONNECTED\(3 downto 0),
      S(3) => \VGA_R[7]_i_557_n_0\,
      S(2) => \VGA_R[7]_i_558_n_0\,
      S(1) => \VGA_R[7]_i_559_n_0\,
      S(0) => \VGA_R[7]_i_560_n_0\
    );
\VGA_R_reg[7]_i_68\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_121_n_0\,
      CO(3) => sel0(1),
      CO(2) => \VGA_R_reg[7]_i_68_n_1\,
      CO(1) => \VGA_R_reg[7]_i_68_n_2\,
      CO(0) => \VGA_R_reg[7]_i_68_n_3\,
      CYINIT => '0',
      DI(3) => sel0(2),
      DI(2) => \VGA_G_reg[7]_i_7_n_6\,
      DI(1) => \VGA_G_reg[7]_i_7_n_7\,
      DI(0) => \VGA_R_reg[7]_i_122_n_4\,
      O(3) => \NLW_VGA_R_reg[7]_i_68_O_UNCONNECTED\(3),
      O(2) => \VGA_R_reg[7]_i_68_n_5\,
      O(1) => \VGA_R_reg[7]_i_68_n_6\,
      O(0) => \VGA_R_reg[7]_i_68_n_7\,
      S(3) => \VGA_R[7]_i_123_n_0\,
      S(2) => \VGA_R[7]_i_124_n_0\,
      S(1) => \VGA_R[7]_i_125_n_0\,
      S(0) => \VGA_R[7]_i_126_n_0\
    );
\VGA_R_reg[7]_i_69\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R[7]_i_330_0\(0),
      CO(3 downto 1) => \NLW_VGA_R_reg[7]_i_69_CO_UNCONNECTED\(3 downto 1),
      CO(0) => sel0(12),
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 2) => \NLW_VGA_R_reg[7]_i_69_O_UNCONNECTED\(3 downto 2),
      O(1) => \VGA_R_reg[7]_i_69_n_6\,
      O(0) => \NLW_VGA_R_reg[7]_i_69_O_UNCONNECTED\(0),
      S(3 downto 2) => B"00",
      S(1) => \VGA_R[7]_i_128_n_0\,
      S(0) => \VGA_R[7]_i_330_1\(0)
    );
\VGA_R_reg[7]_i_70\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_130_n_0\,
      CO(3) => sel0(11),
      CO(2) => \VGA_R_reg[7]_i_70_n_1\,
      CO(1) => \VGA_R_reg[7]_i_70_n_2\,
      CO(0) => \VGA_R_reg[7]_i_70_n_3\,
      CYINIT => '0',
      DI(3) => sel0(12),
      DI(2 downto 1) => \VGA_R_reg[7]_i_70_0\(1 downto 0),
      DI(0) => \VGA_R_reg[7]_i_74_0\(0),
      O(3) => \NLW_VGA_R_reg[7]_i_70_O_UNCONNECTED\(3),
      O(2) => \VGA_R_reg[7]_i_70_n_5\,
      O(1) => \VGA_R_reg[7]_i_70_n_6\,
      O(0) => \VGA_R_reg[7]_i_70_n_7\,
      S(3) => \VGA_R[7]_i_132_n_0\,
      S(2) => \VGA_R[7]_i_133_n_0\,
      S(1) => \VGA_R[7]_i_134_n_0\,
      S(0) => \VGA_R[7]_i_135_n_0\
    );
\VGA_R_reg[7]_i_71\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_136_n_0\,
      CO(3) => sel0(6),
      CO(2) => \VGA_R_reg[7]_i_71_n_1\,
      CO(1) => \VGA_R_reg[7]_i_71_n_2\,
      CO(0) => \VGA_R_reg[7]_i_71_n_3\,
      CYINIT => '0',
      DI(3) => sel0(7),
      DI(2) => \VGA_R_reg[7]_i_78_n_6\,
      DI(1) => \VGA_R_reg[7]_i_78_n_7\,
      DI(0) => \VGA_R_reg[7]_i_137_n_4\,
      O(3) => \NLW_VGA_R_reg[7]_i_71_O_UNCONNECTED\(3),
      O(2) => \VGA_R_reg[7]_i_71_n_5\,
      O(1) => \VGA_R_reg[7]_i_71_n_6\,
      O(0) => \VGA_R_reg[7]_i_71_n_7\,
      S(3) => \VGA_R[7]_i_138_n_0\,
      S(2) => \VGA_R[7]_i_139_n_0\,
      S(1) => \VGA_R[7]_i_140_n_0\,
      S(0) => \VGA_R[7]_i_141_n_0\
    );
\VGA_R_reg[7]_i_72\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_142_n_0\,
      CO(3) => sel0(9),
      CO(2) => \VGA_R_reg[7]_i_72_n_1\,
      CO(1) => \VGA_R_reg[7]_i_72_n_2\,
      CO(0) => \VGA_R_reg[7]_i_72_n_3\,
      CYINIT => '0',
      DI(3) => sel0(10),
      DI(2) => \VGA_R_reg[7]_i_74_n_6\,
      DI(1) => \VGA_R_reg[7]_i_74_n_7\,
      DI(0) => \VGA_R_reg[7]_i_143_n_4\,
      O(3) => \NLW_VGA_R_reg[7]_i_72_O_UNCONNECTED\(3),
      O(2) => \VGA_R_reg[7]_i_72_n_5\,
      O(1) => \VGA_R_reg[7]_i_72_n_6\,
      O(0) => \VGA_R_reg[7]_i_72_n_7\,
      S(3) => \VGA_R[7]_i_144_n_0\,
      S(2) => \VGA_R[7]_i_145_n_0\,
      S(1) => \VGA_R[7]_i_146_n_0\,
      S(0) => \VGA_R[7]_i_147_n_0\
    );
\VGA_R_reg[7]_i_73\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_148_n_0\,
      CO(3) => sel0(8),
      CO(2) => \VGA_R_reg[7]_i_73_n_1\,
      CO(1) => \VGA_R_reg[7]_i_73_n_2\,
      CO(0) => \VGA_R_reg[7]_i_73_n_3\,
      CYINIT => '0',
      DI(3) => sel0(9),
      DI(2) => \VGA_R_reg[7]_i_72_n_6\,
      DI(1) => \VGA_R_reg[7]_i_72_n_7\,
      DI(0) => \VGA_R_reg[7]_i_142_n_4\,
      O(3) => \NLW_VGA_R_reg[7]_i_73_O_UNCONNECTED\(3),
      O(2) => \VGA_R_reg[7]_i_73_n_5\,
      O(1) => \VGA_R_reg[7]_i_73_n_6\,
      O(0) => \VGA_R_reg[7]_i_73_n_7\,
      S(3) => \VGA_R[7]_i_149_n_0\,
      S(2) => \VGA_R[7]_i_150_n_0\,
      S(1) => \VGA_R[7]_i_151_n_0\,
      S(0) => \VGA_R[7]_i_152_n_0\
    );
\VGA_R_reg[7]_i_74\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_143_n_0\,
      CO(3) => sel0(10),
      CO(2) => \VGA_R_reg[7]_i_74_n_1\,
      CO(1) => \VGA_R_reg[7]_i_74_n_2\,
      CO(0) => \VGA_R_reg[7]_i_74_n_3\,
      CYINIT => '0',
      DI(3) => sel0(11),
      DI(2) => \VGA_R_reg[7]_i_70_n_6\,
      DI(1) => \VGA_R_reg[7]_i_70_n_7\,
      DI(0) => \VGA_R_reg[7]_i_130_n_4\,
      O(3) => \NLW_VGA_R_reg[7]_i_74_O_UNCONNECTED\(3),
      O(2) => \VGA_R_reg[7]_i_74_n_5\,
      O(1) => \VGA_R_reg[7]_i_74_n_6\,
      O(0) => \VGA_R_reg[7]_i_74_n_7\,
      S(3) => \VGA_R[7]_i_153_n_0\,
      S(2) => \VGA_R[7]_i_154_n_0\,
      S(1) => \VGA_R[7]_i_155_n_0\,
      S(0) => \VGA_R[7]_i_156_n_0\
    );
\VGA_R_reg[7]_i_75\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_157_n_0\,
      CO(3) => sel0(3),
      CO(2) => \VGA_R_reg[7]_i_75_n_1\,
      CO(1) => \VGA_R_reg[7]_i_75_n_2\,
      CO(0) => \VGA_R_reg[7]_i_75_n_3\,
      CYINIT => '0',
      DI(3) => sel0(4),
      DI(2) => \VGA_R_reg[7]_i_76_n_6\,
      DI(1) => \VGA_R_reg[7]_i_76_n_7\,
      DI(0) => \VGA_R_reg[7]_i_158_n_4\,
      O(3) => \NLW_VGA_R_reg[7]_i_75_O_UNCONNECTED\(3),
      O(2) => \VGA_R_reg[7]_i_75_n_5\,
      O(1) => \VGA_R_reg[7]_i_75_n_6\,
      O(0) => \VGA_R_reg[7]_i_75_n_7\,
      S(3) => \VGA_R[7]_i_159_n_0\,
      S(2) => \VGA_R[7]_i_160_n_0\,
      S(1) => \VGA_R[7]_i_161_n_0\,
      S(0) => \VGA_R[7]_i_162_n_0\
    );
\VGA_R_reg[7]_i_76\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_158_n_0\,
      CO(3) => sel0(4),
      CO(2) => \VGA_R_reg[7]_i_76_n_1\,
      CO(1) => \VGA_R_reg[7]_i_76_n_2\,
      CO(0) => \VGA_R_reg[7]_i_76_n_3\,
      CYINIT => '0',
      DI(3) => sel0(5),
      DI(2) => \VGA_R_reg[7]_i_77_n_6\,
      DI(1) => \VGA_R_reg[7]_i_77_n_7\,
      DI(0) => \VGA_R_reg[7]_i_163_n_4\,
      O(3) => \NLW_VGA_R_reg[7]_i_76_O_UNCONNECTED\(3),
      O(2) => \VGA_R_reg[7]_i_76_n_5\,
      O(1) => \VGA_R_reg[7]_i_76_n_6\,
      O(0) => \VGA_R_reg[7]_i_76_n_7\,
      S(3) => \VGA_R[7]_i_164_n_0\,
      S(2) => \VGA_R[7]_i_165_n_0\,
      S(1) => \VGA_R[7]_i_166_n_0\,
      S(0) => \VGA_R[7]_i_167_n_0\
    );
\VGA_R_reg[7]_i_77\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_163_n_0\,
      CO(3) => sel0(5),
      CO(2) => \VGA_R_reg[7]_i_77_n_1\,
      CO(1) => \VGA_R_reg[7]_i_77_n_2\,
      CO(0) => \VGA_R_reg[7]_i_77_n_3\,
      CYINIT => '0',
      DI(3) => sel0(6),
      DI(2) => \VGA_R_reg[7]_i_71_n_6\,
      DI(1) => \VGA_R_reg[7]_i_71_n_7\,
      DI(0) => \VGA_R_reg[7]_i_136_n_4\,
      O(3) => \NLW_VGA_R_reg[7]_i_77_O_UNCONNECTED\(3),
      O(2) => \VGA_R_reg[7]_i_77_n_5\,
      O(1) => \VGA_R_reg[7]_i_77_n_6\,
      O(0) => \VGA_R_reg[7]_i_77_n_7\,
      S(3) => \VGA_R[7]_i_168_n_0\,
      S(2) => \VGA_R[7]_i_169_n_0\,
      S(1) => \VGA_R[7]_i_170_n_0\,
      S(0) => \VGA_R[7]_i_171_n_0\
    );
\VGA_R_reg[7]_i_78\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_137_n_0\,
      CO(3) => sel0(7),
      CO(2) => \VGA_R_reg[7]_i_78_n_1\,
      CO(1) => \VGA_R_reg[7]_i_78_n_2\,
      CO(0) => \VGA_R_reg[7]_i_78_n_3\,
      CYINIT => '0',
      DI(3) => sel0(8),
      DI(2) => \VGA_R_reg[7]_i_73_n_6\,
      DI(1) => \VGA_R_reg[7]_i_73_n_7\,
      DI(0) => \VGA_R_reg[7]_i_148_n_4\,
      O(3) => \NLW_VGA_R_reg[7]_i_78_O_UNCONNECTED\(3),
      O(2) => \VGA_R_reg[7]_i_78_n_5\,
      O(1) => \VGA_R_reg[7]_i_78_n_6\,
      O(0) => \VGA_R_reg[7]_i_78_n_7\,
      S(3) => \VGA_R[7]_i_172_n_0\,
      S(2) => \VGA_R[7]_i_173_n_0\,
      S(1) => \VGA_R[7]_i_174_n_0\,
      S(0) => \VGA_R[7]_i_175_n_0\
    );
\VGA_R_reg[7]_i_86\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[7]_i_86_n_0\,
      CO(2) => \VGA_R_reg[7]_i_86_n_1\,
      CO(1) => \VGA_R_reg[7]_i_86_n_2\,
      CO(0) => \VGA_R_reg[7]_i_86_n_3\,
      CYINIT => \VGA_G_reg[7]_i_6_n_0\,
      DI(3) => \VGA_R_reg[7]_i_87_n_5\,
      DI(2) => \VGA_R_reg[7]_i_87_n_6\,
      DI(1) => \VGA_G_reg[7]_i_6_n_0\,
      DI(0) => \VGA_R[7]_i_193_n_0\,
      O(3) => \VGA_R_reg[7]_i_86_n_4\,
      O(2) => \VGA_R_reg[7]_i_86_n_5\,
      O(1) => \VGA_R_reg[7]_i_86_n_6\,
      O(0) => \VGA_R_reg[7]_i_86_n_7\,
      S(3) => \VGA_R[7]_i_194_n_0\,
      S(2) => \VGA_R[7]_i_195_n_0\,
      S(1) => \VGA_R[7]_i_196_n_0\,
      S(0) => \VGA_R[7]_i_197_n_0\
    );
\VGA_R_reg[7]_i_87\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[7]_i_87_n_0\,
      CO(2) => \VGA_R_reg[7]_i_87_n_1\,
      CO(1) => \VGA_R_reg[7]_i_87_n_2\,
      CO(0) => \VGA_R_reg[7]_i_87_n_3\,
      CYINIT => \VGA_R_reg[7]_i_94_n_0\,
      DI(3) => \VGA_G_reg[7]_i_8_n_5\,
      DI(2) => \VGA_G_reg[7]_i_8_n_6\,
      DI(1) => \VGA_R_reg[7]_i_94_n_0\,
      DI(0) => \VGA_R[7]_i_198_n_0\,
      O(3) => \VGA_R_reg[7]_i_87_n_4\,
      O(2) => \VGA_R_reg[7]_i_87_n_5\,
      O(1) => \VGA_R_reg[7]_i_87_n_6\,
      O(0) => \VGA_R_reg[7]_i_87_n_7\,
      S(3) => \VGA_R[7]_i_199_n_0\,
      S(2) => \VGA_R[7]_i_200_n_0\,
      S(1) => \VGA_R[7]_i_201_n_0\,
      S(0) => \VGA_R[7]_i_202_n_0\
    );
\VGA_R_reg[7]_i_94\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_G_reg[7]_i_8_n_0\,
      CO(3) => \VGA_R_reg[7]_i_94_n_0\,
      CO(2) => \VGA_R_reg[7]_i_94_n_1\,
      CO(1) => \VGA_R_reg[7]_i_94_n_2\,
      CO(0) => \VGA_R_reg[7]_i_94_n_3\,
      CYINIT => '0',
      DI(3) => \VGA_R_reg[7]_i_95_n_0\,
      DI(2) => \VGA_R_reg[7]_i_95_n_6\,
      DI(1) => \VGA_R_reg[7]_i_95_n_7\,
      DI(0) => \VGA_R_reg[7]_i_211_n_4\,
      O(3) => \NLW_VGA_R_reg[7]_i_94_O_UNCONNECTED\(3),
      O(2) => \VGA_R_reg[7]_i_94_n_5\,
      O(1) => \VGA_R_reg[7]_i_94_n_6\,
      O(0) => \VGA_R_reg[7]_i_94_n_7\,
      S(3) => \VGA_R[7]_i_212_n_0\,
      S(2) => \VGA_R[7]_i_213_n_0\,
      S(1) => \VGA_R[7]_i_214_n_0\,
      S(0) => \VGA_R[7]_i_215_n_0\
    );
\VGA_R_reg[7]_i_95\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_211_n_0\,
      CO(3) => \VGA_R_reg[7]_i_95_n_0\,
      CO(2) => \VGA_R_reg[7]_i_95_n_1\,
      CO(1) => \VGA_R_reg[7]_i_95_n_2\,
      CO(0) => \VGA_R_reg[7]_i_95_n_3\,
      CYINIT => '0',
      DI(3) => \VGA_R_reg[7]_i_96_n_0\,
      DI(2) => \VGA_R_reg[7]_i_96_n_6\,
      DI(1) => \VGA_R_reg[7]_i_96_n_7\,
      DI(0) => \VGA_R_reg[7]_i_216_n_4\,
      O(3) => \NLW_VGA_R_reg[7]_i_95_O_UNCONNECTED\(3),
      O(2) => \VGA_R_reg[7]_i_95_n_5\,
      O(1) => \VGA_R_reg[7]_i_95_n_6\,
      O(0) => \VGA_R_reg[7]_i_95_n_7\,
      S(3) => \VGA_R[7]_i_217_n_0\,
      S(2) => \VGA_R[7]_i_218_n_0\,
      S(1) => \VGA_R[7]_i_219_n_0\,
      S(0) => \VGA_R[7]_i_220_n_0\
    );
\VGA_R_reg[7]_i_96\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_216_n_0\,
      CO(3) => \VGA_R_reg[7]_i_96_n_0\,
      CO(2) => \VGA_R_reg[7]_i_96_n_1\,
      CO(1) => \VGA_R_reg[7]_i_96_n_2\,
      CO(0) => \VGA_R_reg[7]_i_96_n_3\,
      CYINIT => '0',
      DI(3) => \VGA_R_reg[7]_i_97_n_0\,
      DI(2) => \VGA_R_reg[7]_i_97_n_6\,
      DI(1) => \VGA_R_reg[7]_i_97_n_7\,
      DI(0) => \VGA_R_reg[7]_i_221_n_4\,
      O(3) => \NLW_VGA_R_reg[7]_i_96_O_UNCONNECTED\(3),
      O(2) => \VGA_R_reg[7]_i_96_n_5\,
      O(1) => \VGA_R_reg[7]_i_96_n_6\,
      O(0) => \VGA_R_reg[7]_i_96_n_7\,
      S(3) => \VGA_R[7]_i_222_n_0\,
      S(2) => \VGA_R[7]_i_223_n_0\,
      S(1) => \VGA_R[7]_i_224_n_0\,
      S(0) => \VGA_R[7]_i_225_n_0\
    );
\VGA_R_reg[7]_i_97\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_221_n_0\,
      CO(3) => \VGA_R_reg[7]_i_97_n_0\,
      CO(2) => \VGA_R_reg[7]_i_97_n_1\,
      CO(1) => \VGA_R_reg[7]_i_97_n_2\,
      CO(0) => \VGA_R_reg[7]_i_97_n_3\,
      CYINIT => '0',
      DI(3) => \VGA_R_reg[7]_i_98_n_0\,
      DI(2) => \VGA_R_reg[7]_i_98_n_6\,
      DI(1) => \VGA_R_reg[7]_i_98_n_7\,
      DI(0) => \VGA_R_reg[7]_i_226_n_4\,
      O(3) => \NLW_VGA_R_reg[7]_i_97_O_UNCONNECTED\(3),
      O(2) => \VGA_R_reg[7]_i_97_n_5\,
      O(1) => \VGA_R_reg[7]_i_97_n_6\,
      O(0) => \VGA_R_reg[7]_i_97_n_7\,
      S(3) => \VGA_R[7]_i_227_n_0\,
      S(2) => \VGA_R[7]_i_228_n_0\,
      S(1) => \VGA_R[7]_i_229_n_0\,
      S(0) => \VGA_R[7]_i_230_n_0\
    );
\VGA_R_reg[7]_i_98\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_226_n_0\,
      CO(3) => \VGA_R_reg[7]_i_98_n_0\,
      CO(2) => \VGA_R_reg[7]_i_98_n_1\,
      CO(1) => \VGA_R_reg[7]_i_98_n_2\,
      CO(0) => \VGA_R_reg[7]_i_98_n_3\,
      CYINIT => '0',
      DI(3) => \VGA_R_reg[7]_i_99_n_0\,
      DI(2) => \VGA_R_reg[7]_i_99_n_6\,
      DI(1) => \VGA_R_reg[7]_i_99_n_7\,
      DI(0) => \VGA_R_reg[7]_i_231_n_4\,
      O(3) => \NLW_VGA_R_reg[7]_i_98_O_UNCONNECTED\(3),
      O(2) => \VGA_R_reg[7]_i_98_n_5\,
      O(1) => \VGA_R_reg[7]_i_98_n_6\,
      O(0) => \VGA_R_reg[7]_i_98_n_7\,
      S(3) => \VGA_R[7]_i_232_n_0\,
      S(2) => \VGA_R[7]_i_233_n_0\,
      S(1) => \VGA_R[7]_i_234_n_0\,
      S(0) => \VGA_R[7]_i_235_n_0\
    );
\VGA_R_reg[7]_i_99\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_231_n_0\,
      CO(3) => \VGA_R_reg[7]_i_99_n_0\,
      CO(2) => \VGA_R_reg[7]_i_99_n_1\,
      CO(1) => \VGA_R_reg[7]_i_99_n_2\,
      CO(0) => \VGA_R_reg[7]_i_99_n_3\,
      CYINIT => '0',
      DI(3) => \VGA_R_reg[7]_i_100_n_0\,
      DI(2) => \VGA_R_reg[7]_i_100_n_6\,
      DI(1) => \VGA_R_reg[7]_i_100_n_7\,
      DI(0) => \VGA_R_reg[7]_i_236_n_4\,
      O(3) => \NLW_VGA_R_reg[7]_i_99_O_UNCONNECTED\(3),
      O(2) => \VGA_R_reg[7]_i_99_n_5\,
      O(1) => \VGA_R_reg[7]_i_99_n_6\,
      O(0) => \VGA_R_reg[7]_i_99_n_7\,
      S(3) => \VGA_R[7]_i_237_n_0\,
      S(2) => \VGA_R[7]_i_238_n_0\,
      S(1) => \VGA_R[7]_i_239_n_0\,
      S(0) => \VGA_R[7]_i_240_n_0\
    );
VGA_VS_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"6567777765644444"
    )
        port map (
      I0 => VGA_HS_i_2_n_0,
      I1 => RST,
      I2 => VGA_VS1,
      I3 => VGA_VS0,
      I4 => VGA_HS1,
      I5 => \^vga_vs\,
      O => VGA_VS_i_1_n_0
    );
VGA_VS_i_10: unisim.vcomponents.LUT3
    generic map(
      INIT => X"02"
    )
        port map (
      I0 => VCNT(3),
      I1 => VCNT(5),
      I2 => VCNT(4),
      O => VGA_VS_i_10_n_0
    );
VGA_VS_i_11: unisim.vcomponents.LUT5
    generic map(
      INIT => X"08104100"
    )
        port map (
      I0 => VCNT(0),
      I1 => timing_sel(0),
      I2 => timing_sel(1),
      I3 => VCNT(2),
      I4 => VCNT(1),
      O => VGA_VS_i_11_n_0
    );
VGA_VS_i_4: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => VCNT(9),
      I1 => VCNT(10),
      O => VGA_VS_i_4_n_0
    );
VGA_VS_i_5: unisim.vcomponents.LUT3
    generic map(
      INIT => X"01"
    )
        port map (
      I0 => VCNT(8),
      I1 => VCNT(7),
      I2 => VCNT(6),
      O => VGA_VS_i_5_n_0
    );
VGA_VS_i_6: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0000009A"
    )
        port map (
      I0 => VCNT(3),
      I1 => timing_sel(0),
      I2 => timing_sel(1),
      I3 => VCNT(5),
      I4 => VCNT(4),
      O => VGA_VS_i_6_n_0
    );
VGA_VS_i_7: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00410820"
    )
        port map (
      I0 => VCNT(0),
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      I3 => VCNT(2),
      I4 => VCNT(1),
      O => VGA_VS_i_7_n_0
    );
VGA_VS_i_8: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => VCNT(9),
      I1 => VCNT(10),
      O => VGA_VS_i_8_n_0
    );
VGA_VS_i_9: unisim.vcomponents.LUT3
    generic map(
      INIT => X"01"
    )
        port map (
      I0 => VCNT(8),
      I1 => VCNT(7),
      I2 => VCNT(6),
      O => VGA_VS_i_9_n_0
    );
VGA_VS_reg: unisim.vcomponents.FDRE
     port map (
      C => \^pck\,
      CE => '1',
      D => VGA_VS_i_1_n_0,
      Q => \^vga_vs\,
      R => '0'
    );
VGA_VS_reg_i_2: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => VGA_VS1,
      CO(2) => VGA_VS_reg_i_2_n_1,
      CO(1) => VGA_VS_reg_i_2_n_2,
      CO(0) => VGA_VS_reg_i_2_n_3,
      CYINIT => '1',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => NLW_VGA_VS_reg_i_2_O_UNCONNECTED(3 downto 0),
      S(3) => VGA_VS_i_4_n_0,
      S(2) => VGA_VS_i_5_n_0,
      S(1) => VGA_VS_i_6_n_0,
      S(0) => VGA_VS_i_7_n_0
    );
VGA_VS_reg_i_3: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => VGA_VS0,
      CO(2) => VGA_VS_reg_i_3_n_1,
      CO(1) => VGA_VS_reg_i_3_n_2,
      CO(0) => VGA_VS_reg_i_3_n_3,
      CYINIT => '1',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => NLW_VGA_VS_reg_i_3_O_UNCONNECTED(3 downto 0),
      S(3) => VGA_VS_i_8_n_0,
      S(2) => VGA_VS_i_9_n_0,
      S(1) => VGA_VS_i_10_n_0,
      S(0) => VGA_VS_i_11_n_0
    );
\pattern_b1__0_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \pattern_b1__0_i_2_n_0\,
      CO(3 downto 2) => \NLW_pattern_b1__0_i_1_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \pattern_b1__0_i_1_n_2\,
      CO(0) => \pattern_b1__0_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1 downto 0) => VCNT(9 downto 8),
      O(3) => \NLW_pattern_b1__0_i_1_O_UNCONNECTED\(3),
      O(2 downto 0) => \^a\(10 downto 8),
      S(3) => '0',
      S(2) => \pattern_b1__0_i_4_n_0\,
      S(1) => \pattern_b1__0_i_5_n_0\,
      S(0) => \pattern_b1__0_i_6_n_0\
    );
\pattern_b1__0_i_10\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => VCNT(4),
      I1 => zp_sum,
      O => \pattern_b1__0_i_10_n_0\
    );
\pattern_b1__0_i_11\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => zp_sum,
      I1 => VCNT(1),
      O => \pattern_b1__0_i_11_n_0\
    );
\pattern_b1__0_i_12\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => VCNT(0),
      I1 => zp_sum,
      O => \pattern_b1__0_i_12_n_0\
    );
\pattern_b1__0_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \pattern_b1__0_i_3_n_0\,
      CO(3) => \pattern_b1__0_i_2_n_0\,
      CO(2) => \pattern_b1__0_i_2_n_1\,
      CO(1) => \pattern_b1__0_i_2_n_2\,
      CO(0) => \pattern_b1__0_i_2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => VCNT(7 downto 4),
      O(3 downto 0) => \^a\(7 downto 4),
      S(3) => \pattern_b1__0_i_7_n_0\,
      S(2) => \pattern_b1__0_i_8_n_0\,
      S(1) => \pattern_b1__0_i_9_n_0\,
      S(0) => \pattern_b1__0_i_10_n_0\
    );
\pattern_b1__0_i_3\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \pattern_b1__0_i_3_n_0\,
      CO(2) => \pattern_b1__0_i_3_n_1\,
      CO(1) => \pattern_b1__0_i_3_n_2\,
      CO(0) => \pattern_b1__0_i_3_n_3\,
      CYINIT => '1',
      DI(3 downto 0) => VCNT(3 downto 0),
      O(3 downto 0) => \^a\(3 downto 0),
      S(3 downto 2) => VCNT(3 downto 2),
      S(1) => \pattern_b1__0_i_11_n_0\,
      S(0) => \pattern_b1__0_i_12_n_0\
    );
\pattern_b1__0_i_4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => VCNT(10),
      O => \pattern_b1__0_i_4_n_0\
    );
\pattern_b1__0_i_5\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => VCNT(9),
      O => \pattern_b1__0_i_5_n_0\
    );
\pattern_b1__0_i_6\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => VCNT(8),
      O => \pattern_b1__0_i_6_n_0\
    );
\pattern_b1__0_i_7\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => VCNT(7),
      O => \pattern_b1__0_i_7_n_0\
    );
\pattern_b1__0_i_8\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => VCNT(6),
      O => \pattern_b1__0_i_8_n_0\
    );
\pattern_b1__0_i_9\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => VCNT(5),
      I1 => zp_sum,
      O => \pattern_b1__0_i_9_n_0\
    );
pattern_b1_i_1: unisim.vcomponents.CARRY4
     port map (
      CI => pattern_b1_i_2_n_0,
      CO(3 downto 1) => NLW_pattern_b1_i_1_CO_UNCONNECTED(3 downto 1),
      CO(0) => pattern_b1_i_1_n_3,
      CYINIT => '0',
      DI(3 downto 1) => B"000",
      DI(0) => pattern_b1_i_4_n_0,
      O(3 downto 2) => NLW_pattern_b1_i_1_O_UNCONNECTED(3 downto 2),
      O(1 downto 0) => \^p_1_in\(10 downto 9),
      S(3 downto 2) => B"00",
      S(1) => pattern_b1_i_5_n_0,
      S(0) => pattern_b1_i_6_n_0
    );
pattern_b1_i_10: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => HCNT(4),
      I1 => zp_sum0_0(0),
      O => pattern_b1_i_10_n_0
    );
pattern_b1_i_11: unisim.vcomponents.LUT4
    generic map(
      INIT => X"B44B"
    )
        port map (
      I0 => zp_sum0(2),
      I1 => HCNT(7),
      I2 => CO(0),
      I3 => HCNT(8),
      O => pattern_b1_i_11_n_0
    );
pattern_b1_i_12: unisim.vcomponents.LUT4
    generic map(
      INIT => X"B44B"
    )
        port map (
      I0 => zp_sum0(1),
      I1 => HCNT(6),
      I2 => zp_sum0(2),
      I3 => HCNT(7),
      O => pattern_b1_i_12_n_0
    );
pattern_b1_i_13: unisim.vcomponents.LUT4
    generic map(
      INIT => X"B44B"
    )
        port map (
      I0 => zp_sum0(0),
      I1 => HCNT(5),
      I2 => zp_sum0(1),
      I3 => HCNT(6),
      O => pattern_b1_i_13_n_0
    );
pattern_b1_i_14: unisim.vcomponents.LUT4
    generic map(
      INIT => X"B44B"
    )
        port map (
      I0 => zp_sum0_0(0),
      I1 => HCNT(4),
      I2 => zp_sum0(0),
      I3 => HCNT(5),
      O => pattern_b1_i_14_n_0
    );
pattern_b1_i_15: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => HCNT(3),
      I1 => O(2),
      O => pattern_b1_i_15_n_0
    );
pattern_b1_i_16: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => HCNT(2),
      I1 => O(1),
      O => pattern_b1_i_16_n_0
    );
pattern_b1_i_19: unisim.vcomponents.LUT4
    generic map(
      INIT => X"B44B"
    )
        port map (
      I0 => O(2),
      I1 => HCNT(3),
      I2 => zp_sum0_0(0),
      I3 => HCNT(4),
      O => pattern_b1_i_19_n_0
    );
pattern_b1_i_2: unisim.vcomponents.CARRY4
     port map (
      CI => pattern_b1_i_3_n_0,
      CO(3) => pattern_b1_i_2_n_0,
      CO(2) => pattern_b1_i_2_n_1,
      CO(1) => pattern_b1_i_2_n_2,
      CO(0) => pattern_b1_i_2_n_3,
      CYINIT => '0',
      DI(3) => pattern_b1_i_7_n_0,
      DI(2) => pattern_b1_i_8_n_0,
      DI(1) => pattern_b1_i_9_n_0,
      DI(0) => pattern_b1_i_10_n_0,
      O(3 downto 0) => \^p_1_in\(8 downto 5),
      S(3) => pattern_b1_i_11_n_0,
      S(2) => pattern_b1_i_12_n_0,
      S(1) => pattern_b1_i_13_n_0,
      S(0) => pattern_b1_i_14_n_0
    );
pattern_b1_i_20: unisim.vcomponents.LUT4
    generic map(
      INIT => X"B44B"
    )
        port map (
      I0 => O(1),
      I1 => HCNT(2),
      I2 => O(2),
      I3 => HCNT(3),
      O => pattern_b1_i_20_n_0
    );
pattern_b1_i_21: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => O(0),
      I1 => O(1),
      I2 => HCNT(2),
      O => pattern_b1_i_21_n_0
    );
pattern_b1_i_22: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => O(0),
      I1 => HCNT(1),
      O => pattern_b1_i_22_n_0
    );
pattern_b1_i_3: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => pattern_b1_i_3_n_0,
      CO(2) => pattern_b1_i_3_n_1,
      CO(1) => pattern_b1_i_3_n_2,
      CO(0) => pattern_b1_i_3_n_3,
      CYINIT => HCNT(0),
      DI(3) => pattern_b1_i_15_n_0,
      DI(2) => pattern_b1_i_16_n_0,
      DI(1) => DI(0),
      DI(0) => O(0),
      O(3 downto 0) => \^p_1_in\(4 downto 1),
      S(3) => pattern_b1_i_19_n_0,
      S(2) => pattern_b1_i_20_n_0,
      S(1) => pattern_b1_i_21_n_0,
      S(0) => pattern_b1_i_22_n_0
    );
pattern_b1_i_4: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => HCNT(9),
      O => pattern_b1_i_4_n_0
    );
pattern_b1_i_5: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => HCNT(9),
      I1 => HCNT(10),
      O => pattern_b1_i_5_n_0
    );
pattern_b1_i_6: unisim.vcomponents.LUT3
    generic map(
      INIT => X"4B"
    )
        port map (
      I0 => CO(0),
      I1 => HCNT(8),
      I2 => HCNT(9),
      O => pattern_b1_i_6_n_0
    );
pattern_b1_i_7: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => HCNT(7),
      I1 => zp_sum0(2),
      O => pattern_b1_i_7_n_0
    );
pattern_b1_i_8: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => HCNT(6),
      I1 => zp_sum0(1),
      O => pattern_b1_i_8_n_0
    );
pattern_b1_i_9: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => HCNT(5),
      I1 => zp_sum0(0),
      O => pattern_b1_i_9_n_0
    );
pckgen_triple: entity work.system_pattern_multi_0_0_pckgen_triple
     port map (
      CLK => CLK,
      PCK => \^pck\,
      SerialClk => SerialClk,
      locked => locked,
      reconfig_done => reconfig_done,
      reconfig_req => reconfig_req,
      timing_sel_imm(1 downto 0) => timing_sel_imm(1 downto 0)
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity system_pattern_multi_0_0_pattern_multi is
  port (
    locked : out STD_LOGIC;
    PCK : out STD_LOGIC;
    SerialClk : out STD_LOGIC;
    reconfig_done : out STD_LOGIC;
    VGA_HS : out STD_LOGIC;
    VGA_VS : out STD_LOGIC;
    VGA_R : out STD_LOGIC_VECTOR ( 7 downto 0 );
    VGA_G : out STD_LOGIC_VECTOR ( 7 downto 0 );
    VGA_B : out STD_LOGIC_VECTOR ( 7 downto 0 );
    VGA_DE : out STD_LOGIC;
    timing_sel_imm : in STD_LOGIC_VECTOR ( 1 downto 0 );
    timing_sel : in STD_LOGIC_VECTOR ( 1 downto 0 );
    pattern_sel : in STD_LOGIC_VECTOR ( 3 downto 0 );
    CLK : in STD_LOGIC;
    reconfig_req : in STD_LOGIC;
    RST : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of system_pattern_multi_0_0_pattern_multi : entity is "pattern_multi";
end system_pattern_multi_0_0_pattern_multi;

architecture STRUCTURE of system_pattern_multi_0_0_pattern_multi is
  signal A : STD_LOGIC_VECTOR ( 10 downto 6 );
  signal HBACK : STD_LOGIC_VECTOR ( 3 to 3 );
  signal HPERIOD : STD_LOGIC_VECTOR ( 8 to 8 );
  signal HWIDTH : STD_LOGIC_VECTOR ( 4 to 4 );
  signal \^pck\ : STD_LOGIC;
  signal \VGA_R[0]_i_10_n_0\ : STD_LOGIC;
  signal \VGA_R[0]_i_12_n_0\ : STD_LOGIC;
  signal \VGA_R[0]_i_13_n_0\ : STD_LOGIC;
  signal \VGA_R[0]_i_14_n_0\ : STD_LOGIC;
  signal \VGA_R[0]_i_15_n_0\ : STD_LOGIC;
  signal \VGA_R[0]_i_16_n_0\ : STD_LOGIC;
  signal \VGA_R[0]_i_17_n_0\ : STD_LOGIC;
  signal \VGA_R[0]_i_18_n_0\ : STD_LOGIC;
  signal \VGA_R[0]_i_19_n_0\ : STD_LOGIC;
  signal \VGA_R[0]_i_20_n_0\ : STD_LOGIC;
  signal \VGA_R[0]_i_21_n_0\ : STD_LOGIC;
  signal \VGA_R[0]_i_22_n_0\ : STD_LOGIC;
  signal \VGA_R[0]_i_23_n_0\ : STD_LOGIC;
  signal \VGA_R[0]_i_24_n_0\ : STD_LOGIC;
  signal \VGA_R[0]_i_25_n_0\ : STD_LOGIC;
  signal \VGA_R[0]_i_27_n_0\ : STD_LOGIC;
  signal \VGA_R[0]_i_29_n_0\ : STD_LOGIC;
  signal \VGA_R[0]_i_2_n_0\ : STD_LOGIC;
  signal \VGA_R[0]_i_31_n_0\ : STD_LOGIC;
  signal \VGA_R[0]_i_8_n_0\ : STD_LOGIC;
  signal \VGA_R[0]_i_9_n_0\ : STD_LOGIC;
  signal \VGA_R[1]_i_10_n_0\ : STD_LOGIC;
  signal \VGA_R[1]_i_12_n_0\ : STD_LOGIC;
  signal \VGA_R[1]_i_13_n_0\ : STD_LOGIC;
  signal \VGA_R[1]_i_14_n_0\ : STD_LOGIC;
  signal \VGA_R[1]_i_15_n_0\ : STD_LOGIC;
  signal \VGA_R[1]_i_16_n_0\ : STD_LOGIC;
  signal \VGA_R[1]_i_17_n_0\ : STD_LOGIC;
  signal \VGA_R[1]_i_18_n_0\ : STD_LOGIC;
  signal \VGA_R[1]_i_19_n_0\ : STD_LOGIC;
  signal \VGA_R[1]_i_20_n_0\ : STD_LOGIC;
  signal \VGA_R[1]_i_21_n_0\ : STD_LOGIC;
  signal \VGA_R[1]_i_22_n_0\ : STD_LOGIC;
  signal \VGA_R[1]_i_23_n_0\ : STD_LOGIC;
  signal \VGA_R[1]_i_24_n_0\ : STD_LOGIC;
  signal \VGA_R[1]_i_25_n_0\ : STD_LOGIC;
  signal \VGA_R[1]_i_27_n_0\ : STD_LOGIC;
  signal \VGA_R[1]_i_2_n_0\ : STD_LOGIC;
  signal \VGA_R[1]_i_8_n_0\ : STD_LOGIC;
  signal \VGA_R[1]_i_9_n_0\ : STD_LOGIC;
  signal \VGA_R[2]_i_10_n_0\ : STD_LOGIC;
  signal \VGA_R[2]_i_12_n_0\ : STD_LOGIC;
  signal \VGA_R[2]_i_13_n_0\ : STD_LOGIC;
  signal \VGA_R[2]_i_14_n_0\ : STD_LOGIC;
  signal \VGA_R[2]_i_15_n_0\ : STD_LOGIC;
  signal \VGA_R[2]_i_16_n_0\ : STD_LOGIC;
  signal \VGA_R[2]_i_17_n_0\ : STD_LOGIC;
  signal \VGA_R[2]_i_18_n_0\ : STD_LOGIC;
  signal \VGA_R[2]_i_19_n_0\ : STD_LOGIC;
  signal \VGA_R[2]_i_20_n_0\ : STD_LOGIC;
  signal \VGA_R[2]_i_21_n_0\ : STD_LOGIC;
  signal \VGA_R[2]_i_22_n_0\ : STD_LOGIC;
  signal \VGA_R[2]_i_23_n_0\ : STD_LOGIC;
  signal \VGA_R[2]_i_24_n_0\ : STD_LOGIC;
  signal \VGA_R[2]_i_25_n_0\ : STD_LOGIC;
  signal \VGA_R[2]_i_27_n_0\ : STD_LOGIC;
  signal \VGA_R[2]_i_2_n_0\ : STD_LOGIC;
  signal \VGA_R[2]_i_8_n_0\ : STD_LOGIC;
  signal \VGA_R[2]_i_9_n_0\ : STD_LOGIC;
  signal \VGA_R[3]_i_10_n_0\ : STD_LOGIC;
  signal \VGA_R[3]_i_11_n_0\ : STD_LOGIC;
  signal \VGA_R[3]_i_12_n_0\ : STD_LOGIC;
  signal \VGA_R[3]_i_14_n_0\ : STD_LOGIC;
  signal \VGA_R[3]_i_15_n_0\ : STD_LOGIC;
  signal \VGA_R[3]_i_16_n_0\ : STD_LOGIC;
  signal \VGA_R[3]_i_17_n_0\ : STD_LOGIC;
  signal \VGA_R[3]_i_18_n_0\ : STD_LOGIC;
  signal \VGA_R[3]_i_19_n_0\ : STD_LOGIC;
  signal \VGA_R[3]_i_20_n_0\ : STD_LOGIC;
  signal \VGA_R[3]_i_21_n_0\ : STD_LOGIC;
  signal \VGA_R[3]_i_22_n_0\ : STD_LOGIC;
  signal \VGA_R[3]_i_23_n_0\ : STD_LOGIC;
  signal \VGA_R[3]_i_24_n_0\ : STD_LOGIC;
  signal \VGA_R[3]_i_25_n_0\ : STD_LOGIC;
  signal \VGA_R[3]_i_26_n_0\ : STD_LOGIC;
  signal \VGA_R[3]_i_27_n_0\ : STD_LOGIC;
  signal \VGA_R[3]_i_29_n_0\ : STD_LOGIC;
  signal \VGA_R[3]_i_9_n_0\ : STD_LOGIC;
  signal \VGA_R[4]_i_13_n_0\ : STD_LOGIC;
  signal \VGA_R[4]_i_14_n_0\ : STD_LOGIC;
  signal \VGA_R[4]_i_15_n_0\ : STD_LOGIC;
  signal \VGA_R[4]_i_16_n_0\ : STD_LOGIC;
  signal \VGA_R[4]_i_18_n_0\ : STD_LOGIC;
  signal \VGA_R[4]_i_19_n_0\ : STD_LOGIC;
  signal \VGA_R[4]_i_20_n_0\ : STD_LOGIC;
  signal \VGA_R[4]_i_21_n_0\ : STD_LOGIC;
  signal \VGA_R[4]_i_30_n_0\ : STD_LOGIC;
  signal \VGA_R[4]_i_31_n_0\ : STD_LOGIC;
  signal \VGA_R[4]_i_32_n_0\ : STD_LOGIC;
  signal \VGA_R[4]_i_33_n_0\ : STD_LOGIC;
  signal \VGA_R[4]_i_34_n_0\ : STD_LOGIC;
  signal \VGA_R[4]_i_35_n_0\ : STD_LOGIC;
  signal \VGA_R[4]_i_36_n_0\ : STD_LOGIC;
  signal \VGA_R[4]_i_37_n_0\ : STD_LOGIC;
  signal \VGA_R[4]_i_38_n_0\ : STD_LOGIC;
  signal \VGA_R[4]_i_39_n_0\ : STD_LOGIC;
  signal \VGA_R[4]_i_41_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_101_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_102_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_103_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_104_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_105_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_106_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_107_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_109_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_111_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_112_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_113_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_115_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_116_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_118_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_119_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_120_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_121_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_122_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_124_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_125_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_126_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_127_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_128_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_129_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_130_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_131_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_132_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_133_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_134_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_135_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_136_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_137_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_138_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_139_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_140_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_22_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_23_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_24_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_25_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_27_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_28_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_29_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_30_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_5_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_60_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_61_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_62_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_63_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_64_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_65_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_66_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_67_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_68_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_69_n_0\ : STD_LOGIC;
  signal \VGA_R[5]_i_96_n_0\ : STD_LOGIC;
  signal \VGA_R[6]_i_10_n_0\ : STD_LOGIC;
  signal \VGA_R[6]_i_11_n_0\ : STD_LOGIC;
  signal \VGA_R[6]_i_13_n_0\ : STD_LOGIC;
  signal \VGA_R[6]_i_14_n_0\ : STD_LOGIC;
  signal \VGA_R[6]_i_15_n_0\ : STD_LOGIC;
  signal \VGA_R[6]_i_16_n_0\ : STD_LOGIC;
  signal \VGA_R[6]_i_17_n_0\ : STD_LOGIC;
  signal \VGA_R[6]_i_18_n_0\ : STD_LOGIC;
  signal \VGA_R[6]_i_19_n_0\ : STD_LOGIC;
  signal \VGA_R[6]_i_20_n_0\ : STD_LOGIC;
  signal \VGA_R[6]_i_21_n_0\ : STD_LOGIC;
  signal \VGA_R[6]_i_22_n_0\ : STD_LOGIC;
  signal \VGA_R[6]_i_23_n_0\ : STD_LOGIC;
  signal \VGA_R[6]_i_24_n_0\ : STD_LOGIC;
  signal \VGA_R[6]_i_25_n_0\ : STD_LOGIC;
  signal \VGA_R[6]_i_26_n_0\ : STD_LOGIC;
  signal \VGA_R[6]_i_29_n_0\ : STD_LOGIC;
  signal \VGA_R[6]_i_30_n_0\ : STD_LOGIC;
  signal \VGA_R[6]_i_31_n_0\ : STD_LOGIC;
  signal \VGA_R[6]_i_32_n_0\ : STD_LOGIC;
  signal \VGA_R[6]_i_33_n_0\ : STD_LOGIC;
  signal \VGA_R[6]_i_8_n_0\ : STD_LOGIC;
  signal \VGA_R[6]_i_9_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_112_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_113_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_114_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_115_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_119_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_120_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_129_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_131_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_176_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_177_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_178_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_179_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_180_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_183_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_184_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_185_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_186_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_187_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_188_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_189_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_190_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_191_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_192_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_205_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_206_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_207_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_208_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_209_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_210_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_242_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_243_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_244_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_245_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_246_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_247_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_248_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_249_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_25_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_270_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_271_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_272_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_273_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_274_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_277_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_278_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_279_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_280_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_281_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_282_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_283_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_284_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_285_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_286_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_29_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_310_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_311_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_312_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_313_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_314_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_315_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_316_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_319_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_34_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_366_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_369_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_370_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_371_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_372_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_373_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_374_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_375_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_376_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_377_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_379_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_380_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_381_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_382_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_383_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_384_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_385_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_386_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_387_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_388_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_389_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_390_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_391_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_392_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_419_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_420_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_421_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_423_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_424_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_425_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_426_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_427_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_438_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_439_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_440_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_441_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_442_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_443_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_444_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_445_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_446_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_461_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_464_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_465_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_466_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_467_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_468_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_469_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_470_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_471_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_472_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_475_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_479_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_480_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_481_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_482_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_484_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_485_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_486_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_487_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_488_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_489_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_490_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_491_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_492_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_495_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_496_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_497_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_498_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_514_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_515_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_516_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_517_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_518_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_519_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_520_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_521_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_522_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_523_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_524_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_525_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_526_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_529_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_531_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_532_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_533_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_534_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_535_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_536_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_537_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_538_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_539_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_541_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_542_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_543_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_544_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_545_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_546_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_547_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_548_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_549_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_550_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_551_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_553_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_554_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_555_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_561_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_562_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_563_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_564_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_565_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_566_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_567_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_568_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_569_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_570_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_573_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_575_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_576_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_577_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_578_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_579_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_580_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_581_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_582_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_583_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_585_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_586_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_587_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_588_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_589_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_590_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_591_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_594_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_596_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_597_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_598_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_599_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_600_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_601_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_602_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_603_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_604_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_606_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_607_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_608_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_60_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_610_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_611_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_612_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_613_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_614_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_615_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_616_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_617_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_618_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_619_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_620_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_621_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_622_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_623_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_624_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_625_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_626_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_627_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_628_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_629_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_630_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_631_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_632_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_82_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_83_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_84_n_0\ : STD_LOGIC;
  signal \VGA_R[7]_i_85_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[0]_i_11_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[0]_i_11_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[0]_i_11_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[0]_i_11_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[0]_i_26_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[0]_i_28_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[0]_i_30_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[0]_i_5_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[0]_i_5_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[0]_i_6_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[0]_i_6_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[0]_i_6_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[0]_i_7_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[0]_i_7_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[0]_i_7_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[0]_i_7_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[1]_i_11_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[1]_i_11_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[1]_i_11_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[1]_i_11_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[1]_i_11_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[1]_i_11_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[1]_i_11_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[1]_i_11_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[1]_i_26_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[1]_i_5_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[1]_i_5_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[1]_i_5_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[1]_i_5_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[1]_i_6_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[1]_i_6_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[1]_i_6_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[1]_i_6_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[1]_i_6_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[1]_i_6_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[1]_i_7_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[1]_i_7_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[1]_i_7_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[1]_i_7_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[1]_i_7_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[1]_i_7_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[1]_i_7_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[1]_i_7_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[2]_i_11_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[2]_i_11_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[2]_i_11_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[2]_i_11_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[2]_i_11_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[2]_i_11_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[2]_i_11_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[2]_i_11_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[2]_i_26_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[2]_i_5_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[2]_i_5_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[2]_i_5_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[2]_i_5_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[2]_i_6_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[2]_i_6_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[2]_i_6_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[2]_i_6_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[2]_i_6_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[2]_i_6_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[2]_i_7_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[2]_i_7_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[2]_i_7_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[2]_i_7_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[2]_i_7_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[2]_i_7_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[2]_i_7_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[2]_i_7_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[3]_i_13_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[3]_i_13_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[3]_i_13_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[3]_i_13_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[3]_i_13_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[3]_i_13_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[3]_i_13_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[3]_i_13_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[3]_i_28_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[3]_i_6_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[3]_i_6_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[3]_i_6_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[3]_i_6_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[3]_i_6_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[3]_i_7_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[3]_i_7_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[3]_i_7_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[3]_i_7_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[3]_i_7_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[3]_i_7_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[3]_i_8_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[3]_i_8_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[3]_i_8_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[3]_i_8_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[3]_i_8_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[3]_i_8_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[3]_i_8_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[3]_i_8_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[4]_i_12_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[4]_i_12_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[4]_i_12_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[4]_i_12_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[4]_i_12_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[4]_i_12_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[4]_i_12_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[4]_i_12_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[4]_i_17_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[4]_i_17_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[4]_i_17_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[4]_i_17_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[4]_i_17_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[4]_i_17_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[4]_i_17_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[4]_i_17_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[4]_i_40_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[4]_i_6_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[4]_i_6_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[4]_i_6_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[4]_i_6_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[4]_i_6_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[4]_i_7_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[4]_i_7_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[4]_i_7_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[4]_i_7_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[4]_i_7_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[4]_i_7_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_100_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_108_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_108_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_108_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_108_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_10_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_10_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_10_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_10_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_10_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_10_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_110_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_110_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_110_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_110_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_114_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_114_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_114_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_114_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_114_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_114_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_114_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_123_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_123_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_123_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_123_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_21_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_21_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_21_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_21_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_21_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_21_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_21_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_21_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_26_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_26_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_26_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_26_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_26_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_26_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_26_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_26_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_78_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_78_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_79_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_79_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_79_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_79_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_79_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_79_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_97_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_97_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_97_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_98_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_98_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_99_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_99_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_99_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_99_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_9_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_9_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_9_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_9_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[5]_i_9_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[6]_i_12_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[6]_i_12_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[6]_i_12_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[6]_i_12_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[6]_i_12_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[6]_i_12_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[6]_i_12_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[6]_i_12_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[6]_i_27_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[6]_i_28_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[6]_i_28_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[6]_i_28_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[6]_i_28_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[6]_i_28_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[6]_i_28_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[6]_i_5_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[6]_i_5_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[6]_i_5_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[6]_i_5_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[6]_i_5_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[6]_i_5_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[6]_i_6_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[6]_i_6_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[6]_i_6_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[6]_i_6_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[6]_i_6_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[6]_i_7_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[6]_i_7_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[6]_i_7_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[6]_i_7_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[6]_i_7_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[6]_i_7_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[6]_i_7_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[6]_i_7_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_101_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_101_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_101_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_101_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_101_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_101_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_101_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_109_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_109_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_109_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_109_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_109_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_109_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_109_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_109_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_110_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_110_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_110_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_110_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_110_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_110_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_111_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_111_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_111_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_111_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_111_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_111_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_111_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_111_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_127_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_127_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_127_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_127_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_127_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_127_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_127_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_181_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_181_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_181_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_181_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_181_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_181_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_181_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_182_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_182_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_182_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_182_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_182_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_182_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_182_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_182_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_203_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_203_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_203_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_203_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_203_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_203_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_203_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_203_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_204_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_204_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_204_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_204_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_204_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_204_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_204_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_241_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_241_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_241_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_241_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_241_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_241_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_241_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_241_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_275_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_275_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_275_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_275_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_275_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_275_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_276_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_276_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_276_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_276_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_276_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_276_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_276_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_276_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_30_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_30_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_30_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_30_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_30_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_30_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_365_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_367_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_367_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_367_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_367_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_367_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_367_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_367_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_368_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_368_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_368_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_368_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_368_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_368_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_368_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_368_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_378_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_40_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_40_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_40_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_40_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_40_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_435_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_435_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_435_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_435_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_435_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_435_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_436_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_436_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_436_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_436_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_436_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_436_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_437_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_437_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_437_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_437_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_437_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_437_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_437_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_437_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_447_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_447_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_447_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_447_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_447_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_447_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_460_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_460_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_460_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_460_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_460_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_460_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_460_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_462_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_462_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_462_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_462_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_462_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_462_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_462_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_463_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_463_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_463_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_463_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_463_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_463_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_463_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_463_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_473_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_474_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_474_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_474_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_474_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_474_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_474_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_474_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_477_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_477_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_477_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_477_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_477_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_477_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_477_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_477_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_478_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_478_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_478_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_478_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_478_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_478_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_478_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_478_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_483_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_483_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_483_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_483_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_483_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_483_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_483_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_483_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_493_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_494_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_494_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_494_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_494_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_494_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_494_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_494_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_512_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_512_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_512_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_512_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_512_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_512_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_512_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_512_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_513_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_513_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_513_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_513_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_513_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_513_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_513_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_513_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_527_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_528_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_528_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_528_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_528_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_528_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_528_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_528_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_530_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_530_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_530_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_530_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_530_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_530_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_530_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_530_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_540_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_540_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_540_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_540_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_540_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_540_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_540_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_540_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_552_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_552_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_552_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_552_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_571_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_572_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_572_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_572_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_572_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_572_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_572_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_572_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_574_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_574_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_574_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_574_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_574_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_574_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_574_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_574_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_584_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_584_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_584_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_584_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_584_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_584_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_584_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_584_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_592_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_592_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_593_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_593_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_593_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_593_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_593_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_593_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_593_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_595_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_595_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_595_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_595_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_595_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_595_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_595_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_595_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_605_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_605_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_605_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_609_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_609_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_609_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_609_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_609_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_609_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_609_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_79_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_79_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_79_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_79_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_79_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_79_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_79_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_79_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_80_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_80_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_80_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_80_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_80_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_80_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_80_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_81_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_81_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_81_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_81_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_81_n_4\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_81_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_81_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_81_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_92_n_0\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_92_n_1\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_92_n_2\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_92_n_3\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_92_n_5\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_92_n_6\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_92_n_7\ : STD_LOGIC;
  signal \VGA_R_reg[7]_i_93_n_3\ : STD_LOGIC;
  signal data2 : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal data6 : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal data9 : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal disp_enable2 : STD_LOGIC_VECTOR ( 1 to 1 );
  signal disp_y : STD_LOGIC_VECTOR ( 5 downto 0 );
  signal p_1_in : STD_LOGIC_VECTOR ( 10 downto 0 );
  signal pattern_b : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal \pattern_b1__0_i_13_n_0\ : STD_LOGIC;
  signal \pattern_b1__0_n_100\ : STD_LOGIC;
  signal \pattern_b1__0_n_101\ : STD_LOGIC;
  signal \pattern_b1__0_n_102\ : STD_LOGIC;
  signal \pattern_b1__0_n_103\ : STD_LOGIC;
  signal \pattern_b1__0_n_104\ : STD_LOGIC;
  signal \pattern_b1__0_n_105\ : STD_LOGIC;
  signal \pattern_b1__0_n_87\ : STD_LOGIC;
  signal \pattern_b1__0_n_88\ : STD_LOGIC;
  signal \pattern_b1__0_n_89\ : STD_LOGIC;
  signal \pattern_b1__0_n_90\ : STD_LOGIC;
  signal \pattern_b1__0_n_91\ : STD_LOGIC;
  signal \pattern_b1__0_n_92\ : STD_LOGIC;
  signal \pattern_b1__0_n_93\ : STD_LOGIC;
  signal \pattern_b1__0_n_94\ : STD_LOGIC;
  signal \pattern_b1__0_n_95\ : STD_LOGIC;
  signal \pattern_b1__0_n_96\ : STD_LOGIC;
  signal \pattern_b1__0_n_97\ : STD_LOGIC;
  signal \pattern_b1__0_n_98\ : STD_LOGIC;
  signal \pattern_b1__0_n_99\ : STD_LOGIC;
  signal pattern_b1_i_18_n_0 : STD_LOGIC;
  signal pattern_b1_i_18_n_1 : STD_LOGIC;
  signal pattern_b1_i_18_n_2 : STD_LOGIC;
  signal pattern_b1_i_18_n_3 : STD_LOGIC;
  signal pattern_b1_i_18_n_4 : STD_LOGIC;
  signal pattern_b1_i_18_n_5 : STD_LOGIC;
  signal pattern_b1_i_18_n_6 : STD_LOGIC;
  signal pattern_b1_i_23_n_0 : STD_LOGIC;
  signal pattern_b1_i_23_n_2 : STD_LOGIC;
  signal pattern_b1_i_23_n_3 : STD_LOGIC;
  signal pattern_b1_i_23_n_5 : STD_LOGIC;
  signal pattern_b1_i_23_n_6 : STD_LOGIC;
  signal pattern_b1_i_23_n_7 : STD_LOGIC;
  signal pattern_b1_i_24_n_3 : STD_LOGIC;
  signal pattern_b1_i_25_n_0 : STD_LOGIC;
  signal pattern_b1_i_26_n_0 : STD_LOGIC;
  signal pattern_b1_i_27_n_0 : STD_LOGIC;
  signal pattern_b1_i_28_n_0 : STD_LOGIC;
  signal pattern_b1_i_29_n_0 : STD_LOGIC;
  signal pattern_b1_i_30_n_0 : STD_LOGIC;
  signal pattern_b1_i_32_n_0 : STD_LOGIC;
  signal pattern_b1_i_33_n_0 : STD_LOGIC;
  signal pattern_b1_i_34_n_0 : STD_LOGIC;
  signal pattern_b1_i_35_n_0 : STD_LOGIC;
  signal pattern_b1_n_100 : STD_LOGIC;
  signal pattern_b1_n_101 : STD_LOGIC;
  signal pattern_b1_n_102 : STD_LOGIC;
  signal pattern_b1_n_103 : STD_LOGIC;
  signal pattern_b1_n_104 : STD_LOGIC;
  signal pattern_b1_n_105 : STD_LOGIC;
  signal pattern_b1_n_87 : STD_LOGIC;
  signal pattern_b1_n_88 : STD_LOGIC;
  signal pattern_b1_n_89 : STD_LOGIC;
  signal pattern_b1_n_90 : STD_LOGIC;
  signal pattern_b1_n_91 : STD_LOGIC;
  signal pattern_b1_n_92 : STD_LOGIC;
  signal pattern_b1_n_93 : STD_LOGIC;
  signal pattern_b1_n_94 : STD_LOGIC;
  signal pattern_b1_n_95 : STD_LOGIC;
  signal pattern_b1_n_96 : STD_LOGIC;
  signal pattern_b1_n_97 : STD_LOGIC;
  signal pattern_b1_n_98 : STD_LOGIC;
  signal pattern_b1_n_99 : STD_LOGIC;
  signal pattern_g : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal pattern_r : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal syncgen_multi_n_22 : STD_LOGIC;
  signal syncgen_multi_n_23 : STD_LOGIC;
  signal zp_sum0_n_100 : STD_LOGIC;
  signal zp_sum0_n_101 : STD_LOGIC;
  signal zp_sum0_n_102 : STD_LOGIC;
  signal zp_sum0_n_103 : STD_LOGIC;
  signal zp_sum0_n_104 : STD_LOGIC;
  signal zp_sum0_n_105 : STD_LOGIC;
  signal zp_sum0_n_84 : STD_LOGIC;
  signal zp_sum0_n_85 : STD_LOGIC;
  signal zp_sum0_n_86 : STD_LOGIC;
  signal zp_sum0_n_87 : STD_LOGIC;
  signal zp_sum0_n_88 : STD_LOGIC;
  signal zp_sum0_n_89 : STD_LOGIC;
  signal zp_sum0_n_90 : STD_LOGIC;
  signal zp_sum0_n_91 : STD_LOGIC;
  signal zp_sum0_n_92 : STD_LOGIC;
  signal zp_sum0_n_93 : STD_LOGIC;
  signal zp_sum0_n_94 : STD_LOGIC;
  signal zp_sum0_n_95 : STD_LOGIC;
  signal zp_sum0_n_96 : STD_LOGIC;
  signal zp_sum0_n_97 : STD_LOGIC;
  signal zp_sum0_n_98 : STD_LOGIC;
  signal zp_sum0_n_99 : STD_LOGIC;
  signal zp_sum_n_101 : STD_LOGIC;
  signal zp_sum_n_102 : STD_LOGIC;
  signal zp_sum_n_103 : STD_LOGIC;
  signal zp_sum_n_104 : STD_LOGIC;
  signal zp_sum_n_105 : STD_LOGIC;
  signal \NLW_VGA_R_reg[0]_i_11_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[0]_i_26_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[0]_i_26_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_VGA_R_reg[0]_i_28_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[0]_i_28_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_VGA_R_reg[0]_i_30_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[0]_i_30_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_VGA_R_reg[0]_i_5_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_VGA_R_reg[0]_i_5_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[0]_i_6_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[0]_i_7_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[1]_i_26_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[1]_i_26_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_VGA_R_reg[1]_i_5_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_VGA_R_reg[1]_i_5_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_VGA_R_reg[1]_i_6_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_VGA_R_reg[2]_i_26_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[2]_i_26_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_VGA_R_reg[2]_i_5_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_VGA_R_reg[2]_i_5_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_VGA_R_reg[2]_i_6_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_VGA_R_reg[3]_i_28_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[3]_i_28_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_VGA_R_reg[3]_i_6_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_VGA_R_reg[3]_i_6_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 2 to 2 );
  signal \NLW_VGA_R_reg[3]_i_7_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_VGA_R_reg[4]_i_40_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[4]_i_40_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_VGA_R_reg[4]_i_6_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_VGA_R_reg[4]_i_6_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 2 to 2 );
  signal \NLW_VGA_R_reg[4]_i_7_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_VGA_R_reg[5]_i_10_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_VGA_R_reg[5]_i_100_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[5]_i_100_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_VGA_R_reg[5]_i_108_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_VGA_R_reg[5]_i_108_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_VGA_R_reg[5]_i_110_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[5]_i_114_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_VGA_R_reg[5]_i_123_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[5]_i_78_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_VGA_R_reg[5]_i_78_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[5]_i_79_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 2 to 2 );
  signal \NLW_VGA_R_reg[5]_i_79_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_VGA_R_reg[5]_i_9_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_VGA_R_reg[5]_i_9_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 2 to 2 );
  signal \NLW_VGA_R_reg[5]_i_97_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_VGA_R_reg[5]_i_97_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[5]_i_98_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_VGA_R_reg[5]_i_98_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[5]_i_99_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_VGA_R_reg[5]_i_99_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_VGA_R_reg[6]_i_27_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[6]_i_27_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_VGA_R_reg[6]_i_28_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_VGA_R_reg[6]_i_28_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 2 to 2 );
  signal \NLW_VGA_R_reg[6]_i_5_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_VGA_R_reg[6]_i_6_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_VGA_R_reg[6]_i_6_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 2 to 2 );
  signal \NLW_VGA_R_reg[7]_i_101_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_VGA_R_reg[7]_i_110_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_VGA_R_reg[7]_i_110_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 2 to 2 );
  signal \NLW_VGA_R_reg[7]_i_127_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_VGA_R_reg[7]_i_181_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_VGA_R_reg[7]_i_204_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_VGA_R_reg[7]_i_275_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_VGA_R_reg[7]_i_275_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 2 to 2 );
  signal \NLW_VGA_R_reg[7]_i_30_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_VGA_R_reg[7]_i_365_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[7]_i_365_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_VGA_R_reg[7]_i_367_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_VGA_R_reg[7]_i_378_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[7]_i_378_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_VGA_R_reg[7]_i_40_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_VGA_R_reg[7]_i_40_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 2 to 2 );
  signal \NLW_VGA_R_reg[7]_i_435_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_VGA_R_reg[7]_i_435_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 2 to 2 );
  signal \NLW_VGA_R_reg[7]_i_436_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_VGA_R_reg[7]_i_436_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 2 to 2 );
  signal \NLW_VGA_R_reg[7]_i_447_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_VGA_R_reg[7]_i_447_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 2 to 2 );
  signal \NLW_VGA_R_reg[7]_i_460_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_VGA_R_reg[7]_i_462_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_VGA_R_reg[7]_i_473_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[7]_i_473_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_VGA_R_reg[7]_i_474_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_VGA_R_reg[7]_i_493_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[7]_i_493_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_VGA_R_reg[7]_i_494_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_VGA_R_reg[7]_i_527_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[7]_i_527_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_VGA_R_reg[7]_i_528_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_VGA_R_reg[7]_i_552_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_VGA_R_reg[7]_i_552_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_VGA_R_reg[7]_i_571_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[7]_i_571_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_VGA_R_reg[7]_i_572_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_VGA_R_reg[7]_i_592_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_VGA_R_reg[7]_i_592_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[7]_i_593_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_VGA_R_reg[7]_i_605_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_VGA_R_reg[7]_i_605_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_VGA_R_reg[7]_i_609_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_VGA_R_reg[7]_i_80_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_VGA_R_reg[7]_i_92_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_VGA_R_reg[7]_i_93_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_VGA_R_reg[7]_i_93_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal NLW_pattern_b1_CARRYCASCOUT_UNCONNECTED : STD_LOGIC;
  signal NLW_pattern_b1_MULTSIGNOUT_UNCONNECTED : STD_LOGIC;
  signal NLW_pattern_b1_OVERFLOW_UNCONNECTED : STD_LOGIC;
  signal NLW_pattern_b1_PATTERNBDETECT_UNCONNECTED : STD_LOGIC;
  signal NLW_pattern_b1_PATTERNDETECT_UNCONNECTED : STD_LOGIC;
  signal NLW_pattern_b1_UNDERFLOW_UNCONNECTED : STD_LOGIC;
  signal NLW_pattern_b1_ACOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 29 downto 0 );
  signal NLW_pattern_b1_BCOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 17 downto 0 );
  signal NLW_pattern_b1_CARRYOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal NLW_pattern_b1_P_UNCONNECTED : STD_LOGIC_VECTOR ( 47 downto 19 );
  signal NLW_pattern_b1_PCOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 47 downto 0 );
  signal \NLW_pattern_b1__0_CARRYCASCOUT_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_pattern_b1__0_MULTSIGNOUT_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_pattern_b1__0_OVERFLOW_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_pattern_b1__0_PATTERNBDETECT_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_pattern_b1__0_PATTERNDETECT_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_pattern_b1__0_UNDERFLOW_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_pattern_b1__0_ACOUT_UNCONNECTED\ : STD_LOGIC_VECTOR ( 29 downto 0 );
  signal \NLW_pattern_b1__0_BCOUT_UNCONNECTED\ : STD_LOGIC_VECTOR ( 17 downto 0 );
  signal \NLW_pattern_b1__0_CARRYOUT_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_pattern_b1__0_P_UNCONNECTED\ : STD_LOGIC_VECTOR ( 47 downto 19 );
  signal \NLW_pattern_b1__0_PCOUT_UNCONNECTED\ : STD_LOGIC_VECTOR ( 47 downto 0 );
  signal NLW_pattern_b1_i_18_O_UNCONNECTED : STD_LOGIC_VECTOR ( 0 to 0 );
  signal NLW_pattern_b1_i_23_CO_UNCONNECTED : STD_LOGIC_VECTOR ( 2 to 2 );
  signal NLW_pattern_b1_i_23_O_UNCONNECTED : STD_LOGIC_VECTOR ( 3 to 3 );
  signal NLW_pattern_b1_i_24_CO_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal NLW_pattern_b1_i_24_O_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal NLW_zp_sum_CARRYCASCOUT_UNCONNECTED : STD_LOGIC;
  signal NLW_zp_sum_MULTSIGNOUT_UNCONNECTED : STD_LOGIC;
  signal NLW_zp_sum_OVERFLOW_UNCONNECTED : STD_LOGIC;
  signal NLW_zp_sum_PATTERNBDETECT_UNCONNECTED : STD_LOGIC;
  signal NLW_zp_sum_PATTERNDETECT_UNCONNECTED : STD_LOGIC;
  signal NLW_zp_sum_UNDERFLOW_UNCONNECTED : STD_LOGIC;
  signal NLW_zp_sum_ACOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 29 downto 0 );
  signal NLW_zp_sum_BCOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 17 downto 0 );
  signal NLW_zp_sum_CARRYOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal NLW_zp_sum_P_UNCONNECTED : STD_LOGIC_VECTOR ( 47 downto 13 );
  signal NLW_zp_sum_PCOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 47 downto 0 );
  signal NLW_zp_sum0_CARRYCASCOUT_UNCONNECTED : STD_LOGIC;
  signal NLW_zp_sum0_MULTSIGNOUT_UNCONNECTED : STD_LOGIC;
  signal NLW_zp_sum0_OVERFLOW_UNCONNECTED : STD_LOGIC;
  signal NLW_zp_sum0_PATTERNBDETECT_UNCONNECTED : STD_LOGIC;
  signal NLW_zp_sum0_PATTERNDETECT_UNCONNECTED : STD_LOGIC;
  signal NLW_zp_sum0_UNDERFLOW_UNCONNECTED : STD_LOGIC;
  signal NLW_zp_sum0_ACOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 29 downto 0 );
  signal NLW_zp_sum0_BCOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 17 downto 0 );
  signal NLW_zp_sum0_CARRYOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal NLW_zp_sum0_P_UNCONNECTED : STD_LOGIC_VECTOR ( 47 downto 22 );
  signal NLW_zp_sum0_PCOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 47 downto 0 );
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \VGA_R[0]_i_2\ : label is "soft_lutpair42";
  attribute SOFT_HLUTNM of \VGA_R[1]_i_2\ : label is "soft_lutpair41";
  attribute SOFT_HLUTNM of \VGA_R[2]_i_2\ : label is "soft_lutpair40";
  attribute SOFT_HLUTNM of \VGA_R[5]_i_101\ : label is "soft_lutpair44";
  attribute SOFT_HLUTNM of \VGA_R[5]_i_102\ : label is "soft_lutpair44";
  attribute SOFT_HLUTNM of \VGA_R[5]_i_5\ : label is "soft_lutpair41";
  attribute SOFT_HLUTNM of \VGA_R[7]_i_119\ : label is "soft_lutpair43";
  attribute SOFT_HLUTNM of \VGA_R[7]_i_120\ : label is "soft_lutpair43";
  attribute SOFT_HLUTNM of \VGA_R[7]_i_25\ : label is "soft_lutpair40";
  attribute SOFT_HLUTNM of \VGA_R[7]_i_29\ : label is "soft_lutpair42";
  attribute ADDER_THRESHOLD : integer;
  attribute ADDER_THRESHOLD of \VGA_R_reg[5]_i_110\ : label is 35;
  attribute ADDER_THRESHOLD of \VGA_R_reg[5]_i_123\ : label is 35;
  attribute ADDER_THRESHOLD of \VGA_R_reg[5]_i_98\ : label is 35;
  attribute METHODOLOGY_DRC_VIOS : string;
  attribute METHODOLOGY_DRC_VIOS of pattern_b1 : label is "{SYNTH-13 {cell *THIS*}}";
  attribute METHODOLOGY_DRC_VIOS of \pattern_b1__0\ : label is "{SYNTH-13 {cell *THIS*}}";
  attribute METHODOLOGY_DRC_VIOS of zp_sum : label is "{SYNTH-13 {cell *THIS*}}";
  attribute METHODOLOGY_DRC_VIOS of zp_sum0 : label is "{SYNTH-13 {cell *THIS*}}";
begin
  PCK <= \^pck\;
\VGA_B_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => \^pck\,
      CE => '1',
      D => pattern_b(0),
      Q => VGA_B(0),
      R => syncgen_multi_n_22
    );
\VGA_B_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => \^pck\,
      CE => '1',
      D => pattern_b(1),
      Q => VGA_B(1),
      R => syncgen_multi_n_22
    );
\VGA_B_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => \^pck\,
      CE => '1',
      D => pattern_b(2),
      Q => VGA_B(2),
      R => syncgen_multi_n_22
    );
\VGA_B_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => \^pck\,
      CE => '1',
      D => pattern_b(3),
      Q => VGA_B(3),
      R => syncgen_multi_n_22
    );
\VGA_B_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => \^pck\,
      CE => '1',
      D => pattern_b(4),
      Q => VGA_B(4),
      R => syncgen_multi_n_22
    );
\VGA_B_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => \^pck\,
      CE => '1',
      D => pattern_b(5),
      Q => VGA_B(5),
      R => syncgen_multi_n_22
    );
\VGA_B_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => \^pck\,
      CE => '1',
      D => pattern_b(6),
      Q => VGA_B(6),
      R => syncgen_multi_n_22
    );
\VGA_B_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => \^pck\,
      CE => '1',
      D => pattern_b(7),
      Q => VGA_B(7),
      R => syncgen_multi_n_22
    );
VGA_DE_reg: unisim.vcomponents.FDRE
     port map (
      C => \^pck\,
      CE => '1',
      D => syncgen_multi_n_23,
      Q => VGA_DE,
      R => '0'
    );
\VGA_G_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => \^pck\,
      CE => '1',
      D => pattern_g(0),
      Q => VGA_G(0),
      R => syncgen_multi_n_22
    );
\VGA_G_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => \^pck\,
      CE => '1',
      D => pattern_g(1),
      Q => VGA_G(1),
      R => syncgen_multi_n_22
    );
\VGA_G_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => \^pck\,
      CE => '1',
      D => pattern_g(2),
      Q => VGA_G(2),
      R => syncgen_multi_n_22
    );
\VGA_G_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => \^pck\,
      CE => '1',
      D => pattern_g(3),
      Q => VGA_G(3),
      R => syncgen_multi_n_22
    );
\VGA_G_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => \^pck\,
      CE => '1',
      D => pattern_g(4),
      Q => VGA_G(4),
      R => syncgen_multi_n_22
    );
\VGA_G_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => \^pck\,
      CE => '1',
      D => pattern_g(5),
      Q => VGA_G(5),
      R => syncgen_multi_n_22
    );
\VGA_G_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => \^pck\,
      CE => '1',
      D => pattern_g(6),
      Q => VGA_G(6),
      R => syncgen_multi_n_22
    );
\VGA_G_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => \^pck\,
      CE => '1',
      D => pattern_g(7),
      Q => VGA_G(7),
      R => syncgen_multi_n_22
    );
\VGA_R[0]_i_10\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_286_n_0\,
      I1 => data6(1),
      I2 => \VGA_R_reg[1]_i_7_n_4\,
      O => \VGA_R[0]_i_10_n_0\
    );
\VGA_R[0]_i_12\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => data2(1),
      I1 => \VGA_R_reg[1]_i_6_n_5\,
      O => \VGA_R[0]_i_12_n_0\
    );
\VGA_R[0]_i_13\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => data2(1),
      I1 => \VGA_R[7]_i_192_n_0\,
      I2 => \VGA_R_reg[1]_i_6_n_6\,
      O => \VGA_R[0]_i_13_n_0\
    );
\VGA_R[0]_i_14\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_192_n_0\,
      I1 => data2(1),
      I2 => \VGA_R_reg[1]_i_6_n_7\,
      O => \VGA_R[0]_i_14_n_0\
    );
\VGA_R[0]_i_15\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => data2(1),
      I1 => \VGA_R[7]_i_192_n_0\,
      I2 => \VGA_R_reg[1]_i_11_n_4\,
      O => \VGA_R[0]_i_15_n_0\
    );
\VGA_R[0]_i_16\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \VGA_R_reg[3]_i_6_n_4\,
      O => \VGA_R[0]_i_16_n_0\
    );
\VGA_R[0]_i_17\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => data6(1),
      I1 => \VGA_R_reg[1]_i_7_n_5\,
      O => \VGA_R[0]_i_17_n_0\
    );
\VGA_R[0]_i_18\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => data6(1),
      I1 => \VGA_R_reg[1]_i_7_n_6\,
      O => \VGA_R[0]_i_18_n_0\
    );
\VGA_R[0]_i_19\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_286_n_0\,
      I1 => data6(1),
      I2 => \VGA_R_reg[1]_i_7_n_7\,
      O => \VGA_R[0]_i_19_n_0\
    );
\VGA_R[0]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00080000"
    )
        port map (
      I0 => pattern_sel(0),
      I1 => pattern_sel(3),
      I2 => pattern_sel(2),
      I3 => pattern_sel(1),
      I4 => data9(0),
      O => \VGA_R[0]_i_2_n_0\
    );
\VGA_R[0]_i_20\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => data6(1),
      I1 => \VGA_R[7]_i_286_n_0\,
      I2 => \VGA_R_reg[3]_i_6_n_4\,
      O => \VGA_R[0]_i_20_n_0\
    );
\VGA_R[0]_i_21\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \VGA_R_reg[0]_i_26_n_7\,
      O => \VGA_R[0]_i_21_n_0\
    );
\VGA_R[0]_i_22\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_192_n_0\,
      I1 => data2(1),
      I2 => \VGA_R_reg[1]_i_11_n_5\,
      O => \VGA_R[0]_i_22_n_0\
    );
\VGA_R[0]_i_23\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"659A"
    )
        port map (
      I0 => data2(1),
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      I3 => \VGA_R_reg[1]_i_11_n_6\,
      O => \VGA_R[0]_i_23_n_0\
    );
\VGA_R[0]_i_24\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => data2(1),
      I1 => \VGA_R_reg[1]_i_11_n_7\,
      O => \VGA_R[0]_i_24_n_0\
    );
\VGA_R[0]_i_25\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"659A"
    )
        port map (
      I0 => data2(1),
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      I3 => \VGA_R_reg[0]_i_26_n_7\,
      O => \VGA_R[0]_i_25_n_0\
    );
\VGA_R[0]_i_27\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[0]_i_28_n_7\,
      I1 => data2(3),
      O => \VGA_R[0]_i_27_n_0\
    );
\VGA_R[0]_i_29\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[0]_i_30_n_7\,
      I1 => data2(4),
      O => \VGA_R[0]_i_29_n_0\
    );
\VGA_R[0]_i_31\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => pattern_b1_n_101,
      I1 => data2(5),
      O => \VGA_R[0]_i_31_n_0\
    );
\VGA_R[0]_i_8\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => data6(1),
      I1 => \VGA_R_reg[1]_i_5_n_6\,
      O => \VGA_R[0]_i_8_n_0\
    );
\VGA_R[0]_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => data6(1),
      I1 => \VGA_R[7]_i_286_n_0\,
      I2 => \VGA_R_reg[1]_i_5_n_7\,
      O => \VGA_R[0]_i_9_n_0\
    );
\VGA_R[1]_i_10\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_286_n_0\,
      I1 => data6(2),
      I2 => \VGA_R_reg[2]_i_7_n_4\,
      O => \VGA_R[1]_i_10_n_0\
    );
\VGA_R[1]_i_12\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => data2(2),
      I1 => \VGA_R_reg[2]_i_6_n_5\,
      O => \VGA_R[1]_i_12_n_0\
    );
\VGA_R[1]_i_13\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => data2(2),
      I1 => \VGA_R[7]_i_192_n_0\,
      I2 => \VGA_R_reg[2]_i_6_n_6\,
      O => \VGA_R[1]_i_13_n_0\
    );
\VGA_R[1]_i_14\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_192_n_0\,
      I1 => data2(2),
      I2 => \VGA_R_reg[2]_i_6_n_7\,
      O => \VGA_R[1]_i_14_n_0\
    );
\VGA_R[1]_i_15\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => data2(2),
      I1 => \VGA_R[7]_i_192_n_0\,
      I2 => \VGA_R_reg[2]_i_11_n_4\,
      O => \VGA_R[1]_i_15_n_0\
    );
\VGA_R[1]_i_16\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \VGA_R_reg[6]_i_6_n_4\,
      O => \VGA_R[1]_i_16_n_0\
    );
\VGA_R[1]_i_17\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => data6(2),
      I1 => \VGA_R_reg[2]_i_7_n_5\,
      O => \VGA_R[1]_i_17_n_0\
    );
\VGA_R[1]_i_18\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => data6(2),
      I1 => \VGA_R_reg[2]_i_7_n_6\,
      O => \VGA_R[1]_i_18_n_0\
    );
\VGA_R[1]_i_19\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_286_n_0\,
      I1 => data6(2),
      I2 => \VGA_R_reg[2]_i_7_n_7\,
      O => \VGA_R[1]_i_19_n_0\
    );
\VGA_R[1]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00080000"
    )
        port map (
      I0 => pattern_sel(0),
      I1 => pattern_sel(3),
      I2 => pattern_sel(2),
      I3 => pattern_sel(1),
      I4 => data9(1),
      O => \VGA_R[1]_i_2_n_0\
    );
\VGA_R[1]_i_20\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => data6(2),
      I1 => \VGA_R[7]_i_286_n_0\,
      I2 => \VGA_R_reg[6]_i_6_n_4\,
      O => \VGA_R[1]_i_20_n_0\
    );
\VGA_R[1]_i_21\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \VGA_R_reg[1]_i_26_n_7\,
      O => \VGA_R[1]_i_21_n_0\
    );
\VGA_R[1]_i_22\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_192_n_0\,
      I1 => data2(2),
      I2 => \VGA_R_reg[2]_i_11_n_5\,
      O => \VGA_R[1]_i_22_n_0\
    );
\VGA_R[1]_i_23\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"659A"
    )
        port map (
      I0 => data2(2),
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      I3 => \VGA_R_reg[2]_i_11_n_6\,
      O => \VGA_R[1]_i_23_n_0\
    );
\VGA_R[1]_i_24\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => data2(2),
      I1 => \VGA_R_reg[2]_i_11_n_7\,
      O => \VGA_R[1]_i_24_n_0\
    );
\VGA_R[1]_i_25\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => data2(2),
      I1 => \VGA_R[7]_i_366_n_0\,
      I2 => \VGA_R_reg[1]_i_26_n_7\,
      O => \VGA_R[1]_i_25_n_0\
    );
\VGA_R[1]_i_27\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => pattern_b1_n_100,
      I1 => data2(6),
      O => \VGA_R[1]_i_27_n_0\
    );
\VGA_R[1]_i_8\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => data6(2),
      I1 => \VGA_R_reg[2]_i_5_n_6\,
      O => \VGA_R[1]_i_8_n_0\
    );
\VGA_R[1]_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => data6(2),
      I1 => \VGA_R[7]_i_286_n_0\,
      I2 => \VGA_R_reg[2]_i_5_n_7\,
      O => \VGA_R[1]_i_9_n_0\
    );
\VGA_R[2]_i_10\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_286_n_0\,
      I1 => data6(3),
      I2 => \VGA_R_reg[3]_i_8_n_4\,
      O => \VGA_R[2]_i_10_n_0\
    );
\VGA_R[2]_i_12\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => data2(3),
      I1 => \VGA_R_reg[3]_i_7_n_5\,
      O => \VGA_R[2]_i_12_n_0\
    );
\VGA_R[2]_i_13\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => data2(3),
      I1 => \VGA_R[7]_i_192_n_0\,
      I2 => \VGA_R_reg[3]_i_7_n_6\,
      O => \VGA_R[2]_i_13_n_0\
    );
\VGA_R[2]_i_14\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_192_n_0\,
      I1 => data2(3),
      I2 => \VGA_R_reg[3]_i_7_n_7\,
      O => \VGA_R[2]_i_14_n_0\
    );
\VGA_R[2]_i_15\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => data2(3),
      I1 => \VGA_R[7]_i_192_n_0\,
      I2 => \VGA_R_reg[3]_i_13_n_4\,
      O => \VGA_R[2]_i_15_n_0\
    );
\VGA_R[2]_i_16\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_40_n_4\,
      O => \VGA_R[2]_i_16_n_0\
    );
\VGA_R[2]_i_17\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => data6(3),
      I1 => \VGA_R_reg[3]_i_8_n_5\,
      O => \VGA_R[2]_i_17_n_0\
    );
\VGA_R[2]_i_18\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => data6(3),
      I1 => \VGA_R_reg[3]_i_8_n_6\,
      O => \VGA_R[2]_i_18_n_0\
    );
\VGA_R[2]_i_19\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_286_n_0\,
      I1 => data6(3),
      I2 => \VGA_R_reg[3]_i_8_n_7\,
      O => \VGA_R[2]_i_19_n_0\
    );
\VGA_R[2]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00080000"
    )
        port map (
      I0 => pattern_sel(0),
      I1 => pattern_sel(3),
      I2 => pattern_sel(2),
      I3 => pattern_sel(1),
      I4 => data9(2),
      O => \VGA_R[2]_i_2_n_0\
    );
\VGA_R[2]_i_20\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => data6(3),
      I1 => \VGA_R[7]_i_286_n_0\,
      I2 => \VGA_R_reg[7]_i_40_n_4\,
      O => \VGA_R[2]_i_20_n_0\
    );
\VGA_R[2]_i_21\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \VGA_R_reg[2]_i_26_n_7\,
      O => \VGA_R[2]_i_21_n_0\
    );
\VGA_R[2]_i_22\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_192_n_0\,
      I1 => data2(3),
      I2 => \VGA_R_reg[3]_i_13_n_5\,
      O => \VGA_R[2]_i_22_n_0\
    );
\VGA_R[2]_i_23\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"659A"
    )
        port map (
      I0 => data2(3),
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      I3 => \VGA_R_reg[3]_i_13_n_6\,
      O => \VGA_R[2]_i_23_n_0\
    );
\VGA_R[2]_i_24\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => data2(3),
      I1 => \VGA_R_reg[3]_i_13_n_7\,
      O => \VGA_R[2]_i_24_n_0\
    );
\VGA_R[2]_i_25\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => data2(3),
      I1 => \VGA_R[7]_i_366_n_0\,
      I2 => \VGA_R_reg[2]_i_26_n_7\,
      O => \VGA_R[2]_i_25_n_0\
    );
\VGA_R[2]_i_27\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => pattern_b1_n_99,
      I1 => data2(7),
      O => \VGA_R[2]_i_27_n_0\
    );
\VGA_R[2]_i_8\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => data6(3),
      I1 => \VGA_R_reg[3]_i_6_n_6\,
      O => \VGA_R[2]_i_8_n_0\
    );
\VGA_R[2]_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => data6(3),
      I1 => \VGA_R[7]_i_286_n_0\,
      I2 => \VGA_R_reg[3]_i_6_n_7\,
      O => \VGA_R[2]_i_9_n_0\
    );
\VGA_R[3]_i_10\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => data6(4),
      I1 => \VGA_R_reg[4]_i_6_n_6\,
      O => \VGA_R[3]_i_10_n_0\
    );
\VGA_R[3]_i_11\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => data6(4),
      I1 => \VGA_R[7]_i_286_n_0\,
      I2 => \VGA_R_reg[4]_i_6_n_7\,
      O => \VGA_R[3]_i_11_n_0\
    );
\VGA_R[3]_i_12\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_286_n_0\,
      I1 => data6(4),
      I2 => \VGA_R_reg[4]_i_12_n_4\,
      O => \VGA_R[3]_i_12_n_0\
    );
\VGA_R[3]_i_14\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => data2(4),
      I1 => \VGA_R_reg[4]_i_7_n_5\,
      O => \VGA_R[3]_i_14_n_0\
    );
\VGA_R[3]_i_15\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => data2(4),
      I1 => \VGA_R[7]_i_192_n_0\,
      I2 => \VGA_R_reg[4]_i_7_n_6\,
      O => \VGA_R[3]_i_15_n_0\
    );
\VGA_R[3]_i_16\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_192_n_0\,
      I1 => data2(4),
      I2 => \VGA_R_reg[4]_i_7_n_7\,
      O => \VGA_R[3]_i_16_n_0\
    );
\VGA_R[3]_i_17\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => data2(4),
      I1 => \VGA_R[7]_i_192_n_0\,
      I2 => \VGA_R_reg[4]_i_17_n_4\,
      O => \VGA_R[3]_i_17_n_0\
    );
\VGA_R[3]_i_18\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_110_n_4\,
      O => \VGA_R[3]_i_18_n_0\
    );
\VGA_R[3]_i_19\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => data6(4),
      I1 => \VGA_R_reg[4]_i_12_n_5\,
      O => \VGA_R[3]_i_19_n_0\
    );
\VGA_R[3]_i_20\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => data6(4),
      I1 => \VGA_R_reg[4]_i_12_n_6\,
      O => \VGA_R[3]_i_20_n_0\
    );
\VGA_R[3]_i_21\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_286_n_0\,
      I1 => data6(4),
      I2 => \VGA_R_reg[4]_i_12_n_7\,
      O => \VGA_R[3]_i_21_n_0\
    );
\VGA_R[3]_i_22\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => data6(4),
      I1 => \VGA_R[7]_i_286_n_0\,
      I2 => \VGA_R_reg[7]_i_110_n_4\,
      O => \VGA_R[3]_i_22_n_0\
    );
\VGA_R[3]_i_23\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \VGA_R_reg[3]_i_28_n_7\,
      O => \VGA_R[3]_i_23_n_0\
    );
\VGA_R[3]_i_24\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_192_n_0\,
      I1 => data2(4),
      I2 => \VGA_R_reg[4]_i_17_n_5\,
      O => \VGA_R[3]_i_24_n_0\
    );
\VGA_R[3]_i_25\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"659A"
    )
        port map (
      I0 => data2(4),
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      I3 => \VGA_R_reg[4]_i_17_n_6\,
      O => \VGA_R[3]_i_25_n_0\
    );
\VGA_R[3]_i_26\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => data2(4),
      I1 => \VGA_R_reg[4]_i_17_n_7\,
      O => \VGA_R[3]_i_26_n_0\
    );
\VGA_R[3]_i_27\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => data2(4),
      I1 => \VGA_R[7]_i_366_n_0\,
      I2 => \VGA_R_reg[3]_i_28_n_7\,
      O => \VGA_R[3]_i_27_n_0\
    );
\VGA_R[3]_i_29\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => pattern_b1_n_98,
      I1 => \VGA_R_reg[7]_i_80_n_0\,
      O => \VGA_R[3]_i_29_n_0\
    );
\VGA_R[3]_i_9\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => data6(3),
      I1 => \VGA_R_reg[4]_i_6_n_4\,
      O => \VGA_R[3]_i_9_n_0\
    );
\VGA_R[4]_i_13\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => data6(4),
      I1 => \VGA_R_reg[5]_i_9_n_4\,
      O => \VGA_R[4]_i_13_n_0\
    );
\VGA_R[4]_i_14\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => data6(5),
      I1 => \VGA_R_reg[5]_i_9_n_6\,
      O => \VGA_R[4]_i_14_n_0\
    );
\VGA_R[4]_i_15\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => data6(5),
      I1 => \VGA_R[7]_i_286_n_0\,
      I2 => \VGA_R_reg[5]_i_9_n_7\,
      O => \VGA_R[4]_i_15_n_0\
    );
\VGA_R[4]_i_16\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_286_n_0\,
      I1 => data6(5),
      I2 => \VGA_R_reg[5]_i_21_n_4\,
      O => \VGA_R[4]_i_16_n_0\
    );
\VGA_R[4]_i_18\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => data2(5),
      I1 => \VGA_R_reg[5]_i_10_n_5\,
      O => \VGA_R[4]_i_18_n_0\
    );
\VGA_R[4]_i_19\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => data2(5),
      I1 => \VGA_R[7]_i_192_n_0\,
      I2 => \VGA_R_reg[5]_i_10_n_6\,
      O => \VGA_R[4]_i_19_n_0\
    );
\VGA_R[4]_i_20\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_192_n_0\,
      I1 => data2(5),
      I2 => \VGA_R_reg[5]_i_10_n_7\,
      O => \VGA_R[4]_i_20_n_0\
    );
\VGA_R[4]_i_21\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => data2(5),
      I1 => \VGA_R[7]_i_192_n_0\,
      I2 => \VGA_R_reg[5]_i_26_n_4\,
      O => \VGA_R[4]_i_21_n_0\
    );
\VGA_R[4]_i_30\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_275_n_4\,
      O => \VGA_R[4]_i_30_n_0\
    );
\VGA_R[4]_i_31\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => data6(5),
      I1 => \VGA_R_reg[5]_i_21_n_5\,
      O => \VGA_R[4]_i_31_n_0\
    );
\VGA_R[4]_i_32\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => data6(5),
      I1 => \VGA_R_reg[5]_i_21_n_6\,
      O => \VGA_R[4]_i_32_n_0\
    );
\VGA_R[4]_i_33\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_286_n_0\,
      I1 => data6(5),
      I2 => \VGA_R_reg[5]_i_21_n_7\,
      O => \VGA_R[4]_i_33_n_0\
    );
\VGA_R[4]_i_34\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => data6(5),
      I1 => \VGA_R[7]_i_286_n_0\,
      I2 => \VGA_R_reg[7]_i_275_n_4\,
      O => \VGA_R[4]_i_34_n_0\
    );
\VGA_R[4]_i_35\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \VGA_R_reg[4]_i_40_n_7\,
      O => \VGA_R[4]_i_35_n_0\
    );
\VGA_R[4]_i_36\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_192_n_0\,
      I1 => data2(5),
      I2 => \VGA_R_reg[5]_i_26_n_5\,
      O => \VGA_R[4]_i_36_n_0\
    );
\VGA_R[4]_i_37\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"659A"
    )
        port map (
      I0 => data2(5),
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      I3 => \VGA_R_reg[5]_i_26_n_6\,
      O => \VGA_R[4]_i_37_n_0\
    );
\VGA_R[4]_i_38\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => data2(5),
      I1 => \VGA_R_reg[5]_i_26_n_7\,
      O => \VGA_R[4]_i_38_n_0\
    );
\VGA_R[4]_i_39\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => data2(5),
      I1 => \VGA_R[7]_i_366_n_0\,
      I2 => \VGA_R_reg[4]_i_40_n_7\,
      O => \VGA_R[4]_i_39_n_0\
    );
\VGA_R[4]_i_41\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => pattern_b1_n_97,
      I1 => \VGA_R_reg[7]_i_181_n_0\,
      O => \VGA_R[4]_i_41_n_0\
    );
\VGA_R[5]_i_101\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B44B44B4"
    )
        port map (
      I0 => timing_sel(1),
      I1 => timing_sel(0),
      I2 => \VGA_R_reg[5]_i_78_n_6\,
      I3 => \VGA_R_reg[5]_i_79_n_5\,
      I4 => \VGA_R_reg[5]_i_79_n_6\,
      O => \VGA_R[5]_i_101_n_0\
    );
\VGA_R[5]_i_102\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"4242D642"
    )
        port map (
      I0 => \VGA_R_reg[5]_i_79_n_5\,
      I1 => \VGA_R_reg[5]_i_78_n_6\,
      I2 => \VGA_R_reg[5]_i_79_n_6\,
      I3 => timing_sel(0),
      I4 => timing_sel(1),
      O => \VGA_R[5]_i_102_n_0\
    );
\VGA_R[5]_i_103\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => timing_sel(1),
      I1 => timing_sel(0),
      O => \VGA_R[5]_i_103_n_0\
    );
\VGA_R[5]_i_104\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => timing_sel(0),
      I1 => timing_sel(1),
      O => \VGA_R[5]_i_104_n_0\
    );
\VGA_R[5]_i_105\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"2D"
    )
        port map (
      I0 => timing_sel(0),
      I1 => timing_sel(1),
      I2 => \VGA_R[7]_i_286_n_0\,
      O => \VGA_R[5]_i_105_n_0\
    );
\VGA_R[5]_i_106\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => timing_sel(1),
      I1 => timing_sel(0),
      O => \VGA_R[5]_i_106_n_0\
    );
\VGA_R[5]_i_107\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => timing_sel(0),
      I1 => timing_sel(1),
      O => \VGA_R[5]_i_107_n_0\
    );
\VGA_R[5]_i_109\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => timing_sel(1),
      I1 => timing_sel(0),
      O => \VGA_R[5]_i_109_n_0\
    );
\VGA_R[5]_i_111\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \VGA_R_reg[5]_i_99_n_6\,
      I1 => \VGA_R[7]_i_286_n_0\,
      O => \VGA_R[5]_i_111_n_0\
    );
\VGA_R[5]_i_112\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"4B"
    )
        port map (
      I0 => \VGA_R_reg[5]_i_99_n_6\,
      I1 => \VGA_R[7]_i_286_n_0\,
      I2 => \VGA_R_reg[5]_i_99_n_1\,
      O => \VGA_R[5]_i_112_n_0\
    );
\VGA_R[5]_i_113\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[5]_i_99_n_6\,
      I1 => \VGA_R[7]_i_286_n_0\,
      O => \VGA_R[5]_i_113_n_0\
    );
\VGA_R[5]_i_115\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => timing_sel(1),
      I1 => timing_sel(0),
      O => \VGA_R[5]_i_115_n_0\
    );
\VGA_R[5]_i_116\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \pattern_b1__0_i_13_n_0\,
      I1 => \VGA_R_reg[5]_i_97_n_1\,
      O => \VGA_R[5]_i_116_n_0\
    );
\VGA_R[5]_i_117\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => timing_sel(0),
      I1 => timing_sel(1),
      O => HPERIOD(8)
    );
\VGA_R[5]_i_118\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \VGA_R[7]_i_286_n_0\,
      I1 => \VGA_R_reg[5]_i_97_n_1\,
      O => \VGA_R[5]_i_118_n_0\
    );
\VGA_R[5]_i_119\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => pattern_b1_n_96,
      I1 => \VGA_R_reg[7]_i_367_n_0\,
      O => \VGA_R[5]_i_119_n_0\
    );
\VGA_R[5]_i_120\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => timing_sel(1),
      I1 => timing_sel(0),
      O => \VGA_R[5]_i_120_n_0\
    );
\VGA_R[5]_i_121\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"9A"
    )
        port map (
      I0 => \VGA_R[7]_i_286_n_0\,
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      O => \VGA_R[5]_i_121_n_0\
    );
\VGA_R[5]_i_122\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => timing_sel(0),
      I1 => timing_sel(1),
      O => \VGA_R[5]_i_122_n_0\
    );
\VGA_R[5]_i_124\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \VGA_R_reg[5]_i_114_n_6\,
      I1 => \VGA_R[7]_i_286_n_0\,
      O => \VGA_R[5]_i_124_n_0\
    );
\VGA_R[5]_i_125\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \VGA_R_reg[5]_i_97_n_1\,
      O => \VGA_R[5]_i_125_n_0\
    );
\VGA_R[5]_i_126\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"78"
    )
        port map (
      I0 => \VGA_R[7]_i_286_n_0\,
      I1 => \VGA_R_reg[5]_i_114_n_5\,
      I2 => \VGA_R_reg[5]_i_114_n_4\,
      O => \VGA_R[5]_i_126_n_0\
    );
\VGA_R[5]_i_127\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"1E"
    )
        port map (
      I0 => \VGA_R_reg[5]_i_114_n_6\,
      I1 => \VGA_R[7]_i_286_n_0\,
      I2 => \VGA_R_reg[5]_i_114_n_5\,
      O => \VGA_R[5]_i_127_n_0\
    );
\VGA_R[5]_i_128\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \VGA_R_reg[5]_i_97_n_1\,
      I1 => \VGA_R[7]_i_286_n_0\,
      I2 => \VGA_R_reg[5]_i_114_n_6\,
      O => \VGA_R[5]_i_128_n_0\
    );
\VGA_R[5]_i_129\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \VGA_R_reg[5]_i_97_n_1\,
      O => \VGA_R[5]_i_129_n_0\
    );
\VGA_R[5]_i_130\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \VGA_R_reg[5]_i_97_n_1\,
      I1 => \pattern_b1__0_i_13_n_0\,
      O => \VGA_R[5]_i_130_n_0\
    );
\VGA_R[5]_i_131\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \VGA_R_reg[5]_i_97_n_1\,
      O => \VGA_R[5]_i_131_n_0\
    );
\VGA_R[5]_i_132\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \VGA_R_reg[5]_i_97_n_1\,
      O => \VGA_R[5]_i_132_n_0\
    );
\VGA_R[5]_i_133\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \VGA_R_reg[5]_i_97_n_1\,
      O => \VGA_R[5]_i_133_n_0\
    );
\VGA_R[5]_i_134\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"4"
    )
        port map (
      I0 => \VGA_R_reg[5]_i_97_n_1\,
      I1 => \pattern_b1__0_i_13_n_0\,
      O => \VGA_R[5]_i_134_n_0\
    );
\VGA_R[5]_i_135\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \pattern_b1__0_i_13_n_0\,
      O => \VGA_R[5]_i_135_n_0\
    );
\VGA_R[5]_i_136\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \VGA_R_reg[5]_i_97_n_6\,
      O => \VGA_R[5]_i_136_n_0\
    );
\VGA_R[5]_i_137\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \VGA_R_reg[5]_i_97_n_1\,
      O => \VGA_R[5]_i_137_n_0\
    );
\VGA_R[5]_i_138\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[5]_i_97_n_1\,
      I1 => \VGA_R_reg[5]_i_97_n_6\,
      O => \VGA_R[5]_i_138_n_0\
    );
\VGA_R[5]_i_139\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[5]_i_97_n_6\,
      I1 => \VGA_R_reg[5]_i_97_n_1\,
      O => \VGA_R[5]_i_139_n_0\
    );
\VGA_R[5]_i_140\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \VGA_R_reg[5]_i_97_n_1\,
      O => \VGA_R[5]_i_140_n_0\
    );
\VGA_R[5]_i_22\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => data6(5),
      I1 => \pattern_b1__0_n_101\,
      O => \VGA_R[5]_i_22_n_0\
    );
\VGA_R[5]_i_23\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => data6(6),
      I1 => \VGA_R_reg[6]_i_6_n_6\,
      O => \VGA_R[5]_i_23_n_0\
    );
\VGA_R[5]_i_24\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => data6(6),
      I1 => \VGA_R[7]_i_286_n_0\,
      I2 => \VGA_R_reg[6]_i_6_n_7\,
      O => \VGA_R[5]_i_24_n_0\
    );
\VGA_R[5]_i_25\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_286_n_0\,
      I1 => data6(6),
      I2 => \VGA_R_reg[6]_i_12_n_4\,
      O => \VGA_R[5]_i_25_n_0\
    );
\VGA_R[5]_i_27\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => data2(6),
      I1 => \VGA_R_reg[6]_i_5_n_5\,
      O => \VGA_R[5]_i_27_n_0\
    );
\VGA_R[5]_i_28\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => data2(6),
      I1 => \VGA_R[7]_i_192_n_0\,
      I2 => \VGA_R_reg[6]_i_5_n_6\,
      O => \VGA_R[5]_i_28_n_0\
    );
\VGA_R[5]_i_29\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_192_n_0\,
      I1 => data2(6),
      I2 => \VGA_R_reg[6]_i_5_n_7\,
      O => \VGA_R[5]_i_29_n_0\
    );
\VGA_R[5]_i_30\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => data2(6),
      I1 => \VGA_R[7]_i_192_n_0\,
      I2 => \VGA_R_reg[6]_i_7_n_4\,
      O => \VGA_R[5]_i_30_n_0\
    );
\VGA_R[5]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"02"
    )
        port map (
      I0 => pattern_sel(3),
      I1 => pattern_sel(2),
      I2 => pattern_sel(1),
      O => \VGA_R[5]_i_5_n_0\
    );
\VGA_R[5]_i_60\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_436_n_4\,
      O => \VGA_R[5]_i_60_n_0\
    );
\VGA_R[5]_i_61\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => data6(6),
      I1 => \VGA_R_reg[6]_i_12_n_5\,
      O => \VGA_R[5]_i_61_n_0\
    );
\VGA_R[5]_i_62\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => data6(6),
      I1 => \VGA_R_reg[6]_i_12_n_6\,
      O => \VGA_R[5]_i_62_n_0\
    );
\VGA_R[5]_i_63\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_286_n_0\,
      I1 => data6(6),
      I2 => \VGA_R_reg[6]_i_12_n_7\,
      O => \VGA_R[5]_i_63_n_0\
    );
\VGA_R[5]_i_64\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => data6(6),
      I1 => \VGA_R[7]_i_286_n_0\,
      I2 => \VGA_R_reg[7]_i_436_n_4\,
      O => \VGA_R[5]_i_64_n_0\
    );
\VGA_R[5]_i_65\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \VGA_R_reg[5]_i_100_n_7\,
      O => \VGA_R[5]_i_65_n_0\
    );
\VGA_R[5]_i_66\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_192_n_0\,
      I1 => data2(6),
      I2 => \VGA_R_reg[6]_i_7_n_5\,
      O => \VGA_R[5]_i_66_n_0\
    );
\VGA_R[5]_i_67\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"659A"
    )
        port map (
      I0 => data2(6),
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      I3 => \VGA_R_reg[6]_i_7_n_6\,
      O => \VGA_R[5]_i_67_n_0\
    );
\VGA_R[5]_i_68\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => data2(6),
      I1 => \VGA_R_reg[6]_i_7_n_7\,
      O => \VGA_R[5]_i_68_n_0\
    );
\VGA_R[5]_i_69\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => data2(6),
      I1 => \VGA_R[7]_i_366_n_0\,
      I2 => \VGA_R_reg[5]_i_100_n_7\,
      O => \VGA_R[5]_i_69_n_0\
    );
\VGA_R[5]_i_96\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"45"
    )
        port map (
      I0 => \VGA_R_reg[5]_i_98_n_2\,
      I1 => \VGA_R[7]_i_286_n_0\,
      I2 => \VGA_R_reg[5]_i_99_n_1\,
      O => \VGA_R[5]_i_96_n_0\
    );
\VGA_R[6]_i_10\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_192_n_0\,
      I1 => data2(7),
      I2 => \VGA_R_reg[7]_i_30_n_7\,
      O => \VGA_R[6]_i_10_n_0\
    );
\VGA_R[6]_i_11\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => data2(7),
      I1 => \VGA_R[7]_i_192_n_0\,
      I2 => \VGA_R_reg[7]_i_79_n_4\,
      O => \VGA_R[6]_i_11_n_0\
    );
\VGA_R[6]_i_13\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => data6(6),
      I1 => \pattern_b1__0_n_100\,
      O => \VGA_R[6]_i_13_n_0\
    );
\VGA_R[6]_i_14\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => data6(7),
      I1 => \VGA_R_reg[7]_i_40_n_6\,
      O => \VGA_R[6]_i_14_n_0\
    );
\VGA_R[6]_i_15\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => data6(7),
      I1 => \VGA_R[7]_i_286_n_0\,
      I2 => \VGA_R_reg[7]_i_40_n_7\,
      O => \VGA_R[6]_i_15_n_0\
    );
\VGA_R[6]_i_16\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_286_n_0\,
      I1 => data6(7),
      I2 => \VGA_R_reg[7]_i_109_n_4\,
      O => \VGA_R[6]_i_16_n_0\
    );
\VGA_R[6]_i_17\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \VGA_R_reg[6]_i_27_n_7\,
      O => \VGA_R[6]_i_17_n_0\
    );
\VGA_R[6]_i_18\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_192_n_0\,
      I1 => data2(7),
      I2 => \VGA_R_reg[7]_i_79_n_5\,
      O => \VGA_R[6]_i_18_n_0\
    );
\VGA_R[6]_i_19\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"659A"
    )
        port map (
      I0 => data2(7),
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      I3 => \VGA_R_reg[7]_i_79_n_6\,
      O => \VGA_R[6]_i_19_n_0\
    );
\VGA_R[6]_i_20\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => data2(7),
      I1 => \VGA_R_reg[7]_i_79_n_7\,
      O => \VGA_R[6]_i_20_n_0\
    );
\VGA_R[6]_i_21\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => data2(7),
      I1 => \VGA_R[7]_i_366_n_0\,
      I2 => \VGA_R_reg[6]_i_27_n_7\,
      O => \VGA_R[6]_i_21_n_0\
    );
\VGA_R[6]_i_22\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \VGA_R_reg[6]_i_28_n_4\,
      O => \VGA_R[6]_i_22_n_0\
    );
\VGA_R[6]_i_23\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => data6(7),
      I1 => \VGA_R_reg[7]_i_109_n_5\,
      O => \VGA_R[6]_i_23_n_0\
    );
\VGA_R[6]_i_24\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => data6(7),
      I1 => \VGA_R_reg[7]_i_109_n_6\,
      O => \VGA_R[6]_i_24_n_0\
    );
\VGA_R[6]_i_25\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_286_n_0\,
      I1 => data6(7),
      I2 => \VGA_R_reg[7]_i_109_n_7\,
      O => \VGA_R[6]_i_25_n_0\
    );
\VGA_R[6]_i_26\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => data6(7),
      I1 => \VGA_R[7]_i_286_n_0\,
      I2 => \VGA_R_reg[6]_i_28_n_4\,
      O => \VGA_R[6]_i_26_n_0\
    );
\VGA_R[6]_i_29\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => pattern_b1_n_95,
      I1 => \VGA_R_reg[7]_i_462_n_0\,
      O => \VGA_R[6]_i_29_n_0\
    );
\VGA_R[6]_i_30\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[6]_i_28_n_1\,
      I1 => \pattern_b1__0_n_95\,
      O => \VGA_R[6]_i_30_n_0\
    );
\VGA_R[6]_i_31\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_435_n_1\,
      I1 => \VGA_R_reg[7]_i_435_n_6\,
      O => \VGA_R[6]_i_31_n_0\
    );
\VGA_R[6]_i_32\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_435_n_1\,
      I1 => \VGA_R[7]_i_286_n_0\,
      I2 => \VGA_R_reg[7]_i_435_n_7\,
      O => \VGA_R[6]_i_32_n_0\
    );
\VGA_R[6]_i_33\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_286_n_0\,
      I1 => \VGA_R_reg[7]_i_435_n_1\,
      I2 => \VGA_R_reg[7]_i_477_n_4\,
      O => \VGA_R[6]_i_33_n_0\
    );
\VGA_R[6]_i_8\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => data2(7),
      I1 => \VGA_R_reg[7]_i_30_n_5\,
      O => \VGA_R[6]_i_8_n_0\
    );
\VGA_R[6]_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => data2(7),
      I1 => \VGA_R[7]_i_192_n_0\,
      I2 => \VGA_R_reg[7]_i_30_n_6\,
      O => \VGA_R[6]_i_9_n_0\
    );
\VGA_R[7]_i_112\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => data6(7),
      I1 => \pattern_b1__0_n_99\,
      O => \VGA_R[7]_i_112_n_0\
    );
\VGA_R[7]_i_113\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_110_n_1\,
      I1 => \VGA_R_reg[7]_i_110_n_6\,
      O => \VGA_R[7]_i_113_n_0\
    );
\VGA_R[7]_i_114\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_110_n_1\,
      I1 => \VGA_R[7]_i_286_n_0\,
      I2 => \VGA_R_reg[7]_i_110_n_7\,
      O => \VGA_R[7]_i_114_n_0\
    );
\VGA_R[7]_i_115\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_286_n_0\,
      I1 => \VGA_R_reg[7]_i_110_n_1\,
      I2 => \VGA_R_reg[7]_i_111_n_4\,
      O => \VGA_R[7]_i_115_n_0\
    );
\VGA_R[7]_i_119\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000001"
    )
        port map (
      I0 => pattern_b1_i_24_n_3,
      I1 => pattern_b1_i_18_n_5,
      I2 => pattern_b1_i_18_n_6,
      I3 => pattern_b1_i_18_n_4,
      I4 => pattern_b1_i_23_n_7,
      O => \VGA_R[7]_i_119_n_0\
    );
\VGA_R[7]_i_120\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"01"
    )
        port map (
      I0 => pattern_b1_i_18_n_5,
      I1 => pattern_b1_i_18_n_6,
      I2 => pattern_b1_i_18_n_4,
      O => \VGA_R[7]_i_120_n_0\
    );
\VGA_R[7]_i_129\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => timing_sel(0),
      I1 => timing_sel(1),
      O => \VGA_R[7]_i_129_n_0\
    );
\VGA_R[7]_i_131\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"2D"
    )
        port map (
      I0 => timing_sel(0),
      I1 => timing_sel(1),
      I2 => \pattern_b1__0_i_13_n_0\,
      O => \VGA_R[7]_i_131_n_0\
    );
\VGA_R[7]_i_176\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_365_n_7\,
      O => \VGA_R[7]_i_176_n_0\
    );
\VGA_R[7]_i_177\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_192_n_0\,
      I1 => \VGA_R_reg[7]_i_80_n_0\,
      I2 => \VGA_R_reg[7]_i_81_n_5\,
      O => \VGA_R[7]_i_177_n_0\
    );
\VGA_R[7]_i_178\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"659A"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_80_n_0\,
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      I3 => \VGA_R_reg[7]_i_81_n_6\,
      O => \VGA_R[7]_i_178_n_0\
    );
\VGA_R[7]_i_179\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_80_n_0\,
      I1 => \VGA_R_reg[7]_i_81_n_7\,
      O => \VGA_R[7]_i_179_n_0\
    );
\VGA_R[7]_i_180\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_80_n_0\,
      I1 => \VGA_R[7]_i_366_n_0\,
      I2 => \VGA_R_reg[7]_i_365_n_7\,
      O => \VGA_R[7]_i_180_n_0\
    );
\VGA_R[7]_i_183\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_181_n_0\,
      I1 => \VGA_R_reg[7]_i_181_n_5\,
      O => \VGA_R[7]_i_183_n_0\
    );
\VGA_R[7]_i_184\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_181_n_0\,
      I1 => \VGA_R[7]_i_192_n_0\,
      I2 => \VGA_R_reg[7]_i_181_n_6\,
      O => \VGA_R[7]_i_184_n_0\
    );
\VGA_R[7]_i_185\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_192_n_0\,
      I1 => \VGA_R_reg[7]_i_181_n_0\,
      I2 => \VGA_R_reg[7]_i_181_n_7\,
      O => \VGA_R[7]_i_185_n_0\
    );
\VGA_R[7]_i_186\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_181_n_0\,
      I1 => \VGA_R[7]_i_192_n_0\,
      I2 => \VGA_R_reg[7]_i_182_n_4\,
      O => \VGA_R[7]_i_186_n_0\
    );
\VGA_R[7]_i_187\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_378_n_7\,
      O => \VGA_R[7]_i_187_n_0\
    );
\VGA_R[7]_i_188\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_192_n_0\,
      I1 => \VGA_R_reg[7]_i_181_n_0\,
      I2 => \VGA_R_reg[7]_i_182_n_5\,
      O => \VGA_R[7]_i_188_n_0\
    );
\VGA_R[7]_i_189\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"659A"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_181_n_0\,
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      I3 => \VGA_R_reg[7]_i_182_n_6\,
      O => \VGA_R[7]_i_189_n_0\
    );
\VGA_R[7]_i_190\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_181_n_0\,
      I1 => \VGA_R_reg[7]_i_182_n_7\,
      O => \VGA_R[7]_i_190_n_0\
    );
\VGA_R[7]_i_191\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_181_n_0\,
      I1 => \VGA_R[7]_i_366_n_0\,
      I2 => \VGA_R_reg[7]_i_378_n_7\,
      O => \VGA_R[7]_i_191_n_0\
    );
\VGA_R[7]_i_192\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => timing_sel(1),
      I1 => timing_sel(0),
      O => \VGA_R[7]_i_192_n_0\
    );
\VGA_R[7]_i_205\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"2D"
    )
        port map (
      I0 => timing_sel(0),
      I1 => timing_sel(1),
      I2 => \pattern_b1__0_i_13_n_0\,
      O => \VGA_R[7]_i_205_n_0\
    );
\VGA_R[7]_i_206\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_93_n_3\,
      I1 => \VGA_R_reg[7]_i_204_n_4\,
      O => \VGA_R[7]_i_206_n_0\
    );
\VGA_R[7]_i_207\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_93_n_3\,
      I1 => \pattern_b1__0_i_13_n_0\,
      I2 => \VGA_R_reg[7]_i_204_n_5\,
      O => \VGA_R[7]_i_207_n_0\
    );
\VGA_R[7]_i_208\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \pattern_b1__0_i_13_n_0\,
      I1 => \VGA_R_reg[7]_i_93_n_3\,
      I2 => \VGA_R_reg[7]_i_204_n_6\,
      O => \VGA_R[7]_i_208_n_0\
    );
\VGA_R[7]_i_209\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"65"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_93_n_3\,
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      O => \VGA_R[7]_i_209_n_0\
    );
\VGA_R[7]_i_210\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => timing_sel(0),
      I1 => timing_sel(1),
      O => \VGA_R[7]_i_210_n_0\
    );
\VGA_R[7]_i_242\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_101_n_0\,
      I1 => \VGA_R_reg[7]_i_101_n_5\,
      O => \VGA_R[7]_i_242_n_0\
    );
\VGA_R[7]_i_243\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_101_n_0\,
      I1 => \pattern_b1__0_i_13_n_0\,
      I2 => \VGA_R_reg[7]_i_101_n_6\,
      O => \VGA_R[7]_i_243_n_0\
    );
\VGA_R[7]_i_244\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \pattern_b1__0_i_13_n_0\,
      I1 => \VGA_R_reg[7]_i_101_n_0\,
      I2 => \VGA_R_reg[7]_i_101_n_7\,
      O => \VGA_R[7]_i_244_n_0\
    );
\VGA_R[7]_i_245\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_101_n_0\,
      I1 => \pattern_b1__0_i_13_n_0\,
      I2 => \VGA_R_reg[7]_i_241_n_4\,
      O => \VGA_R[7]_i_245_n_0\
    );
\VGA_R[7]_i_246\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_92_n_0\,
      I1 => \VGA_R_reg[7]_i_92_n_5\,
      O => \VGA_R[7]_i_246_n_0\
    );
\VGA_R[7]_i_247\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_92_n_0\,
      I1 => \pattern_b1__0_i_13_n_0\,
      I2 => \VGA_R_reg[7]_i_92_n_6\,
      O => \VGA_R[7]_i_247_n_0\
    );
\VGA_R[7]_i_248\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \pattern_b1__0_i_13_n_0\,
      I1 => \VGA_R_reg[7]_i_92_n_0\,
      I2 => \VGA_R_reg[7]_i_92_n_7\,
      O => \VGA_R[7]_i_248_n_0\
    );
\VGA_R[7]_i_249\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_92_n_0\,
      I1 => \pattern_b1__0_i_13_n_0\,
      I2 => \VGA_R_reg[7]_i_203_n_4\,
      O => \VGA_R[7]_i_249_n_0\
    );
\VGA_R[7]_i_25\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"45"
    )
        port map (
      I0 => pattern_sel(2),
      I1 => pattern_sel(1),
      I2 => pattern_sel(0),
      O => \VGA_R[7]_i_25_n_0\
    );
\VGA_R[7]_i_270\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_435_n_4\,
      O => \VGA_R[7]_i_270_n_0\
    );
\VGA_R[7]_i_271\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_110_n_1\,
      I1 => \VGA_R_reg[7]_i_111_n_5\,
      O => \VGA_R[7]_i_271_n_0\
    );
\VGA_R[7]_i_272\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_110_n_1\,
      I1 => \VGA_R_reg[7]_i_111_n_6\,
      O => \VGA_R[7]_i_272_n_0\
    );
\VGA_R[7]_i_273\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_286_n_0\,
      I1 => \VGA_R_reg[7]_i_110_n_1\,
      I2 => \VGA_R_reg[7]_i_111_n_7\,
      O => \VGA_R[7]_i_273_n_0\
    );
\VGA_R[7]_i_274\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_110_n_1\,
      I1 => \VGA_R[7]_i_286_n_0\,
      I2 => \VGA_R_reg[7]_i_435_n_4\,
      O => \VGA_R[7]_i_274_n_0\
    );
\VGA_R[7]_i_277\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_110_n_1\,
      I1 => \pattern_b1__0_n_98\,
      O => \VGA_R[7]_i_277_n_0\
    );
\VGA_R[7]_i_278\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_275_n_1\,
      I1 => \VGA_R_reg[7]_i_275_n_6\,
      O => \VGA_R[7]_i_278_n_0\
    );
\VGA_R[7]_i_279\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_275_n_1\,
      I1 => \VGA_R[7]_i_286_n_0\,
      I2 => \VGA_R_reg[7]_i_275_n_7\,
      O => \VGA_R[7]_i_279_n_0\
    );
\VGA_R[7]_i_280\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_286_n_0\,
      I1 => \VGA_R_reg[7]_i_275_n_1\,
      I2 => \VGA_R_reg[7]_i_276_n_4\,
      O => \VGA_R[7]_i_280_n_0\
    );
\VGA_R[7]_i_281\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_447_n_4\,
      O => \VGA_R[7]_i_281_n_0\
    );
\VGA_R[7]_i_282\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_275_n_1\,
      I1 => \VGA_R_reg[7]_i_276_n_5\,
      O => \VGA_R[7]_i_282_n_0\
    );
\VGA_R[7]_i_283\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_275_n_1\,
      I1 => \VGA_R_reg[7]_i_276_n_6\,
      O => \VGA_R[7]_i_283_n_0\
    );
\VGA_R[7]_i_284\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_286_n_0\,
      I1 => \VGA_R_reg[7]_i_275_n_1\,
      I2 => \VGA_R_reg[7]_i_276_n_7\,
      O => \VGA_R[7]_i_284_n_0\
    );
\VGA_R[7]_i_285\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_275_n_1\,
      I1 => \VGA_R[7]_i_286_n_0\,
      I2 => \VGA_R_reg[7]_i_447_n_4\,
      O => \VGA_R[7]_i_285_n_0\
    );
\VGA_R[7]_i_286\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => timing_sel(1),
      I1 => timing_sel(0),
      O => \VGA_R[7]_i_286_n_0\
    );
\VGA_R[7]_i_29\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pattern_sel(1),
      I1 => pattern_sel(2),
      O => \VGA_R[7]_i_29_n_0\
    );
\VGA_R[7]_i_309\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => timing_sel(0),
      I1 => timing_sel(1),
      O => HWIDTH(4)
    );
\VGA_R[7]_i_310\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => timing_sel(1),
      I1 => timing_sel(0),
      O => \VGA_R[7]_i_310_n_0\
    );
\VGA_R[7]_i_311\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => timing_sel(0),
      I1 => timing_sel(1),
      O => \VGA_R[7]_i_311_n_0\
    );
\VGA_R[7]_i_312\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => timing_sel(1),
      I1 => timing_sel(0),
      O => \VGA_R[7]_i_312_n_0\
    );
\VGA_R[7]_i_313\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => timing_sel(0),
      I1 => timing_sel(1),
      O => \VGA_R[7]_i_313_n_0\
    );
\VGA_R[7]_i_314\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => timing_sel(1),
      I1 => timing_sel(0),
      O => \VGA_R[7]_i_314_n_0\
    );
\VGA_R[7]_i_315\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"EF"
    )
        port map (
      I0 => \pattern_b1__0_i_13_n_0\,
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      O => \VGA_R[7]_i_315_n_0\
    );
\VGA_R[7]_i_316\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => timing_sel(0),
      I1 => timing_sel(1),
      O => \VGA_R[7]_i_316_n_0\
    );
\VGA_R[7]_i_319\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => timing_sel(0),
      I1 => timing_sel(1),
      O => \VGA_R[7]_i_319_n_0\
    );
\VGA_R[7]_i_34\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"FE"
    )
        port map (
      I0 => pattern_sel(0),
      I1 => \VGA_R_reg[7]_i_92_n_0\,
      I2 => \VGA_R_reg[7]_i_93_n_3\,
      O => \VGA_R[7]_i_34_n_0\
    );
\VGA_R[7]_i_366\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => timing_sel(1),
      I1 => timing_sel(0),
      O => \VGA_R[7]_i_366_n_0\
    );
\VGA_R[7]_i_369\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_367_n_0\,
      I1 => \VGA_R_reg[7]_i_367_n_5\,
      O => \VGA_R[7]_i_369_n_0\
    );
\VGA_R[7]_i_370\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_367_n_0\,
      I1 => \VGA_R[7]_i_192_n_0\,
      I2 => \VGA_R_reg[7]_i_367_n_6\,
      O => \VGA_R[7]_i_370_n_0\
    );
\VGA_R[7]_i_371\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_192_n_0\,
      I1 => \VGA_R_reg[7]_i_367_n_0\,
      I2 => \VGA_R_reg[7]_i_367_n_7\,
      O => \VGA_R[7]_i_371_n_0\
    );
\VGA_R[7]_i_372\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_367_n_0\,
      I1 => \VGA_R[7]_i_192_n_0\,
      I2 => \VGA_R_reg[7]_i_368_n_4\,
      O => \VGA_R[7]_i_372_n_0\
    );
\VGA_R[7]_i_373\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_473_n_7\,
      O => \VGA_R[7]_i_373_n_0\
    );
\VGA_R[7]_i_374\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_192_n_0\,
      I1 => \VGA_R_reg[7]_i_367_n_0\,
      I2 => \VGA_R_reg[7]_i_368_n_5\,
      O => \VGA_R[7]_i_374_n_0\
    );
\VGA_R[7]_i_375\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"659A"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_367_n_0\,
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      I3 => \VGA_R_reg[7]_i_368_n_6\,
      O => \VGA_R[7]_i_375_n_0\
    );
\VGA_R[7]_i_376\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_367_n_0\,
      I1 => \VGA_R_reg[7]_i_368_n_7\,
      O => \VGA_R[7]_i_376_n_0\
    );
\VGA_R[7]_i_377\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_367_n_0\,
      I1 => \VGA_R[7]_i_366_n_0\,
      I2 => \VGA_R_reg[7]_i_473_n_7\,
      O => \VGA_R[7]_i_377_n_0\
    );
\VGA_R[7]_i_379\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_93_n_3\,
      I1 => \pattern_b1__0_i_13_n_0\,
      O => \VGA_R[7]_i_379_n_0\
    );
\VGA_R[7]_i_380\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => timing_sel(0),
      I1 => timing_sel(1),
      O => \VGA_R[7]_i_380_n_0\
    );
\VGA_R[7]_i_381\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D2"
    )
        port map (
      I0 => timing_sel(0),
      I1 => timing_sel(1),
      I2 => \VGA_R_reg[7]_i_93_n_3\,
      O => \VGA_R[7]_i_381_n_0\
    );
\VGA_R[7]_i_382\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_93_n_3\,
      I1 => \pattern_b1__0_i_13_n_0\,
      O => \VGA_R[7]_i_382_n_0\
    );
\VGA_R[7]_i_383\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_93_n_3\,
      O => \VGA_R[7]_i_383_n_0\
    );
\VGA_R[7]_i_384\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"A6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_93_n_3\,
      I1 => timing_sel(0),
      I2 => timing_sel(1),
      O => \VGA_R[7]_i_384_n_0\
    );
\VGA_R[7]_i_385\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D2"
    )
        port map (
      I0 => timing_sel(0),
      I1 => timing_sel(1),
      I2 => \VGA_R_reg[7]_i_93_n_3\,
      O => \VGA_R[7]_i_385_n_0\
    );
\VGA_R[7]_i_386\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => timing_sel(1),
      I1 => timing_sel(0),
      O => \VGA_R[7]_i_386_n_0\
    );
\VGA_R[7]_i_387\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => timing_sel(0),
      I1 => timing_sel(1),
      O => \VGA_R[7]_i_387_n_0\
    );
\VGA_R[7]_i_388\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => timing_sel(1),
      I1 => timing_sel(0),
      O => \VGA_R[7]_i_388_n_0\
    );
\VGA_R[7]_i_389\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => timing_sel(0),
      I1 => timing_sel(1),
      O => \VGA_R[7]_i_389_n_0\
    );
\VGA_R[7]_i_390\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => timing_sel(1),
      I1 => timing_sel(0),
      O => \VGA_R[7]_i_390_n_0\
    );
\VGA_R[7]_i_391\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"EF"
    )
        port map (
      I0 => \pattern_b1__0_i_13_n_0\,
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      O => \VGA_R[7]_i_391_n_0\
    );
\VGA_R[7]_i_392\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => timing_sel(0),
      I1 => timing_sel(1),
      O => \VGA_R[7]_i_392_n_0\
    );
\VGA_R[7]_i_419\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \pattern_b1__0_i_13_n_0\,
      I1 => \VGA_R_reg[7]_i_101_n_0\,
      I2 => \VGA_R_reg[7]_i_241_n_5\,
      O => \VGA_R[7]_i_419_n_0\
    );
\VGA_R[7]_i_420\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"659A"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_101_n_0\,
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      I3 => \VGA_R_reg[7]_i_241_n_6\,
      O => \VGA_R[7]_i_420_n_0\
    );
\VGA_R[7]_i_421\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_101_n_0\,
      I1 => \VGA_R_reg[7]_i_241_n_7\,
      O => \VGA_R[7]_i_421_n_0\
    );
\VGA_R[7]_i_423\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D2"
    )
        port map (
      I0 => timing_sel(0),
      I1 => timing_sel(1),
      I2 => \VGA_R_reg[7]_i_92_n_0\,
      O => \VGA_R[7]_i_423_n_0\
    );
\VGA_R[7]_i_424\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \pattern_b1__0_i_13_n_0\,
      I1 => \VGA_R_reg[7]_i_92_n_0\,
      I2 => \VGA_R_reg[7]_i_203_n_5\,
      O => \VGA_R[7]_i_424_n_0\
    );
\VGA_R[7]_i_425\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"659A"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_92_n_0\,
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      I3 => \VGA_R_reg[7]_i_203_n_6\,
      O => \VGA_R[7]_i_425_n_0\
    );
\VGA_R[7]_i_426\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_92_n_0\,
      I1 => \VGA_R_reg[7]_i_203_n_7\,
      O => \VGA_R[7]_i_426_n_0\
    );
\VGA_R[7]_i_427\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D2"
    )
        port map (
      I0 => timing_sel(0),
      I1 => timing_sel(1),
      I2 => \VGA_R_reg[7]_i_92_n_0\,
      O => \VGA_R[7]_i_427_n_0\
    );
\VGA_R[7]_i_438\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_275_n_1\,
      I1 => \pattern_b1__0_n_97\,
      O => \VGA_R[7]_i_438_n_0\
    );
\VGA_R[7]_i_439\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_436_n_1\,
      I1 => \VGA_R_reg[7]_i_436_n_6\,
      O => \VGA_R[7]_i_439_n_0\
    );
\VGA_R[7]_i_440\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_436_n_1\,
      I1 => \VGA_R[7]_i_286_n_0\,
      I2 => \VGA_R_reg[7]_i_436_n_7\,
      O => \VGA_R[7]_i_440_n_0\
    );
\VGA_R[7]_i_441\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_286_n_0\,
      I1 => \VGA_R_reg[7]_i_436_n_1\,
      I2 => \VGA_R_reg[7]_i_437_n_4\,
      O => \VGA_R[7]_i_441_n_0\
    );
\VGA_R[7]_i_442\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_493_n_7\,
      O => \VGA_R[7]_i_442_n_0\
    );
\VGA_R[7]_i_443\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_436_n_1\,
      I1 => \VGA_R_reg[7]_i_437_n_5\,
      O => \VGA_R[7]_i_443_n_0\
    );
\VGA_R[7]_i_444\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_436_n_1\,
      I1 => \VGA_R_reg[7]_i_437_n_6\,
      O => \VGA_R[7]_i_444_n_0\
    );
\VGA_R[7]_i_445\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_286_n_0\,
      I1 => \VGA_R_reg[7]_i_436_n_1\,
      I2 => \VGA_R_reg[7]_i_437_n_7\,
      O => \VGA_R[7]_i_445_n_0\
    );
\VGA_R[7]_i_446\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_436_n_1\,
      I1 => \VGA_R[7]_i_286_n_0\,
      I2 => \VGA_R_reg[7]_i_493_n_7\,
      O => \VGA_R[7]_i_446_n_0\
    );
\VGA_R[7]_i_461\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => pattern_b1_n_94,
      I1 => \VGA_R_reg[7]_i_460_n_0\,
      O => \VGA_R[7]_i_461_n_0\
    );
\VGA_R[7]_i_464\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_462_n_0\,
      I1 => \VGA_R_reg[7]_i_462_n_5\,
      O => \VGA_R[7]_i_464_n_0\
    );
\VGA_R[7]_i_465\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_462_n_0\,
      I1 => \VGA_R[7]_i_192_n_0\,
      I2 => \VGA_R_reg[7]_i_462_n_6\,
      O => \VGA_R[7]_i_465_n_0\
    );
\VGA_R[7]_i_466\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_192_n_0\,
      I1 => \VGA_R_reg[7]_i_462_n_0\,
      I2 => \VGA_R_reg[7]_i_462_n_7\,
      O => \VGA_R[7]_i_466_n_0\
    );
\VGA_R[7]_i_467\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_462_n_0\,
      I1 => \VGA_R[7]_i_192_n_0\,
      I2 => \VGA_R_reg[7]_i_463_n_4\,
      O => \VGA_R[7]_i_467_n_0\
    );
\VGA_R[7]_i_468\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_527_n_7\,
      O => \VGA_R[7]_i_468_n_0\
    );
\VGA_R[7]_i_469\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_192_n_0\,
      I1 => \VGA_R_reg[7]_i_462_n_0\,
      I2 => \VGA_R_reg[7]_i_463_n_5\,
      O => \VGA_R[7]_i_469_n_0\
    );
\VGA_R[7]_i_470\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"659A"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_462_n_0\,
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      I3 => \VGA_R_reg[7]_i_463_n_6\,
      O => \VGA_R[7]_i_470_n_0\
    );
\VGA_R[7]_i_471\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_462_n_0\,
      I1 => \VGA_R_reg[7]_i_463_n_7\,
      O => \VGA_R[7]_i_471_n_0\
    );
\VGA_R[7]_i_472\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_462_n_0\,
      I1 => \VGA_R[7]_i_366_n_0\,
      I2 => \VGA_R_reg[7]_i_527_n_7\,
      O => \VGA_R[7]_i_472_n_0\
    );
\VGA_R[7]_i_475\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => pattern_b1_n_93,
      I1 => \VGA_R_reg[7]_i_474_n_0\,
      O => \VGA_R[7]_i_475_n_0\
    );
\VGA_R[7]_i_479\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_435_n_1\,
      I1 => \pattern_b1__0_n_94\,
      O => \VGA_R[7]_i_479_n_0\
    );
\VGA_R[7]_i_480\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_447_n_1\,
      I1 => \VGA_R_reg[7]_i_447_n_6\,
      O => \VGA_R[7]_i_480_n_0\
    );
\VGA_R[7]_i_481\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_447_n_1\,
      I1 => \VGA_R[7]_i_286_n_0\,
      I2 => \VGA_R_reg[7]_i_447_n_7\,
      O => \VGA_R[7]_i_481_n_0\
    );
\VGA_R[7]_i_482\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_286_n_0\,
      I1 => \VGA_R_reg[7]_i_447_n_1\,
      I2 => \VGA_R_reg[7]_i_478_n_4\,
      O => \VGA_R[7]_i_482_n_0\
    );
\VGA_R[7]_i_484\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_436_n_1\,
      I1 => \pattern_b1__0_n_96\,
      O => \VGA_R[7]_i_484_n_0\
    );
\VGA_R[7]_i_485\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[6]_i_28_n_1\,
      I1 => \VGA_R_reg[6]_i_28_n_6\,
      O => \VGA_R[7]_i_485_n_0\
    );
\VGA_R[7]_i_486\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \VGA_R_reg[6]_i_28_n_1\,
      I1 => \VGA_R[7]_i_286_n_0\,
      I2 => \VGA_R_reg[6]_i_28_n_7\,
      O => \VGA_R[7]_i_486_n_0\
    );
\VGA_R[7]_i_487\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_286_n_0\,
      I1 => \VGA_R_reg[6]_i_28_n_1\,
      I2 => \VGA_R_reg[7]_i_483_n_4\,
      O => \VGA_R[7]_i_487_n_0\
    );
\VGA_R[7]_i_488\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \pattern_b1__0_n_91\,
      O => \VGA_R[7]_i_488_n_0\
    );
\VGA_R[7]_i_489\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \VGA_R_reg[6]_i_28_n_1\,
      I1 => \VGA_R_reg[7]_i_483_n_5\,
      O => \VGA_R[7]_i_489_n_0\
    );
\VGA_R[7]_i_490\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \VGA_R_reg[6]_i_28_n_1\,
      I1 => \VGA_R_reg[7]_i_483_n_6\,
      O => \VGA_R[7]_i_490_n_0\
    );
\VGA_R[7]_i_491\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_286_n_0\,
      I1 => \VGA_R_reg[6]_i_28_n_1\,
      I2 => \VGA_R_reg[7]_i_483_n_7\,
      O => \VGA_R[7]_i_491_n_0\
    );
\VGA_R[7]_i_492\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \VGA_R_reg[6]_i_28_n_1\,
      I1 => \VGA_R[7]_i_286_n_0\,
      I2 => \pattern_b1__0_n_91\,
      O => \VGA_R[7]_i_492_n_0\
    );
\VGA_R[7]_i_495\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_447_n_1\,
      I1 => \pattern_b1__0_n_93\,
      O => \VGA_R[7]_i_495_n_0\
    );
\VGA_R[7]_i_496\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_494_n_0\,
      I1 => \VGA_R_reg[7]_i_494_n_5\,
      O => \VGA_R[7]_i_496_n_0\
    );
\VGA_R[7]_i_497\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_494_n_0\,
      I1 => \VGA_R[7]_i_286_n_0\,
      I2 => \VGA_R_reg[7]_i_494_n_6\,
      O => \VGA_R[7]_i_497_n_0\
    );
\VGA_R[7]_i_498\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_286_n_0\,
      I1 => \VGA_R_reg[7]_i_494_n_0\,
      I2 => \VGA_R_reg[7]_i_494_n_7\,
      O => \VGA_R[7]_i_498_n_0\
    );
\VGA_R[7]_i_514\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_474_n_0\,
      I1 => \VGA_R_reg[7]_i_474_n_5\,
      O => \VGA_R[7]_i_514_n_0\
    );
\VGA_R[7]_i_515\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_474_n_0\,
      I1 => \VGA_R[7]_i_192_n_0\,
      I2 => \VGA_R_reg[7]_i_474_n_6\,
      O => \VGA_R[7]_i_515_n_0\
    );
\VGA_R[7]_i_516\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_192_n_0\,
      I1 => \VGA_R_reg[7]_i_474_n_0\,
      I2 => \VGA_R_reg[7]_i_474_n_7\,
      O => \VGA_R[7]_i_516_n_0\
    );
\VGA_R[7]_i_517\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_474_n_0\,
      I1 => \VGA_R[7]_i_192_n_0\,
      I2 => \VGA_R_reg[7]_i_513_n_4\,
      O => \VGA_R[7]_i_517_n_0\
    );
\VGA_R[7]_i_518\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_460_n_0\,
      I1 => \VGA_R_reg[7]_i_460_n_5\,
      O => \VGA_R[7]_i_518_n_0\
    );
\VGA_R[7]_i_519\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_460_n_0\,
      I1 => \VGA_R[7]_i_192_n_0\,
      I2 => \VGA_R_reg[7]_i_460_n_6\,
      O => \VGA_R[7]_i_519_n_0\
    );
\VGA_R[7]_i_520\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_192_n_0\,
      I1 => \VGA_R_reg[7]_i_460_n_0\,
      I2 => \VGA_R_reg[7]_i_460_n_7\,
      O => \VGA_R[7]_i_520_n_0\
    );
\VGA_R[7]_i_521\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_460_n_0\,
      I1 => \VGA_R[7]_i_192_n_0\,
      I2 => \VGA_R_reg[7]_i_512_n_4\,
      O => \VGA_R[7]_i_521_n_0\
    );
\VGA_R[7]_i_522\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_571_n_7\,
      O => \VGA_R[7]_i_522_n_0\
    );
\VGA_R[7]_i_523\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_192_n_0\,
      I1 => \VGA_R_reg[7]_i_460_n_0\,
      I2 => \VGA_R_reg[7]_i_512_n_5\,
      O => \VGA_R[7]_i_523_n_0\
    );
\VGA_R[7]_i_524\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"659A"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_460_n_0\,
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      I3 => \VGA_R_reg[7]_i_512_n_6\,
      O => \VGA_R[7]_i_524_n_0\
    );
\VGA_R[7]_i_525\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_460_n_0\,
      I1 => \VGA_R_reg[7]_i_512_n_7\,
      O => \VGA_R[7]_i_525_n_0\
    );
\VGA_R[7]_i_526\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_460_n_0\,
      I1 => \VGA_R[7]_i_366_n_0\,
      I2 => \VGA_R_reg[7]_i_571_n_7\,
      O => \VGA_R[7]_i_526_n_0\
    );
\VGA_R[7]_i_529\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => pattern_b1_n_92,
      I1 => \VGA_R_reg[7]_i_528_n_0\,
      O => \VGA_R[7]_i_529_n_0\
    );
\VGA_R[7]_i_531\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_528_n_0\,
      I1 => \VGA_R_reg[7]_i_528_n_5\,
      O => \VGA_R[7]_i_531_n_0\
    );
\VGA_R[7]_i_532\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_528_n_0\,
      I1 => \VGA_R[7]_i_192_n_0\,
      I2 => \VGA_R_reg[7]_i_528_n_6\,
      O => \VGA_R[7]_i_532_n_0\
    );
\VGA_R[7]_i_533\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_192_n_0\,
      I1 => \VGA_R_reg[7]_i_528_n_0\,
      I2 => \VGA_R_reg[7]_i_528_n_7\,
      O => \VGA_R[7]_i_533_n_0\
    );
\VGA_R[7]_i_534\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_528_n_0\,
      I1 => \VGA_R[7]_i_192_n_0\,
      I2 => \VGA_R_reg[7]_i_530_n_4\,
      O => \VGA_R[7]_i_534_n_0\
    );
\VGA_R[7]_i_535\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \pattern_b1__0_n_89\,
      O => \VGA_R[7]_i_535_n_0\
    );
\VGA_R[7]_i_536\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_447_n_1\,
      I1 => \VGA_R_reg[7]_i_478_n_5\,
      O => \VGA_R[7]_i_536_n_0\
    );
\VGA_R[7]_i_537\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_447_n_1\,
      I1 => \VGA_R_reg[7]_i_478_n_6\,
      O => \VGA_R[7]_i_537_n_0\
    );
\VGA_R[7]_i_538\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_286_n_0\,
      I1 => \VGA_R_reg[7]_i_447_n_1\,
      I2 => \VGA_R_reg[7]_i_478_n_7\,
      O => \VGA_R[7]_i_538_n_0\
    );
\VGA_R[7]_i_539\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_447_n_1\,
      I1 => \VGA_R[7]_i_286_n_0\,
      I2 => \pattern_b1__0_n_89\,
      O => \VGA_R[7]_i_539_n_0\
    );
\VGA_R[7]_i_541\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_494_n_0\,
      I1 => \VGA_R_reg[7]_i_540_n_4\,
      O => \VGA_R[7]_i_541_n_0\
    );
\VGA_R[7]_i_542\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_494_n_0\,
      I1 => \VGA_R_reg[7]_i_540_n_5\,
      O => \VGA_R[7]_i_542_n_0\
    );
\VGA_R[7]_i_543\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_286_n_0\,
      I1 => \VGA_R_reg[7]_i_494_n_0\,
      I2 => \VGA_R_reg[7]_i_540_n_6\,
      O => \VGA_R[7]_i_543_n_0\
    );
\VGA_R[7]_i_544\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_494_n_0\,
      I1 => \VGA_R[7]_i_286_n_0\,
      I2 => \VGA_R_reg[7]_i_540_n_7\,
      O => \VGA_R[7]_i_544_n_0\
    );
\VGA_R[7]_i_545\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \pattern_b1__0_n_90\,
      O => \VGA_R[7]_i_545_n_0\
    );
\VGA_R[7]_i_546\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_435_n_1\,
      I1 => \VGA_R_reg[7]_i_477_n_5\,
      O => \VGA_R[7]_i_546_n_0\
    );
\VGA_R[7]_i_547\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_435_n_1\,
      I1 => \VGA_R_reg[7]_i_477_n_6\,
      O => \VGA_R[7]_i_547_n_0\
    );
\VGA_R[7]_i_548\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_286_n_0\,
      I1 => \VGA_R_reg[7]_i_435_n_1\,
      I2 => \VGA_R_reg[7]_i_477_n_7\,
      O => \VGA_R[7]_i_548_n_0\
    );
\VGA_R[7]_i_549\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_435_n_1\,
      I1 => \VGA_R[7]_i_286_n_0\,
      I2 => \pattern_b1__0_n_90\,
      O => \VGA_R[7]_i_549_n_0\
    );
\VGA_R[7]_i_550\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_494_n_0\,
      I1 => \pattern_b1__0_n_92\,
      O => \VGA_R[7]_i_550_n_0\
    );
\VGA_R[7]_i_551\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => timing_sel(1),
      I1 => timing_sel(0),
      O => \VGA_R[7]_i_551_n_0\
    );
\VGA_R[7]_i_553\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R[7]_i_286_n_0\,
      I1 => \VGA_R_reg[7]_i_552_n_6\,
      O => \VGA_R[7]_i_553_n_0\
    );
\VGA_R[7]_i_554\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \VGA_R[7]_i_286_n_0\,
      I1 => \VGA_R_reg[7]_i_552_n_7\,
      O => \VGA_R[7]_i_554_n_0\
    );
\VGA_R[7]_i_555\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_584_n_4\,
      O => \VGA_R[7]_i_555_n_0\
    );
\VGA_R[7]_i_561\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_592_n_6\,
      O => \VGA_R[7]_i_561_n_0\
    );
\VGA_R[7]_i_562\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_192_n_0\,
      I1 => \VGA_R_reg[7]_i_474_n_0\,
      I2 => \VGA_R_reg[7]_i_513_n_5\,
      O => \VGA_R[7]_i_562_n_0\
    );
\VGA_R[7]_i_563\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"659A"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_474_n_0\,
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      I3 => \VGA_R_reg[7]_i_513_n_6\,
      O => \VGA_R[7]_i_563_n_0\
    );
\VGA_R[7]_i_564\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_474_n_0\,
      I1 => \VGA_R_reg[7]_i_513_n_7\,
      O => \VGA_R[7]_i_564_n_0\
    );
\VGA_R[7]_i_565\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_474_n_0\,
      I1 => \VGA_R[7]_i_366_n_0\,
      I2 => \VGA_R_reg[7]_i_592_n_6\,
      O => \VGA_R[7]_i_565_n_0\
    );
\VGA_R[7]_i_566\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => pattern_b1_n_88,
      O => \VGA_R[7]_i_566_n_0\
    );
\VGA_R[7]_i_567\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_192_n_0\,
      I1 => \VGA_R_reg[7]_i_528_n_0\,
      I2 => \VGA_R_reg[7]_i_530_n_5\,
      O => \VGA_R[7]_i_567_n_0\
    );
\VGA_R[7]_i_568\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"659A"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_528_n_0\,
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      I3 => \VGA_R_reg[7]_i_530_n_6\,
      O => \VGA_R[7]_i_568_n_0\
    );
\VGA_R[7]_i_569\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_528_n_0\,
      I1 => \VGA_R_reg[7]_i_530_n_7\,
      O => \VGA_R[7]_i_569_n_0\
    );
\VGA_R[7]_i_570\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_528_n_0\,
      I1 => \VGA_R[7]_i_366_n_0\,
      I2 => pattern_b1_n_88,
      O => \VGA_R[7]_i_570_n_0\
    );
\VGA_R[7]_i_573\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => pattern_b1_n_91,
      I1 => \VGA_R_reg[7]_i_572_n_0\,
      O => \VGA_R[7]_i_573_n_0\
    );
\VGA_R[7]_i_575\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_572_n_0\,
      I1 => \VGA_R_reg[7]_i_572_n_5\,
      O => \VGA_R[7]_i_575_n_0\
    );
\VGA_R[7]_i_576\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_572_n_0\,
      I1 => \VGA_R[7]_i_192_n_0\,
      I2 => \VGA_R_reg[7]_i_572_n_6\,
      O => \VGA_R[7]_i_576_n_0\
    );
\VGA_R[7]_i_577\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_192_n_0\,
      I1 => \VGA_R_reg[7]_i_572_n_0\,
      I2 => \VGA_R_reg[7]_i_572_n_7\,
      O => \VGA_R[7]_i_577_n_0\
    );
\VGA_R[7]_i_578\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_572_n_0\,
      I1 => \VGA_R[7]_i_192_n_0\,
      I2 => \VGA_R_reg[7]_i_574_n_4\,
      O => \VGA_R[7]_i_578_n_0\
    );
\VGA_R[7]_i_579\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => pattern_b1_n_87,
      O => \VGA_R[7]_i_579_n_0\
    );
\VGA_R[7]_i_580\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_192_n_0\,
      I1 => \VGA_R_reg[7]_i_572_n_0\,
      I2 => \VGA_R_reg[7]_i_574_n_5\,
      O => \VGA_R[7]_i_580_n_0\
    );
\VGA_R[7]_i_581\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"659A"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_572_n_0\,
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      I3 => \VGA_R_reg[7]_i_574_n_6\,
      O => \VGA_R[7]_i_581_n_0\
    );
\VGA_R[7]_i_582\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_572_n_0\,
      I1 => \VGA_R_reg[7]_i_574_n_7\,
      O => \VGA_R[7]_i_582_n_0\
    );
\VGA_R[7]_i_583\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"659A"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_572_n_0\,
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      I3 => pattern_b1_n_87,
      O => \VGA_R[7]_i_583_n_0\
    );
\VGA_R[7]_i_585\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => timing_sel(1),
      I1 => timing_sel(0),
      O => \VGA_R[7]_i_585_n_0\
    );
\VGA_R[7]_i_586\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_584_n_5\,
      O => \VGA_R[7]_i_586_n_0\
    );
\VGA_R[7]_i_587\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \VGA_R[7]_i_286_n_0\,
      I1 => \VGA_R_reg[7]_i_584_n_6\,
      O => \VGA_R[7]_i_587_n_0\
    );
\VGA_R[7]_i_588\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R[7]_i_286_n_0\,
      I1 => \VGA_R_reg[7]_i_584_n_7\,
      O => \VGA_R[7]_i_588_n_0\
    );
\VGA_R[7]_i_589\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => timing_sel(0),
      I1 => timing_sel(1),
      O => \VGA_R[7]_i_589_n_0\
    );
\VGA_R[7]_i_590\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => timing_sel(0),
      I1 => timing_sel(1),
      O => \VGA_R[7]_i_590_n_0\
    );
\VGA_R[7]_i_591\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_605_n_1\,
      O => \VGA_R[7]_i_591_n_0\
    );
\VGA_R[7]_i_594\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => pattern_b1_n_90,
      I1 => \VGA_R_reg[7]_i_593_n_0\,
      O => \VGA_R[7]_i_594_n_0\
    );
\VGA_R[7]_i_596\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_593_n_0\,
      I1 => \VGA_R_reg[7]_i_593_n_5\,
      O => \VGA_R[7]_i_596_n_0\
    );
\VGA_R[7]_i_597\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_593_n_0\,
      I1 => \VGA_R[7]_i_192_n_0\,
      I2 => \VGA_R_reg[7]_i_593_n_6\,
      O => \VGA_R[7]_i_597_n_0\
    );
\VGA_R[7]_i_598\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_192_n_0\,
      I1 => \VGA_R_reg[7]_i_593_n_0\,
      I2 => \VGA_R_reg[7]_i_593_n_7\,
      O => \VGA_R[7]_i_598_n_0\
    );
\VGA_R[7]_i_599\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_593_n_0\,
      I1 => \VGA_R[7]_i_192_n_0\,
      I2 => \VGA_R_reg[7]_i_595_n_4\,
      O => \VGA_R[7]_i_599_n_0\
    );
\VGA_R[7]_i_60\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000001"
    )
        port map (
      I0 => pattern_b1_i_23_n_7,
      I1 => pattern_b1_i_18_n_4,
      I2 => pattern_b1_i_18_n_6,
      I3 => pattern_b1_i_18_n_5,
      I4 => pattern_b1_i_24_n_3,
      I5 => pattern_b1_i_23_n_6,
      O => \VGA_R[7]_i_60_n_0\
    );
\VGA_R[7]_i_600\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D2"
    )
        port map (
      I0 => timing_sel(0),
      I1 => timing_sel(1),
      I2 => \VGA_R_reg[7]_i_593_n_0\,
      O => \VGA_R[7]_i_600_n_0\
    );
\VGA_R[7]_i_601\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_192_n_0\,
      I1 => \VGA_R_reg[7]_i_593_n_0\,
      I2 => \VGA_R_reg[7]_i_595_n_5\,
      O => \VGA_R[7]_i_601_n_0\
    );
\VGA_R[7]_i_602\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"659A"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_593_n_0\,
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      I3 => \VGA_R_reg[7]_i_595_n_6\,
      O => \VGA_R[7]_i_602_n_0\
    );
\VGA_R[7]_i_603\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_593_n_0\,
      I1 => \VGA_R_reg[7]_i_595_n_7\,
      O => \VGA_R[7]_i_603_n_0\
    );
\VGA_R[7]_i_604\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D2"
    )
        port map (
      I0 => timing_sel(0),
      I1 => timing_sel(1),
      I2 => \VGA_R_reg[7]_i_593_n_0\,
      O => \VGA_R[7]_i_604_n_0\
    );
\VGA_R[7]_i_606\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => timing_sel(1),
      I1 => timing_sel(0),
      O => \VGA_R[7]_i_606_n_0\
    );
\VGA_R[7]_i_607\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \VGA_R[7]_i_286_n_0\,
      I1 => \VGA_R_reg[7]_i_605_n_6\,
      O => \VGA_R[7]_i_607_n_0\
    );
\VGA_R[7]_i_608\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => timing_sel(1),
      I1 => timing_sel(0),
      O => \VGA_R[7]_i_608_n_0\
    );
\VGA_R[7]_i_610\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => pattern_b1_n_89,
      I1 => \VGA_R_reg[7]_i_592_n_3\,
      O => \VGA_R[7]_i_610_n_0\
    );
\VGA_R[7]_i_611\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => timing_sel(0),
      I1 => timing_sel(1),
      O => \VGA_R[7]_i_611_n_0\
    );
\VGA_R[7]_i_612\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"2D"
    )
        port map (
      I0 => timing_sel(0),
      I1 => timing_sel(1),
      I2 => \VGA_R[7]_i_192_n_0\,
      O => \VGA_R[7]_i_612_n_0\
    );
\VGA_R[7]_i_613\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_592_n_3\,
      I1 => \VGA_R_reg[7]_i_609_n_4\,
      O => \VGA_R[7]_i_613_n_0\
    );
\VGA_R[7]_i_614\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_592_n_3\,
      I1 => \VGA_R[7]_i_192_n_0\,
      I2 => \VGA_R_reg[7]_i_609_n_5\,
      O => \VGA_R[7]_i_614_n_0\
    );
\VGA_R[7]_i_615\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_192_n_0\,
      I1 => \VGA_R_reg[7]_i_592_n_3\,
      I2 => \VGA_R_reg[7]_i_609_n_6\,
      O => \VGA_R[7]_i_615_n_0\
    );
\VGA_R[7]_i_616\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"65"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_592_n_3\,
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      O => \VGA_R[7]_i_616_n_0\
    );
\VGA_R[7]_i_617\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_592_n_3\,
      I1 => \VGA_R[7]_i_192_n_0\,
      O => \VGA_R[7]_i_617_n_0\
    );
\VGA_R[7]_i_618\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => timing_sel(0),
      I1 => timing_sel(1),
      O => \VGA_R[7]_i_618_n_0\
    );
\VGA_R[7]_i_619\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D2"
    )
        port map (
      I0 => timing_sel(0),
      I1 => timing_sel(1),
      I2 => \VGA_R_reg[7]_i_592_n_3\,
      O => \VGA_R[7]_i_619_n_0\
    );
\VGA_R[7]_i_620\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_592_n_3\,
      I1 => \VGA_R[7]_i_192_n_0\,
      O => \VGA_R[7]_i_620_n_0\
    );
\VGA_R[7]_i_621\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_592_n_3\,
      O => \VGA_R[7]_i_621_n_0\
    );
\VGA_R[7]_i_622\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"A6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_592_n_3\,
      I1 => timing_sel(0),
      I2 => timing_sel(1),
      O => \VGA_R[7]_i_622_n_0\
    );
\VGA_R[7]_i_623\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D2"
    )
        port map (
      I0 => timing_sel(0),
      I1 => timing_sel(1),
      I2 => \VGA_R_reg[7]_i_592_n_3\,
      O => \VGA_R[7]_i_623_n_0\
    );
\VGA_R[7]_i_624\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => timing_sel(1),
      I1 => timing_sel(0),
      O => \VGA_R[7]_i_624_n_0\
    );
\VGA_R[7]_i_625\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => timing_sel(1),
      I1 => timing_sel(0),
      O => \VGA_R[7]_i_625_n_0\
    );
\VGA_R[7]_i_626\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => timing_sel(1),
      I1 => timing_sel(0),
      O => \VGA_R[7]_i_626_n_0\
    );
\VGA_R[7]_i_627\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => timing_sel(0),
      I1 => timing_sel(1),
      O => \VGA_R[7]_i_627_n_0\
    );
\VGA_R[7]_i_628\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => timing_sel(1),
      I1 => timing_sel(0),
      O => \VGA_R[7]_i_628_n_0\
    );
\VGA_R[7]_i_629\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => timing_sel(0),
      I1 => timing_sel(1),
      O => \VGA_R[7]_i_629_n_0\
    );
\VGA_R[7]_i_630\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => timing_sel(1),
      I1 => timing_sel(0),
      O => \VGA_R[7]_i_630_n_0\
    );
\VGA_R[7]_i_631\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"EF"
    )
        port map (
      I0 => \VGA_R[7]_i_192_n_0\,
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      O => \VGA_R[7]_i_631_n_0\
    );
\VGA_R[7]_i_632\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => timing_sel(0),
      I1 => timing_sel(1),
      O => \VGA_R[7]_i_632_n_0\
    );
\VGA_R[7]_i_82\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_80_n_0\,
      I1 => \VGA_R_reg[7]_i_80_n_5\,
      O => \VGA_R[7]_i_82_n_0\
    );
\VGA_R[7]_i_83\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_80_n_0\,
      I1 => \VGA_R[7]_i_192_n_0\,
      I2 => \VGA_R_reg[7]_i_80_n_6\,
      O => \VGA_R[7]_i_83_n_0\
    );
\VGA_R[7]_i_84\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"69"
    )
        port map (
      I0 => \VGA_R[7]_i_192_n_0\,
      I1 => \VGA_R_reg[7]_i_80_n_0\,
      I2 => \VGA_R_reg[7]_i_80_n_7\,
      O => \VGA_R[7]_i_84_n_0\
    );
\VGA_R[7]_i_85\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \VGA_R_reg[7]_i_80_n_0\,
      I1 => \VGA_R[7]_i_192_n_0\,
      I2 => \VGA_R_reg[7]_i_81_n_4\,
      O => \VGA_R[7]_i_85_n_0\
    );
\VGA_R_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => \^pck\,
      CE => '1',
      D => pattern_r(0),
      Q => VGA_R(0),
      R => syncgen_multi_n_22
    );
\VGA_R_reg[0]_i_11\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[0]_i_11_n_0\,
      CO(2) => \VGA_R_reg[0]_i_11_n_1\,
      CO(1) => \VGA_R_reg[0]_i_11_n_2\,
      CO(0) => \VGA_R_reg[0]_i_11_n_3\,
      CYINIT => data2(1),
      DI(3) => \VGA_R_reg[1]_i_11_n_5\,
      DI(2) => \VGA_R_reg[1]_i_11_n_6\,
      DI(1) => data2(1),
      DI(0) => \VGA_R[0]_i_21_n_0\,
      O(3 downto 0) => \NLW_VGA_R_reg[0]_i_11_O_UNCONNECTED\(3 downto 0),
      S(3) => \VGA_R[0]_i_22_n_0\,
      S(2) => \VGA_R[0]_i_23_n_0\,
      S(1) => \VGA_R[0]_i_24_n_0\,
      S(0) => \VGA_R[0]_i_25_n_0\
    );
\VGA_R_reg[0]_i_26\: unisim.vcomponents.CARRY4
     port map (
      CI => data2(3),
      CO(3 downto 0) => \NLW_VGA_R_reg[0]_i_26_CO_UNCONNECTED\(3 downto 0),
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 1) => \NLW_VGA_R_reg[0]_i_26_O_UNCONNECTED\(3 downto 1),
      O(0) => \VGA_R_reg[0]_i_26_n_7\,
      S(3 downto 1) => B"000",
      S(0) => \VGA_R[0]_i_27_n_0\
    );
\VGA_R_reg[0]_i_28\: unisim.vcomponents.CARRY4
     port map (
      CI => data2(4),
      CO(3 downto 0) => \NLW_VGA_R_reg[0]_i_28_CO_UNCONNECTED\(3 downto 0),
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 1) => \NLW_VGA_R_reg[0]_i_28_O_UNCONNECTED\(3 downto 1),
      O(0) => \VGA_R_reg[0]_i_28_n_7\,
      S(3 downto 1) => B"000",
      S(0) => \VGA_R[0]_i_29_n_0\
    );
\VGA_R_reg[0]_i_30\: unisim.vcomponents.CARRY4
     port map (
      CI => data2(5),
      CO(3 downto 0) => \NLW_VGA_R_reg[0]_i_30_CO_UNCONNECTED\(3 downto 0),
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 1) => \NLW_VGA_R_reg[0]_i_30_O_UNCONNECTED\(3 downto 1),
      O(0) => \VGA_R_reg[0]_i_30_n_7\,
      S(3 downto 1) => B"000",
      S(0) => \VGA_R[0]_i_31_n_0\
    );
\VGA_R_reg[0]_i_5\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[0]_i_7_n_0\,
      CO(3) => \NLW_VGA_R_reg[0]_i_5_CO_UNCONNECTED\(3),
      CO(2) => data6(0),
      CO(1) => \VGA_R_reg[0]_i_5_n_2\,
      CO(0) => \VGA_R_reg[0]_i_5_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => data6(1),
      DI(1) => \VGA_R_reg[1]_i_5_n_7\,
      DI(0) => \VGA_R_reg[1]_i_7_n_4\,
      O(3 downto 0) => \NLW_VGA_R_reg[0]_i_5_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \VGA_R[0]_i_8_n_0\,
      S(1) => \VGA_R[0]_i_9_n_0\,
      S(0) => \VGA_R[0]_i_10_n_0\
    );
\VGA_R_reg[0]_i_6\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[0]_i_11_n_0\,
      CO(3) => data2(0),
      CO(2) => \VGA_R_reg[0]_i_6_n_1\,
      CO(1) => \VGA_R_reg[0]_i_6_n_2\,
      CO(0) => \VGA_R_reg[0]_i_6_n_3\,
      CYINIT => '0',
      DI(3) => data2(1),
      DI(2) => \VGA_R_reg[1]_i_6_n_6\,
      DI(1) => \VGA_R_reg[1]_i_6_n_7\,
      DI(0) => \VGA_R_reg[1]_i_11_n_4\,
      O(3 downto 0) => \NLW_VGA_R_reg[0]_i_6_O_UNCONNECTED\(3 downto 0),
      S(3) => \VGA_R[0]_i_12_n_0\,
      S(2) => \VGA_R[0]_i_13_n_0\,
      S(1) => \VGA_R[0]_i_14_n_0\,
      S(0) => \VGA_R[0]_i_15_n_0\
    );
\VGA_R_reg[0]_i_7\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[0]_i_7_n_0\,
      CO(2) => \VGA_R_reg[0]_i_7_n_1\,
      CO(1) => \VGA_R_reg[0]_i_7_n_2\,
      CO(0) => \VGA_R_reg[0]_i_7_n_3\,
      CYINIT => data6(1),
      DI(3) => \VGA_R_reg[1]_i_7_n_5\,
      DI(2) => \VGA_R_reg[1]_i_7_n_6\,
      DI(1) => \VGA_R_reg[1]_i_7_n_7\,
      DI(0) => \VGA_R[0]_i_16_n_0\,
      O(3 downto 0) => \NLW_VGA_R_reg[0]_i_7_O_UNCONNECTED\(3 downto 0),
      S(3) => \VGA_R[0]_i_17_n_0\,
      S(2) => \VGA_R[0]_i_18_n_0\,
      S(1) => \VGA_R[0]_i_19_n_0\,
      S(0) => \VGA_R[0]_i_20_n_0\
    );
\VGA_R_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => \^pck\,
      CE => '1',
      D => pattern_r(1),
      Q => VGA_R(1),
      R => syncgen_multi_n_22
    );
\VGA_R_reg[1]_i_11\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[1]_i_11_n_0\,
      CO(2) => \VGA_R_reg[1]_i_11_n_1\,
      CO(1) => \VGA_R_reg[1]_i_11_n_2\,
      CO(0) => \VGA_R_reg[1]_i_11_n_3\,
      CYINIT => data2(2),
      DI(3) => \VGA_R_reg[2]_i_11_n_5\,
      DI(2) => \VGA_R_reg[2]_i_11_n_6\,
      DI(1) => data2(2),
      DI(0) => \VGA_R[1]_i_21_n_0\,
      O(3) => \VGA_R_reg[1]_i_11_n_4\,
      O(2) => \VGA_R_reg[1]_i_11_n_5\,
      O(1) => \VGA_R_reg[1]_i_11_n_6\,
      O(0) => \VGA_R_reg[1]_i_11_n_7\,
      S(3) => \VGA_R[1]_i_22_n_0\,
      S(2) => \VGA_R[1]_i_23_n_0\,
      S(1) => \VGA_R[1]_i_24_n_0\,
      S(0) => \VGA_R[1]_i_25_n_0\
    );
\VGA_R_reg[1]_i_26\: unisim.vcomponents.CARRY4
     port map (
      CI => data2(6),
      CO(3 downto 0) => \NLW_VGA_R_reg[1]_i_26_CO_UNCONNECTED\(3 downto 0),
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 1) => \NLW_VGA_R_reg[1]_i_26_O_UNCONNECTED\(3 downto 1),
      O(0) => \VGA_R_reg[1]_i_26_n_7\,
      S(3 downto 1) => B"000",
      S(0) => \VGA_R[1]_i_27_n_0\
    );
\VGA_R_reg[1]_i_5\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[1]_i_7_n_0\,
      CO(3) => \NLW_VGA_R_reg[1]_i_5_CO_UNCONNECTED\(3),
      CO(2) => data6(1),
      CO(1) => \VGA_R_reg[1]_i_5_n_2\,
      CO(0) => \VGA_R_reg[1]_i_5_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => data6(2),
      DI(1) => \VGA_R_reg[2]_i_5_n_7\,
      DI(0) => \VGA_R_reg[2]_i_7_n_4\,
      O(3 downto 2) => \NLW_VGA_R_reg[1]_i_5_O_UNCONNECTED\(3 downto 2),
      O(1) => \VGA_R_reg[1]_i_5_n_6\,
      O(0) => \VGA_R_reg[1]_i_5_n_7\,
      S(3) => '0',
      S(2) => \VGA_R[1]_i_8_n_0\,
      S(1) => \VGA_R[1]_i_9_n_0\,
      S(0) => \VGA_R[1]_i_10_n_0\
    );
\VGA_R_reg[1]_i_6\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[1]_i_11_n_0\,
      CO(3) => data2(1),
      CO(2) => \VGA_R_reg[1]_i_6_n_1\,
      CO(1) => \VGA_R_reg[1]_i_6_n_2\,
      CO(0) => \VGA_R_reg[1]_i_6_n_3\,
      CYINIT => '0',
      DI(3) => data2(2),
      DI(2) => \VGA_R_reg[2]_i_6_n_6\,
      DI(1) => \VGA_R_reg[2]_i_6_n_7\,
      DI(0) => \VGA_R_reg[2]_i_11_n_4\,
      O(3) => \NLW_VGA_R_reg[1]_i_6_O_UNCONNECTED\(3),
      O(2) => \VGA_R_reg[1]_i_6_n_5\,
      O(1) => \VGA_R_reg[1]_i_6_n_6\,
      O(0) => \VGA_R_reg[1]_i_6_n_7\,
      S(3) => \VGA_R[1]_i_12_n_0\,
      S(2) => \VGA_R[1]_i_13_n_0\,
      S(1) => \VGA_R[1]_i_14_n_0\,
      S(0) => \VGA_R[1]_i_15_n_0\
    );
\VGA_R_reg[1]_i_7\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[1]_i_7_n_0\,
      CO(2) => \VGA_R_reg[1]_i_7_n_1\,
      CO(1) => \VGA_R_reg[1]_i_7_n_2\,
      CO(0) => \VGA_R_reg[1]_i_7_n_3\,
      CYINIT => data6(2),
      DI(3) => \VGA_R_reg[2]_i_7_n_5\,
      DI(2) => \VGA_R_reg[2]_i_7_n_6\,
      DI(1) => \VGA_R_reg[2]_i_7_n_7\,
      DI(0) => \VGA_R[1]_i_16_n_0\,
      O(3) => \VGA_R_reg[1]_i_7_n_4\,
      O(2) => \VGA_R_reg[1]_i_7_n_5\,
      O(1) => \VGA_R_reg[1]_i_7_n_6\,
      O(0) => \VGA_R_reg[1]_i_7_n_7\,
      S(3) => \VGA_R[1]_i_17_n_0\,
      S(2) => \VGA_R[1]_i_18_n_0\,
      S(1) => \VGA_R[1]_i_19_n_0\,
      S(0) => \VGA_R[1]_i_20_n_0\
    );
\VGA_R_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => \^pck\,
      CE => '1',
      D => pattern_r(2),
      Q => VGA_R(2),
      R => syncgen_multi_n_22
    );
\VGA_R_reg[2]_i_11\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[2]_i_11_n_0\,
      CO(2) => \VGA_R_reg[2]_i_11_n_1\,
      CO(1) => \VGA_R_reg[2]_i_11_n_2\,
      CO(0) => \VGA_R_reg[2]_i_11_n_3\,
      CYINIT => data2(3),
      DI(3) => \VGA_R_reg[3]_i_13_n_5\,
      DI(2) => \VGA_R_reg[3]_i_13_n_6\,
      DI(1) => data2(3),
      DI(0) => \VGA_R[2]_i_21_n_0\,
      O(3) => \VGA_R_reg[2]_i_11_n_4\,
      O(2) => \VGA_R_reg[2]_i_11_n_5\,
      O(1) => \VGA_R_reg[2]_i_11_n_6\,
      O(0) => \VGA_R_reg[2]_i_11_n_7\,
      S(3) => \VGA_R[2]_i_22_n_0\,
      S(2) => \VGA_R[2]_i_23_n_0\,
      S(1) => \VGA_R[2]_i_24_n_0\,
      S(0) => \VGA_R[2]_i_25_n_0\
    );
\VGA_R_reg[2]_i_26\: unisim.vcomponents.CARRY4
     port map (
      CI => data2(7),
      CO(3 downto 0) => \NLW_VGA_R_reg[2]_i_26_CO_UNCONNECTED\(3 downto 0),
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 1) => \NLW_VGA_R_reg[2]_i_26_O_UNCONNECTED\(3 downto 1),
      O(0) => \VGA_R_reg[2]_i_26_n_7\,
      S(3 downto 1) => B"000",
      S(0) => \VGA_R[2]_i_27_n_0\
    );
\VGA_R_reg[2]_i_5\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[2]_i_7_n_0\,
      CO(3) => \NLW_VGA_R_reg[2]_i_5_CO_UNCONNECTED\(3),
      CO(2) => data6(2),
      CO(1) => \VGA_R_reg[2]_i_5_n_2\,
      CO(0) => \VGA_R_reg[2]_i_5_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => data6(3),
      DI(1) => \VGA_R_reg[3]_i_6_n_7\,
      DI(0) => \VGA_R_reg[3]_i_8_n_4\,
      O(3 downto 2) => \NLW_VGA_R_reg[2]_i_5_O_UNCONNECTED\(3 downto 2),
      O(1) => \VGA_R_reg[2]_i_5_n_6\,
      O(0) => \VGA_R_reg[2]_i_5_n_7\,
      S(3) => '0',
      S(2) => \VGA_R[2]_i_8_n_0\,
      S(1) => \VGA_R[2]_i_9_n_0\,
      S(0) => \VGA_R[2]_i_10_n_0\
    );
\VGA_R_reg[2]_i_6\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[2]_i_11_n_0\,
      CO(3) => data2(2),
      CO(2) => \VGA_R_reg[2]_i_6_n_1\,
      CO(1) => \VGA_R_reg[2]_i_6_n_2\,
      CO(0) => \VGA_R_reg[2]_i_6_n_3\,
      CYINIT => '0',
      DI(3) => data2(3),
      DI(2) => \VGA_R_reg[3]_i_7_n_6\,
      DI(1) => \VGA_R_reg[3]_i_7_n_7\,
      DI(0) => \VGA_R_reg[3]_i_13_n_4\,
      O(3) => \NLW_VGA_R_reg[2]_i_6_O_UNCONNECTED\(3),
      O(2) => \VGA_R_reg[2]_i_6_n_5\,
      O(1) => \VGA_R_reg[2]_i_6_n_6\,
      O(0) => \VGA_R_reg[2]_i_6_n_7\,
      S(3) => \VGA_R[2]_i_12_n_0\,
      S(2) => \VGA_R[2]_i_13_n_0\,
      S(1) => \VGA_R[2]_i_14_n_0\,
      S(0) => \VGA_R[2]_i_15_n_0\
    );
\VGA_R_reg[2]_i_7\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[2]_i_7_n_0\,
      CO(2) => \VGA_R_reg[2]_i_7_n_1\,
      CO(1) => \VGA_R_reg[2]_i_7_n_2\,
      CO(0) => \VGA_R_reg[2]_i_7_n_3\,
      CYINIT => data6(3),
      DI(3) => \VGA_R_reg[3]_i_8_n_5\,
      DI(2) => \VGA_R_reg[3]_i_8_n_6\,
      DI(1) => \VGA_R_reg[3]_i_8_n_7\,
      DI(0) => \VGA_R[2]_i_16_n_0\,
      O(3) => \VGA_R_reg[2]_i_7_n_4\,
      O(2) => \VGA_R_reg[2]_i_7_n_5\,
      O(1) => \VGA_R_reg[2]_i_7_n_6\,
      O(0) => \VGA_R_reg[2]_i_7_n_7\,
      S(3) => \VGA_R[2]_i_17_n_0\,
      S(2) => \VGA_R[2]_i_18_n_0\,
      S(1) => \VGA_R[2]_i_19_n_0\,
      S(0) => \VGA_R[2]_i_20_n_0\
    );
\VGA_R_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => \^pck\,
      CE => '1',
      D => pattern_r(3),
      Q => VGA_R(3),
      R => syncgen_multi_n_22
    );
\VGA_R_reg[3]_i_13\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[3]_i_13_n_0\,
      CO(2) => \VGA_R_reg[3]_i_13_n_1\,
      CO(1) => \VGA_R_reg[3]_i_13_n_2\,
      CO(0) => \VGA_R_reg[3]_i_13_n_3\,
      CYINIT => data2(4),
      DI(3) => \VGA_R_reg[4]_i_17_n_5\,
      DI(2) => \VGA_R_reg[4]_i_17_n_6\,
      DI(1) => data2(4),
      DI(0) => \VGA_R[3]_i_23_n_0\,
      O(3) => \VGA_R_reg[3]_i_13_n_4\,
      O(2) => \VGA_R_reg[3]_i_13_n_5\,
      O(1) => \VGA_R_reg[3]_i_13_n_6\,
      O(0) => \VGA_R_reg[3]_i_13_n_7\,
      S(3) => \VGA_R[3]_i_24_n_0\,
      S(2) => \VGA_R[3]_i_25_n_0\,
      S(1) => \VGA_R[3]_i_26_n_0\,
      S(0) => \VGA_R[3]_i_27_n_0\
    );
\VGA_R_reg[3]_i_28\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_80_n_0\,
      CO(3 downto 0) => \NLW_VGA_R_reg[3]_i_28_CO_UNCONNECTED\(3 downto 0),
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 1) => \NLW_VGA_R_reg[3]_i_28_O_UNCONNECTED\(3 downto 1),
      O(0) => \VGA_R_reg[3]_i_28_n_7\,
      S(3 downto 1) => B"000",
      S(0) => \VGA_R[3]_i_29_n_0\
    );
\VGA_R_reg[3]_i_6\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[3]_i_8_n_0\,
      CO(3) => \NLW_VGA_R_reg[3]_i_6_CO_UNCONNECTED\(3),
      CO(2) => data6(3),
      CO(1) => \VGA_R_reg[3]_i_6_n_2\,
      CO(0) => \VGA_R_reg[3]_i_6_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => data6(4),
      DI(1) => \VGA_R_reg[4]_i_6_n_7\,
      DI(0) => \VGA_R_reg[4]_i_12_n_4\,
      O(3) => \VGA_R_reg[3]_i_6_n_4\,
      O(2) => \NLW_VGA_R_reg[3]_i_6_O_UNCONNECTED\(2),
      O(1) => \VGA_R_reg[3]_i_6_n_6\,
      O(0) => \VGA_R_reg[3]_i_6_n_7\,
      S(3) => \VGA_R[3]_i_9_n_0\,
      S(2) => \VGA_R[3]_i_10_n_0\,
      S(1) => \VGA_R[3]_i_11_n_0\,
      S(0) => \VGA_R[3]_i_12_n_0\
    );
\VGA_R_reg[3]_i_7\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[3]_i_13_n_0\,
      CO(3) => data2(3),
      CO(2) => \VGA_R_reg[3]_i_7_n_1\,
      CO(1) => \VGA_R_reg[3]_i_7_n_2\,
      CO(0) => \VGA_R_reg[3]_i_7_n_3\,
      CYINIT => '0',
      DI(3) => data2(4),
      DI(2) => \VGA_R_reg[4]_i_7_n_6\,
      DI(1) => \VGA_R_reg[4]_i_7_n_7\,
      DI(0) => \VGA_R_reg[4]_i_17_n_4\,
      O(3) => \NLW_VGA_R_reg[3]_i_7_O_UNCONNECTED\(3),
      O(2) => \VGA_R_reg[3]_i_7_n_5\,
      O(1) => \VGA_R_reg[3]_i_7_n_6\,
      O(0) => \VGA_R_reg[3]_i_7_n_7\,
      S(3) => \VGA_R[3]_i_14_n_0\,
      S(2) => \VGA_R[3]_i_15_n_0\,
      S(1) => \VGA_R[3]_i_16_n_0\,
      S(0) => \VGA_R[3]_i_17_n_0\
    );
\VGA_R_reg[3]_i_8\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[3]_i_8_n_0\,
      CO(2) => \VGA_R_reg[3]_i_8_n_1\,
      CO(1) => \VGA_R_reg[3]_i_8_n_2\,
      CO(0) => \VGA_R_reg[3]_i_8_n_3\,
      CYINIT => data6(4),
      DI(3) => \VGA_R_reg[4]_i_12_n_5\,
      DI(2) => \VGA_R_reg[4]_i_12_n_6\,
      DI(1) => \VGA_R_reg[4]_i_12_n_7\,
      DI(0) => \VGA_R[3]_i_18_n_0\,
      O(3) => \VGA_R_reg[3]_i_8_n_4\,
      O(2) => \VGA_R_reg[3]_i_8_n_5\,
      O(1) => \VGA_R_reg[3]_i_8_n_6\,
      O(0) => \VGA_R_reg[3]_i_8_n_7\,
      S(3) => \VGA_R[3]_i_19_n_0\,
      S(2) => \VGA_R[3]_i_20_n_0\,
      S(1) => \VGA_R[3]_i_21_n_0\,
      S(0) => \VGA_R[3]_i_22_n_0\
    );
\VGA_R_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => \^pck\,
      CE => '1',
      D => pattern_r(4),
      Q => VGA_R(4),
      R => syncgen_multi_n_22
    );
\VGA_R_reg[4]_i_12\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[4]_i_12_n_0\,
      CO(2) => \VGA_R_reg[4]_i_12_n_1\,
      CO(1) => \VGA_R_reg[4]_i_12_n_2\,
      CO(0) => \VGA_R_reg[4]_i_12_n_3\,
      CYINIT => data6(5),
      DI(3) => \VGA_R_reg[5]_i_21_n_5\,
      DI(2) => \VGA_R_reg[5]_i_21_n_6\,
      DI(1) => \VGA_R_reg[5]_i_21_n_7\,
      DI(0) => \VGA_R[4]_i_30_n_0\,
      O(3) => \VGA_R_reg[4]_i_12_n_4\,
      O(2) => \VGA_R_reg[4]_i_12_n_5\,
      O(1) => \VGA_R_reg[4]_i_12_n_6\,
      O(0) => \VGA_R_reg[4]_i_12_n_7\,
      S(3) => \VGA_R[4]_i_31_n_0\,
      S(2) => \VGA_R[4]_i_32_n_0\,
      S(1) => \VGA_R[4]_i_33_n_0\,
      S(0) => \VGA_R[4]_i_34_n_0\
    );
\VGA_R_reg[4]_i_17\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[4]_i_17_n_0\,
      CO(2) => \VGA_R_reg[4]_i_17_n_1\,
      CO(1) => \VGA_R_reg[4]_i_17_n_2\,
      CO(0) => \VGA_R_reg[4]_i_17_n_3\,
      CYINIT => data2(5),
      DI(3) => \VGA_R_reg[5]_i_26_n_5\,
      DI(2) => \VGA_R_reg[5]_i_26_n_6\,
      DI(1) => data2(5),
      DI(0) => \VGA_R[4]_i_35_n_0\,
      O(3) => \VGA_R_reg[4]_i_17_n_4\,
      O(2) => \VGA_R_reg[4]_i_17_n_5\,
      O(1) => \VGA_R_reg[4]_i_17_n_6\,
      O(0) => \VGA_R_reg[4]_i_17_n_7\,
      S(3) => \VGA_R[4]_i_36_n_0\,
      S(2) => \VGA_R[4]_i_37_n_0\,
      S(1) => \VGA_R[4]_i_38_n_0\,
      S(0) => \VGA_R[4]_i_39_n_0\
    );
\VGA_R_reg[4]_i_40\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_181_n_0\,
      CO(3 downto 0) => \NLW_VGA_R_reg[4]_i_40_CO_UNCONNECTED\(3 downto 0),
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 1) => \NLW_VGA_R_reg[4]_i_40_O_UNCONNECTED\(3 downto 1),
      O(0) => \VGA_R_reg[4]_i_40_n_7\,
      S(3 downto 1) => B"000",
      S(0) => \VGA_R[4]_i_41_n_0\
    );
\VGA_R_reg[4]_i_6\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[4]_i_12_n_0\,
      CO(3) => \NLW_VGA_R_reg[4]_i_6_CO_UNCONNECTED\(3),
      CO(2) => data6(4),
      CO(1) => \VGA_R_reg[4]_i_6_n_2\,
      CO(0) => \VGA_R_reg[4]_i_6_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => data6(5),
      DI(1) => \VGA_R_reg[5]_i_9_n_7\,
      DI(0) => \VGA_R_reg[5]_i_21_n_4\,
      O(3) => \VGA_R_reg[4]_i_6_n_4\,
      O(2) => \NLW_VGA_R_reg[4]_i_6_O_UNCONNECTED\(2),
      O(1) => \VGA_R_reg[4]_i_6_n_6\,
      O(0) => \VGA_R_reg[4]_i_6_n_7\,
      S(3) => \VGA_R[4]_i_13_n_0\,
      S(2) => \VGA_R[4]_i_14_n_0\,
      S(1) => \VGA_R[4]_i_15_n_0\,
      S(0) => \VGA_R[4]_i_16_n_0\
    );
\VGA_R_reg[4]_i_7\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[4]_i_17_n_0\,
      CO(3) => data2(4),
      CO(2) => \VGA_R_reg[4]_i_7_n_1\,
      CO(1) => \VGA_R_reg[4]_i_7_n_2\,
      CO(0) => \VGA_R_reg[4]_i_7_n_3\,
      CYINIT => '0',
      DI(3) => data2(5),
      DI(2) => \VGA_R_reg[5]_i_10_n_6\,
      DI(1) => \VGA_R_reg[5]_i_10_n_7\,
      DI(0) => \VGA_R_reg[5]_i_26_n_4\,
      O(3) => \NLW_VGA_R_reg[4]_i_7_O_UNCONNECTED\(3),
      O(2) => \VGA_R_reg[4]_i_7_n_5\,
      O(1) => \VGA_R_reg[4]_i_7_n_6\,
      O(0) => \VGA_R_reg[4]_i_7_n_7\,
      S(3) => \VGA_R[4]_i_18_n_0\,
      S(2) => \VGA_R[4]_i_19_n_0\,
      S(1) => \VGA_R[4]_i_20_n_0\,
      S(0) => \VGA_R[4]_i_21_n_0\
    );
\VGA_R_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => \^pck\,
      CE => '1',
      D => pattern_r(5),
      Q => VGA_R(5),
      R => syncgen_multi_n_22
    );
\VGA_R_reg[5]_i_10\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[5]_i_26_n_0\,
      CO(3) => data2(5),
      CO(2) => \VGA_R_reg[5]_i_10_n_1\,
      CO(1) => \VGA_R_reg[5]_i_10_n_2\,
      CO(0) => \VGA_R_reg[5]_i_10_n_3\,
      CYINIT => '0',
      DI(3) => data2(6),
      DI(2) => \VGA_R_reg[6]_i_5_n_6\,
      DI(1) => \VGA_R_reg[6]_i_5_n_7\,
      DI(0) => \VGA_R_reg[6]_i_7_n_4\,
      O(3) => \NLW_VGA_R_reg[5]_i_10_O_UNCONNECTED\(3),
      O(2) => \VGA_R_reg[5]_i_10_n_5\,
      O(1) => \VGA_R_reg[5]_i_10_n_6\,
      O(0) => \VGA_R_reg[5]_i_10_n_7\,
      S(3) => \VGA_R[5]_i_27_n_0\,
      S(2) => \VGA_R[5]_i_28_n_0\,
      S(1) => \VGA_R[5]_i_29_n_0\,
      S(0) => \VGA_R[5]_i_30_n_0\
    );
\VGA_R_reg[5]_i_100\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_367_n_0\,
      CO(3 downto 0) => \NLW_VGA_R_reg[5]_i_100_CO_UNCONNECTED\(3 downto 0),
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 1) => \NLW_VGA_R_reg[5]_i_100_O_UNCONNECTED\(3 downto 1),
      O(0) => \VGA_R_reg[5]_i_100_n_7\,
      S(3 downto 1) => B"000",
      S(0) => \VGA_R[5]_i_119_n_0\
    );
\VGA_R_reg[5]_i_108\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \NLW_VGA_R_reg[5]_i_108_CO_UNCONNECTED\(3),
      CO(2) => \VGA_R_reg[5]_i_108_n_1\,
      CO(1) => \NLW_VGA_R_reg[5]_i_108_CO_UNCONNECTED\(1),
      CO(0) => \VGA_R_reg[5]_i_108_n_3\,
      CYINIT => HWIDTH(4),
      DI(3 downto 2) => B"00",
      DI(1) => \VGA_R[5]_i_120_n_0\,
      DI(0) => '0',
      O(3 downto 2) => \NLW_VGA_R_reg[5]_i_108_O_UNCONNECTED\(3 downto 2),
      O(1) => \VGA_R_reg[5]_i_108_n_6\,
      O(0) => \VGA_R_reg[5]_i_108_n_7\,
      S(3 downto 2) => B"01",
      S(1) => \VGA_R[5]_i_121_n_0\,
      S(0) => \VGA_R[5]_i_122_n_0\
    );
\VGA_R_reg[5]_i_110\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[5]_i_123_n_0\,
      CO(3) => \VGA_R_reg[5]_i_110_n_0\,
      CO(2) => \VGA_R_reg[5]_i_110_n_1\,
      CO(1) => \VGA_R_reg[5]_i_110_n_2\,
      CO(0) => \VGA_R_reg[5]_i_110_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \VGA_R_reg[5]_i_114_n_4\,
      DI(1) => \VGA_R[5]_i_124_n_0\,
      DI(0) => \VGA_R[5]_i_125_n_0\,
      O(3 downto 0) => \NLW_VGA_R_reg[5]_i_110_O_UNCONNECTED\(3 downto 0),
      S(3) => \VGA_R_reg[5]_i_99_n_7\,
      S(2) => \VGA_R[5]_i_126_n_0\,
      S(1) => \VGA_R[5]_i_127_n_0\,
      S(0) => \VGA_R[5]_i_128_n_0\
    );
\VGA_R_reg[5]_i_114\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[5]_i_114_n_0\,
      CO(2) => \VGA_R_reg[5]_i_114_n_1\,
      CO(1) => \VGA_R_reg[5]_i_114_n_2\,
      CO(0) => \VGA_R_reg[5]_i_114_n_3\,
      CYINIT => \VGA_R[5]_i_129_n_0\,
      DI(3) => \VGA_R[5]_i_130_n_0\,
      DI(2) => \VGA_R[5]_i_131_n_0\,
      DI(1) => \VGA_R[5]_i_132_n_0\,
      DI(0) => '0',
      O(3) => \VGA_R_reg[5]_i_114_n_4\,
      O(2) => \VGA_R_reg[5]_i_114_n_5\,
      O(1) => \VGA_R_reg[5]_i_114_n_6\,
      O(0) => \NLW_VGA_R_reg[5]_i_114_O_UNCONNECTED\(0),
      S(3) => \VGA_R[5]_i_133_n_0\,
      S(2) => \VGA_R[5]_i_134_n_0\,
      S(1) => \VGA_R[5]_i_135_n_0\,
      S(0) => '1'
    );
\VGA_R_reg[5]_i_123\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[5]_i_123_n_0\,
      CO(2) => \VGA_R_reg[5]_i_123_n_1\,
      CO(1) => \VGA_R_reg[5]_i_123_n_2\,
      CO(0) => \VGA_R_reg[5]_i_123_n_3\,
      CYINIT => '0',
      DI(3) => \VGA_R[5]_i_136_n_0\,
      DI(2) => \VGA_R[5]_i_137_n_0\,
      DI(1 downto 0) => B"11",
      O(3 downto 0) => \NLW_VGA_R_reg[5]_i_123_O_UNCONNECTED\(3 downto 0),
      S(3) => \VGA_R[5]_i_138_n_0\,
      S(2) => \VGA_R[5]_i_139_n_0\,
      S(1) => \VGA_R[5]_i_140_n_0\,
      S(0) => \VGA_R_reg[5]_i_97_n_6\
    );
\VGA_R_reg[5]_i_21\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[5]_i_21_n_0\,
      CO(2) => \VGA_R_reg[5]_i_21_n_1\,
      CO(1) => \VGA_R_reg[5]_i_21_n_2\,
      CO(0) => \VGA_R_reg[5]_i_21_n_3\,
      CYINIT => data6(6),
      DI(3) => \VGA_R_reg[6]_i_12_n_5\,
      DI(2) => \VGA_R_reg[6]_i_12_n_6\,
      DI(1) => \VGA_R_reg[6]_i_12_n_7\,
      DI(0) => \VGA_R[5]_i_60_n_0\,
      O(3) => \VGA_R_reg[5]_i_21_n_4\,
      O(2) => \VGA_R_reg[5]_i_21_n_5\,
      O(1) => \VGA_R_reg[5]_i_21_n_6\,
      O(0) => \VGA_R_reg[5]_i_21_n_7\,
      S(3) => \VGA_R[5]_i_61_n_0\,
      S(2) => \VGA_R[5]_i_62_n_0\,
      S(1) => \VGA_R[5]_i_63_n_0\,
      S(0) => \VGA_R[5]_i_64_n_0\
    );
\VGA_R_reg[5]_i_26\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[5]_i_26_n_0\,
      CO(2) => \VGA_R_reg[5]_i_26_n_1\,
      CO(1) => \VGA_R_reg[5]_i_26_n_2\,
      CO(0) => \VGA_R_reg[5]_i_26_n_3\,
      CYINIT => data2(6),
      DI(3) => \VGA_R_reg[6]_i_7_n_5\,
      DI(2) => \VGA_R_reg[6]_i_7_n_6\,
      DI(1) => data2(6),
      DI(0) => \VGA_R[5]_i_65_n_0\,
      O(3) => \VGA_R_reg[5]_i_26_n_4\,
      O(2) => \VGA_R_reg[5]_i_26_n_5\,
      O(1) => \VGA_R_reg[5]_i_26_n_6\,
      O(0) => \VGA_R_reg[5]_i_26_n_7\,
      S(3) => \VGA_R[5]_i_66_n_0\,
      S(2) => \VGA_R[5]_i_67_n_0\,
      S(1) => \VGA_R[5]_i_68_n_0\,
      S(0) => \VGA_R[5]_i_69_n_0\
    );
\VGA_R_reg[5]_i_78\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3 downto 1) => \NLW_VGA_R_reg[5]_i_78_CO_UNCONNECTED\(3 downto 1),
      CO(0) => \VGA_R_reg[5]_i_78_n_3\,
      CYINIT => \VGA_R_reg[5]_i_79_n_0\,
      DI(3 downto 0) => B"0000",
      O(3 downto 2) => \NLW_VGA_R_reg[5]_i_78_O_UNCONNECTED\(3 downto 2),
      O(1) => \VGA_R_reg[5]_i_78_n_6\,
      O(0) => \NLW_VGA_R_reg[5]_i_78_O_UNCONNECTED\(0),
      S(3 downto 2) => B"00",
      S(1) => \VGA_R[5]_i_103_n_0\,
      S(0) => '1'
    );
\VGA_R_reg[5]_i_79\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[5]_i_79_n_0\,
      CO(2) => \NLW_VGA_R_reg[5]_i_79_CO_UNCONNECTED\(2),
      CO(1) => \VGA_R_reg[5]_i_79_n_2\,
      CO(0) => \VGA_R_reg[5]_i_79_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \VGA_R[5]_i_104_n_0\,
      DI(1 downto 0) => B"01",
      O(3) => \NLW_VGA_R_reg[5]_i_79_O_UNCONNECTED\(3),
      O(2) => \VGA_R_reg[5]_i_79_n_5\,
      O(1) => \VGA_R_reg[5]_i_79_n_6\,
      O(0) => \VGA_R_reg[5]_i_79_n_7\,
      S(3) => '1',
      S(2) => \VGA_R[5]_i_105_n_0\,
      S(1) => \VGA_R[5]_i_106_n_0\,
      S(0) => \VGA_R[5]_i_107_n_0\
    );
\VGA_R_reg[5]_i_9\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[5]_i_21_n_0\,
      CO(3) => \NLW_VGA_R_reg[5]_i_9_CO_UNCONNECTED\(3),
      CO(2) => data6(5),
      CO(1) => \VGA_R_reg[5]_i_9_n_2\,
      CO(0) => \VGA_R_reg[5]_i_9_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => data6(6),
      DI(1) => \VGA_R_reg[6]_i_6_n_7\,
      DI(0) => \VGA_R_reg[6]_i_12_n_4\,
      O(3) => \VGA_R_reg[5]_i_9_n_4\,
      O(2) => \NLW_VGA_R_reg[5]_i_9_O_UNCONNECTED\(2),
      O(1) => \VGA_R_reg[5]_i_9_n_6\,
      O(0) => \VGA_R_reg[5]_i_9_n_7\,
      S(3) => \VGA_R[5]_i_22_n_0\,
      S(2) => \VGA_R[5]_i_23_n_0\,
      S(1) => \VGA_R[5]_i_24_n_0\,
      S(0) => \VGA_R[5]_i_25_n_0\
    );
\VGA_R_reg[5]_i_97\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \NLW_VGA_R_reg[5]_i_97_CO_UNCONNECTED\(3),
      CO(2) => \VGA_R_reg[5]_i_97_n_1\,
      CO(1) => \NLW_VGA_R_reg[5]_i_97_CO_UNCONNECTED\(1),
      CO(0) => \VGA_R_reg[5]_i_97_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \VGA_R[5]_i_109_n_0\,
      DI(0) => '0',
      O(3 downto 2) => \NLW_VGA_R_reg[5]_i_97_O_UNCONNECTED\(3 downto 2),
      O(1) => \VGA_R_reg[5]_i_97_n_6\,
      O(0) => \NLW_VGA_R_reg[5]_i_97_O_UNCONNECTED\(0),
      S(3 downto 0) => B"0111"
    );
\VGA_R_reg[5]_i_98\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[5]_i_110_n_0\,
      CO(3 downto 2) => \NLW_VGA_R_reg[5]_i_98_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \VGA_R_reg[5]_i_98_n_2\,
      CO(0) => \VGA_R_reg[5]_i_98_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \VGA_R[5]_i_111_n_0\,
      DI(0) => '0',
      O(3 downto 0) => \NLW_VGA_R_reg[5]_i_98_O_UNCONNECTED\(3 downto 0),
      S(3 downto 2) => B"00",
      S(1) => \VGA_R[5]_i_112_n_0\,
      S(0) => \VGA_R[5]_i_113_n_0\
    );
\VGA_R_reg[5]_i_99\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[5]_i_114_n_0\,
      CO(3) => \NLW_VGA_R_reg[5]_i_99_CO_UNCONNECTED\(3),
      CO(2) => \VGA_R_reg[5]_i_99_n_1\,
      CO(1) => \NLW_VGA_R_reg[5]_i_99_CO_UNCONNECTED\(1),
      CO(0) => \VGA_R_reg[5]_i_99_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \VGA_R[5]_i_115_n_0\,
      DI(0) => \VGA_R[5]_i_116_n_0\,
      O(3 downto 2) => \NLW_VGA_R_reg[5]_i_99_O_UNCONNECTED\(3 downto 2),
      O(1) => \VGA_R_reg[5]_i_99_n_6\,
      O(0) => \VGA_R_reg[5]_i_99_n_7\,
      S(3 downto 2) => B"01",
      S(1) => HPERIOD(8),
      S(0) => \VGA_R[5]_i_118_n_0\
    );
\VGA_R_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => \^pck\,
      CE => '1',
      D => pattern_r(6),
      Q => VGA_R(6),
      R => syncgen_multi_n_22
    );
\VGA_R_reg[6]_i_12\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[6]_i_12_n_0\,
      CO(2) => \VGA_R_reg[6]_i_12_n_1\,
      CO(1) => \VGA_R_reg[6]_i_12_n_2\,
      CO(0) => \VGA_R_reg[6]_i_12_n_3\,
      CYINIT => data6(7),
      DI(3) => \VGA_R_reg[7]_i_109_n_5\,
      DI(2) => \VGA_R_reg[7]_i_109_n_6\,
      DI(1) => \VGA_R_reg[7]_i_109_n_7\,
      DI(0) => \VGA_R[6]_i_22_n_0\,
      O(3) => \VGA_R_reg[6]_i_12_n_4\,
      O(2) => \VGA_R_reg[6]_i_12_n_5\,
      O(1) => \VGA_R_reg[6]_i_12_n_6\,
      O(0) => \VGA_R_reg[6]_i_12_n_7\,
      S(3) => \VGA_R[6]_i_23_n_0\,
      S(2) => \VGA_R[6]_i_24_n_0\,
      S(1) => \VGA_R[6]_i_25_n_0\,
      S(0) => \VGA_R[6]_i_26_n_0\
    );
\VGA_R_reg[6]_i_27\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_462_n_0\,
      CO(3 downto 0) => \NLW_VGA_R_reg[6]_i_27_CO_UNCONNECTED\(3 downto 0),
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 1) => \NLW_VGA_R_reg[6]_i_27_O_UNCONNECTED\(3 downto 1),
      O(0) => \VGA_R_reg[6]_i_27_n_7\,
      S(3 downto 1) => B"000",
      S(0) => \VGA_R[6]_i_29_n_0\
    );
\VGA_R_reg[6]_i_28\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_483_n_0\,
      CO(3) => \NLW_VGA_R_reg[6]_i_28_CO_UNCONNECTED\(3),
      CO(2) => \VGA_R_reg[6]_i_28_n_1\,
      CO(1) => \VGA_R_reg[6]_i_28_n_2\,
      CO(0) => \VGA_R_reg[6]_i_28_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \VGA_R_reg[7]_i_435_n_1\,
      DI(1) => \VGA_R_reg[7]_i_435_n_7\,
      DI(0) => \VGA_R_reg[7]_i_477_n_4\,
      O(3) => \VGA_R_reg[6]_i_28_n_4\,
      O(2) => \NLW_VGA_R_reg[6]_i_28_O_UNCONNECTED\(2),
      O(1) => \VGA_R_reg[6]_i_28_n_6\,
      O(0) => \VGA_R_reg[6]_i_28_n_7\,
      S(3) => \VGA_R[6]_i_30_n_0\,
      S(2) => \VGA_R[6]_i_31_n_0\,
      S(1) => \VGA_R[6]_i_32_n_0\,
      S(0) => \VGA_R[6]_i_33_n_0\
    );
\VGA_R_reg[6]_i_5\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[6]_i_7_n_0\,
      CO(3) => data2(6),
      CO(2) => \VGA_R_reg[6]_i_5_n_1\,
      CO(1) => \VGA_R_reg[6]_i_5_n_2\,
      CO(0) => \VGA_R_reg[6]_i_5_n_3\,
      CYINIT => '0',
      DI(3) => data2(7),
      DI(2) => \VGA_R_reg[7]_i_30_n_6\,
      DI(1) => \VGA_R_reg[7]_i_30_n_7\,
      DI(0) => \VGA_R_reg[7]_i_79_n_4\,
      O(3) => \NLW_VGA_R_reg[6]_i_5_O_UNCONNECTED\(3),
      O(2) => \VGA_R_reg[6]_i_5_n_5\,
      O(1) => \VGA_R_reg[6]_i_5_n_6\,
      O(0) => \VGA_R_reg[6]_i_5_n_7\,
      S(3) => \VGA_R[6]_i_8_n_0\,
      S(2) => \VGA_R[6]_i_9_n_0\,
      S(1) => \VGA_R[6]_i_10_n_0\,
      S(0) => \VGA_R[6]_i_11_n_0\
    );
\VGA_R_reg[6]_i_6\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[6]_i_12_n_0\,
      CO(3) => \NLW_VGA_R_reg[6]_i_6_CO_UNCONNECTED\(3),
      CO(2) => data6(6),
      CO(1) => \VGA_R_reg[6]_i_6_n_2\,
      CO(0) => \VGA_R_reg[6]_i_6_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => data6(7),
      DI(1) => \VGA_R_reg[7]_i_40_n_7\,
      DI(0) => \VGA_R_reg[7]_i_109_n_4\,
      O(3) => \VGA_R_reg[6]_i_6_n_4\,
      O(2) => \NLW_VGA_R_reg[6]_i_6_O_UNCONNECTED\(2),
      O(1) => \VGA_R_reg[6]_i_6_n_6\,
      O(0) => \VGA_R_reg[6]_i_6_n_7\,
      S(3) => \VGA_R[6]_i_13_n_0\,
      S(2) => \VGA_R[6]_i_14_n_0\,
      S(1) => \VGA_R[6]_i_15_n_0\,
      S(0) => \VGA_R[6]_i_16_n_0\
    );
\VGA_R_reg[6]_i_7\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[6]_i_7_n_0\,
      CO(2) => \VGA_R_reg[6]_i_7_n_1\,
      CO(1) => \VGA_R_reg[6]_i_7_n_2\,
      CO(0) => \VGA_R_reg[6]_i_7_n_3\,
      CYINIT => data2(7),
      DI(3) => \VGA_R_reg[7]_i_79_n_5\,
      DI(2) => \VGA_R_reg[7]_i_79_n_6\,
      DI(1) => data2(7),
      DI(0) => \VGA_R[6]_i_17_n_0\,
      O(3) => \VGA_R_reg[6]_i_7_n_4\,
      O(2) => \VGA_R_reg[6]_i_7_n_5\,
      O(1) => \VGA_R_reg[6]_i_7_n_6\,
      O(0) => \VGA_R_reg[6]_i_7_n_7\,
      S(3) => \VGA_R[6]_i_18_n_0\,
      S(2) => \VGA_R[6]_i_19_n_0\,
      S(1) => \VGA_R[6]_i_20_n_0\,
      S(0) => \VGA_R[6]_i_21_n_0\
    );
\VGA_R_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => \^pck\,
      CE => '1',
      D => pattern_r(7),
      Q => VGA_R(7),
      R => syncgen_multi_n_22
    );
\VGA_R_reg[7]_i_101\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_241_n_0\,
      CO(3) => \VGA_R_reg[7]_i_101_n_0\,
      CO(2) => \VGA_R_reg[7]_i_101_n_1\,
      CO(1) => \VGA_R_reg[7]_i_101_n_2\,
      CO(0) => \VGA_R_reg[7]_i_101_n_3\,
      CYINIT => '0',
      DI(3) => \VGA_R_reg[7]_i_92_n_0\,
      DI(2) => \VGA_R_reg[7]_i_92_n_6\,
      DI(1) => \VGA_R_reg[7]_i_92_n_7\,
      DI(0) => \VGA_R_reg[7]_i_203_n_4\,
      O(3) => \NLW_VGA_R_reg[7]_i_101_O_UNCONNECTED\(3),
      O(2) => \VGA_R_reg[7]_i_101_n_5\,
      O(1) => \VGA_R_reg[7]_i_101_n_6\,
      O(0) => \VGA_R_reg[7]_i_101_n_7\,
      S(3) => \VGA_R[7]_i_246_n_0\,
      S(2) => \VGA_R[7]_i_247_n_0\,
      S(1) => \VGA_R[7]_i_248_n_0\,
      S(0) => \VGA_R[7]_i_249_n_0\
    );
\VGA_R_reg[7]_i_109\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[7]_i_109_n_0\,
      CO(2) => \VGA_R_reg[7]_i_109_n_1\,
      CO(1) => \VGA_R_reg[7]_i_109_n_2\,
      CO(0) => \VGA_R_reg[7]_i_109_n_3\,
      CYINIT => \VGA_R_reg[7]_i_110_n_1\,
      DI(3) => \VGA_R_reg[7]_i_111_n_5\,
      DI(2) => \VGA_R_reg[7]_i_111_n_6\,
      DI(1) => \VGA_R_reg[7]_i_111_n_7\,
      DI(0) => \VGA_R[7]_i_270_n_0\,
      O(3) => \VGA_R_reg[7]_i_109_n_4\,
      O(2) => \VGA_R_reg[7]_i_109_n_5\,
      O(1) => \VGA_R_reg[7]_i_109_n_6\,
      O(0) => \VGA_R_reg[7]_i_109_n_7\,
      S(3) => \VGA_R[7]_i_271_n_0\,
      S(2) => \VGA_R[7]_i_272_n_0\,
      S(1) => \VGA_R[7]_i_273_n_0\,
      S(0) => \VGA_R[7]_i_274_n_0\
    );
\VGA_R_reg[7]_i_110\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_111_n_0\,
      CO(3) => \NLW_VGA_R_reg[7]_i_110_CO_UNCONNECTED\(3),
      CO(2) => \VGA_R_reg[7]_i_110_n_1\,
      CO(1) => \VGA_R_reg[7]_i_110_n_2\,
      CO(0) => \VGA_R_reg[7]_i_110_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \VGA_R_reg[7]_i_275_n_1\,
      DI(1) => \VGA_R_reg[7]_i_275_n_7\,
      DI(0) => \VGA_R_reg[7]_i_276_n_4\,
      O(3) => \VGA_R_reg[7]_i_110_n_4\,
      O(2) => \NLW_VGA_R_reg[7]_i_110_O_UNCONNECTED\(2),
      O(1) => \VGA_R_reg[7]_i_110_n_6\,
      O(0) => \VGA_R_reg[7]_i_110_n_7\,
      S(3) => \VGA_R[7]_i_277_n_0\,
      S(2) => \VGA_R[7]_i_278_n_0\,
      S(1) => \VGA_R[7]_i_279_n_0\,
      S(0) => \VGA_R[7]_i_280_n_0\
    );
\VGA_R_reg[7]_i_111\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[7]_i_111_n_0\,
      CO(2) => \VGA_R_reg[7]_i_111_n_1\,
      CO(1) => \VGA_R_reg[7]_i_111_n_2\,
      CO(0) => \VGA_R_reg[7]_i_111_n_3\,
      CYINIT => \VGA_R_reg[7]_i_275_n_1\,
      DI(3) => \VGA_R_reg[7]_i_276_n_5\,
      DI(2) => \VGA_R_reg[7]_i_276_n_6\,
      DI(1) => \VGA_R_reg[7]_i_276_n_7\,
      DI(0) => \VGA_R[7]_i_281_n_0\,
      O(3) => \VGA_R_reg[7]_i_111_n_4\,
      O(2) => \VGA_R_reg[7]_i_111_n_5\,
      O(1) => \VGA_R_reg[7]_i_111_n_6\,
      O(0) => \VGA_R_reg[7]_i_111_n_7\,
      S(3) => \VGA_R[7]_i_282_n_0\,
      S(2) => \VGA_R[7]_i_283_n_0\,
      S(1) => \VGA_R[7]_i_284_n_0\,
      S(0) => \VGA_R[7]_i_285_n_0\
    );
\VGA_R_reg[7]_i_127\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[7]_i_127_n_0\,
      CO(2) => \VGA_R_reg[7]_i_127_n_1\,
      CO(1) => \VGA_R_reg[7]_i_127_n_2\,
      CO(0) => \VGA_R_reg[7]_i_127_n_3\,
      CYINIT => HWIDTH(4),
      DI(3) => \VGA_R[7]_i_310_n_0\,
      DI(2) => \VGA_R[7]_i_311_n_0\,
      DI(1) => \VGA_R[7]_i_312_n_0\,
      DI(0) => \VGA_R[7]_i_313_n_0\,
      O(3) => \VGA_R_reg[7]_i_127_n_4\,
      O(2) => \VGA_R_reg[7]_i_127_n_5\,
      O(1) => \VGA_R_reg[7]_i_127_n_6\,
      O(0) => \NLW_VGA_R_reg[7]_i_127_O_UNCONNECTED\(0),
      S(3) => '0',
      S(2) => \VGA_R[7]_i_314_n_0\,
      S(1) => \VGA_R[7]_i_315_n_0\,
      S(0) => \VGA_R[7]_i_316_n_0\
    );
\VGA_R_reg[7]_i_181\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_182_n_0\,
      CO(3) => \VGA_R_reg[7]_i_181_n_0\,
      CO(2) => \VGA_R_reg[7]_i_181_n_1\,
      CO(1) => \VGA_R_reg[7]_i_181_n_2\,
      CO(0) => \VGA_R_reg[7]_i_181_n_3\,
      CYINIT => '0',
      DI(3) => \VGA_R_reg[7]_i_367_n_0\,
      DI(2) => \VGA_R_reg[7]_i_367_n_6\,
      DI(1) => \VGA_R_reg[7]_i_367_n_7\,
      DI(0) => \VGA_R_reg[7]_i_368_n_4\,
      O(3) => \NLW_VGA_R_reg[7]_i_181_O_UNCONNECTED\(3),
      O(2) => \VGA_R_reg[7]_i_181_n_5\,
      O(1) => \VGA_R_reg[7]_i_181_n_6\,
      O(0) => \VGA_R_reg[7]_i_181_n_7\,
      S(3) => \VGA_R[7]_i_369_n_0\,
      S(2) => \VGA_R[7]_i_370_n_0\,
      S(1) => \VGA_R[7]_i_371_n_0\,
      S(0) => \VGA_R[7]_i_372_n_0\
    );
\VGA_R_reg[7]_i_182\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[7]_i_182_n_0\,
      CO(2) => \VGA_R_reg[7]_i_182_n_1\,
      CO(1) => \VGA_R_reg[7]_i_182_n_2\,
      CO(0) => \VGA_R_reg[7]_i_182_n_3\,
      CYINIT => \VGA_R_reg[7]_i_367_n_0\,
      DI(3) => \VGA_R_reg[7]_i_368_n_5\,
      DI(2) => \VGA_R_reg[7]_i_368_n_6\,
      DI(1) => \VGA_R_reg[7]_i_367_n_0\,
      DI(0) => \VGA_R[7]_i_373_n_0\,
      O(3) => \VGA_R_reg[7]_i_182_n_4\,
      O(2) => \VGA_R_reg[7]_i_182_n_5\,
      O(1) => \VGA_R_reg[7]_i_182_n_6\,
      O(0) => \VGA_R_reg[7]_i_182_n_7\,
      S(3) => \VGA_R[7]_i_374_n_0\,
      S(2) => \VGA_R[7]_i_375_n_0\,
      S(1) => \VGA_R[7]_i_376_n_0\,
      S(0) => \VGA_R[7]_i_377_n_0\
    );
\VGA_R_reg[7]_i_203\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[7]_i_203_n_0\,
      CO(2) => \VGA_R_reg[7]_i_203_n_1\,
      CO(1) => \VGA_R_reg[7]_i_203_n_2\,
      CO(0) => \VGA_R_reg[7]_i_203_n_3\,
      CYINIT => \VGA_R_reg[7]_i_93_n_3\,
      DI(3) => \VGA_R[7]_i_379_n_0\,
      DI(2) => \VGA_R[7]_i_380_n_0\,
      DI(1) => \VGA_R_reg[7]_i_93_n_3\,
      DI(0) => \VGA_R[7]_i_381_n_0\,
      O(3) => \VGA_R_reg[7]_i_203_n_4\,
      O(2) => \VGA_R_reg[7]_i_203_n_5\,
      O(1) => \VGA_R_reg[7]_i_203_n_6\,
      O(0) => \VGA_R_reg[7]_i_203_n_7\,
      S(3) => \VGA_R[7]_i_382_n_0\,
      S(2) => \VGA_R[7]_i_383_n_0\,
      S(1) => \VGA_R[7]_i_384_n_0\,
      S(0) => \VGA_R[7]_i_385_n_0\
    );
\VGA_R_reg[7]_i_204\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[7]_i_204_n_0\,
      CO(2) => \VGA_R_reg[7]_i_204_n_1\,
      CO(1) => \VGA_R_reg[7]_i_204_n_2\,
      CO(0) => \VGA_R_reg[7]_i_204_n_3\,
      CYINIT => HWIDTH(4),
      DI(3) => \VGA_R[7]_i_386_n_0\,
      DI(2) => \VGA_R[7]_i_387_n_0\,
      DI(1) => \VGA_R[7]_i_388_n_0\,
      DI(0) => \VGA_R[7]_i_389_n_0\,
      O(3) => \VGA_R_reg[7]_i_204_n_4\,
      O(2) => \VGA_R_reg[7]_i_204_n_5\,
      O(1) => \VGA_R_reg[7]_i_204_n_6\,
      O(0) => \NLW_VGA_R_reg[7]_i_204_O_UNCONNECTED\(0),
      S(3) => '0',
      S(2) => \VGA_R[7]_i_390_n_0\,
      S(1) => \VGA_R[7]_i_391_n_0\,
      S(0) => \VGA_R[7]_i_392_n_0\
    );
\VGA_R_reg[7]_i_241\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[7]_i_241_n_0\,
      CO(2) => \VGA_R_reg[7]_i_241_n_1\,
      CO(1) => \VGA_R_reg[7]_i_241_n_2\,
      CO(0) => \VGA_R_reg[7]_i_241_n_3\,
      CYINIT => \VGA_R_reg[7]_i_92_n_0\,
      DI(3) => \VGA_R_reg[7]_i_203_n_5\,
      DI(2) => \VGA_R_reg[7]_i_203_n_6\,
      DI(1) => \VGA_R_reg[7]_i_92_n_0\,
      DI(0) => \VGA_R[7]_i_423_n_0\,
      O(3) => \VGA_R_reg[7]_i_241_n_4\,
      O(2) => \VGA_R_reg[7]_i_241_n_5\,
      O(1) => \VGA_R_reg[7]_i_241_n_6\,
      O(0) => \VGA_R_reg[7]_i_241_n_7\,
      S(3) => \VGA_R[7]_i_424_n_0\,
      S(2) => \VGA_R[7]_i_425_n_0\,
      S(1) => \VGA_R[7]_i_426_n_0\,
      S(0) => \VGA_R[7]_i_427_n_0\
    );
\VGA_R_reg[7]_i_275\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_276_n_0\,
      CO(3) => \NLW_VGA_R_reg[7]_i_275_CO_UNCONNECTED\(3),
      CO(2) => \VGA_R_reg[7]_i_275_n_1\,
      CO(1) => \VGA_R_reg[7]_i_275_n_2\,
      CO(0) => \VGA_R_reg[7]_i_275_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \VGA_R_reg[7]_i_436_n_1\,
      DI(1) => \VGA_R_reg[7]_i_436_n_7\,
      DI(0) => \VGA_R_reg[7]_i_437_n_4\,
      O(3) => \VGA_R_reg[7]_i_275_n_4\,
      O(2) => \NLW_VGA_R_reg[7]_i_275_O_UNCONNECTED\(2),
      O(1) => \VGA_R_reg[7]_i_275_n_6\,
      O(0) => \VGA_R_reg[7]_i_275_n_7\,
      S(3) => \VGA_R[7]_i_438_n_0\,
      S(2) => \VGA_R[7]_i_439_n_0\,
      S(1) => \VGA_R[7]_i_440_n_0\,
      S(0) => \VGA_R[7]_i_441_n_0\
    );
\VGA_R_reg[7]_i_276\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[7]_i_276_n_0\,
      CO(2) => \VGA_R_reg[7]_i_276_n_1\,
      CO(1) => \VGA_R_reg[7]_i_276_n_2\,
      CO(0) => \VGA_R_reg[7]_i_276_n_3\,
      CYINIT => \VGA_R_reg[7]_i_436_n_1\,
      DI(3) => \VGA_R_reg[7]_i_437_n_5\,
      DI(2) => \VGA_R_reg[7]_i_437_n_6\,
      DI(1) => \VGA_R_reg[7]_i_437_n_7\,
      DI(0) => \VGA_R[7]_i_442_n_0\,
      O(3) => \VGA_R_reg[7]_i_276_n_4\,
      O(2) => \VGA_R_reg[7]_i_276_n_5\,
      O(1) => \VGA_R_reg[7]_i_276_n_6\,
      O(0) => \VGA_R_reg[7]_i_276_n_7\,
      S(3) => \VGA_R[7]_i_443_n_0\,
      S(2) => \VGA_R[7]_i_444_n_0\,
      S(1) => \VGA_R[7]_i_445_n_0\,
      S(0) => \VGA_R[7]_i_446_n_0\
    );
\VGA_R_reg[7]_i_30\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_79_n_0\,
      CO(3) => data2(7),
      CO(2) => \VGA_R_reg[7]_i_30_n_1\,
      CO(1) => \VGA_R_reg[7]_i_30_n_2\,
      CO(0) => \VGA_R_reg[7]_i_30_n_3\,
      CYINIT => '0',
      DI(3) => \VGA_R_reg[7]_i_80_n_0\,
      DI(2) => \VGA_R_reg[7]_i_80_n_6\,
      DI(1) => \VGA_R_reg[7]_i_80_n_7\,
      DI(0) => \VGA_R_reg[7]_i_81_n_4\,
      O(3) => \NLW_VGA_R_reg[7]_i_30_O_UNCONNECTED\(3),
      O(2) => \VGA_R_reg[7]_i_30_n_5\,
      O(1) => \VGA_R_reg[7]_i_30_n_6\,
      O(0) => \VGA_R_reg[7]_i_30_n_7\,
      S(3) => \VGA_R[7]_i_82_n_0\,
      S(2) => \VGA_R[7]_i_83_n_0\,
      S(1) => \VGA_R[7]_i_84_n_0\,
      S(0) => \VGA_R[7]_i_85_n_0\
    );
\VGA_R_reg[7]_i_365\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_460_n_0\,
      CO(3 downto 0) => \NLW_VGA_R_reg[7]_i_365_CO_UNCONNECTED\(3 downto 0),
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 1) => \NLW_VGA_R_reg[7]_i_365_O_UNCONNECTED\(3 downto 1),
      O(0) => \VGA_R_reg[7]_i_365_n_7\,
      S(3 downto 1) => B"000",
      S(0) => \VGA_R[7]_i_461_n_0\
    );
\VGA_R_reg[7]_i_367\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_368_n_0\,
      CO(3) => \VGA_R_reg[7]_i_367_n_0\,
      CO(2) => \VGA_R_reg[7]_i_367_n_1\,
      CO(1) => \VGA_R_reg[7]_i_367_n_2\,
      CO(0) => \VGA_R_reg[7]_i_367_n_3\,
      CYINIT => '0',
      DI(3) => \VGA_R_reg[7]_i_462_n_0\,
      DI(2) => \VGA_R_reg[7]_i_462_n_6\,
      DI(1) => \VGA_R_reg[7]_i_462_n_7\,
      DI(0) => \VGA_R_reg[7]_i_463_n_4\,
      O(3) => \NLW_VGA_R_reg[7]_i_367_O_UNCONNECTED\(3),
      O(2) => \VGA_R_reg[7]_i_367_n_5\,
      O(1) => \VGA_R_reg[7]_i_367_n_6\,
      O(0) => \VGA_R_reg[7]_i_367_n_7\,
      S(3) => \VGA_R[7]_i_464_n_0\,
      S(2) => \VGA_R[7]_i_465_n_0\,
      S(1) => \VGA_R[7]_i_466_n_0\,
      S(0) => \VGA_R[7]_i_467_n_0\
    );
\VGA_R_reg[7]_i_368\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[7]_i_368_n_0\,
      CO(2) => \VGA_R_reg[7]_i_368_n_1\,
      CO(1) => \VGA_R_reg[7]_i_368_n_2\,
      CO(0) => \VGA_R_reg[7]_i_368_n_3\,
      CYINIT => \VGA_R_reg[7]_i_462_n_0\,
      DI(3) => \VGA_R_reg[7]_i_463_n_5\,
      DI(2) => \VGA_R_reg[7]_i_463_n_6\,
      DI(1) => \VGA_R_reg[7]_i_462_n_0\,
      DI(0) => \VGA_R[7]_i_468_n_0\,
      O(3) => \VGA_R_reg[7]_i_368_n_4\,
      O(2) => \VGA_R_reg[7]_i_368_n_5\,
      O(1) => \VGA_R_reg[7]_i_368_n_6\,
      O(0) => \VGA_R_reg[7]_i_368_n_7\,
      S(3) => \VGA_R[7]_i_469_n_0\,
      S(2) => \VGA_R[7]_i_470_n_0\,
      S(1) => \VGA_R[7]_i_471_n_0\,
      S(0) => \VGA_R[7]_i_472_n_0\
    );
\VGA_R_reg[7]_i_378\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_474_n_0\,
      CO(3 downto 0) => \NLW_VGA_R_reg[7]_i_378_CO_UNCONNECTED\(3 downto 0),
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 1) => \NLW_VGA_R_reg[7]_i_378_O_UNCONNECTED\(3 downto 1),
      O(0) => \VGA_R_reg[7]_i_378_n_7\,
      S(3 downto 1) => B"000",
      S(0) => \VGA_R[7]_i_475_n_0\
    );
\VGA_R_reg[7]_i_40\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_109_n_0\,
      CO(3) => \NLW_VGA_R_reg[7]_i_40_CO_UNCONNECTED\(3),
      CO(2) => data6(7),
      CO(1) => \VGA_R_reg[7]_i_40_n_2\,
      CO(0) => \VGA_R_reg[7]_i_40_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \VGA_R_reg[7]_i_110_n_1\,
      DI(1) => \VGA_R_reg[7]_i_110_n_7\,
      DI(0) => \VGA_R_reg[7]_i_111_n_4\,
      O(3) => \VGA_R_reg[7]_i_40_n_4\,
      O(2) => \NLW_VGA_R_reg[7]_i_40_O_UNCONNECTED\(2),
      O(1) => \VGA_R_reg[7]_i_40_n_6\,
      O(0) => \VGA_R_reg[7]_i_40_n_7\,
      S(3) => \VGA_R[7]_i_112_n_0\,
      S(2) => \VGA_R[7]_i_113_n_0\,
      S(1) => \VGA_R[7]_i_114_n_0\,
      S(0) => \VGA_R[7]_i_115_n_0\
    );
\VGA_R_reg[7]_i_435\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_477_n_0\,
      CO(3) => \NLW_VGA_R_reg[7]_i_435_CO_UNCONNECTED\(3),
      CO(2) => \VGA_R_reg[7]_i_435_n_1\,
      CO(1) => \VGA_R_reg[7]_i_435_n_2\,
      CO(0) => \VGA_R_reg[7]_i_435_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \VGA_R_reg[7]_i_447_n_1\,
      DI(1) => \VGA_R_reg[7]_i_447_n_7\,
      DI(0) => \VGA_R_reg[7]_i_478_n_4\,
      O(3) => \VGA_R_reg[7]_i_435_n_4\,
      O(2) => \NLW_VGA_R_reg[7]_i_435_O_UNCONNECTED\(2),
      O(1) => \VGA_R_reg[7]_i_435_n_6\,
      O(0) => \VGA_R_reg[7]_i_435_n_7\,
      S(3) => \VGA_R[7]_i_479_n_0\,
      S(2) => \VGA_R[7]_i_480_n_0\,
      S(1) => \VGA_R[7]_i_481_n_0\,
      S(0) => \VGA_R[7]_i_482_n_0\
    );
\VGA_R_reg[7]_i_436\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_437_n_0\,
      CO(3) => \NLW_VGA_R_reg[7]_i_436_CO_UNCONNECTED\(3),
      CO(2) => \VGA_R_reg[7]_i_436_n_1\,
      CO(1) => \VGA_R_reg[7]_i_436_n_2\,
      CO(0) => \VGA_R_reg[7]_i_436_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \VGA_R_reg[6]_i_28_n_1\,
      DI(1) => \VGA_R_reg[6]_i_28_n_7\,
      DI(0) => \VGA_R_reg[7]_i_483_n_4\,
      O(3) => \VGA_R_reg[7]_i_436_n_4\,
      O(2) => \NLW_VGA_R_reg[7]_i_436_O_UNCONNECTED\(2),
      O(1) => \VGA_R_reg[7]_i_436_n_6\,
      O(0) => \VGA_R_reg[7]_i_436_n_7\,
      S(3) => \VGA_R[7]_i_484_n_0\,
      S(2) => \VGA_R[7]_i_485_n_0\,
      S(1) => \VGA_R[7]_i_486_n_0\,
      S(0) => \VGA_R[7]_i_487_n_0\
    );
\VGA_R_reg[7]_i_437\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[7]_i_437_n_0\,
      CO(2) => \VGA_R_reg[7]_i_437_n_1\,
      CO(1) => \VGA_R_reg[7]_i_437_n_2\,
      CO(0) => \VGA_R_reg[7]_i_437_n_3\,
      CYINIT => \VGA_R_reg[6]_i_28_n_1\,
      DI(3) => \VGA_R_reg[7]_i_483_n_5\,
      DI(2) => \VGA_R_reg[7]_i_483_n_6\,
      DI(1) => \VGA_R_reg[7]_i_483_n_7\,
      DI(0) => \VGA_R[7]_i_488_n_0\,
      O(3) => \VGA_R_reg[7]_i_437_n_4\,
      O(2) => \VGA_R_reg[7]_i_437_n_5\,
      O(1) => \VGA_R_reg[7]_i_437_n_6\,
      O(0) => \VGA_R_reg[7]_i_437_n_7\,
      S(3) => \VGA_R[7]_i_489_n_0\,
      S(2) => \VGA_R[7]_i_490_n_0\,
      S(1) => \VGA_R[7]_i_491_n_0\,
      S(0) => \VGA_R[7]_i_492_n_0\
    );
\VGA_R_reg[7]_i_447\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_478_n_0\,
      CO(3) => \NLW_VGA_R_reg[7]_i_447_CO_UNCONNECTED\(3),
      CO(2) => \VGA_R_reg[7]_i_447_n_1\,
      CO(1) => \VGA_R_reg[7]_i_447_n_2\,
      CO(0) => \VGA_R_reg[7]_i_447_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \VGA_R_reg[7]_i_494_n_0\,
      DI(1) => \VGA_R_reg[7]_i_494_n_6\,
      DI(0) => \VGA_R_reg[7]_i_494_n_7\,
      O(3) => \VGA_R_reg[7]_i_447_n_4\,
      O(2) => \NLW_VGA_R_reg[7]_i_447_O_UNCONNECTED\(2),
      O(1) => \VGA_R_reg[7]_i_447_n_6\,
      O(0) => \VGA_R_reg[7]_i_447_n_7\,
      S(3) => \VGA_R[7]_i_495_n_0\,
      S(2) => \VGA_R[7]_i_496_n_0\,
      S(1) => \VGA_R[7]_i_497_n_0\,
      S(0) => \VGA_R[7]_i_498_n_0\
    );
\VGA_R_reg[7]_i_460\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_512_n_0\,
      CO(3) => \VGA_R_reg[7]_i_460_n_0\,
      CO(2) => \VGA_R_reg[7]_i_460_n_1\,
      CO(1) => \VGA_R_reg[7]_i_460_n_2\,
      CO(0) => \VGA_R_reg[7]_i_460_n_3\,
      CYINIT => '0',
      DI(3) => \VGA_R_reg[7]_i_474_n_0\,
      DI(2) => \VGA_R_reg[7]_i_474_n_6\,
      DI(1) => \VGA_R_reg[7]_i_474_n_7\,
      DI(0) => \VGA_R_reg[7]_i_513_n_4\,
      O(3) => \NLW_VGA_R_reg[7]_i_460_O_UNCONNECTED\(3),
      O(2) => \VGA_R_reg[7]_i_460_n_5\,
      O(1) => \VGA_R_reg[7]_i_460_n_6\,
      O(0) => \VGA_R_reg[7]_i_460_n_7\,
      S(3) => \VGA_R[7]_i_514_n_0\,
      S(2) => \VGA_R[7]_i_515_n_0\,
      S(1) => \VGA_R[7]_i_516_n_0\,
      S(0) => \VGA_R[7]_i_517_n_0\
    );
\VGA_R_reg[7]_i_462\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_463_n_0\,
      CO(3) => \VGA_R_reg[7]_i_462_n_0\,
      CO(2) => \VGA_R_reg[7]_i_462_n_1\,
      CO(1) => \VGA_R_reg[7]_i_462_n_2\,
      CO(0) => \VGA_R_reg[7]_i_462_n_3\,
      CYINIT => '0',
      DI(3) => \VGA_R_reg[7]_i_460_n_0\,
      DI(2) => \VGA_R_reg[7]_i_460_n_6\,
      DI(1) => \VGA_R_reg[7]_i_460_n_7\,
      DI(0) => \VGA_R_reg[7]_i_512_n_4\,
      O(3) => \NLW_VGA_R_reg[7]_i_462_O_UNCONNECTED\(3),
      O(2) => \VGA_R_reg[7]_i_462_n_5\,
      O(1) => \VGA_R_reg[7]_i_462_n_6\,
      O(0) => \VGA_R_reg[7]_i_462_n_7\,
      S(3) => \VGA_R[7]_i_518_n_0\,
      S(2) => \VGA_R[7]_i_519_n_0\,
      S(1) => \VGA_R[7]_i_520_n_0\,
      S(0) => \VGA_R[7]_i_521_n_0\
    );
\VGA_R_reg[7]_i_463\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[7]_i_463_n_0\,
      CO(2) => \VGA_R_reg[7]_i_463_n_1\,
      CO(1) => \VGA_R_reg[7]_i_463_n_2\,
      CO(0) => \VGA_R_reg[7]_i_463_n_3\,
      CYINIT => \VGA_R_reg[7]_i_460_n_0\,
      DI(3) => \VGA_R_reg[7]_i_512_n_5\,
      DI(2) => \VGA_R_reg[7]_i_512_n_6\,
      DI(1) => \VGA_R_reg[7]_i_460_n_0\,
      DI(0) => \VGA_R[7]_i_522_n_0\,
      O(3) => \VGA_R_reg[7]_i_463_n_4\,
      O(2) => \VGA_R_reg[7]_i_463_n_5\,
      O(1) => \VGA_R_reg[7]_i_463_n_6\,
      O(0) => \VGA_R_reg[7]_i_463_n_7\,
      S(3) => \VGA_R[7]_i_523_n_0\,
      S(2) => \VGA_R[7]_i_524_n_0\,
      S(1) => \VGA_R[7]_i_525_n_0\,
      S(0) => \VGA_R[7]_i_526_n_0\
    );
\VGA_R_reg[7]_i_473\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_528_n_0\,
      CO(3 downto 0) => \NLW_VGA_R_reg[7]_i_473_CO_UNCONNECTED\(3 downto 0),
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 1) => \NLW_VGA_R_reg[7]_i_473_O_UNCONNECTED\(3 downto 1),
      O(0) => \VGA_R_reg[7]_i_473_n_7\,
      S(3 downto 1) => B"000",
      S(0) => \VGA_R[7]_i_529_n_0\
    );
\VGA_R_reg[7]_i_474\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_513_n_0\,
      CO(3) => \VGA_R_reg[7]_i_474_n_0\,
      CO(2) => \VGA_R_reg[7]_i_474_n_1\,
      CO(1) => \VGA_R_reg[7]_i_474_n_2\,
      CO(0) => \VGA_R_reg[7]_i_474_n_3\,
      CYINIT => '0',
      DI(3) => \VGA_R_reg[7]_i_528_n_0\,
      DI(2) => \VGA_R_reg[7]_i_528_n_6\,
      DI(1) => \VGA_R_reg[7]_i_528_n_7\,
      DI(0) => \VGA_R_reg[7]_i_530_n_4\,
      O(3) => \NLW_VGA_R_reg[7]_i_474_O_UNCONNECTED\(3),
      O(2) => \VGA_R_reg[7]_i_474_n_5\,
      O(1) => \VGA_R_reg[7]_i_474_n_6\,
      O(0) => \VGA_R_reg[7]_i_474_n_7\,
      S(3) => \VGA_R[7]_i_531_n_0\,
      S(2) => \VGA_R[7]_i_532_n_0\,
      S(1) => \VGA_R[7]_i_533_n_0\,
      S(0) => \VGA_R[7]_i_534_n_0\
    );
\VGA_R_reg[7]_i_477\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[7]_i_477_n_0\,
      CO(2) => \VGA_R_reg[7]_i_477_n_1\,
      CO(1) => \VGA_R_reg[7]_i_477_n_2\,
      CO(0) => \VGA_R_reg[7]_i_477_n_3\,
      CYINIT => \VGA_R_reg[7]_i_447_n_1\,
      DI(3) => \VGA_R_reg[7]_i_478_n_5\,
      DI(2) => \VGA_R_reg[7]_i_478_n_6\,
      DI(1) => \VGA_R_reg[7]_i_478_n_7\,
      DI(0) => \VGA_R[7]_i_535_n_0\,
      O(3) => \VGA_R_reg[7]_i_477_n_4\,
      O(2) => \VGA_R_reg[7]_i_477_n_5\,
      O(1) => \VGA_R_reg[7]_i_477_n_6\,
      O(0) => \VGA_R_reg[7]_i_477_n_7\,
      S(3) => \VGA_R[7]_i_536_n_0\,
      S(2) => \VGA_R[7]_i_537_n_0\,
      S(1) => \VGA_R[7]_i_538_n_0\,
      S(0) => \VGA_R[7]_i_539_n_0\
    );
\VGA_R_reg[7]_i_478\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[7]_i_478_n_0\,
      CO(2) => \VGA_R_reg[7]_i_478_n_1\,
      CO(1) => \VGA_R_reg[7]_i_478_n_2\,
      CO(0) => \VGA_R_reg[7]_i_478_n_3\,
      CYINIT => \VGA_R_reg[7]_i_494_n_0\,
      DI(3) => \VGA_R_reg[7]_i_540_n_4\,
      DI(2) => \VGA_R_reg[7]_i_540_n_5\,
      DI(1) => \VGA_R_reg[7]_i_540_n_6\,
      DI(0) => \VGA_R_reg[7]_i_540_n_7\,
      O(3) => \VGA_R_reg[7]_i_478_n_4\,
      O(2) => \VGA_R_reg[7]_i_478_n_5\,
      O(1) => \VGA_R_reg[7]_i_478_n_6\,
      O(0) => \VGA_R_reg[7]_i_478_n_7\,
      S(3) => \VGA_R[7]_i_541_n_0\,
      S(2) => \VGA_R[7]_i_542_n_0\,
      S(1) => \VGA_R[7]_i_543_n_0\,
      S(0) => \VGA_R[7]_i_544_n_0\
    );
\VGA_R_reg[7]_i_483\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[7]_i_483_n_0\,
      CO(2) => \VGA_R_reg[7]_i_483_n_1\,
      CO(1) => \VGA_R_reg[7]_i_483_n_2\,
      CO(0) => \VGA_R_reg[7]_i_483_n_3\,
      CYINIT => \VGA_R_reg[7]_i_435_n_1\,
      DI(3) => \VGA_R_reg[7]_i_477_n_5\,
      DI(2) => \VGA_R_reg[7]_i_477_n_6\,
      DI(1) => \VGA_R_reg[7]_i_477_n_7\,
      DI(0) => \VGA_R[7]_i_545_n_0\,
      O(3) => \VGA_R_reg[7]_i_483_n_4\,
      O(2) => \VGA_R_reg[7]_i_483_n_5\,
      O(1) => \VGA_R_reg[7]_i_483_n_6\,
      O(0) => \VGA_R_reg[7]_i_483_n_7\,
      S(3) => \VGA_R[7]_i_546_n_0\,
      S(2) => \VGA_R[7]_i_547_n_0\,
      S(1) => \VGA_R[7]_i_548_n_0\,
      S(0) => \VGA_R[7]_i_549_n_0\
    );
\VGA_R_reg[7]_i_493\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_494_n_0\,
      CO(3 downto 0) => \NLW_VGA_R_reg[7]_i_493_CO_UNCONNECTED\(3 downto 0),
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 1) => \NLW_VGA_R_reg[7]_i_493_O_UNCONNECTED\(3 downto 1),
      O(0) => \VGA_R_reg[7]_i_493_n_7\,
      S(3 downto 1) => B"000",
      S(0) => \VGA_R[7]_i_550_n_0\
    );
\VGA_R_reg[7]_i_494\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_540_n_0\,
      CO(3) => \VGA_R_reg[7]_i_494_n_0\,
      CO(2) => \VGA_R_reg[7]_i_494_n_1\,
      CO(1) => \VGA_R_reg[7]_i_494_n_2\,
      CO(0) => \VGA_R_reg[7]_i_494_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \VGA_R[7]_i_551_n_0\,
      DI(1) => \VGA_R_reg[7]_i_552_n_7\,
      DI(0) => '1',
      O(3) => \NLW_VGA_R_reg[7]_i_494_O_UNCONNECTED\(3),
      O(2) => \VGA_R_reg[7]_i_494_n_5\,
      O(1) => \VGA_R_reg[7]_i_494_n_6\,
      O(0) => \VGA_R_reg[7]_i_494_n_7\,
      S(3) => \VGA_R_reg[7]_i_552_n_1\,
      S(2) => \VGA_R[7]_i_553_n_0\,
      S(1) => \VGA_R[7]_i_554_n_0\,
      S(0) => \VGA_R[7]_i_555_n_0\
    );
\VGA_R_reg[7]_i_512\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[7]_i_512_n_0\,
      CO(2) => \VGA_R_reg[7]_i_512_n_1\,
      CO(1) => \VGA_R_reg[7]_i_512_n_2\,
      CO(0) => \VGA_R_reg[7]_i_512_n_3\,
      CYINIT => \VGA_R_reg[7]_i_474_n_0\,
      DI(3) => \VGA_R_reg[7]_i_513_n_5\,
      DI(2) => \VGA_R_reg[7]_i_513_n_6\,
      DI(1) => \VGA_R_reg[7]_i_474_n_0\,
      DI(0) => \VGA_R[7]_i_561_n_0\,
      O(3) => \VGA_R_reg[7]_i_512_n_4\,
      O(2) => \VGA_R_reg[7]_i_512_n_5\,
      O(1) => \VGA_R_reg[7]_i_512_n_6\,
      O(0) => \VGA_R_reg[7]_i_512_n_7\,
      S(3) => \VGA_R[7]_i_562_n_0\,
      S(2) => \VGA_R[7]_i_563_n_0\,
      S(1) => \VGA_R[7]_i_564_n_0\,
      S(0) => \VGA_R[7]_i_565_n_0\
    );
\VGA_R_reg[7]_i_513\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[7]_i_513_n_0\,
      CO(2) => \VGA_R_reg[7]_i_513_n_1\,
      CO(1) => \VGA_R_reg[7]_i_513_n_2\,
      CO(0) => \VGA_R_reg[7]_i_513_n_3\,
      CYINIT => \VGA_R_reg[7]_i_528_n_0\,
      DI(3) => \VGA_R_reg[7]_i_530_n_5\,
      DI(2) => \VGA_R_reg[7]_i_530_n_6\,
      DI(1) => \VGA_R_reg[7]_i_528_n_0\,
      DI(0) => \VGA_R[7]_i_566_n_0\,
      O(3) => \VGA_R_reg[7]_i_513_n_4\,
      O(2) => \VGA_R_reg[7]_i_513_n_5\,
      O(1) => \VGA_R_reg[7]_i_513_n_6\,
      O(0) => \VGA_R_reg[7]_i_513_n_7\,
      S(3) => \VGA_R[7]_i_567_n_0\,
      S(2) => \VGA_R[7]_i_568_n_0\,
      S(1) => \VGA_R[7]_i_569_n_0\,
      S(0) => \VGA_R[7]_i_570_n_0\
    );
\VGA_R_reg[7]_i_527\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_572_n_0\,
      CO(3 downto 0) => \NLW_VGA_R_reg[7]_i_527_CO_UNCONNECTED\(3 downto 0),
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 1) => \NLW_VGA_R_reg[7]_i_527_O_UNCONNECTED\(3 downto 1),
      O(0) => \VGA_R_reg[7]_i_527_n_7\,
      S(3 downto 1) => B"000",
      S(0) => \VGA_R[7]_i_573_n_0\
    );
\VGA_R_reg[7]_i_528\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_530_n_0\,
      CO(3) => \VGA_R_reg[7]_i_528_n_0\,
      CO(2) => \VGA_R_reg[7]_i_528_n_1\,
      CO(1) => \VGA_R_reg[7]_i_528_n_2\,
      CO(0) => \VGA_R_reg[7]_i_528_n_3\,
      CYINIT => '0',
      DI(3) => \VGA_R_reg[7]_i_572_n_0\,
      DI(2) => \VGA_R_reg[7]_i_572_n_6\,
      DI(1) => \VGA_R_reg[7]_i_572_n_7\,
      DI(0) => \VGA_R_reg[7]_i_574_n_4\,
      O(3) => \NLW_VGA_R_reg[7]_i_528_O_UNCONNECTED\(3),
      O(2) => \VGA_R_reg[7]_i_528_n_5\,
      O(1) => \VGA_R_reg[7]_i_528_n_6\,
      O(0) => \VGA_R_reg[7]_i_528_n_7\,
      S(3) => \VGA_R[7]_i_575_n_0\,
      S(2) => \VGA_R[7]_i_576_n_0\,
      S(1) => \VGA_R[7]_i_577_n_0\,
      S(0) => \VGA_R[7]_i_578_n_0\
    );
\VGA_R_reg[7]_i_530\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[7]_i_530_n_0\,
      CO(2) => \VGA_R_reg[7]_i_530_n_1\,
      CO(1) => \VGA_R_reg[7]_i_530_n_2\,
      CO(0) => \VGA_R_reg[7]_i_530_n_3\,
      CYINIT => \VGA_R_reg[7]_i_572_n_0\,
      DI(3) => \VGA_R_reg[7]_i_574_n_5\,
      DI(2) => \VGA_R_reg[7]_i_574_n_6\,
      DI(1) => \VGA_R_reg[7]_i_572_n_0\,
      DI(0) => \VGA_R[7]_i_579_n_0\,
      O(3) => \VGA_R_reg[7]_i_530_n_4\,
      O(2) => \VGA_R_reg[7]_i_530_n_5\,
      O(1) => \VGA_R_reg[7]_i_530_n_6\,
      O(0) => \VGA_R_reg[7]_i_530_n_7\,
      S(3) => \VGA_R[7]_i_580_n_0\,
      S(2) => \VGA_R[7]_i_581_n_0\,
      S(1) => \VGA_R[7]_i_582_n_0\,
      S(0) => \VGA_R[7]_i_583_n_0\
    );
\VGA_R_reg[7]_i_540\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[7]_i_540_n_0\,
      CO(2) => \VGA_R_reg[7]_i_540_n_1\,
      CO(1) => \VGA_R_reg[7]_i_540_n_2\,
      CO(0) => \VGA_R_reg[7]_i_540_n_3\,
      CYINIT => '0',
      DI(3) => '1',
      DI(2) => \VGA_R_reg[7]_i_584_n_6\,
      DI(1) => \VGA_R[7]_i_585_n_0\,
      DI(0) => '0',
      O(3) => \VGA_R_reg[7]_i_540_n_4\,
      O(2) => \VGA_R_reg[7]_i_540_n_5\,
      O(1) => \VGA_R_reg[7]_i_540_n_6\,
      O(0) => \VGA_R_reg[7]_i_540_n_7\,
      S(3) => \VGA_R[7]_i_586_n_0\,
      S(2) => \VGA_R[7]_i_587_n_0\,
      S(1) => \VGA_R[7]_i_588_n_0\,
      S(0) => \pattern_b1__0_n_88\
    );
\VGA_R_reg[7]_i_552\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_584_n_0\,
      CO(3) => \NLW_VGA_R_reg[7]_i_552_CO_UNCONNECTED\(3),
      CO(2) => \VGA_R_reg[7]_i_552_n_1\,
      CO(1) => \NLW_VGA_R_reg[7]_i_552_CO_UNCONNECTED\(1),
      CO(0) => \VGA_R_reg[7]_i_552_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \VGA_R[7]_i_589_n_0\,
      DI(0) => '1',
      O(3 downto 2) => \NLW_VGA_R_reg[7]_i_552_O_UNCONNECTED\(3 downto 2),
      O(1) => \VGA_R_reg[7]_i_552_n_6\,
      O(0) => \VGA_R_reg[7]_i_552_n_7\,
      S(3 downto 2) => B"01",
      S(1) => \VGA_R[7]_i_590_n_0\,
      S(0) => \VGA_R[7]_i_591_n_0\
    );
\VGA_R_reg[7]_i_571\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_593_n_0\,
      CO(3 downto 0) => \NLW_VGA_R_reg[7]_i_571_CO_UNCONNECTED\(3 downto 0),
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 1) => \NLW_VGA_R_reg[7]_i_571_O_UNCONNECTED\(3 downto 1),
      O(0) => \VGA_R_reg[7]_i_571_n_7\,
      S(3 downto 1) => B"000",
      S(0) => \VGA_R[7]_i_594_n_0\
    );
\VGA_R_reg[7]_i_572\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_574_n_0\,
      CO(3) => \VGA_R_reg[7]_i_572_n_0\,
      CO(2) => \VGA_R_reg[7]_i_572_n_1\,
      CO(1) => \VGA_R_reg[7]_i_572_n_2\,
      CO(0) => \VGA_R_reg[7]_i_572_n_3\,
      CYINIT => '0',
      DI(3) => \VGA_R_reg[7]_i_593_n_0\,
      DI(2) => \VGA_R_reg[7]_i_593_n_6\,
      DI(1) => \VGA_R_reg[7]_i_593_n_7\,
      DI(0) => \VGA_R_reg[7]_i_595_n_4\,
      O(3) => \NLW_VGA_R_reg[7]_i_572_O_UNCONNECTED\(3),
      O(2) => \VGA_R_reg[7]_i_572_n_5\,
      O(1) => \VGA_R_reg[7]_i_572_n_6\,
      O(0) => \VGA_R_reg[7]_i_572_n_7\,
      S(3) => \VGA_R[7]_i_596_n_0\,
      S(2) => \VGA_R[7]_i_597_n_0\,
      S(1) => \VGA_R[7]_i_598_n_0\,
      S(0) => \VGA_R[7]_i_599_n_0\
    );
\VGA_R_reg[7]_i_574\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[7]_i_574_n_0\,
      CO(2) => \VGA_R_reg[7]_i_574_n_1\,
      CO(1) => \VGA_R_reg[7]_i_574_n_2\,
      CO(0) => \VGA_R_reg[7]_i_574_n_3\,
      CYINIT => \VGA_R_reg[7]_i_593_n_0\,
      DI(3) => \VGA_R_reg[7]_i_595_n_5\,
      DI(2) => \VGA_R_reg[7]_i_595_n_6\,
      DI(1) => \VGA_R_reg[7]_i_593_n_0\,
      DI(0) => \VGA_R[7]_i_600_n_0\,
      O(3) => \VGA_R_reg[7]_i_574_n_4\,
      O(2) => \VGA_R_reg[7]_i_574_n_5\,
      O(1) => \VGA_R_reg[7]_i_574_n_6\,
      O(0) => \VGA_R_reg[7]_i_574_n_7\,
      S(3) => \VGA_R[7]_i_601_n_0\,
      S(2) => \VGA_R[7]_i_602_n_0\,
      S(1) => \VGA_R[7]_i_603_n_0\,
      S(0) => \VGA_R[7]_i_604_n_0\
    );
\VGA_R_reg[7]_i_584\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[7]_i_584_n_0\,
      CO(2) => \VGA_R_reg[7]_i_584_n_1\,
      CO(1) => \VGA_R_reg[7]_i_584_n_2\,
      CO(0) => \VGA_R_reg[7]_i_584_n_3\,
      CYINIT => '0',
      DI(3) => '1',
      DI(2) => \VGA_R_reg[7]_i_605_n_6\,
      DI(1) => \VGA_R[7]_i_606_n_0\,
      DI(0) => '0',
      O(3) => \VGA_R_reg[7]_i_584_n_4\,
      O(2) => \VGA_R_reg[7]_i_584_n_5\,
      O(1) => \VGA_R_reg[7]_i_584_n_6\,
      O(0) => \VGA_R_reg[7]_i_584_n_7\,
      S(3) => \VGA_R_reg[7]_i_605_n_1\,
      S(2) => \VGA_R[7]_i_607_n_0\,
      S(1) => \VGA_R[7]_i_608_n_0\,
      S(0) => \pattern_b1__0_n_87\
    );
\VGA_R_reg[7]_i_592\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_609_n_0\,
      CO(3 downto 1) => \NLW_VGA_R_reg[7]_i_592_CO_UNCONNECTED\(3 downto 1),
      CO(0) => \VGA_R_reg[7]_i_592_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 2) => \NLW_VGA_R_reg[7]_i_592_O_UNCONNECTED\(3 downto 2),
      O(1) => \VGA_R_reg[7]_i_592_n_6\,
      O(0) => \NLW_VGA_R_reg[7]_i_592_O_UNCONNECTED\(0),
      S(3 downto 2) => B"00",
      S(1) => \VGA_R[7]_i_610_n_0\,
      S(0) => \VGA_R[7]_i_611_n_0\
    );
\VGA_R_reg[7]_i_593\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_595_n_0\,
      CO(3) => \VGA_R_reg[7]_i_593_n_0\,
      CO(2) => \VGA_R_reg[7]_i_593_n_1\,
      CO(1) => \VGA_R_reg[7]_i_593_n_2\,
      CO(0) => \VGA_R_reg[7]_i_593_n_3\,
      CYINIT => '0',
      DI(3) => \VGA_R_reg[7]_i_592_n_3\,
      DI(2) => \VGA_R_reg[7]_i_609_n_5\,
      DI(1) => \VGA_R_reg[7]_i_609_n_6\,
      DI(0) => \VGA_R[7]_i_612_n_0\,
      O(3) => \NLW_VGA_R_reg[7]_i_593_O_UNCONNECTED\(3),
      O(2) => \VGA_R_reg[7]_i_593_n_5\,
      O(1) => \VGA_R_reg[7]_i_593_n_6\,
      O(0) => \VGA_R_reg[7]_i_593_n_7\,
      S(3) => \VGA_R[7]_i_613_n_0\,
      S(2) => \VGA_R[7]_i_614_n_0\,
      S(1) => \VGA_R[7]_i_615_n_0\,
      S(0) => \VGA_R[7]_i_616_n_0\
    );
\VGA_R_reg[7]_i_595\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[7]_i_595_n_0\,
      CO(2) => \VGA_R_reg[7]_i_595_n_1\,
      CO(1) => \VGA_R_reg[7]_i_595_n_2\,
      CO(0) => \VGA_R_reg[7]_i_595_n_3\,
      CYINIT => \VGA_R_reg[7]_i_592_n_3\,
      DI(3) => \VGA_R[7]_i_617_n_0\,
      DI(2) => \VGA_R[7]_i_618_n_0\,
      DI(1) => \VGA_R_reg[7]_i_592_n_3\,
      DI(0) => \VGA_R[7]_i_619_n_0\,
      O(3) => \VGA_R_reg[7]_i_595_n_4\,
      O(2) => \VGA_R_reg[7]_i_595_n_5\,
      O(1) => \VGA_R_reg[7]_i_595_n_6\,
      O(0) => \VGA_R_reg[7]_i_595_n_7\,
      S(3) => \VGA_R[7]_i_620_n_0\,
      S(2) => \VGA_R[7]_i_621_n_0\,
      S(1) => \VGA_R[7]_i_622_n_0\,
      S(0) => \VGA_R[7]_i_623_n_0\
    );
\VGA_R_reg[7]_i_605\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \NLW_VGA_R_reg[7]_i_605_CO_UNCONNECTED\(3),
      CO(2) => \VGA_R_reg[7]_i_605_n_1\,
      CO(1) => \NLW_VGA_R_reg[7]_i_605_CO_UNCONNECTED\(1),
      CO(0) => \VGA_R_reg[7]_i_605_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \VGA_R[7]_i_624_n_0\,
      DI(0) => '0',
      O(3 downto 2) => \NLW_VGA_R_reg[7]_i_605_O_UNCONNECTED\(3 downto 2),
      O(1) => \VGA_R_reg[7]_i_605_n_6\,
      O(0) => \NLW_VGA_R_reg[7]_i_605_O_UNCONNECTED\(0),
      S(3 downto 2) => B"01",
      S(1) => \VGA_R[7]_i_625_n_0\,
      S(0) => '0'
    );
\VGA_R_reg[7]_i_609\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[7]_i_609_n_0\,
      CO(2) => \VGA_R_reg[7]_i_609_n_1\,
      CO(1) => \VGA_R_reg[7]_i_609_n_2\,
      CO(0) => \VGA_R_reg[7]_i_609_n_3\,
      CYINIT => HWIDTH(4),
      DI(3) => \VGA_R[7]_i_626_n_0\,
      DI(2) => \VGA_R[7]_i_627_n_0\,
      DI(1) => \VGA_R[7]_i_628_n_0\,
      DI(0) => \VGA_R[7]_i_629_n_0\,
      O(3) => \VGA_R_reg[7]_i_609_n_4\,
      O(2) => \VGA_R_reg[7]_i_609_n_5\,
      O(1) => \VGA_R_reg[7]_i_609_n_6\,
      O(0) => \NLW_VGA_R_reg[7]_i_609_O_UNCONNECTED\(0),
      S(3) => '0',
      S(2) => \VGA_R[7]_i_630_n_0\,
      S(1) => \VGA_R[7]_i_631_n_0\,
      S(0) => \VGA_R[7]_i_632_n_0\
    );
\VGA_R_reg[7]_i_79\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[7]_i_79_n_0\,
      CO(2) => \VGA_R_reg[7]_i_79_n_1\,
      CO(1) => \VGA_R_reg[7]_i_79_n_2\,
      CO(0) => \VGA_R_reg[7]_i_79_n_3\,
      CYINIT => \VGA_R_reg[7]_i_80_n_0\,
      DI(3) => \VGA_R_reg[7]_i_81_n_5\,
      DI(2) => \VGA_R_reg[7]_i_81_n_6\,
      DI(1) => \VGA_R_reg[7]_i_80_n_0\,
      DI(0) => \VGA_R[7]_i_176_n_0\,
      O(3) => \VGA_R_reg[7]_i_79_n_4\,
      O(2) => \VGA_R_reg[7]_i_79_n_5\,
      O(1) => \VGA_R_reg[7]_i_79_n_6\,
      O(0) => \VGA_R_reg[7]_i_79_n_7\,
      S(3) => \VGA_R[7]_i_177_n_0\,
      S(2) => \VGA_R[7]_i_178_n_0\,
      S(1) => \VGA_R[7]_i_179_n_0\,
      S(0) => \VGA_R[7]_i_180_n_0\
    );
\VGA_R_reg[7]_i_80\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_81_n_0\,
      CO(3) => \VGA_R_reg[7]_i_80_n_0\,
      CO(2) => \VGA_R_reg[7]_i_80_n_1\,
      CO(1) => \VGA_R_reg[7]_i_80_n_2\,
      CO(0) => \VGA_R_reg[7]_i_80_n_3\,
      CYINIT => '0',
      DI(3) => \VGA_R_reg[7]_i_181_n_0\,
      DI(2) => \VGA_R_reg[7]_i_181_n_6\,
      DI(1) => \VGA_R_reg[7]_i_181_n_7\,
      DI(0) => \VGA_R_reg[7]_i_182_n_4\,
      O(3) => \NLW_VGA_R_reg[7]_i_80_O_UNCONNECTED\(3),
      O(2) => \VGA_R_reg[7]_i_80_n_5\,
      O(1) => \VGA_R_reg[7]_i_80_n_6\,
      O(0) => \VGA_R_reg[7]_i_80_n_7\,
      S(3) => \VGA_R[7]_i_183_n_0\,
      S(2) => \VGA_R[7]_i_184_n_0\,
      S(1) => \VGA_R[7]_i_185_n_0\,
      S(0) => \VGA_R[7]_i_186_n_0\
    );
\VGA_R_reg[7]_i_81\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \VGA_R_reg[7]_i_81_n_0\,
      CO(2) => \VGA_R_reg[7]_i_81_n_1\,
      CO(1) => \VGA_R_reg[7]_i_81_n_2\,
      CO(0) => \VGA_R_reg[7]_i_81_n_3\,
      CYINIT => \VGA_R_reg[7]_i_181_n_0\,
      DI(3) => \VGA_R_reg[7]_i_182_n_5\,
      DI(2) => \VGA_R_reg[7]_i_182_n_6\,
      DI(1) => \VGA_R_reg[7]_i_181_n_0\,
      DI(0) => \VGA_R[7]_i_187_n_0\,
      O(3) => \VGA_R_reg[7]_i_81_n_4\,
      O(2) => \VGA_R_reg[7]_i_81_n_5\,
      O(1) => \VGA_R_reg[7]_i_81_n_6\,
      O(0) => \VGA_R_reg[7]_i_81_n_7\,
      S(3) => \VGA_R[7]_i_188_n_0\,
      S(2) => \VGA_R[7]_i_189_n_0\,
      S(1) => \VGA_R[7]_i_190_n_0\,
      S(0) => \VGA_R[7]_i_191_n_0\
    );
\VGA_R_reg[7]_i_92\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_203_n_0\,
      CO(3) => \VGA_R_reg[7]_i_92_n_0\,
      CO(2) => \VGA_R_reg[7]_i_92_n_1\,
      CO(1) => \VGA_R_reg[7]_i_92_n_2\,
      CO(0) => \VGA_R_reg[7]_i_92_n_3\,
      CYINIT => '0',
      DI(3) => \VGA_R_reg[7]_i_93_n_3\,
      DI(2) => \VGA_R_reg[7]_i_204_n_5\,
      DI(1) => \VGA_R_reg[7]_i_204_n_6\,
      DI(0) => \VGA_R[7]_i_205_n_0\,
      O(3) => \NLW_VGA_R_reg[7]_i_92_O_UNCONNECTED\(3),
      O(2) => \VGA_R_reg[7]_i_92_n_5\,
      O(1) => \VGA_R_reg[7]_i_92_n_6\,
      O(0) => \VGA_R_reg[7]_i_92_n_7\,
      S(3) => \VGA_R[7]_i_206_n_0\,
      S(2) => \VGA_R[7]_i_207_n_0\,
      S(1) => \VGA_R[7]_i_208_n_0\,
      S(0) => \VGA_R[7]_i_209_n_0\
    );
\VGA_R_reg[7]_i_93\: unisim.vcomponents.CARRY4
     port map (
      CI => \VGA_R_reg[7]_i_204_n_0\,
      CO(3 downto 1) => \NLW_VGA_R_reg[7]_i_93_CO_UNCONNECTED\(3 downto 1),
      CO(0) => \VGA_R_reg[7]_i_93_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => \NLW_VGA_R_reg[7]_i_93_O_UNCONNECTED\(3 downto 0),
      S(3 downto 1) => B"000",
      S(0) => \VGA_R[7]_i_210_n_0\
    );
pattern_b1: unisim.vcomponents.DSP48E1
    generic map(
      ACASCREG => 0,
      ADREG => 1,
      ALUMODEREG => 0,
      AREG => 0,
      AUTORESET_PATDET => "NO_RESET",
      A_INPUT => "DIRECT",
      BCASCREG => 0,
      BREG => 0,
      B_INPUT => "DIRECT",
      CARRYINREG => 0,
      CARRYINSELREG => 0,
      CREG => 1,
      DREG => 1,
      INMODEREG => 0,
      MASK => X"3FFFFFFFFFFF",
      MREG => 0,
      OPMODEREG => 0,
      PATTERN => X"000000000000",
      PREG => 0,
      SEL_MASK => "MASK",
      SEL_PATTERN => "PATTERN",
      USE_DPORT => false,
      USE_MULT => "MULTIPLY",
      USE_PATTERN_DETECT => "NO_PATDET",
      USE_SIMD => "ONE48"
    )
        port map (
      A(29 downto 11) => B"0000000000000000000",
      A(10 downto 0) => p_1_in(10 downto 0),
      ACIN(29 downto 0) => B"000000000000000000000000000000",
      ACOUT(29 downto 0) => NLW_pattern_b1_ACOUT_UNCONNECTED(29 downto 0),
      ALUMODE(3 downto 0) => B"0000",
      B(17 downto 0) => B"000000000011111111",
      BCIN(17 downto 0) => B"000000000000000000",
      BCOUT(17 downto 0) => NLW_pattern_b1_BCOUT_UNCONNECTED(17 downto 0),
      C(47 downto 0) => B"111111111111111111111111111111111111111111111111",
      CARRYCASCIN => '0',
      CARRYCASCOUT => NLW_pattern_b1_CARRYCASCOUT_UNCONNECTED,
      CARRYIN => '0',
      CARRYINSEL(2 downto 0) => B"000",
      CARRYOUT(3 downto 0) => NLW_pattern_b1_CARRYOUT_UNCONNECTED(3 downto 0),
      CEA1 => '0',
      CEA2 => '0',
      CEAD => '0',
      CEALUMODE => '0',
      CEB1 => '0',
      CEB2 => '0',
      CEC => '0',
      CECARRYIN => '0',
      CECTRL => '0',
      CED => '0',
      CEINMODE => '0',
      CEM => '0',
      CEP => '0',
      CLK => '0',
      D(24 downto 0) => B"0000000000000000000000000",
      INMODE(4 downto 0) => B"00000",
      MULTSIGNIN => '0',
      MULTSIGNOUT => NLW_pattern_b1_MULTSIGNOUT_UNCONNECTED,
      OPMODE(6 downto 0) => B"0000101",
      OVERFLOW => NLW_pattern_b1_OVERFLOW_UNCONNECTED,
      P(47 downto 19) => NLW_pattern_b1_P_UNCONNECTED(47 downto 19),
      P(18) => pattern_b1_n_87,
      P(17) => pattern_b1_n_88,
      P(16) => pattern_b1_n_89,
      P(15) => pattern_b1_n_90,
      P(14) => pattern_b1_n_91,
      P(13) => pattern_b1_n_92,
      P(12) => pattern_b1_n_93,
      P(11) => pattern_b1_n_94,
      P(10) => pattern_b1_n_95,
      P(9) => pattern_b1_n_96,
      P(8) => pattern_b1_n_97,
      P(7) => pattern_b1_n_98,
      P(6) => pattern_b1_n_99,
      P(5) => pattern_b1_n_100,
      P(4) => pattern_b1_n_101,
      P(3) => pattern_b1_n_102,
      P(2) => pattern_b1_n_103,
      P(1) => pattern_b1_n_104,
      P(0) => pattern_b1_n_105,
      PATTERNBDETECT => NLW_pattern_b1_PATTERNBDETECT_UNCONNECTED,
      PATTERNDETECT => NLW_pattern_b1_PATTERNDETECT_UNCONNECTED,
      PCIN(47 downto 0) => B"000000000000000000000000000000000000000000000000",
      PCOUT(47 downto 0) => NLW_pattern_b1_PCOUT_UNCONNECTED(47 downto 0),
      RSTA => '0',
      RSTALLCARRYIN => '0',
      RSTALUMODE => '0',
      RSTB => '0',
      RSTC => '0',
      RSTCTRL => '0',
      RSTD => '0',
      RSTINMODE => '0',
      RSTM => '0',
      RSTP => '0',
      UNDERFLOW => NLW_pattern_b1_UNDERFLOW_UNCONNECTED
    );
\pattern_b1__0\: unisim.vcomponents.DSP48E1
    generic map(
      ACASCREG => 0,
      ADREG => 1,
      ALUMODEREG => 0,
      AREG => 0,
      AUTORESET_PATDET => "NO_RESET",
      A_INPUT => "DIRECT",
      BCASCREG => 0,
      BREG => 0,
      B_INPUT => "DIRECT",
      CARRYINREG => 0,
      CARRYINSELREG => 0,
      CREG => 1,
      DREG => 1,
      INMODEREG => 0,
      MASK => X"3FFFFFFFFFFF",
      MREG => 0,
      OPMODEREG => 0,
      PATTERN => X"000000000000",
      PREG => 0,
      SEL_MASK => "MASK",
      SEL_PATTERN => "PATTERN",
      USE_DPORT => false,
      USE_MULT => "MULTIPLY",
      USE_PATTERN_DETECT => "NO_PATDET",
      USE_SIMD => "ONE48"
    )
        port map (
      A(29 downto 11) => B"0000000000000000000",
      A(10 downto 6) => A(10 downto 6),
      A(5 downto 0) => disp_y(5 downto 0),
      ACIN(29 downto 0) => B"000000000000000000000000000000",
      ACOUT(29 downto 0) => \NLW_pattern_b1__0_ACOUT_UNCONNECTED\(29 downto 0),
      ALUMODE(3 downto 0) => B"0000",
      B(17 downto 0) => B"000000000011111111",
      BCIN(17 downto 0) => B"000000000000000000",
      BCOUT(17 downto 0) => \NLW_pattern_b1__0_BCOUT_UNCONNECTED\(17 downto 0),
      C(47 downto 0) => B"111111111111111111111111111111111111111111111111",
      CARRYCASCIN => '0',
      CARRYCASCOUT => \NLW_pattern_b1__0_CARRYCASCOUT_UNCONNECTED\,
      CARRYIN => '0',
      CARRYINSEL(2 downto 0) => B"000",
      CARRYOUT(3 downto 0) => \NLW_pattern_b1__0_CARRYOUT_UNCONNECTED\(3 downto 0),
      CEA1 => '0',
      CEA2 => '0',
      CEAD => '0',
      CEALUMODE => '0',
      CEB1 => '0',
      CEB2 => '0',
      CEC => '0',
      CECARRYIN => '0',
      CECTRL => '0',
      CED => '0',
      CEINMODE => '0',
      CEM => '0',
      CEP => '0',
      CLK => '0',
      D(24 downto 0) => B"0000000000000000000000000",
      INMODE(4 downto 0) => B"00000",
      MULTSIGNIN => '0',
      MULTSIGNOUT => \NLW_pattern_b1__0_MULTSIGNOUT_UNCONNECTED\,
      OPMODE(6 downto 0) => B"0000101",
      OVERFLOW => \NLW_pattern_b1__0_OVERFLOW_UNCONNECTED\,
      P(47 downto 19) => \NLW_pattern_b1__0_P_UNCONNECTED\(47 downto 19),
      P(18) => \pattern_b1__0_n_87\,
      P(17) => \pattern_b1__0_n_88\,
      P(16) => \pattern_b1__0_n_89\,
      P(15) => \pattern_b1__0_n_90\,
      P(14) => \pattern_b1__0_n_91\,
      P(13) => \pattern_b1__0_n_92\,
      P(12) => \pattern_b1__0_n_93\,
      P(11) => \pattern_b1__0_n_94\,
      P(10) => \pattern_b1__0_n_95\,
      P(9) => \pattern_b1__0_n_96\,
      P(8) => \pattern_b1__0_n_97\,
      P(7) => \pattern_b1__0_n_98\,
      P(6) => \pattern_b1__0_n_99\,
      P(5) => \pattern_b1__0_n_100\,
      P(4) => \pattern_b1__0_n_101\,
      P(3) => \pattern_b1__0_n_102\,
      P(2) => \pattern_b1__0_n_103\,
      P(1) => \pattern_b1__0_n_104\,
      P(0) => \pattern_b1__0_n_105\,
      PATTERNBDETECT => \NLW_pattern_b1__0_PATTERNBDETECT_UNCONNECTED\,
      PATTERNDETECT => \NLW_pattern_b1__0_PATTERNDETECT_UNCONNECTED\,
      PCIN(47 downto 0) => B"000000000000000000000000000000000000000000000000",
      PCOUT(47 downto 0) => \NLW_pattern_b1__0_PCOUT_UNCONNECTED\(47 downto 0),
      RSTA => '0',
      RSTALLCARRYIN => '0',
      RSTALUMODE => '0',
      RSTB => '0',
      RSTC => '0',
      RSTCTRL => '0',
      RSTD => '0',
      RSTINMODE => '0',
      RSTM => '0',
      RSTP => '0',
      UNDERFLOW => \NLW_pattern_b1__0_UNDERFLOW_UNCONNECTED\
    );
\pattern_b1__0_i_13\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => timing_sel(1),
      I1 => timing_sel(0),
      O => \pattern_b1__0_i_13_n_0\
    );
pattern_b1_i_17: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => pattern_b1_i_18_n_6,
      O => disp_enable2(1)
    );
pattern_b1_i_18: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => pattern_b1_i_18_n_0,
      CO(2) => pattern_b1_i_18_n_1,
      CO(1) => pattern_b1_i_18_n_2,
      CO(0) => pattern_b1_i_18_n_3,
      CYINIT => '0',
      DI(3) => pattern_b1_i_25_n_0,
      DI(2) => pattern_b1_i_26_n_0,
      DI(1) => pattern_b1_i_27_n_0,
      DI(0) => '0',
      O(3) => pattern_b1_i_18_n_4,
      O(2) => pattern_b1_i_18_n_5,
      O(1) => pattern_b1_i_18_n_6,
      O(0) => NLW_pattern_b1_i_18_O_UNCONNECTED(0),
      S(3) => pattern_b1_i_28_n_0,
      S(2) => pattern_b1_i_29_n_0,
      S(1) => pattern_b1_i_30_n_0,
      S(0) => '0'
    );
pattern_b1_i_23: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => pattern_b1_i_23_n_0,
      CO(2) => NLW_pattern_b1_i_23_CO_UNCONNECTED(2),
      CO(1) => pattern_b1_i_23_n_2,
      CO(0) => pattern_b1_i_23_n_3,
      CYINIT => HBACK(3),
      DI(3) => '0',
      DI(2) => pattern_b1_i_32_n_0,
      DI(1) => '1',
      DI(0) => pattern_b1_i_33_n_0,
      O(3) => NLW_pattern_b1_i_23_O_UNCONNECTED(3),
      O(2) => pattern_b1_i_23_n_5,
      O(1) => pattern_b1_i_23_n_6,
      O(0) => pattern_b1_i_23_n_7,
      S(3 downto 2) => B"10",
      S(1) => pattern_b1_i_34_n_0,
      S(0) => pattern_b1_i_35_n_0
    );
pattern_b1_i_24: unisim.vcomponents.CARRY4
     port map (
      CI => pattern_b1_i_18_n_0,
      CO(3 downto 1) => NLW_pattern_b1_i_24_CO_UNCONNECTED(3 downto 1),
      CO(0) => pattern_b1_i_24_n_3,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => NLW_pattern_b1_i_24_O_UNCONNECTED(3 downto 0),
      S(3 downto 0) => B"0001"
    );
pattern_b1_i_25: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => timing_sel(1),
      I1 => timing_sel(0),
      O => pattern_b1_i_25_n_0
    );
pattern_b1_i_26: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => timing_sel(1),
      I1 => timing_sel(0),
      O => pattern_b1_i_26_n_0
    );
pattern_b1_i_27: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => timing_sel(1),
      I1 => timing_sel(0),
      O => pattern_b1_i_27_n_0
    );
pattern_b1_i_28: unisim.vcomponents.LUT3
    generic map(
      INIT => X"9A"
    )
        port map (
      I0 => \pattern_b1__0_i_13_n_0\,
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      O => pattern_b1_i_28_n_0
    );
pattern_b1_i_29: unisim.vcomponents.LUT3
    generic map(
      INIT => X"40"
    )
        port map (
      I0 => timing_sel(1),
      I1 => timing_sel(0),
      I2 => \pattern_b1__0_i_13_n_0\,
      O => pattern_b1_i_29_n_0
    );
pattern_b1_i_30: unisim.vcomponents.LUT3
    generic map(
      INIT => X"9A"
    )
        port map (
      I0 => \pattern_b1__0_i_13_n_0\,
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      O => pattern_b1_i_30_n_0
    );
pattern_b1_i_31: unisim.vcomponents.LUT3
    generic map(
      INIT => X"BA"
    )
        port map (
      I0 => \pattern_b1__0_i_13_n_0\,
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      O => HBACK(3)
    );
pattern_b1_i_32: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => timing_sel(1),
      I1 => timing_sel(0),
      O => pattern_b1_i_32_n_0
    );
pattern_b1_i_33: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => timing_sel(0),
      I1 => timing_sel(1),
      O => pattern_b1_i_33_n_0
    );
pattern_b1_i_34: unisim.vcomponents.LUT3
    generic map(
      INIT => X"BA"
    )
        port map (
      I0 => \pattern_b1__0_i_13_n_0\,
      I1 => timing_sel(1),
      I2 => timing_sel(0),
      O => pattern_b1_i_34_n_0
    );
pattern_b1_i_35: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => timing_sel(0),
      I1 => timing_sel(1),
      O => pattern_b1_i_35_n_0
    );
syncgen_multi: entity work.system_pattern_multi_0_0_syncgen_multi
     port map (
      A(10 downto 6) => A(10 downto 6),
      A(5 downto 0) => disp_y(5 downto 0),
      CLK => CLK,
      CO(0) => pattern_b1_i_23_n_0,
      D(7 downto 0) => pattern_b(7 downto 0),
      DI(0) => disp_enable2(1),
      O(2) => pattern_b1_i_18_n_4,
      O(1) => pattern_b1_i_18_n_5,
      O(0) => pattern_b1_i_18_n_6,
      P(4 downto 0) => data9(7 downto 3),
      PCK => \^pck\,
      RST => RST,
      RST_0 => syncgen_multi_n_23,
      S(2) => \VGA_R[7]_i_419_n_0\,
      S(1) => \VGA_R[7]_i_420_n_0\,
      S(0) => \VGA_R[7]_i_421_n_0\,
      SR(0) => syncgen_multi_n_22,
      SerialClk => SerialClk,
      \VGA_B_reg[0]\ => \VGA_R[0]_i_2_n_0\,
      \VGA_B_reg[1]\ => \VGA_R[1]_i_2_n_0\,
      \VGA_B_reg[2]\ => \VGA_R[2]_i_2_n_0\,
      \VGA_B_reg[7]\ => \VGA_R[7]_i_34_n_0\,
      VGA_HS => VGA_HS,
      \VGA_R[7]_i_330_0\(0) => \VGA_R_reg[7]_i_127_n_0\,
      \VGA_R[7]_i_330_1\(0) => \VGA_R[7]_i_129_n_0\,
      \VGA_R[7]_i_343_0\(0) => \VGA_R[7]_i_319_n_0\,
      \VGA_R_reg[4]_i_5_0\ => \VGA_R[7]_i_286_n_0\,
      \VGA_R_reg[5]\ => \VGA_R[5]_i_5_n_0\,
      \VGA_R_reg[5]_i_11_0\(0) => \VGA_R_reg[5]_i_79_n_0\,
      \VGA_R_reg[5]_i_14_0\(0) => \VGA_R_reg[5]_i_98_n_2\,
      \VGA_R_reg[5]_i_14_1\(0) => \VGA_R_reg[5]_i_99_n_1\,
      \VGA_R_reg[5]_i_14_2\(0) => \VGA_R_reg[5]_i_97_n_6\,
      \VGA_R_reg[5]_i_14_3\(0) => \VGA_R_reg[5]_i_97_n_1\,
      \VGA_R_reg[5]_i_14_4\ => \VGA_R[5]_i_96_n_0\,
      \VGA_R_reg[5]_i_31_0\(0) => \VGA_R_reg[5]_i_78_n_6\,
      \VGA_R_reg[5]_i_31_1\ => \VGA_R[5]_i_102_n_0\,
      \VGA_R_reg[5]_i_31_2\ => \VGA_R[5]_i_101_n_0\,
      \VGA_R_reg[5]_i_31_3\(2) => \VGA_R_reg[5]_i_79_n_5\,
      \VGA_R_reg[5]_i_31_3\(1) => \VGA_R_reg[5]_i_79_n_6\,
      \VGA_R_reg[5]_i_31_3\(0) => \VGA_R_reg[5]_i_79_n_7\,
      \VGA_R_reg[5]_i_35_0\(0) => \VGA_R_reg[5]_i_108_n_1\,
      \VGA_R_reg[5]_i_35_1\(1) => \VGA_R_reg[5]_i_108_n_6\,
      \VGA_R_reg[5]_i_35_1\(0) => \VGA_R_reg[5]_i_108_n_7\,
      \VGA_R_reg[6]\ => \VGA_R[7]_i_29_n_0\,
      \VGA_R_reg[6]_0\ => \VGA_R[7]_i_25_n_0\,
      \VGA_R_reg[7]_i_16_0\ => \VGA_R[7]_i_120_n_0\,
      \VGA_R_reg[7]_i_16_1\ => \VGA_R[7]_i_119_n_0\,
      \VGA_R_reg[7]_i_231_0\ => \VGA_R[7]_i_366_n_0\,
      \VGA_R_reg[7]_i_236_0\(0) => \VGA_R_reg[7]_i_101_n_0\,
      \VGA_R_reg[7]_i_4_0\ => \VGA_R[7]_i_60_n_0\,
      \VGA_R_reg[7]_i_70_0\(2) => \VGA_R_reg[7]_i_127_n_4\,
      \VGA_R_reg[7]_i_70_0\(1) => \VGA_R_reg[7]_i_127_n_5\,
      \VGA_R_reg[7]_i_70_0\(0) => \VGA_R_reg[7]_i_127_n_6\,
      \VGA_R_reg[7]_i_74_0\(0) => \VGA_R[7]_i_131_n_0\,
      \VGA_R_reg[7]_i_99_0\(2) => \VGA_R_reg[7]_i_241_n_4\,
      \VGA_R_reg[7]_i_99_0\(1) => \VGA_R_reg[7]_i_241_n_5\,
      \VGA_R_reg[7]_i_99_0\(0) => \VGA_R_reg[7]_i_241_n_6\,
      \VGA_R_reg[7]_i_99_1\(1) => \VGA_R_reg[7]_i_101_n_6\,
      \VGA_R_reg[7]_i_99_1\(0) => \VGA_R_reg[7]_i_101_n_7\,
      \VGA_R_reg[7]_i_99_2\(3) => \VGA_R[7]_i_242_n_0\,
      \VGA_R_reg[7]_i_99_2\(2) => \VGA_R[7]_i_243_n_0\,
      \VGA_R_reg[7]_i_99_2\(1) => \VGA_R[7]_i_244_n_0\,
      \VGA_R_reg[7]_i_99_2\(0) => \VGA_R[7]_i_245_n_0\,
      VGA_VS => VGA_VS,
      data2(7 downto 0) => data2(7 downto 0),
      data6(7 downto 0) => data6(7 downto 0),
      locked => locked,
      p_1_in(10 downto 0) => p_1_in(10 downto 0),
      pattern_sel(3 downto 0) => pattern_sel(3 downto 0),
      \pattern_sel[3]\(7 downto 0) => pattern_g(7 downto 0),
      \pattern_sel[3]_0\(7 downto 0) => pattern_r(7 downto 0),
      reconfig_done => reconfig_done,
      reconfig_req => reconfig_req,
      timing_sel(1 downto 0) => timing_sel(1 downto 0),
      timing_sel_imm(1 downto 0) => timing_sel_imm(1 downto 0),
      zp_sum => \pattern_b1__0_i_13_n_0\,
      zp_sum0(2) => pattern_b1_i_23_n_5,
      zp_sum0(1) => pattern_b1_i_23_n_6,
      zp_sum0(0) => pattern_b1_i_23_n_7,
      zp_sum0_0(0) => pattern_b1_i_24_n_3
    );
zp_sum: unisim.vcomponents.DSP48E1
    generic map(
      ACASCREG => 0,
      ADREG => 1,
      ALUMODEREG => 0,
      AREG => 0,
      AUTORESET_PATDET => "NO_RESET",
      A_INPUT => "DIRECT",
      BCASCREG => 0,
      BREG => 0,
      B_INPUT => "DIRECT",
      CARRYINREG => 0,
      CARRYINSELREG => 0,
      CREG => 0,
      DREG => 1,
      INMODEREG => 0,
      MASK => X"3FFFFFFFFFFF",
      MREG => 0,
      OPMODEREG => 0,
      PATTERN => X"000000000000",
      PREG => 0,
      SEL_MASK => "MASK",
      SEL_PATTERN => "PATTERN",
      USE_DPORT => false,
      USE_MULT => "MULTIPLY",
      USE_PATTERN_DETECT => "NO_PATDET",
      USE_SIMD => "ONE48"
    )
        port map (
      A(29 downto 11) => B"0000000000000000000",
      A(10 downto 6) => A(10 downto 6),
      A(5 downto 0) => disp_y(5 downto 0),
      ACIN(29 downto 0) => B"000000000000000000000000000000",
      ACOUT(29 downto 0) => NLW_zp_sum_ACOUT_UNCONNECTED(29 downto 0),
      ALUMODE(3 downto 0) => B"0000",
      B(17 downto 11) => B"0000000",
      B(10 downto 6) => A(10 downto 6),
      B(5 downto 0) => disp_y(5 downto 0),
      BCIN(17 downto 0) => B"000000000000000000",
      BCOUT(17 downto 0) => NLW_zp_sum_BCOUT_UNCONNECTED(17 downto 0),
      C(47 downto 13) => B"00000000000000000000000000000000000",
      C(12) => zp_sum0_n_93,
      C(11) => zp_sum0_n_94,
      C(10) => zp_sum0_n_95,
      C(9) => zp_sum0_n_96,
      C(8) => zp_sum0_n_97,
      C(7) => zp_sum0_n_98,
      C(6) => zp_sum0_n_99,
      C(5) => zp_sum0_n_100,
      C(4) => zp_sum0_n_101,
      C(3) => zp_sum0_n_102,
      C(2) => zp_sum0_n_103,
      C(1) => zp_sum0_n_104,
      C(0) => zp_sum0_n_105,
      CARRYCASCIN => '0',
      CARRYCASCOUT => NLW_zp_sum_CARRYCASCOUT_UNCONNECTED,
      CARRYIN => '0',
      CARRYINSEL(2 downto 0) => B"000",
      CARRYOUT(3 downto 0) => NLW_zp_sum_CARRYOUT_UNCONNECTED(3 downto 0),
      CEA1 => '0',
      CEA2 => '0',
      CEAD => '0',
      CEALUMODE => '0',
      CEB1 => '0',
      CEB2 => '0',
      CEC => '0',
      CECARRYIN => '0',
      CECTRL => '0',
      CED => '0',
      CEINMODE => '0',
      CEM => '0',
      CEP => '0',
      CLK => '0',
      D(24 downto 0) => B"0000000000000000000000000",
      INMODE(4 downto 0) => B"00000",
      MULTSIGNIN => '0',
      MULTSIGNOUT => NLW_zp_sum_MULTSIGNOUT_UNCONNECTED,
      OPMODE(6 downto 0) => B"0110101",
      OVERFLOW => NLW_zp_sum_OVERFLOW_UNCONNECTED,
      P(47 downto 13) => NLW_zp_sum_P_UNCONNECTED(47 downto 13),
      P(12 downto 5) => data9(7 downto 0),
      P(4) => zp_sum_n_101,
      P(3) => zp_sum_n_102,
      P(2) => zp_sum_n_103,
      P(1) => zp_sum_n_104,
      P(0) => zp_sum_n_105,
      PATTERNBDETECT => NLW_zp_sum_PATTERNBDETECT_UNCONNECTED,
      PATTERNDETECT => NLW_zp_sum_PATTERNDETECT_UNCONNECTED,
      PCIN(47 downto 0) => B"000000000000000000000000000000000000000000000000",
      PCOUT(47 downto 0) => NLW_zp_sum_PCOUT_UNCONNECTED(47 downto 0),
      RSTA => '0',
      RSTALLCARRYIN => '0',
      RSTALUMODE => '0',
      RSTB => '0',
      RSTC => '0',
      RSTCTRL => '0',
      RSTD => '0',
      RSTINMODE => '0',
      RSTM => '0',
      RSTP => '0',
      UNDERFLOW => NLW_zp_sum_UNDERFLOW_UNCONNECTED
    );
zp_sum0: unisim.vcomponents.DSP48E1
    generic map(
      ACASCREG => 0,
      ADREG => 1,
      ALUMODEREG => 0,
      AREG => 0,
      AUTORESET_PATDET => "NO_RESET",
      A_INPUT => "DIRECT",
      BCASCREG => 0,
      BREG => 0,
      B_INPUT => "DIRECT",
      CARRYINREG => 0,
      CARRYINSELREG => 0,
      CREG => 1,
      DREG => 1,
      INMODEREG => 0,
      MASK => X"3FFFFFFFFFFF",
      MREG => 0,
      OPMODEREG => 0,
      PATTERN => X"000000000000",
      PREG => 0,
      SEL_MASK => "MASK",
      SEL_PATTERN => "PATTERN",
      USE_DPORT => false,
      USE_MULT => "MULTIPLY",
      USE_PATTERN_DETECT => "NO_PATDET",
      USE_SIMD => "ONE48"
    )
        port map (
      A(29 downto 11) => B"0000000000000000000",
      A(10 downto 0) => p_1_in(10 downto 0),
      ACIN(29 downto 0) => B"000000000000000000000000000000",
      ACOUT(29 downto 0) => NLW_zp_sum0_ACOUT_UNCONNECTED(29 downto 0),
      ALUMODE(3 downto 0) => B"0000",
      B(17 downto 11) => B"0000000",
      B(10 downto 0) => p_1_in(10 downto 0),
      BCIN(17 downto 0) => B"000000000000000000",
      BCOUT(17 downto 0) => NLW_zp_sum0_BCOUT_UNCONNECTED(17 downto 0),
      C(47 downto 0) => B"111111111111111111111111111111111111111111111111",
      CARRYCASCIN => '0',
      CARRYCASCOUT => NLW_zp_sum0_CARRYCASCOUT_UNCONNECTED,
      CARRYIN => '0',
      CARRYINSEL(2 downto 0) => B"000",
      CARRYOUT(3 downto 0) => NLW_zp_sum0_CARRYOUT_UNCONNECTED(3 downto 0),
      CEA1 => '0',
      CEA2 => '0',
      CEAD => '0',
      CEALUMODE => '0',
      CEB1 => '0',
      CEB2 => '0',
      CEC => '0',
      CECARRYIN => '0',
      CECTRL => '0',
      CED => '0',
      CEINMODE => '0',
      CEM => '0',
      CEP => '0',
      CLK => '0',
      D(24 downto 0) => B"0000000000000000000000000",
      INMODE(4 downto 0) => B"00000",
      MULTSIGNIN => '0',
      MULTSIGNOUT => NLW_zp_sum0_MULTSIGNOUT_UNCONNECTED,
      OPMODE(6 downto 0) => B"0000101",
      OVERFLOW => NLW_zp_sum0_OVERFLOW_UNCONNECTED,
      P(47 downto 22) => NLW_zp_sum0_P_UNCONNECTED(47 downto 22),
      P(21) => zp_sum0_n_84,
      P(20) => zp_sum0_n_85,
      P(19) => zp_sum0_n_86,
      P(18) => zp_sum0_n_87,
      P(17) => zp_sum0_n_88,
      P(16) => zp_sum0_n_89,
      P(15) => zp_sum0_n_90,
      P(14) => zp_sum0_n_91,
      P(13) => zp_sum0_n_92,
      P(12) => zp_sum0_n_93,
      P(11) => zp_sum0_n_94,
      P(10) => zp_sum0_n_95,
      P(9) => zp_sum0_n_96,
      P(8) => zp_sum0_n_97,
      P(7) => zp_sum0_n_98,
      P(6) => zp_sum0_n_99,
      P(5) => zp_sum0_n_100,
      P(4) => zp_sum0_n_101,
      P(3) => zp_sum0_n_102,
      P(2) => zp_sum0_n_103,
      P(1) => zp_sum0_n_104,
      P(0) => zp_sum0_n_105,
      PATTERNBDETECT => NLW_zp_sum0_PATTERNBDETECT_UNCONNECTED,
      PATTERNDETECT => NLW_zp_sum0_PATTERNDETECT_UNCONNECTED,
      PCIN(47 downto 0) => B"000000000000000000000000000000000000000000000000",
      PCOUT(47 downto 0) => NLW_zp_sum0_PCOUT_UNCONNECTED(47 downto 0),
      RSTA => '0',
      RSTALLCARRYIN => '0',
      RSTALUMODE => '0',
      RSTB => '0',
      RSTC => '0',
      RSTCTRL => '0',
      RSTD => '0',
      RSTINMODE => '0',
      RSTM => '0',
      RSTP => '0',
      UNDERFLOW => NLW_zp_sum0_UNDERFLOW_UNCONNECTED
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity system_pattern_multi_0_0 is
  port (
    CLK : in STD_LOGIC;
    RST : in STD_LOGIC;
    timing_sel : in STD_LOGIC_VECTOR ( 1 downto 0 );
    timing_sel_imm : in STD_LOGIC_VECTOR ( 1 downto 0 );
    pattern_sel : in STD_LOGIC_VECTOR ( 3 downto 0 );
    reconfig_req : in STD_LOGIC;
    VGA_R : out STD_LOGIC_VECTOR ( 7 downto 0 );
    VGA_G : out STD_LOGIC_VECTOR ( 7 downto 0 );
    VGA_B : out STD_LOGIC_VECTOR ( 7 downto 0 );
    VGA_HS : out STD_LOGIC;
    VGA_VS : out STD_LOGIC;
    VGA_DE : out STD_LOGIC;
    PCK : out STD_LOGIC;
    SerialClk : out STD_LOGIC;
    locked : out STD_LOGIC;
    reconfig_done : out STD_LOGIC
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of system_pattern_multi_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of system_pattern_multi_0_0 : entity is "system_pattern_multi_0_0,pattern_multi,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of system_pattern_multi_0_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of system_pattern_multi_0_0 : entity is "module_ref";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of system_pattern_multi_0_0 : entity is "pattern_multi,Vivado 2024.2.2";
end system_pattern_multi_0_0;

architecture STRUCTURE of system_pattern_multi_0_0 is
  attribute X_INTERFACE_INFO : string;
  attribute X_INTERFACE_INFO of CLK : signal is "xilinx.com:signal:clock:1.0 CLK CLK";
  attribute X_INTERFACE_MODE : string;
  attribute X_INTERFACE_MODE of CLK : signal is "slave";
  attribute X_INTERFACE_PARAMETER : string;
  attribute X_INTERFACE_PARAMETER of CLK : signal is "XIL_INTERFACENAME CLK, ASSOCIATED_RESET RST, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN system_processing_system7_0_0_FCLK_CLK0, INSERT_VIP 0";
  attribute X_INTERFACE_INFO of RST : signal is "xilinx.com:signal:reset:1.0 RST RST";
  attribute X_INTERFACE_MODE of RST : signal is "slave";
  attribute X_INTERFACE_PARAMETER of RST : signal is "XIL_INTERFACENAME RST, POLARITY ACTIVE_HIGH, INSERT_VIP 0";
begin
inst: entity work.system_pattern_multi_0_0_pattern_multi
     port map (
      CLK => CLK,
      PCK => PCK,
      RST => RST,
      SerialClk => SerialClk,
      VGA_B(7 downto 0) => VGA_B(7 downto 0),
      VGA_DE => VGA_DE,
      VGA_G(7 downto 0) => VGA_G(7 downto 0),
      VGA_HS => VGA_HS,
      VGA_R(7 downto 0) => VGA_R(7 downto 0),
      VGA_VS => VGA_VS,
      locked => locked,
      pattern_sel(3 downto 0) => pattern_sel(3 downto 0),
      reconfig_done => reconfig_done,
      reconfig_req => reconfig_req,
      timing_sel(1 downto 0) => timing_sel(1 downto 0),
      timing_sel_imm(1 downto 0) => timing_sel_imm(1 downto 0)
    );
end STRUCTURE;
