// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2024.2 (win64) Build 5239630 Fri Nov 08 22:35:27 MST 2024
// Date        : Sat Jun  6 11:20:13 2026
// Host        : MASAO running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub
//               v:/IPI/vivado_hdmi_axi/vivado_hdmi_axi.gen/sources_1/bd/system/ip/system_pattern_multi_0_0/system_pattern_multi_0_0_stub.v
// Design      : system_pattern_multi_0_0
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7z010clg400-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* CHECK_LICENSE_TYPE = "system_pattern_multi_0_0,pattern_multi,{}" *) (* CORE_GENERATION_INFO = "system_pattern_multi_0_0,pattern_multi,{x_ipProduct=Vivado 2024.2.2,x_ipVendor=xilinx.com,x_ipLibrary=module_ref,x_ipName=pattern_multi,x_ipVersion=1.0,x_ipCoreRevision=1,x_ipLanguage=VERILOG,x_ipSimLanguage=MIXED}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) 
(* IP_DEFINITION_SOURCE = "module_ref" *) (* X_CORE_INFO = "pattern_multi,Vivado 2024.2.2" *) 
module system_pattern_multi_0_0(CLK, RST, timing_sel, timing_sel_imm, 
  pattern_sel, reconfig_req, VGA_R, VGA_G, VGA_B, VGA_HS, VGA_VS, VGA_DE, PCK, SerialClk, locked, 
  reconfig_done)
/* synthesis syn_black_box black_box_pad_pin="RST,timing_sel[1:0],timing_sel_imm[1:0],pattern_sel[3:0],reconfig_req,VGA_R[7:0],VGA_G[7:0],VGA_B[7:0],VGA_HS,VGA_VS,VGA_DE,locked,reconfig_done" */
/* synthesis syn_force_seq_prim="CLK" */
/* synthesis syn_force_seq_prim="PCK" */
/* synthesis syn_force_seq_prim="SerialClk" */;
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 CLK CLK" *) (* X_INTERFACE_MODE = "slave" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME CLK, ASSOCIATED_RESET RST, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN system_processing_system7_0_0_FCLK_CLK0, INSERT_VIP 0" *) input CLK /* synthesis syn_isclock = 1 */;
  (* X_INTERFACE_INFO = "xilinx.com:signal:reset:1.0 RST RST" *) (* X_INTERFACE_MODE = "slave" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME RST, POLARITY ACTIVE_HIGH, INSERT_VIP 0" *) input RST;
  input [1:0]timing_sel;
  input [1:0]timing_sel_imm;
  input [3:0]pattern_sel;
  input reconfig_req;
  output [7:0]VGA_R;
  output [7:0]VGA_G;
  output [7:0]VGA_B;
  output VGA_HS;
  output VGA_VS;
  output VGA_DE;
  output PCK /* synthesis syn_isclock = 1 */;
  output SerialClk /* synthesis syn_isclock = 1 */;
  output locked;
  output reconfig_done;
endmodule
