// (c) Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// (c) Copyright 2022-2026 Advanced Micro Devices, Inc. All rights reserved.
// 
// This file contains confidential and proprietary information
// of AMD and is protected under U.S. and international copyright
// and other intellectual property laws.
// 
// DISCLAIMER
// This disclaimer is not a license and does not grant any
// rights to the materials distributed herewith. Except as
// otherwise provided in a valid license issued to you by
// AMD, and to the maximum extent permitted by applicable
// law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
// WITH ALL FAULTS, AND AMD HEREBY DISCLAIMS ALL WARRANTIES
// AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
// BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
// INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
// (2) AMD shall not be liable (whether in contract or tort,
// including negligence, or under any other theory of
// liability) for any loss or damage of any kind or nature
// related to, arising under or in connection with these
// materials, including for any direct, or any indirect,
// special, incidental, or consequential loss or damage
// (including loss of data, profits, goodwill, or any type of
// loss or damage suffered as a result of any action brought
// by a third party) even if such damage or loss was
// reasonably foreseeable or AMD had been advised of the
// possibility of the same.
// 
// CRITICAL APPLICATIONS
// AMD products are not designed or intended to be fail-
// safe, or for use in any application requiring fail-safe
// performance, such as life-support or safety devices or
// systems, Class III medical devices, nuclear facilities,
// applications related to the deployment of airbags, or any
// other applications that could lead to death, personal
// injury, or severe property or environmental damage
// (individually and collectively, "Critical
// Applications"). Customer assumes the sole risk and
// liability of any use of AMD products in Critical
// Applications, subject only to applicable laws and
// regulations governing limitations on product liability.
// 
// THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
// PART OF THIS FILE AT ALL TIMES.
// 
// DO NOT MODIFY THIS FILE.


// IP VLNV: xilinx.com:module_ref:rgb2dvi:1.0
// IP Revision: 1

(* X_CORE_INFO = "rgb2dvi,Vivado 2024.2.2" *)
(* CHECK_LICENSE_TYPE = "system_rgb2dvi_0_0,rgb2dvi,{}" *)
(* CORE_GENERATION_INFO = "system_rgb2dvi_0_0,rgb2dvi,{x_ipProduct=Vivado 2024.2.2,x_ipVendor=xilinx.com,x_ipLibrary=module_ref,x_ipName=rgb2dvi,x_ipVersion=1.0,x_ipCoreRevision=1,x_ipLanguage=VERILOG,x_ipSimLanguage=MIXED,kGenerateSerialClk=false,kClkPrimitive=PLL,kClkRange=1,kRstActiveHigh=true,kD0Swap=false,kD1Swap=false,kD2Swap=false,kClkSwap=false}" *)
(* IP_DEFINITION_SOURCE = "module_ref" *)
(* DowngradeIPIdentifiedWarnings = "yes" *)
module system_rgb2dvi_0_0 (
  TMDS_Clk_p,
  TMDS_Clk_n,
  TMDS_Data_p,
  TMDS_Data_n,
  aRst,
  aRst_n,
  vid_pData,
  vid_pVDE,
  vid_pHSync,
  vid_pVSync,
  PixelClk,
  SerialClk
);

(* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 TMDS_Clk_p CLK" *)
(* X_INTERFACE_MODE = "master" *)
(* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME TMDS_Clk_p, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN system_rgb2dvi_0_0_TMDS_Clk_p, INSERT_VIP 0" *)
output wire TMDS_Clk_p;
(* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 TMDS_Clk_n CLK" *)
(* X_INTERFACE_MODE = "master" *)
(* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME TMDS_Clk_n, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN system_rgb2dvi_0_0_TMDS_Clk_n, INSERT_VIP 0" *)
output wire TMDS_Clk_n;
output wire [2 : 0] TMDS_Data_p;
output wire [2 : 0] TMDS_Data_n;
input wire aRst;
input wire aRst_n;
input wire [23 : 0] vid_pData;
input wire vid_pVDE;
input wire vid_pHSync;
input wire vid_pVSync;
input wire PixelClk;
input wire SerialClk;

  rgb2dvi #(
    .kGenerateSerialClk(1'B0),
    .kClkPrimitive("PLL"),
    .kClkRange(1),
    .kRstActiveHigh(1'B1),
    .kD0Swap(1'B0),
    .kD1Swap(1'B0),
    .kD2Swap(1'B0),
    .kClkSwap(1'B0)
  ) inst (
    .TMDS_Clk_p(TMDS_Clk_p),
    .TMDS_Clk_n(TMDS_Clk_n),
    .TMDS_Data_p(TMDS_Data_p),
    .TMDS_Data_n(TMDS_Data_n),
    .aRst(aRst),
    .aRst_n(aRst_n),
    .vid_pData(vid_pData),
    .vid_pVDE(vid_pVDE),
    .vid_pHSync(vid_pHSync),
    .vid_pVSync(vid_pVSync),
    .PixelClk(PixelClk),
    .SerialClk(SerialClk)
  );
endmodule
