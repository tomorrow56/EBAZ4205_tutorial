# aclk {FREQ_HZ 1e+08 CLK_DOMAIN system_processing_system7_0_0_FCLK_CLK0 PHASE 0.0}
# Clock Domain: system_processing_system7_0_0_FCLK_CLK0
create_clock -name aclk -period 10.000 [get_ports aclk]
# Generated clocks
