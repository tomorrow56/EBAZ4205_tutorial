-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2024.2 (win64) Build 5239630 Fri Nov 08 22:35:27 MST 2024
-- Date        : Sat Jun  6 11:19:28 2026
-- Host        : MASAO running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode synth_stub
--               v:/IPI/vivado_hdmi_axi/vivado_hdmi_axi.gen/sources_1/bd/system/ip/system_rgb2dvi_0_0/system_rgb2dvi_0_0_stub.vhdl
-- Design      : system_rgb2dvi_0_0
-- Purpose     : Stub declaration of top-level module interface
-- Device      : xc7z010clg400-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity system_rgb2dvi_0_0 is
  Port ( 
    TMDS_Clk_p : out STD_LOGIC;
    TMDS_Clk_n : out STD_LOGIC;
    TMDS_Data_p : out STD_LOGIC_VECTOR ( 2 downto 0 );
    TMDS_Data_n : out STD_LOGIC_VECTOR ( 2 downto 0 );
    aRst : in STD_LOGIC;
    aRst_n : in STD_LOGIC;
    vid_pData : in STD_LOGIC_VECTOR ( 23 downto 0 );
    vid_pVDE : in STD_LOGIC;
    vid_pHSync : in STD_LOGIC;
    vid_pVSync : in STD_LOGIC;
    PixelClk : in STD_LOGIC;
    SerialClk : in STD_LOGIC
  );

  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of system_rgb2dvi_0_0 : entity is "system_rgb2dvi_0_0,rgb2dvi,{}";
  attribute CORE_GENERATION_INFO : string;
  attribute CORE_GENERATION_INFO of system_rgb2dvi_0_0 : entity is "system_rgb2dvi_0_0,rgb2dvi,{x_ipProduct=Vivado 2024.2.2,x_ipVendor=xilinx.com,x_ipLibrary=module_ref,x_ipName=rgb2dvi,x_ipVersion=1.0,x_ipCoreRevision=1,x_ipLanguage=VERILOG,x_ipSimLanguage=MIXED,kGenerateSerialClk=false,kClkPrimitive=PLL,kClkRange=1,kRstActiveHigh=true,kD0Swap=false,kD1Swap=false,kD2Swap=false,kClkSwap=false}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of system_rgb2dvi_0_0 : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of system_rgb2dvi_0_0 : entity is "module_ref";
end system_rgb2dvi_0_0;

architecture stub of system_rgb2dvi_0_0 is
  attribute syn_black_box : boolean;
  attribute black_box_pad_pin : string;
  attribute syn_black_box of stub : architecture is true;
  attribute black_box_pad_pin of stub : architecture is "TMDS_Clk_p,TMDS_Clk_n,TMDS_Data_p[2:0],TMDS_Data_n[2:0],aRst,aRst_n,vid_pData[23:0],vid_pVDE,vid_pHSync,vid_pVSync,PixelClk,SerialClk";
  attribute X_INTERFACE_INFO : string;
  attribute X_INTERFACE_INFO of TMDS_Clk_p : signal is "xilinx.com:signal:clock:1.0 TMDS_Clk_p CLK";
  attribute X_INTERFACE_MODE : string;
  attribute X_INTERFACE_MODE of TMDS_Clk_p : signal is "master";
  attribute X_INTERFACE_PARAMETER : string;
  attribute X_INTERFACE_PARAMETER of TMDS_Clk_p : signal is "XIL_INTERFACENAME TMDS_Clk_p, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN system_rgb2dvi_0_0_TMDS_Clk_p, INSERT_VIP 0";
  attribute X_INTERFACE_INFO of TMDS_Clk_n : signal is "xilinx.com:signal:clock:1.0 TMDS_Clk_n CLK";
  attribute X_INTERFACE_MODE of TMDS_Clk_n : signal is "master";
  attribute X_INTERFACE_PARAMETER of TMDS_Clk_n : signal is "XIL_INTERFACENAME TMDS_Clk_n, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN system_rgb2dvi_0_0_TMDS_Clk_n, INSERT_VIP 0";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of stub : architecture is "rgb2dvi,Vivado 2024.2.2";
begin
end;
