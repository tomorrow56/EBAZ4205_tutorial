# Usage with Vitis IDE:
# In Vitis IDE create a Single Application Debug launch configuration,
# change the debug type to 'Attach to running target' and provide this 
# tcl script in 'Execute Script' option.
# Path of this script: V:\IPI\vitis_hdmi_axi\hdmi_axi_system\_ide\scripts\systemdebugger_hdmi_axi_system_standalone.tcl
# 
# 
# Usage with xsct:
# To debug using xsct, launch xsct and run below command
# source V:\IPI\vitis_hdmi_axi\hdmi_axi_system\_ide\scripts\systemdebugger_hdmi_axi_system_standalone.tcl
# 
connect -url tcp:127.0.0.1:3121
targets -set -nocase -filter {name =~"APU*"}
rst -system
after 3000
targets -set -filter {jtag_cable_name =~ "Xilinx Virtual Cable 192.168.1.139:2542" && level==0 && jtag_device_ctx=="jsn-XVC-192.168.1.139:2542-13722093-0"}
fpga -file V:/IPI/vitis_hdmi_axi/hdmi_axi/_ide/bitstream/system_wrapper.bit
targets -set -nocase -filter {name =~"APU*"}
loadhw -hw V:/IPI/vitis_hdmi_axi/ebaz4205_hdmi_axi/export/ebaz4205_hdmi_axi/hw/system_wrapper.xsa -mem-ranges [list {0x40000000 0xbfffffff}] -regs
configparams force-mem-access 1
targets -set -nocase -filter {name =~"APU*"}
source V:/IPI/vitis_hdmi_axi/hdmi_axi/_ide/psinit/ps7_init.tcl
ps7_init
ps7_post_config
targets -set -nocase -filter {name =~ "*A9*#0"}
dow V:/IPI/vitis_hdmi_axi/hdmi_axi/Debug/hdmi_axi.elf
configparams force-mem-access 0
targets -set -nocase -filter {name =~ "*A9*#0"}
con
