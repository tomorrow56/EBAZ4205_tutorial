# 
# Usage: To re-create this platform project launch xsct with below options.
# xsct V:\IPI\vitis_hdmi_axi\ebaz4205_hdmi_axi\platform.tcl
# 
# OR launch xsct and run below command.
# source V:\IPI\vitis_hdmi_axi\ebaz4205_hdmi_axi\platform.tcl
# 
# To create the platform in a different location, modify the -out option of "platform create" command.
# -out option specifies the output directory of the platform project.

platform create -name {ebaz4205_hdmi_axi}\
-hw {V:\IPI\vivado_hdmi_axi\system_wrapper.xsa}\
-proc {ps7_cortexa9_0} -os {standalone} -out {V:/IPI/vitis_hdmi_axi}

platform write
platform generate -domains 
platform active {ebaz4205_hdmi_axi}
bsp reload
bsp config stdin "ps7_uart_0"
bsp reload
platform generate
